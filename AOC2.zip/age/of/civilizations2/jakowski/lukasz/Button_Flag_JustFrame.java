/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Flag_JustFrame
extends Button {
    protected Button_Flag_JustFrame(int n, int n2, boolean bl) {
        super.init("", 0, n, n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight(), bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.0375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.425f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.top_flag_frame).getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5, false, true);
            spriteBatch.setColor(Color.WHITE);
        }
        if (bl) {
            ImageManager.getImage(Images.top_flag_frame_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
        } else {
            ImageManager.getImage(Images.top_flag_frame).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
        }
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

