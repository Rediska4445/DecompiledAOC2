/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_ArmyUpkeep {
    protected float fScore = 0.0f;
    protected int iCost;
    protected int iProvinceID;

    protected AI_ArmyUpkeep(int n, int n2) {
        this.iProvinceID = n2;
        this.iCost = (int)CFG.game_NextTurnUpdate.getMilitaryUpkeep(n2, n);
    }
}

