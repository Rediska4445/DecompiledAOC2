/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Transparent_WithHoverEnabled
extends Button {
    protected Button_Transparent_WithHoverEnabled(int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init("", n, n2, n3, n4, n5, bl, true, false, false, null);
    }

    protected Button_Transparent_WithHoverEnabled(int n, int n2, int n3, int n4, boolean bl) {
        super.init("", 0, n, n2, n3, n4, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }
}

