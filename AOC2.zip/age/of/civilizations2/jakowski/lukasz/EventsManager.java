/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_GameData;
import age.of.civilizations2.jakowski.lukasz.Event_SelectCivAction;
import age.of.civilizations2.jakowski.lukasz.Event_Type;
import age.of.civilizations2.jakowski.lukasz.Events_GameData;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Menu;
import com.badlogic.gdx.Gdx;

class EventsManager {
    protected Event_SelectCivAction eSelectCivAction;
    protected Events_GameData eventsGD = new Events_GameData();
    protected int iCreateEvent_Age = 0;
    protected int iCreateEvent_Day = 1;
    protected int iCreateEvent_EditConditionID = 0;
    protected int iCreateEvent_EditEventID = 0;
    protected int iCreateEvent_EditTriggerID = 0;
    protected int iCreateEvent_Month = 1;
    protected int iCreateEvent_Year = 0;
    protected Event_GameData lCreateScenario_Event = new Event_GameData();
    protected boolean setSinceDate = true;

    EventsManager() {
        this.eSelectCivAction = Event_SelectCivAction.SELECT_RECIPENT;
    }

    protected final void addEvent(Event_GameData event_GameData) {
        this.eventsGD.lEvents.add(event_GameData);
        this.eventsGD.iEventsSize = this.eventsGD.lEvents.size();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void checkCondtsitionsAndTryRun(int n) {
        boolean bl;
        block9: {
            boolean bl2;
            bl = false;
            Gdx.app.log("AoC", "checkCondtsitionsAndTryRun: name: " + this.eventsGD.lEvents.get(n).getEventName() + " 000");
            int n2 = 0;
            while (true) {
                block11: {
                    block10: {
                        bl2 = bl;
                        if (n2 >= this.eventsGD.lEvents.get((int)n).lTriggers.size()) break block10;
                        if (this.eventsGD.lEvents.get((int)n).lTriggers.get((int)n2).triggerType != Event_Type.OR || !this.eventsGD.lEvents.get((int)n).lTriggers.get(n2).getTriggerOut()) break block11;
                        bl2 = true;
                    }
                    Gdx.app.log("AoC", "checkCondtsitionsAndTryRun: name: " + this.eventsGD.lEvents.get(n).getEventName() + " canRunEvent1: " + bl2);
                    bl = bl2;
                    if (!bl2) {
                        break;
                    }
                    break block9;
                }
                ++n2;
            }
            boolean bl3 = true;
            bl2 = false;
            n2 = 0;
            while (true) {
                block13: {
                    block16: {
                        block12: {
                            block14: {
                                block15: {
                                    bl = bl3;
                                    if (n2 >= this.eventsGD.lEvents.get((int)n).lTriggers.size()) break block12;
                                    bl = bl2;
                                    if (this.eventsGD.lEvents.get((int)n).lTriggers.get((int)n2).triggerType == Event_Type.OR) break block13;
                                    if (this.eventsGD.lEvents.get((int)n).lTriggers.get((int)n2).triggerType != Event_Type.AND) break block14;
                                    if (this.eventsGD.lEvents.get((int)n).lTriggers.get(n2).getTriggerOut()) break block15;
                                    bl = false;
                                    break block12;
                                }
                                bl = true;
                                break block13;
                            }
                            bl = bl2;
                            if (this.eventsGD.lEvents.get((int)n).lTriggers.get((int)n2).triggerType != Event_Type.NOT) break block13;
                            if (!this.eventsGD.lEvents.get((int)n).lTriggers.get(n2).getTriggerOut()) break block16;
                            bl = false;
                        }
                        Gdx.app.log("AoC", "checkCondtsitionsAndTryRun: name: " + this.eventsGD.lEvents.get(n).getEventName() + " canRunEvent1.5: " + bl);
                        Gdx.app.log("AoC", "checkCondtsitionsAndTryRun: name: " + this.eventsGD.lEvents.get(n).getEventName() + " checked: " + bl2);
                        if (bl2) break;
                        bl = false;
                        break;
                    }
                    bl = true;
                }
                ++n2;
                bl2 = bl;
            }
        }
        Gdx.app.log("AoC", "checkCondtsitionsAndTryRun: name: " + this.eventsGD.lEvents.get(n).getEventName() + " canRunEvent2: " + bl);
        if (bl) {
            this.tryRunEvent(n);
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void checkEvents() {
        block7: {
            try {
                var1_1 = Gdx.app;
                var2_2 = new StringBuilder();
                var1_1.log("AoC", var2_2.append("checkEvents: ").append(this.eventsGD.iEventsSize).toString());
                var3_4 = 0;
lbl6:
                // 2 sources

                while (var3_4 < this.eventsGD.iEventsSize) {
                    var2_2 = Gdx.app;
                    var1_1 = new StringBuilder();
                    var2_2.log("AoC", var1_1.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(", wasFired:").append(this.eventsGD.lEvents.get(var3_4).getWasFired()).toString());
                    if (this.eventsGD.lEvents.get(var3_4).getWasFired()) break block7;
                    var1_1 = Gdx.app;
                    var2_2 = new StringBuilder();
                    var1_1.log("AoC", var2_2.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" 000").toString());
                    var1_1 = Gdx.app;
                    var2_2 = new StringBuilder();
                    var1_1.log("AoC", var2_2.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" EventcurrYear: ").append(this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventYear).toString());
                    var2_2 = Gdx.app;
                    var1_1 = new StringBuilder();
                    var2_2.log("AoC", var1_1.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" iEventMonth: ").append(this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventMonth).toString());
                    var2_2 = Gdx.app;
                    var1_1 = new StringBuilder();
                    var2_2.log("AoC", var1_1.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" iEventDay: ").append(this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventDay).toString());
                    if (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventYear >= Game_Calendar.currentYear && (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventYear != Game_Calendar.currentYear || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventMonth >= Game_Calendar.currentMonth) && (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventYear != Game_Calendar.currentYear || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventMonth != Game_Calendar.currentMonth || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Since().iEventDay > Game_Calendar.currentDay)) ** GOTO lbl-1000
                    var1_1 = Gdx.app;
                    var2_2 = new StringBuilder();
                    var1_1.log("AoC", var2_2.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" 111").toString());
                    if (!this.eventsGD.lEvents.get(var3_4).getWasTriedToRunOnce()) {
                        var1_1 = Gdx.app;
                        var2_2 = new StringBuilder();
                        var1_1.log("AoC", var2_2.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" 222").toString());
                        this.eventsGD.lEvents.get(var3_4).setWasTriedToRunOnce(true);
                        this.checkCondtsitionsAndTryRun(var3_4);
                        break block7;
                    }
                    ** GOTO lbl-1000
                }
                return;
            }
            catch (NullPointerException var2_3) {
                CFG.exceptionStack(var2_3);
                return;
            }
        }
lbl40:
        // 4 sources

        while (true) {
            ++var3_4;
            ** GOTO lbl6
            break;
        }
lbl-1000:
        // 1 sources

        {
            var2_2 = Gdx.app;
            var1_1 = new StringBuilder();
            var2_2.log("AoC", var1_1.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" 333").toString());
            if (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventYear != 9999999 && this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventYear <= Game_Calendar.currentYear && (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventYear != Game_Calendar.currentYear || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventMonth <= Game_Calendar.currentMonth) && (this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventYear != Game_Calendar.currentYear || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventMonth != Game_Calendar.currentMonth || this.eventsGD.lEvents.get((int)var3_4).getEventDate_Until().iEventDay < Game_Calendar.currentDay)) ** GOTO lbl40
            var2_2 = Gdx.app;
            var1_1 = new StringBuilder();
            var2_2.log("AoC", var1_1.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" 444").toString());
            this.checkCondtsitionsAndTryRun(var3_4);
            ** GOTO lbl40
        }
lbl-1000:
        // 1 sources

        {
            var1_1 = Gdx.app;
            var2_2 = new StringBuilder();
            var1_1.log("AoC", var2_2.append("checkEvents: name: ").append(this.eventsGD.lEvents.get(var3_4).getEventName()).append(" END").toString());
            ** continue;
        }
    }

    protected final void clearEvents() {
        this.eventsGD.lEvents.clear();
        this.eventsGD.iEventsSize = 0;
    }

    protected final Event_GameData getEvent(int n) {
        return this.eventsGD.lEvents.get(n);
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final String getEventTypeText(Event_Type object) {
        void var1_3;
        if (object == Event_Type.AND) {
            String string2 = CFG.langManager.get("AND");
            return var1_3;
        }
        if (object == Event_Type.OR) {
            String string3 = CFG.langManager.get("OR");
            return var1_3;
        }
        String string4 = CFG.langManager.get("NOT");
        return var1_3;
    }

    protected final int getEventsSize() {
        return this.eventsGD.iEventsSize;
    }

    protected final void removeEvent(int n) {
        this.eventsGD.lEvents.remove(n);
        this.eventsGD.iEventsSize = this.eventsGD.lEvents.size();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void runEvent_Tag(String object) {
        int n = -1;
        int n2 = 0;
        while (true) {
            block6: {
                int n3;
                block5: {
                    n3 = n;
                    if (n2 >= this.getEventsSize()) break block5;
                    if (!this.getEvent(n2).getEventTag().equals(object)) break block6;
                    n3 = n2;
                }
                if (n3 >= 0) {
                    CFG.game.getCiv(this.eventsGD.lEvents.get(n3).getCivID()).addEventToRunID(n3);
                    object = this.eventsGD.lEvents.get(n3);
                    boolean bl = !this.eventsGD.lEvents.get(n3).getRepeatable();
                    ((Event_GameData)object).setWasFired(bl);
                }
                return;
            }
            ++n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void selectCivAction(int n) {
        switch (this.eSelectCivAction) {
            case SELECT_RECIPENT: {
                this.lCreateScenario_Event.setCivID(n);
                return;
            }
            case SELECT_COND_CIV_EXIST: 
            case COND_SELECTCIV_DECISIONTAKEN: 
            case SELECT_CIV_CONTROL_PROVINCES: 
            case SELECT_CIV_CONTROL_OCCUPIED: 
            case SELECT_CIV_HAVE_ARMY: 
            case SELECT_CIV_CORE: 
            case SELECT_CIV_ISCAPITAL: 
            case SELECT_CIV_NUMOFPROVINCES: 
            case SELECT_CIV_NUMOFPROVINCES_LOW: 
            case SELECT_CIV_NUMOFUNITS: 
            case SELECT_CIV_NUMOFUNITS_LOW: 
            case SELECT_CIV_NUMOFVASSALS: 
            case SELECT_CIV_NUMOFVASSALS_LOW: 
            case SELECT_CIV_NUMOFWARS: 
            case SELECT_CIV_NUMOFWARS_LOW: 
            case SELECT_CIV_NUMOFALLIES: 
            case SELECT_CIV_NUMOFALLIES_LOW: 
            case SELECT_CIV_NUMOFNEIGHBORS_LOW: 
            case SELECT_CIV_NUMOFNEIGHBORS: 
            case SELECT_CIV_POPULATION: 
            case SELECT_CIV_POPULATION_LOW: 
            case SELECT_CIV_ECONOMY_LOW: 
            case SELECT_CIV_ECONOMY: 
            case SELECT_CIV_RELATION_LOW: 
            case SELECT_CIV_RELATION: 
            case SELECT_CIV_ISATWAR: 
            case SELECT_CIV_ALLIES: 
            case SELECT_CIV_ATWAR: 
            case SELECT_CIV_DEFENSIVE: 
            case SELECT_CIV_INDEPENDENCE: 
            case SELECT_CIV_NONAGGRESSION: 
            case SELECT_CIV_MILITARYACCESS: 
            case SELECT_CIV_ISVASSAL: 
            case SELECT_CIV_ISVASSALOFCIV: 
            case SELECT_CIV_ISPARTOFHRE: 
            case SELECT_CIV_IDEOLOGY: 
            case SELECT_CIV_TECHNOLOGY: 
            case SELECT_CIV_TECHNOLOGY_LOW: 
            case SELECT_CIV_HAPPINESS: 
            case SELECT_CIV_HAPPINESS_LOW: 
            case SELECT_CIV_TREASURY: 
            case SELECT_CIV_TREASURY_LOW: 
            case SELECT_CIV_CONTROLLEDBYPLAYER: {
                this.lCreateScenario_Event.getTrigger((int)this.iCreateEvent_EditTriggerID).lConditions.get(this.iCreateEvent_EditConditionID).setCivID(n);
                return;
            }
            case SELECT_CIV_RELATION2: 
            case SELECT_CIV_RELATION_LOW2: 
            case SELECT_CIV_ALLIES2: 
            case SELECT_CIV_ATWAR2: 
            case SELECT_CIV_DEFENSIVE2: 
            case SELECT_CIV_INDEPENDENCE2: 
            case SELECT_CIV_NONAGGRESSION2: 
            case SELECT_CIV_MILITARYACCESS2: 
            case SELECT_CIV_ISVASSALOFCIV2: {
                this.lCreateScenario_Event.getTrigger((int)this.iCreateEvent_EditTriggerID).lConditions.get(this.iCreateEvent_EditConditionID).setCivID2(n);
                return;
            }
            case SELECT_CONTROLS_PROVINCES: 
            case SELECT_OCCUPIED_PROVINCES: 
            case SELECT_PROVINCES_HAVEARMY: 
            case SELECT_PROVINCES_HAVECORE: 
            case SELECT_PROVINCES_ISCAPITAL: 
            case SELECT_PROVINCES_DEVELOPMENT: 
            case SELECT_PROVINCES_DEVELOPMENT_LOW: 
            case SELECT_PROVINCES_WASTELAND: 
            case SELECT_PROVINCES_NEUTRAL: 
            case SELECT_PROVINCES_WATCHTOWER: 
            case SELECT_PROVINCES_FORT: 
            case SELECT_PROVINCES_FARM: 
            case SELECT_PROVINCES_PORT: {
                this.lCreateScenario_Event.getTrigger((int)this.iCreateEvent_EditTriggerID).lConditions.get(this.iCreateEvent_EditConditionID).setProvinces(CFG.game.getSelectedProvinces().getProvinces());
                return;
            }
            case OUT_SELECTIDEOLOGY_COND_IDEOLOGY: {
                this.lCreateScenario_Event.getTrigger((int)this.iCreateEvent_EditTriggerID).lConditions.get(this.iCreateEvent_EditConditionID).setValue(n);
                return;
            }
            case OUT_SELECTCIV: 
            case OUT_SELECTCIV_ADDCORE: 
            case OUT_SELECTCIV_REMOVECORE: 
            case OUT_SELECTCIV_DECLAREWAR_A: 
            case OUT_SELECTCIV_WHITEPEACE_A: 
            case OUT_SELECTCIV_INCRELATION_A: 
            case OUT_SELECTCIV_DECRELATION_A: 
            case OUT_SELECTCIV_CREATEVASSAL_A: 
            case OUT_SELECTCIV_JOINALLIANCE_A: 
            case OUT_SELECTCIV_LEAVEALLIANCE: 
            case OUT_SELECTCIV_JOINUNION_A: 
            case OUT_SELECTCIV_NONAGGRESSION_A: 
            case OUT_SELECTCIV_MILITARY_A: 
            case OUT_SELECTCIV_DEFENSIVE_A: 
            case OUT_SELECTCIV_INDEPENDENCE_A: 
            case OUT_SELECTCIV_MOVECAPITAL: 
            case OUT_SELECTCIV_LIBERATEVASSAL: 
            case OUT_SELECTCIV_CHANGEIDEOLOGY: 
            case OUT_SELECTCIV_ADDARMY: 
            case OUT_SELECTCIV_UPDATEPOPULAION: 
            case OUT_SELECTCIV_UPDATEPOPULAION_PERC: 
            case OUT_SELECTCIV_UPDATEECONOMY_PERC: 
            case OUT_SELECTCIV_UPDATEECONOMY: 
            case OUT_SELECTCIV_UPDATEECONOMY_OFCIV: 
            case OUT_SELECTCIV_UPDATEPOPULAION_OFCIV: 
            case OUT_SELECTCIV_TECHLEVEL: 
            case OUT_SELECTCIV_DEVELOPMENT: 
            case OUT_SELECTCIV_HAPPINESS: 
            case OUT_SELECTCIV_HAPPINESS_OF_CIV: 
            case OUT_SELECTCIV_MONEY: 
            case OUT_SELECTCIV_DIPLOMACYPOINTS: 
            case OUT_SELECTCIV_MOVEMENTPOINTS: 
            case OUT_SELECTCIV_FORMCIV: 
            case OUT_SELECTCIV_OCCUPY: {
                CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setCivID(n);
                return;
            }
            case OUT_SELECTCIV2: 
            case OUT_SELECTCIV_DECLAREWAR_B: 
            case OUT_SELECTCIV_WHITEPEACE_B: 
            case OUT_SELECTCIV_INCRELATION_B: 
            case OUT_SELECTCIV_DECRELATION_B: 
            case OUT_SELECTCIV_CREATEVASSAL_B: 
            case OUT_SELECTCIV_JOINALLIANCE_B: 
            case OUT_SELECTCIV_JOINUNION_B: 
            case OUT_SELECTCIV_NONAGGRESSION_B: 
            case OUT_SELECTCIV_MILITARY_B: 
            case OUT_SELECTCIV_DEFENSIVE_B: 
            case OUT_SELECTCIV_INDEPENDENCE_B: 
            case OUT_SELECTCIV2_OCCUPY: {
                CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setCivID2(n);
                return;
            }
            case OUT_SELECTPROVINCES: 
            case OUT_SELECTPROVINCES_ADDCORE: 
            case OUT_SELECTPROVINCES_REMOVECORE: 
            case OUT_SELECTPROVINCES_CREATEVASSAL: 
            case OUT_SELECTPROVICNES_ADDARMY: 
            case OUT_SELECTPROVICNES_UPDATEPOPULAION: 
            case OUT_SELECTPROVICNES_UPDATEPOPULAION_PERC: 
            case OUT_SELECTPROVICNES_UPDATEECONOMY: 
            case OUT_SELECTPROVICNES_UPDATEECONOMY_PERC: 
            case OUT_SELECTPROVICNES_DEVELOPMENT: 
            case OUT_SELECTPROVICNES_HAPPINESS: 
            case OUT_SELECTPROVICNES_WASTELAND: 
            case OUT_SELECTPROVINCES_OCCUPY: {
                CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setProvinces(CFG.game.getSelectedProvinces().getProvinces());
                return;
            }
            case OUT_SELECTPROVICNES_MOVECAPITAL: {
                if (CFG.game.getSelectedProvinces().getProvinces().size() > 0) {
                    CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setValue(CFG.game.getSelectedProvinces().getProvinces().get(0));
                    return;
                }
                CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setValue(-1);
                return;
            }
            case OUT_SELECTIDEOLOGY_CHANGEIDEOLOGY: {
                CFG.eventsManager.lCreateScenario_Event.lDecisions.get((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lOutcomes.get(CFG.eventsManager.iCreateEvent_EditConditionID).setValue(n);
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void selectCivBack() {
        switch (1.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Event_SelectCivAction[this.eSelectCivAction.ordinal()]) {
            case 1: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS);
                CFG.menuManager.setVisibleCreateScenario_Events_Edit(true);
                return;
            }
            case 2: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_CIVEXIST);
                return;
            }
            case 4: 
            case 54: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_CONTROLS_PROVINCES);
                return;
            }
            case 6: 
            case 56: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_HAVEARMY);
                return;
            }
            case 7: 
            case 57: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_HAVECORE);
                return;
            }
            case 8: 
            case 58: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ISCAPITAL);
                return;
            }
            case 9: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFPROVINCES);
                return;
            }
            case 10: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFPROVINCES_LOW);
                return;
            }
            case 11: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFUNITS);
                return;
            }
            case 12: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFUNITS_LOW);
                return;
            }
            case 13: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFVASSALS);
                return;
            }
            case 14: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFVASSALS_LOW);
                return;
            }
            case 15: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFWARS);
                return;
            }
            case 16: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFWARS_LOW);
                return;
            }
            case 17: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFALLIES);
                return;
            }
            case 18: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFALLIES_LOW);
                return;
            }
            case 20: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFNEIGHBORS);
                return;
            }
            case 19: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFNEIGHBORS_LOW);
                return;
            }
            case 23: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ECONOMY_LOW);
                return;
            }
            case 24: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ECONOMY);
                return;
            }
            case 21: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_POPULATION);
                return;
            }
            case 22: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_POPULATION_LOW);
                return;
            }
            case 26: 
            case 45: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_RELATION);
                return;
            }
            case 25: 
            case 46: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_RELATION_LOW);
                return;
            }
            case 27: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ISATWAR);
                return;
            }
            case 28: 
            case 47: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ALLIES);
                return;
            }
            case 34: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ISVASSAL);
                return;
            }
            case 35: 
            case 53: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ISVASSAL_OFCIV);
                return;
            }
            case 36: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ISPARTOFHRE);
                return;
            }
            case 37: 
            case 67: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_IDEOLOGY);
                return;
            }
            case 38: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_TECHNOLOGY);
                return;
            }
            case 39: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_TECHNOLOGY_LOW);
                return;
            }
            case 59: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DEVELOPMENT);
                return;
            }
            case 60: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DEVELOPMENT_LOW);
                return;
            }
            case 40: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_HAPPINESS);
                return;
            }
            case 41: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_HAPPINESS_LOW);
                return;
            }
            case 42: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_TREASURY);
                return;
            }
            case 43: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_TREASURY_LOW);
                return;
            }
            case 44: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_CONTROLLEDBYPLAYER);
                return;
            }
            case 61: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_WASTELAND);
                return;
            }
            case 62: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NEUTRAL);
                return;
            }
            case 65: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_FARM);
                return;
            }
            case 66: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_PORT);
                return;
            }
            case 64: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_FORT);
                return;
            }
            case 63: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_WATCHTOWER);
                return;
            }
            case 32: 
            case 51: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NONAGGRESSION);
                return;
            }
            case 30: 
            case 49: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DEFENSIVE);
                return;
            }
            case 33: 
            case 52: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_MILITARYACCESS);
                return;
            }
            case 31: 
            case 50: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_INDEPENDENCE);
                return;
            }
            case 29: 
            case 48: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_ATWAR);
                return;
            }
            case 5: 
            case 55: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_OCCUPIED_PROVINCES);
                return;
            }
            case 68: 
            case 102: 
            case 115: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CHANGE_OWNER);
                return;
            }
            case 69: 
            case 116: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_ADDCORE);
                return;
            }
            case 70: 
            case 117: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_ADDCORE);
                return;
            }
            case 71: 
            case 103: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DECLAREWAR);
                return;
            }
            case 72: 
            case 104: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_WHITEPEACE);
                return;
            }
            case 73: 
            case 105: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_INCRELATION);
                return;
            }
            case 74: 
            case 106: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DECRELATION);
                return;
            }
            case 75: 
            case 107: 
            case 118: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CREATEVASSAL);
                return;
            }
            case 76: 
            case 108: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_JOINALLIANCE);
                return;
            }
            case 77: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_LEAVEALLIANCE);
                return;
            }
            case 78: 
            case 109: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_JOINUNION);
                return;
            }
            case 79: 
            case 110: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_NONAGGRESSION);
                return;
            }
            case 81: 
            case 112: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DEFENSIVE);
                return;
            }
            case 82: 
            case 113: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_INDEPENENCE);
                return;
            }
            case 80: 
            case 111: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_MILITARY);
                return;
            }
            case 83: 
            case 128: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_MOVECAPITAL);
                return;
            }
            case 84: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_LIBERATEVASSAL);
                return;
            }
            case 85: 
            case 129: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CHANGEIDEOLOGY);
                return;
            }
            case 86: 
            case 119: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_ADDARMY);
                return;
            }
            case 87: 
            case 120: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEPOPULATION);
                return;
            }
            case 88: 
            case 121: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEPOPULATION_PERC);
                return;
            }
            case 90: 
            case 122: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEECONOMY);
                return;
            }
            case 89: 
            case 123: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEECONOMYPERC);
                return;
            }
            case 91: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEECONOMY_OFCIV);
                return;
            }
            case 92: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_UPDATEPOPULATION_OFCIV);
                return;
            }
            case 93: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_TECHLEVEL);
                return;
            }
            case 94: 
            case 124: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DEVELOPEMNT);
                return;
            }
            case 95: 
            case 125: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_HAPPINESS);
                return;
            }
            case 96: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_HAPPINESS_OF_CIV);
                return;
            }
            case 98: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DIPLOMACYPOINTS);
                return;
            }
            case 97: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_MONEY);
                return;
            }
            case 99: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_MOVEMENTPOINTS);
                return;
            }
            case 101: 
            case 114: 
            case 127: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_OCCUPY);
                return;
            }
            case 126: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_WASTELAND);
                return;
            }
            case 130: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_TRIGGERANOTHEREVENT);
                return;
            }
            case 100: 
            case 131: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_FORM_CIV);
                return;
            }
            case 3: 
            case 132: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DECISIONTAKEN);
                return;
            }
            case 133: 
            case 134: {
                CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_PLAYASCIV);
                return;
            }
        }
    }

    protected final void setEvent(int n, Event_GameData event_GameData) {
        this.eventsGD.lEvents.set(n, event_GameData);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void sortEventsByDate() {
        int n = 0;
        while (n < this.getEventsSize() - 1) {
            for (int i = n + 1; i < this.getEventsSize(); ++i) {
                Event_GameData event_GameData;
                if (this.getEvent((int)n).getEventDate_Since().iEventYear > this.getEvent((int)i).getEventDate_Since().iEventYear) {
                    event_GameData = this.getEvent(n);
                    this.setEvent(n, this.getEvent(i));
                    this.setEvent(i, event_GameData);
                    continue;
                }
                if (this.getEvent((int)n).getEventDate_Since().iEventYear != this.getEvent((int)i).getEventDate_Since().iEventYear) continue;
                if (this.getEvent((int)n).getEventDate_Since().iEventMonth > this.getEvent((int)i).getEventDate_Since().iEventMonth) {
                    event_GameData = this.getEvent(n);
                    this.setEvent(n, this.getEvent(i));
                    this.setEvent(i, event_GameData);
                    continue;
                }
                if (this.getEvent((int)n).getEventDate_Since().iEventMonth != this.getEvent((int)i).getEventDate_Since().iEventMonth || this.getEvent((int)n).getEventDate_Since().iEventDay <= this.getEvent((int)i).getEventDate_Since().iEventDay) continue;
                event_GameData = this.getEvent(n);
                this.setEvent(n, this.getEvent(i));
                this.setEvent(i, event_GameData);
            }
            ++n;
        }
        return;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void swapIDsOfCivs(int n, int n2) {
        int n3 = 0;
        block0: while (n3 < this.eventsGD.iEventsSize) {
            int n4;
            if (this.eventsGD.lEvents.get(n3).getCivID() == n) {
                this.eventsGD.lEvents.get(n3).setCivID(n2);
            } else if (this.eventsGD.lEvents.get(n3).getCivID() == n2) {
                this.eventsGD.lEvents.get(n3).setCivID(n);
            }
            int n5 = 0;
            while (true) {
                if (n5 >= this.eventsGD.lEvents.get((int)n3).lTriggers.size()) break;
                for (n4 = 0; n4 < this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.size(); ++n4) {
                    if (this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).getCivID() == n) {
                        this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).setCivID(n2);
                    } else if (this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).getCivID() == n2) {
                        this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).setCivID(n);
                    }
                    if (this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).getCivID2() == n) {
                        this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).setCivID2(n2);
                        continue;
                    }
                    if (this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).getCivID2() != n2) continue;
                    this.eventsGD.lEvents.get((int)n3).lTriggers.get((int)n5).lConditions.get(n4).setCivID2(n);
                }
                ++n5;
            }
            n5 = 0;
            while (true) {
                if (n5 < this.eventsGD.lEvents.get((int)n3).lDecisions.size()) {
                } else {
                    ++n3;
                    continue block0;
                }
                for (n4 = 0; n4 < this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.size(); ++n4) {
                    if (this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).getCivID() == n) {
                        this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).setCivID(n2);
                    } else if (this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).getCivID() == n2) {
                        this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).setCivID(n);
                    }
                    if (this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).getCivID2() == n) {
                        this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).setCivID2(n2);
                        continue;
                    }
                    if (this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).getCivID2() != n2) continue;
                    this.eventsGD.lEvents.get((int)n3).lDecisions.get((int)n5).lOutcomes.get(n4).setCivID2(n);
                }
                ++n5;
            }
            break;
        }
        return;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void tryRunEvent(int var1_1) {
        var2_2 = this.eventsGD.lEvents.get(var1_1).getCivID();
        if (var2_2 > 0) ** GOTO lbl7
        try {
            block2: {
                var2_2 = CFG.game.getPlayer(0).getCivID();
                CFG.game.getCiv(var2_2).addEventToRunID(var1_1);
                break block2;
lbl7:
                // 1 sources

                CFG.game.getCiv(this.eventsGD.lEvents.get(var1_1).getCivID()).addEventToRunID(var1_1);
            }
            var3_3 = this.eventsGD.lEvents.get(var1_1);
            var4_5 = this.eventsGD.lEvents.get(var1_1).getRepeatable() == false;
            var3_3.setWasFired(var4_5);
            return;
        }
        catch (IndexOutOfBoundsException var3_4) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void updateEventsAferRemoveCiv(int var1_1) {
        block8: {
            var2_2 = 0;
            block0: while (var2_2 < this.eventsGD.iEventsSize) {
                if (this.eventsGD.lEvents.get(var2_2).getCivID() != var1_1) {
                    if (this.eventsGD.lEvents.get(var2_2).getCivID() > var1_1) {
                        this.eventsGD.lEvents.get(var2_2).setCivID(this.eventsGD.lEvents.get(var2_2).getCivID() - 1);
                    }
                    break block8;
                }
                this.removeEvent(var2_2);
                var3_3 = var2_2 - 1;
                while (true) {
                    var2_2 = var3_3 + 1;
                    continue block0;
                    break;
                }
            }
            return;
        }
        for (var4_4 = 0; var4_4 < this.eventsGD.lEvents.get((int)var2_2).lTriggers.size(); ++var4_4) {
            for (var3_3 = 0; var3_3 < this.eventsGD.lEvents.get((int)var2_2).lTriggers.get((int)var4_4).lConditions.size(); ++var3_3) {
                this.eventsGD.lEvents.get((int)var2_2).lTriggers.get((int)var4_4).lConditions.get(var3_3).updateCivIDAfterRemove(var1_1);
            }
        }
        var4_4 = 0;
        while (true) {
            var3_3 = var2_2;
            if (var4_4 >= this.eventsGD.lEvents.get((int)var2_2).lDecisions.size()) ** continue;
            for (var3_3 = 0; var3_3 < this.eventsGD.lEvents.get((int)var2_2).lDecisions.get((int)var4_4).lOutcomes.size(); ++var3_3) {
                this.eventsGD.lEvents.get((int)var2_2).lDecisions.get((int)var4_4).lOutcomes.get(var3_3).updateCivIDAfterRemove(var1_1);
            }
            ++var4_4;
        }
    }
}

