/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_PlayAsVassal
extends Button {
    protected Button_PlayAsVassal(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, true, bl2, null);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_PlayAsVassal.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.4f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.4f));
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_PlayAsVassal.this.getPosX() + Button_PlayAsVassal.this.getWidth() - Button_PlayAsVassal.this.getWidth() / 2 + n, Button_PlayAsVassal.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_PlayAsVassal.this.getWidth() / 2, Button_PlayAsVassal.this.getHeight() - 2, true, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_PlayAsVassal.this.getPosX() + n, Button_PlayAsVassal.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_PlayAsVassal.this.getWidth(), Button_PlayAsVassal.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_PlayAsVassal.this.getPosX() + n, Button_PlayAsVassal.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_PlayAsVassal.this.getHeight() - 1 + n2 - Button_PlayAsVassal.this.getHeight() / 4, Button_PlayAsVassal.this.getWidth(), Button_PlayAsVassal.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                    CFG.drawRect_InfoBox_Left(spriteBatch, Button_PlayAsVassal.this.getPosX() + n, Button_PlayAsVassal.this.getPosY() + n2, Button_PlayAsVassal.this.getWidth(), Button_PlayAsVassal.this.getHeight());
                    if (Button_PlayAsVassal.this.getCheckboxState()) {
                        ImageManager.getImage(Images.icon_check_true).draw(spriteBatch, Button_PlayAsVassal.this.getPosX() + Button_PlayAsVassal.this.getWidth() - CFG.PADDING - ImageManager.getImage(Images.icon_check_true).getWidth() + n, Button_PlayAsVassal.this.getPosY() + Button_PlayAsVassal.this.getHeight() / 2 - ImageManager.getImage(Images.icon_check_true).getHeight() / 2 + n2);
                    } else {
                        ImageManager.getImage(Images.icon_check_false).draw(spriteBatch, Button_PlayAsVassal.this.getPosX() + Button_PlayAsVassal.this.getWidth() - CFG.PADDING - ImageManager.getImage(Images.icon_check_true).getWidth() + n, Button_PlayAsVassal.this.getPosY() + Button_PlayAsVassal.this.getHeight() / 2 - ImageManager.getImage(Images.icon_check_false).getHeight() / 2 + n2);
                    }
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.textPosition.getTextPosition() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }
}

