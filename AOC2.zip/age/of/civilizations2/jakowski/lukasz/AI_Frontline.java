/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import java.util.ArrayList;
import java.util.List;

class AI_Frontline {
    protected boolean bordersWithEnemy = false;
    protected int iRegionID = -1;
    protected int iWithCivID = 0;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    protected AI_Frontline(int n, int n2, int n3, boolean bl) {
        this.lProvinces.add(n);
        this.iRegionID = n2;
        this.iWithCivID = n3;
        this.bordersWithEnemy = bl;
    }

    protected boolean containsProvince(int n) {
        for (int i = 0; i < this.lProvinces.size(); ++i) {
            if (this.lProvinces.get(i) != n) continue;
            return true;
        }
        return false;
    }

    protected int getFrontLineArmy(int n) {
        int n2 = 0;
        for (int i = this.lProvinces.size() - 1; i >= 0; --i) {
            n2 += CFG.game.getProvince(this.lProvinces.get(i)).getArmyCivID(n);
        }
        return n2;
    }
}

