/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Port;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option_Port
extends AI_Build_Option {
    AI_Build_Option_Port() {
    }

    @Override
    protected AI_Build getData(int n) {
        return new AI_Build_Port(n, this.getMoney(n));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected float getScore(int n) {
        block6: {
            int n2;
            try {
                if (CFG.game.getCiv(n).getCivRegionsSize() <= CFG.game.getCiv((int)n).iNumOf_Ports) break block6;
                n2 = 0;
            }
            catch (NullPointerException nullPointerException) {
                return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_PORT * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Ports / Math.max(CFG.game.getCiv(n).getSeaAccess_Provinces_Size(), 1)));
            }
            while (true) {
                boolean bl;
                if (n2 >= CFG.game.getCiv(n).getCivRegionsSize()) break;
                if (CFG.game.getCiv(n).getCivRegion(n2).getSeaAccess() && CFG.game.getCiv(n).getCivRegion(n2).getProvincesSize() > 0 && !(bl = CFG.game.getCiv(n).getCivRegion(n2).getSeaAccess_HavePort())) {
                    return 40.0f;
                }
                ++n2;
                continue;
                break;
            }
        }
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_PORT * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Ports / Math.max(CFG.game.getCiv(n).getSeaAccess_Provinces_Size(), 1)));
    }
}

