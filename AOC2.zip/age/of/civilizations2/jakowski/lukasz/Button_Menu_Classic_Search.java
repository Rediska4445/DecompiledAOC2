/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Menu_Classic_Search
extends Button_Menu {
    protected Button_Menu_Classic_Search(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_Classic_Search(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() * 2 / 3, 1);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - 1 + this.getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() * 2 / 3, 1);
        spriteBatch.setColor(Color.WHITE);
    }
}

