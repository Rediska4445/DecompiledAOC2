/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class AI_WarPreparations
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected boolean declareWar = true;
    protected int iLeaderCivID = 0;
    protected int iNumOfTurnsLeft = 0;
    protected int onCivID;

    protected AI_WarPreparations(int n, int n2, boolean bl, int n3) {
        this.onCivID = n2;
        this.declareWar = bl;
        this.iLeaderCivID = n;
        this.iNumOfTurnsLeft = n3;
    }
}

