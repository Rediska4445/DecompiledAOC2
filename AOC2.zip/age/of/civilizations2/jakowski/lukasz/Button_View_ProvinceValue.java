/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_View_ProvinceValue
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.6f;
    protected int iLevelWidth;
    private int iPopulationWidth;
    private int iProvinceID;
    protected boolean isFestivalOrganized;
    private boolean row;
    protected String sLevel;
    private String sPopulation;

    protected Button_View_ProvinceValue(int n, String object, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        boolean bl2 = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        this.isFestivalOrganized = false;
        this.sLevel = "";
        this.iLevelWidth = 0;
        super.init((String)object, 0, n4, n5, n6, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        if (n % 2 == 0) {
            bl2 = true;
        }
        this.row = bl2;
        this.iProvinceID = n2;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(CFG.game.getProvinceValue(this.iProvinceID));
        this.sPopulation = ((StringBuilder)object).toString();
        GlyphLayout glyphLayout = CFG.glyphLayout;
        object = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        glyphLayout.setText((BitmapFont)object, stringBuilder.toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        this.isFestivalOrganized = bl;
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            if (this.iProvinceID < 0) {
                this.menuElementHover = null;
                return;
            }
            Object object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("ProvinceValue"));
            ((StringBuilder)object2).append(": ");
            Object object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            object.add(object3);
            object3 = new StringBuilder();
            ((StringBuilder)object3).append("");
            ((StringBuilder)object3).append(CFG.game.getProvinceValue(this.iProvinceID));
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_PROVINCE_VALUE);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.victoryPoints, CFG.PADDING, 0);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            object2 = new MenuElement_Hover_v2_Element_Type_Space();
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            object3 = new StringBuilder();
            ((StringBuilder)object3).append(CFG.langManager.get("BaseProvinceValue"));
            ((StringBuilder)object3).append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString());
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text("+1", CFG.COLOR_TEXT_MODIFIER_POSITIVE);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            int n = CFG.game.getProvinceValue_Capital(this.iProvinceID);
            if (n > 0) {
                object3 = new StringBuilder();
                ((StringBuilder)object3).append(CFG.langManager.get("Capital"));
                ((StringBuilder)object3).append(": ");
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString());
                object.add(object2);
                object3 = new StringBuilder();
                ((StringBuilder)object3).append("+");
                ((StringBuilder)object3).append(CFG.game.getProvinceValue_Capital(this.iProvinceID));
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                object.add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                object.clear();
            }
            if (CFG.game.getProvinceValue_PopulationGrowthRate(this.iProvinceID) > 0) {
                object2 = new StringBuilder();
                ((StringBuilder)object2).append(CFG.langManager.get("GrowthRate"));
                ((StringBuilder)object2).append(": ");
                object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
                object.add(object3);
                object3 = new StringBuilder();
                ((StringBuilder)object3).append("+");
                ((StringBuilder)object3).append(CFG.game.getProvinceValue_PopulationGrowthRate(this.iProvinceID));
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                object.add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                object.clear();
            }
            if (CFG.game.getProvinceValue_DevelopmentLevel(this.iProvinceID) > 0) {
                object3 = new StringBuilder();
                ((StringBuilder)object3).append(CFG.langManager.get("DevelopmentLevel"));
                ((StringBuilder)object3).append(": ");
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString());
                object.add(object2);
                object2 = new StringBuilder();
                ((StringBuilder)object2).append("+");
                ((StringBuilder)object2).append(CFG.game.getProvinceValue_DevelopmentLevel(this.iProvinceID));
                object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                object.add(object3);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                object.clear();
            }
            if (CFG.game.getProvinceValue_Terrain(this.iProvinceID) > 0) {
                object2 = new StringBuilder();
                ((StringBuilder)object2).append(CFG.terrainTypesManager.getName(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()));
                ((StringBuilder)object2).append(": ");
                object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
                object.add(object3);
                object3 = new StringBuilder();
                ((StringBuilder)object3).append("+");
                ((StringBuilder)object3).append(CFG.game.getProvinceValue_Terrain(this.iProvinceID));
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                object.add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                object.clear();
            }
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + (int)((float)this.getTextWidth() * 0.65f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, CFG.COLOR_TEXT_PROVINCE_VALUE);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : (this.isFestivalOrganized ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_OPTIONS_NS)) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

