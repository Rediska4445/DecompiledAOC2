/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Event_Outcome_AddCore
extends Event_Outcome {
    protected int iCivID = -1;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction(int n) {
        try {
            if (CFG.game.getProvince(this.getProvinces().get(n)).getSeaProvince()) return false;
            n = CFG.game.getProvince(this.getProvinces().get(n)).getWasteland();
            if (n >= 0) return false;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return false;
        }
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_ADDCORE);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("AddCore")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("AddCore");
            return var1_3;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList<Object> arrayList = new ArrayList<Object>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            int n = 0;
            while (true) {
                Object object = arrayList;
                if (n >= this.getProvinces().size()) return object;
                object = new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID());
                arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                object = new StringBuilder();
                Object object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("FabricateClaim")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
                object2 = new StringBuilder();
                object = CFG.game.getProvince(this.getProvinces().get(n)).getName().length() == 0 ? (Serializable)this.getProvinces().get(n) : CFG.game.getProvince(this.getProvinces().get(n)).getName();
                MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(object).append(": ").toString());
                arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
                object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.getProvinces().get(n)).getCivID(), CFG.PADDING, 0);
                arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                object = new MenuElement_Hover_v2_Element2(arrayList2);
                arrayList.add(object);
                arrayList2.clear();
                ++n;
            }
        }
        catch (NullPointerException nullPointerException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void outcomeAction() {
        if (this.getCivID() >= 0 && this.getCivID() < CFG.game.getCivsSize()) {
            for (int i = 0; i < this.lProvinces.size(); ++i) {
                try {
                    if (!this.canMakeAction(i)) continue;
                    CFG.game.getProvince(this.lProvinces.get(i)).getCore().addNewCore(this.getCivID(), Game_Calendar.TURN_ID);
                    continue;
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
            }
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

