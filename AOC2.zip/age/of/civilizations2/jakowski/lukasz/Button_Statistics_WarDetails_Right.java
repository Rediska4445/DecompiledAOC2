/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AoCGame;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics_WarDetails;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

class Button_Statistics_WarDetails_Right
extends Button_Statistics_WarDetails {
    protected Button_Statistics_WarDetails_Right(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, boolean bl) {
        super(n, n2, n3, n4, n5, n6, n7, n8, n9, bl);
        Object object = CFG.glyphLayout;
        Object object2 = CFG.fontMain;
        Object object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(this.sProvinces);
        ((GlyphLayout)object).setText((BitmapFont)object2, ((StringBuilder)object3).toString());
        this.iCivilianDeathsWidth = (int)(CFG.glyphLayout.width * 0.6f);
        object3 = CFG.glyphLayout;
        object = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(n4);
        ((StringBuilder)object2).append("%");
        ((GlyphLayout)object3).setText((BitmapFont)object, ((StringBuilder)object2).toString());
        this.iEconomicLossesWidth = (int)(CFG.glyphLayout.width * 0.6f);
    }

    private final void drawFlag(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - (int)((float)this.getHeight() / 44.0f * 68.0f) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), true, false);
        if (this.civFlag != null) {
            try {
                Color color2 = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.slider_gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - (int)((float)this.getHeight() / 44.0f * 68.0f) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), true, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(1.0f, 1.0f, 1.0f, 0.1f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - (int)((float)this.getHeight() / 44.0f * 68.0f) + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), true, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(0.0f, 0.0f, 0.0f, 0.35f);
                spriteBatch.setColor(color2);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - (int)((float)this.getHeight() / 44.0f * 68.0f) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), true, false);
            }
            catch (NullPointerException nullPointerException) {
                spriteBatch.setShader(AoCGame.defaultShader);
            }
        } else {
            spriteBatch.setShader(AoCGame.defaultShader);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.825f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - (int)((float)this.getHeight() / 44.0f * (float)CFG.PADDING) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * (float)CFG.PADDING), this.getHeight(), true, false);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.135f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.525f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
        this.drawFlag(spriteBatch, n, n2, bl);
        spriteBatch.setColor(new Color(0.06f, 0.06f, 0.1f, 0.45f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.r, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.g, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.b, 0.85f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), 1, false, false);
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object;
        try {
            object = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            spriteBatch.setColor((Color)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
        object = ImageManager.getImage(Images.line_32_off1);
        int n3 = this.getPosX();
        int n4 = this.getPosY();
        int n5 = CFG.PADDING;
        int n6 = (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2;
        int n7 = ImageManager.getImage(Images.line_32_off1).getHeight();
        int n8 = CFG.PADDING;
        ((Image)object).draw(spriteBatch, n3 + n, n4 + n5 + n6 - n7 + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n8 * 2, (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        object = ImageManager.getImage(Images.line_32_off1);
        n6 = this.getPosX();
        n5 = this.getPosY();
        int n9 = this.getHeight();
        int n10 = CFG.PADDING;
        n3 = CFG.TEXT_HEIGHT;
        n7 = (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2;
        n8 = ImageManager.getImage(Images.line_32_off1).getHeight();
        n4 = CFG.PADDING;
        ((Image)object).draw(spriteBatch, n6 + n, n5 + n9 - n10 - n3 + n7 - n8 + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n4 * 2, (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.325f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + CFG.PADDING + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2 - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        spriteBatch.setColor(Color.WHITE);
        try {
            if (this.iCivID >= 0) {
                CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            } else {
                ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) / 2 - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)) / 2 + n, this.getPosY() + CFG.PADDING + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        ImageManager.getImage(Images.economy).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2 - ImageManager.getImage(Images.economy).getHeight() + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)), (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        object = new Rectangle(this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - this.getMaxNameWidth() + n, CFG.GAME_HEIGHT - (this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f) + n2), this.getMaxNameWidth(), -CFG.TEXT_HEIGHT);
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        CFG.fontMain.getData().setScale(0.75f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + this.getWidth() - this.ANIMATION_POSX - (int)Math.min((float)this.getMaxNameWidth(), (float)this.getTextWidth() * 0.75f) - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f) + n2, this.getColor(bl));
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.fontMain.getData().setScale(0.65f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iCivilianDeaths);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + CFG.PADDING + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.65f) / 2.0f) + n2, this.oColorCivilianDeaths);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iEconomicLosses);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.65f) / 2.0f) + n2, this.oColorEconomicLosses);
        CFG.fontMain.getData().setScale(0.6f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iParticipation);
        ((StringBuilder)object).append("%");
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING * 3 - (int)Math.min((float)(this.getMaxNameWidth() - CFG.PADDING * 2), (float)this.getTextWidth() * 0.75f) - this.iEconomicLossesWidth - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f + (float)CFG.TEXT_HEIGHT * 0.75f - (float)CFG.TEXT_HEIGHT * 0.6f) + n2, this.oColorParticipation);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.sProvinces);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - this.ANIMATION_POSX - CFG.PADDING - this.iCivilianDeathsWidth + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, new Color(CFG.COLOR_TEXT_MODIFIER_NEUTRAL.r, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.g, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.b, 0.85f));
        CFG.fontMain.getData().setScale(1.0f);
        if (this.canPeaceOut && this.getIsHovered()) {
            if (this.ANIMATION_POSX < this.getTruceIconWidth()) {
                this.ANIMATION_POSX = (int)(Math.min((float)(System.currentTimeMillis() - this.ANIMATION_TIME) / 175.0f, 1.0f) * (float)this.getTruceIconWidth());
                CFG.setRender_3(true);
            }
            object = new Rectangle(this.getPosX() + this.getWidth() - this.ANIMATION_POSX + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.ANIMATION_POSX, -this.getHeight());
            spriteBatch.flush();
            ScissorStack.pushScissors((Rectangle)object);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.325f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getTruceIconWidth() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getTruceIconWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getTruceIconWidth() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getTruceIconWidth(), this.getHeight());
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.675f));
            ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getTruceIconWidth() + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
            ImageManager.getImage(Images.diplo_truce).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getTruceIconWidth() / 2 - ImageManager.getImage(Images.diplo_truce).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.diplo_truce).getHeight() / 2 + n2);
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        this.backAnimation = false;
        this.fAlphaMod = 0.0f;
        this.lTime = System.currentTimeMillis();
        return;
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }
}

