/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Report_Armies;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Report_ProvinceLosses
extends Button {
    private int iEconomyLosses;
    private int iEconomyLossesWidth;
    private int iPopulationLosses;

    protected Button_Report_ProvinceLosses(int n, int n2, int n3, int n4, int n5) {
        this.iPopulationLosses = n4;
        this.iEconomyLosses = n5;
        GlyphLayout glyphLayout = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("-");
        stringBuilder.append(this.iEconomyLosses);
        glyphLayout.setText(bitmapFont, stringBuilder.toString());
        this.iEconomyLossesWidth = (int)CFG.glyphLayout.width;
        super.init("", 0, n, n2, n3, CFG.TEXT_HEIGHT + CFG.PADDING * 2, true, true, false, false, null);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("CivilianDeaths"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iPopulationLosses);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("EconomicLosses"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iEconomyLosses);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.economy, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.475f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, 0.425f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5, false, true);
        float f = this.getIsHovered() ? 0.95f : 0.745f;
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, f));
        CFG.drawRect(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        CFG.drawRect(spriteBatch, this.getPosX() - 1 + n, this.getPosY() - 1 + n2, this.getWidth() + 2, this.getHeight() + 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        CFG.drawRect(spriteBatch, this.getPosX() + 1 + n, this.getPosY() + 1 + n2, this.getWidth() - 2, this.getHeight() - 2);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.population).getHeight() / 2 + n2);
        ImageManager.getImage(Images.economy).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - ImageManager.getImage(Images.economy).getWidth() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.economy).getHeight() / 2 + n2);
        CFG.fontMain.getData().setScale(0.85f);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("-");
        stringBuilder.append(this.iPopulationLosses);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING * 2 + ImageManager.getImage(Images.population).getWidth() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f) + n2, Button_Report_Armies.COLOR_ARMY_LOST);
        stringBuilder = new StringBuilder();
        stringBuilder.append("-");
        stringBuilder.append(this.iEconomyLosses);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 2 - ImageManager.getImage(Images.economy).getWidth() - (int)((float)this.iEconomyLossesWidth * 0.85f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f) + n2, Button_Report_Armies.COLOR_ARMY_LOST);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

