/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.io.Serializable;

class City
implements Serializable {
    private static final long serialVersionUID = 0L;
    private int iCityLevel = 0;
    private int iPosX;
    private int iPosY;
    protected int iWidth = 0;
    private String sCityName = null;

    protected City(String string2, int n, int n2, int n3) {
        this.sCityName = string2;
        this.updateCityNameWidth();
        this.iPosX = n;
        this.iPosY = n2;
        this.iCityLevel = n3;
    }

    protected final void draw(SpriteBatch spriteBatch, int n, float f) {
        this.draw(spriteBatch, n, f, CFG.COLOR_CITY_NAME, this.getCityLevel());
    }

    protected final void draw(SpriteBatch spriteBatch, int n, float f, int n2) {
        this.draw(spriteBatch, n, f, CFG.COLOR_CITY_NAME, n2);
    }

    protected final void draw(SpriteBatch spriteBatch, int n, float f, Color color2) {
        this.draw(spriteBatch, n, f, color2, this.getCityLevel());
    }

    protected final void draw(SpriteBatch spriteBatch, int n, float f, Color color2, int n2) {
        CFG.drawText(spriteBatch, this.getCityName(), (int)((float)(this.getPosX() * CFG.map.getMapBG().getMapScale() + CFG.game.getProvince(n).getTranslateProvincePosX()) * f - (float)this.iWidth / 2.0f), (int)((float)(this.getPosY() * CFG.map.getMapBG().getMapScale() + CFG.map.getMapCoordinates().getPosY()) * f) - ImageManager.getImage(n2).getHeight() / 2 + ImageManager.getImage(n2).getHeight() + 2, color2);
        ImageManager.getImage(n2).draw(spriteBatch, (int)((float)(this.getPosX() * CFG.map.getMapBG().getMapScale() + CFG.game.getProvince(n).getTranslateProvincePosX()) * f - (float)(ImageManager.getImage(n2).getWidth() / 2)), (int)((float)(this.getPosY() * CFG.map.getMapBG().getMapScale() + CFG.map.getMapCoordinates().getPosY()) * f) - ImageManager.getImage(n2).getHeight() / 2);
    }

    protected final void drawCityImage_Level(SpriteBatch spriteBatch, int n, float f) {
        ImageManager.getImage(this.getCityLevel()).draw(spriteBatch, (int)((float)(this.getPosX() * CFG.map.getMapBG().getMapScale() + CFG.game.getProvince(n).getTranslateProvincePosX()) * f - (float)(ImageManager.getImage(this.getCityLevel()).getWidth() / 2)), (int)((float)(this.getPosY() * CFG.map.getMapBG().getMapScale() + CFG.map.getMapCoordinates().getPosY()) * f) - ImageManager.getImage(this.getCityLevel()).getHeight() / 2);
    }

    protected final void drawInLine(SpriteBatch spriteBatch, int n, float f) {
        this.drawInLine(spriteBatch, n, f, CFG.COLOR_CITY_NAME, this.getCityLevel());
    }

    protected final void drawInLine(SpriteBatch spriteBatch, int n, float f, Color color2, int n2) {
        ImageManager.getImage(n2).draw(spriteBatch, (int)((float)(this.getPosX() * CFG.map.getMapBG().getMapScale() + CFG.game.getProvince(n).getTranslateProvincePosX()) * f - (float)(ImageManager.getImage(n2).getWidth() / 2)), (int)((float)(this.getPosY() * CFG.map.getMapBG().getMapScale() + CFG.map.getMapCoordinates().getPosY()) * f) - ImageManager.getImage(n2).getHeight() / 2);
        CFG.drawText(spriteBatch, this.getCityName(), (int)((float)(this.getPosX() * CFG.map.getMapBG().getMapScale() + CFG.game.getProvince(n).getTranslateProvincePosX()) * f + (float)(ImageManager.getImage(n2).getWidth() / 2) + 1.0f), (int)((float)(this.getPosY() * CFG.map.getMapBG().getMapScale() + CFG.map.getMapCoordinates().getPosY()) * f - (float)(ImageManager.getImage(n2).getHeight() / 2) + (float)(ImageManager.getImage(n2).getHeight() / 2) - (float)(CFG.ARMY_HEIGHT / 4) + 1.0f), color2);
    }

    protected final int getCityLevel() {
        return this.iCityLevel;
    }

    protected final String getCityName() {
        return this.sCityName;
    }

    protected final int getPosX() {
        return this.iPosX;
    }

    protected final int getPosY() {
        return this.iPosY;
    }

    protected final void setCityLevel(int n) {
        this.iCityLevel = n;
    }

    protected final void setCityName(String string2) {
        this.sCityName = string2;
    }

    protected final void setPosX(int n) {
        this.iPosX = n;
    }

    protected final void setPosY(int n) {
        this.iPosY = n;
    }

    protected final void updateCityNameWidth() {
        CFG.glyphLayout.setText(CFG.fontMain, this.sCityName);
        this.iWidth = (int)(CFG.glyphLayout.width * CFG.settingsManager.CITIES_FONT_SCALE);
    }
}

