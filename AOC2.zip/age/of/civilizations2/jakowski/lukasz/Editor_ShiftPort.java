/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Province_GameData2;
import com.badlogic.gdx.Files;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.io.IOException;
import java.io.Serializable;

public class Editor_ShiftPort
extends Editor {
    private int iDiff = 1;

    protected static final void savePortPosition(int n, int n2) {
        CFG.game.getProvince(CFG.game.getActiveProvinceID()).updateProvincePort(n, n2);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void keyDown(int n) {
        int n2;
        int n3;
        if (CFG.game.getActiveProvinceID() < 0) return;
        Object object = Gdx.files;
        Serializable serializable = new StringBuilder();
        serializable.append("map/");
        serializable.append(CFG.map.getFile_ActiveMap_Path());
        serializable.append("data/");
        serializable.append("provinces/");
        serializable.append(CFG.game.getActiveProvinceID());
        object = object.internal(serializable.toString());
        try {
            serializable = (Province_GameData2)CFG.deserialize(((FileHandle)object).readBytes());
            n3 = ((Province_GameData2)serializable).iPort_ShiftX;
            n2 = ((Province_GameData2)serializable).iPort_ShiftY;
            if (Gdx.input.isKeyPressed(51)) {
                ++this.iDiff;
            }
            if (Gdx.input.isKeyPressed(45)) {
                --this.iDiff;
                if (this.iDiff < 1) {
                    this.iDiff = 1;
                }
            }
            n = n3;
            if (Gdx.input.isKeyPressed(21)) {
                n = n3 - this.iDiff;
            }
            n3 = n;
            if (Gdx.input.isKeyPressed(22)) {
                n3 = n + this.iDiff;
            }
            n = n2;
            if (Gdx.input.isKeyPressed(19)) {
                n = n2 - this.iDiff;
            }
            n2 = n;
            if (Gdx.input.isKeyPressed(20)) {
                n2 = n + this.iDiff;
            }
            ((Province_GameData2)serializable).iPort_ShiftX = n3;
            ((Province_GameData2)serializable).iPort_ShiftY = n2;
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(gdxRuntimeException);
            return;
        }
        catch (IOException iOException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
        catch (ClassNotFoundException classNotFoundException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(classNotFoundException);
            return;
        }
        try {
            Files files = Gdx.files;
            object = new StringBuilder();
            ((StringBuilder)object).append("map/");
            ((StringBuilder)object).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object).append("data/");
            ((StringBuilder)object).append("provinces/");
            ((StringBuilder)object).append(CFG.game.getActiveProvinceID());
            files.local(((StringBuilder)object).toString()).writeBytes(CFG.serialize(serializable), false);
        }
        catch (IOException iOException) {
            if (CFG.LOGS) {
                CFG.exceptionStack(iOException);
            }
        }
        {
            Editor_ShiftPort.savePortPosition(n3, n2);
            return;
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SHIFT PORT: ");
        stringBuilder.append(CFG.game.getActiveProvinceID());
        stringBuilder.append("\nSHIFT: ");
        stringBuilder.append(this.iDiff);
        stringBuilder.append(" Q--, W++");
        return stringBuilder.toString();
    }
}

