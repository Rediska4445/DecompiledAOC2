/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Flag
extends MenuElement {
    private DrawButton drawButton;
    private int iCivID;

    protected Button_Flag(int n, int n2, int n3, int n4, int n5, ButtonFlagType buttonFlagType) {
        this.typeOfElement = MenuElement.TypeOfElement.BUTTON_FLAG;
        this.iCivID = n;
        this.setPosX(n2);
        this.setPosY(n3);
        this.setWidth(n4);
        this.setHeight(n5);
        n = 5.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Button_Flag$ButtonFlagType[buttonFlagType.ordinal()];
        if (n != 1) {
            if (n == 2) {
                this.drawButton = this.iCivID > 0 ? new DrawButton(){

                    @Override
                    public void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
                        CFG.game.getCiv(Button_Flag.this.iCivID).getFlag().draw(spriteBatch, Button_Flag.this.getPosX() + Button_Flag.this.getWidth() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, Button_Flag.this.getPosY() - CFG.game.getCiv(Button_Flag.this.iCivID).getFlag().getHeight() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, Button_Flag.this.getPosX() + Button_Flag.this.getWidth() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, Button_Flag.this.getPosY() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2);
                    }
                } : new DrawButton(){

                    @Override
                    public void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
                        ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, Button_Flag.this.getPosX() + Button_Flag.this.getWidth() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, Button_Flag.this.getPosY() - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, Button_Flag.this.getPosX() + Button_Flag.this.getWidth() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, Button_Flag.this.getPosY() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2);
                    }
                };
            }
        } else {
            this.drawButton = this.iCivID >= 0 ? new DrawButton(){

                @Override
                public void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
                    spriteBatch.setColor(new Color((float)CFG.game.getCiv(Button_Flag.this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(Button_Flag.this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(Button_Flag.this.iCivID).getB() / 255.0f, 1.0f));
                    ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, Button_Flag.this.getPosX() + n, Button_Flag.this.getPosY() + n2 - 1, (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE), Button_Flag.this.getHeight());
                    spriteBatch.setColor(Color.WHITE);
                    CFG.game.getCiv(Button_Flag.this.iCivID).getFlag().draw(spriteBatch, Button_Flag.this.getPosX() + (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE) + CFG.PADDING * 2 + n, Button_Flag.this.getPosY() - CFG.game.getCiv(Button_Flag.this.iCivID).getFlag().getHeight() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                    ImageManager.getImage(Images.flag_rect).draw(spriteBatch, Button_Flag.this.getPosX() + (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE) + CFG.PADDING * 2 + n, Button_Flag.this.getPosY() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2);
                }
            } : new DrawButton(){

                @Override
                public void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
                    spriteBatch.setColor(CFG.RANDOM_CIVILIZATION_COLOR);
                    ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, Button_Flag.this.getPosX() + n, Button_Flag.this.getPosY() + n2 - 1, (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE), Button_Flag.this.getHeight());
                    spriteBatch.setColor(Color.WHITE);
                    ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, Button_Flag.this.getPosX() + (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE) + CFG.PADDING * 2 + n, Button_Flag.this.getPosY() - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                    ImageManager.getImage(Images.flag_rect).draw(spriteBatch, Button_Flag.this.getPosX() + (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE) + CFG.PADDING * 2 + n, Button_Flag.this.getPosY() + n2 + Button_Flag.this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2);
                }
            };
        }
    }

    @Override
    protected final void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else {
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
        this.drawButton.draw(spriteBatch, n, n2, bl, bl2);
    }

    public static enum ButtonFlagType {
        FLAG_COLOR,
        FLAG;

    }

    static interface DrawButton {
        public void draw(SpriteBatch var1, int var2, int var3, boolean var4, boolean var5);
    }
}

