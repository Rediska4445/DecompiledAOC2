/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_WarPreparations;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class CivPlans
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iWarPreparationsSize = 0;
    protected List<CivArmyMission> lArmiesMissions;
    protected List<AI_WarPreparations> warPreparations = new ArrayList<AI_WarPreparations>();

    CivPlans() {
        this.lArmiesMissions = new ArrayList<CivArmyMission>();
    }

    protected final boolean addNewArmyMission(int n, CivArmyMission civArmyMission) {
        for (int i = this.lArmiesMissions.size() - 1; i >= 0; --i) {
            if (this.lArmiesMissions.get((int)i).iProvinceID != n) continue;
            return false;
        }
        this.lArmiesMissions.add(civArmyMission);
        return true;
    }

    protected final void addNewWarPreparations(int n, int n2, int n3, int n4) {
        if (!CFG.game.getCivsAtWar(n2, n3)) {
            if (this.isPreparingForTheWar(n3)) {
                this.updatePreparationsTime(n3, n4);
                return;
            }
            Application application = Gdx.app;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Plans: addNewWarPreparations: ");
            stringBuilder.append(CFG.game.getCiv(n2).getCivName());
            stringBuilder.append(" -> ");
            stringBuilder.append(CFG.game.getCiv(n3).getCivName());
            application.log("AoC", stringBuilder.toString());
            this.warPreparations.add(new AI_WarPreparations(n, n3, true, n4));
            this.iWarPreparationsSize = this.warPreparations.size();
        }
    }

    protected final void checkArmyMissions(int n) {
        int n2 = 0;
        while (n2 < this.lArmiesMissions.size()) {
            int n3 = n2;
            if (CFG.game.getProvince(this.lArmiesMissions.get((int)n2).iProvinceID).getArmyCivID(n) <= 0) {
                this.lArmiesMissions.remove(n2);
                n3 = n2 - 1;
            }
            n2 = n3 + 1;
        }
    }

    protected final boolean checkWarPreparations(int n) {
        boolean bl = false;
        int n2 = 0;
        while (n2 < CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.size()) {
            int n3 = n2;
            if (CFG.game.getCivsAtWar(n, CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)n2).onCivID)) {
                CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.remove(n2);
                this.iWarPreparationsSize = this.warPreparations.size();
                n3 = n2 - 1;
            }
            n2 = n3 + 1;
        }
        if (this.warPreparations.size() > 0) {
            bl = true;
        }
        return bl;
    }

    protected final int getPreparationsTime(int n) {
        for (int i = 0; i < this.warPreparations.size(); ++i) {
            if (this.warPreparations.get((int)i).onCivID != n) continue;
            return this.warPreparations.get((int)i).iNumOfTurnsLeft;
        }
        return 0;
    }

    protected final int getPreparations_LeaderCivID(int n) {
        for (int i = 0; i < this.warPreparations.size(); ++i) {
            if (this.warPreparations.get((int)i).onCivID != n) continue;
            return this.warPreparations.get((int)i).iLeaderCivID;
        }
        return 0;
    }

    protected final boolean haveMission(int n) {
        for (int i = 0; i < this.lArmiesMissions.size(); ++i) {
            if (this.lArmiesMissions.get((int)i).iProvinceID != n) continue;
            return true;
        }
        return false;
    }

    protected final int haveMission_Army(int n) {
        int n2 = 0;
        for (int i = 0; i < this.lArmiesMissions.size(); ++i) {
            int n3 = n2;
            if (this.lArmiesMissions.get((int)i).iProvinceID == n) {
                n3 = n2 + this.lArmiesMissions.get((int)i).iArmy;
            }
            n2 = n3;
        }
        return n2;
    }

    protected final int haveMission_Army_ToProvinceID(int n) {
        for (int i = 0; i < this.lArmiesMissions.size(); ++i) {
            if (this.lArmiesMissions.get((int)i).toProvinceID != n) continue;
            return this.lArmiesMissions.get((int)i).iArmy;
        }
        return 0;
    }

    protected final boolean isPreparingForTheWar() {
        boolean bl = this.warPreparations.size() > 0;
        return bl;
    }

    protected final boolean isPreparingForTheWar(int n) {
        for (int i = 0; i < this.warPreparations.size(); ++i) {
            if (this.warPreparations.get((int)i).onCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final boolean isPreparingForTheWar(int n, int n2) {
        for (int i = 0; i < this.warPreparations.size(); ++i) {
            if (this.warPreparations.get((int)i).onCivID != n2 || this.warPreparations.get((int)i).iLeaderCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final void removeMission(int n) {
        for (int i = 0; i < this.lArmiesMissions.size(); ++i) {
            if (this.lArmiesMissions.get((int)n).iProvinceID != n) continue;
            this.lArmiesMissions.remove(i);
            return;
        }
    }

    protected final void updateObsolateMissions() {
        int n = 0;
        while (n < this.lArmiesMissions.size()) {
            CivArmyMission civArmyMission = this.lArmiesMissions.get(n);
            int n2 = civArmyMission.iObsolate;
            civArmyMission.iObsolate = n2 - 1;
            int n3 = n;
            if (n2 <= 0) {
                this.lArmiesMissions.remove(n);
                n3 = n - 1;
            }
            n = n3 + 1;
        }
    }

    protected final void updatePreparationsTime(int n, int n2) {
        for (int i = 0; i < this.warPreparations.size(); ++i) {
            if (this.warPreparations.get((int)i).onCivID != n) continue;
            this.warPreparations.get((int)i).iNumOfTurnsLeft = n2;
            return;
        }
    }
}

