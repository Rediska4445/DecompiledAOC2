/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_RandomGame_Players_Elector
extends Button_New_Game_Players {
    private int iCivID;

    protected Button_RandomGame_Players_Elector(int n, String string2, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n2, n3, n4, n5, bl);
        this.iCivID = n;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.new_game_box_line_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_line_hover).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_line_hover).getHeight(), true, false);
        ImageManager.getImage(Images.new_game_box_line_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_line_hover).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box_line_hover).getHeight(), true, true);
        if (!CFG.holyRomanEmpire_Manager.getHRE().getIsElector(this.iCivID) && !CFG.holyRomanEmpire_Manager.getHRE().getIsEmperor(this.iCivID)) {
            if (bl) {
                spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.275f);
            } else if (this.getIsHovered()) {
                spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.35f);
            } else {
                spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.45f);
            }
        } else if (bl) {
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.75f);
        } else if (this.getIsHovered()) {
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.85f);
        } else {
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 1.0f);
        }
        ImageManager.getImage(Images.hre_icon).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.hre_icon).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.hre_icon).getHeight() / 2 + n2, true);
        spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + 1 + n, this.getPosY() + 2 + n2, 1, this.getHeight() - 6);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }
}

