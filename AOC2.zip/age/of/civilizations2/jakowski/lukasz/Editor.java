/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Editor {
    private boolean inUse = false;

    Editor() {
    }

    protected void draw(SpriteBatch spriteBatch) {
        CFG.fontMain.getData().setScale(0.9f);
        CFG.glyphLayout.setText(CFG.fontMain, this.toString());
        spriteBatch.setColor(0.08f, 0.012f, 0.038f, 0.95f);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, 0, -ImageManager.getImage(Images.slider_gradient).getHeight(), (int)CFG.glyphLayout.width + CFG.PADDING * 6, (int)CFG.glyphLayout.height + CFG.PADDING * 4);
        spriteBatch.setColor(CFG.COLOR_FLAG_FRAME);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, 0, -ImageManager.getImage(Images.slider_gradient).getHeight() + 1, (int)CFG.glyphLayout.width + CFG.PADDING * 6, 1);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, 0, -ImageManager.getImage(Images.slider_gradient).getHeight() + (int)CFG.glyphLayout.height + CFG.PADDING * 4 - 2, (int)CFG.glyphLayout.width + CFG.PADDING * 6, 1);
        spriteBatch.setColor(Color.WHITE);
        CFG.drawTextWithShadow(spriteBatch, this.toString(), CFG.PADDING, CFG.PADDING * 2, Color.WHITE);
        CFG.fontMain.getData().setScale(1.0f);
    }

    protected final boolean getInUse() {
        return this.inUse;
    }

    protected void keyDown(int n) {
    }

    protected void keyUp(int n) {
    }

    protected void setInUse(boolean bl) {
        this.inUse = bl;
    }

    public String toString() {
        return "EDITOR";
    }

    protected void touchDown(int n, int n2, int n3, int n4) {
    }

    protected void touchDragged(int n, int n2, int n3) {
    }

    protected void touchUp(int n, int n2, int n3, int n4) {
    }
}

