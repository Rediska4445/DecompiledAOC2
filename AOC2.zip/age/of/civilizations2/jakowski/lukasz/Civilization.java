/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_BordersWith;
import age.of.civilizations2.jakowski.lukasz.AI_CivsInRange;
import age.of.civilizations2.jakowski.lukasz.AI_Influence;
import age.of.civilizations2.jakowski.lukasz.Alliance;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivBonus_GameData;
import age.of.civilizations2.jakowski.lukasz.CivBonus_Type;
import age.of.civilizations2.jakowski.lukasz.CivFestival;
import age.of.civilizations2.jakowski.lukasz.CivInvest;
import age.of.civilizations2.jakowski.lukasz.CivInvest_Development;
import age.of.civilizations2.jakowski.lukasz.CivPersonality;
import age.of.civilizations2.jakowski.lukasz.CivPlans;
import age.of.civilizations2.jakowski.lukasz.Civ_Mission_ChangeTypeOfGoverment;
import age.of.civilizations2.jakowski.lukasz.Civilization_Diplomacy_GameData;
import age.of.civilizations2.jakowski.lukasz.Civilization_Friends_GameData;
import age.of.civilizations2.jakowski.lukasz.Civilization_Hated_GameData;
import age.of.civilizations2.jakowski.lukasz.Civilization_Region;
import age.of.civilizations2.jakowski.lukasz.Civilization_SentMessages;
import age.of.civilizations2.jakowski.lukasz.Commands;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Game_Action;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Game_NextTurnUpdate;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_FriendlyCivs;
import age.of.civilizations2.jakowski.lukasz.HistoryManager;
import age.of.civilizations2.jakowski.lukasz.HolyRomanEmpire_GameData;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.Loan_GameData;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_Event;
import age.of.civilizations2.jakowski.lukasz.Message_AssimilationEnd;
import age.of.civilizations2.jakowski.lukasz.Message_FestivalIsOver;
import age.of.civilizations2.jakowski.lukasz.Message_InvestDone;
import age.of.civilizations2.jakowski.lukasz.Message_InvestDone_Development;
import age.of.civilizations2.jakowski.lukasz.Message_Producted_NuclearWeapon;
import age.of.civilizations2.jakowski.lukasz.Message_Relations_Friendly;
import age.of.civilizations2.jakowski.lukasz.Message_Repaid;
import age.of.civilizations2.jakowski.lukasz.Message_Type;
import age.of.civilizations2.jakowski.lukasz.Message_WarReparationsRepaid;
import age.of.civilizations2.jakowski.lukasz.Message_WarReparationsRepaid_Green;
import age.of.civilizations2.jakowski.lukasz.MoveUnits_Line;
import age.of.civilizations2.jakowski.lukasz.MoveUnits_Line_Highlighted;
import age.of.civilizations2.jakowski.lukasz.Move_Units;
import age.of.civilizations2.jakowski.lukasz.Move_Units_Plunder;
import age.of.civilizations2.jakowski.lukasz.Province;
import age.of.civilizations2.jakowski.lukasz.RecruitArmy_Request;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.Save_Civ_GameData;
import age.of.civilizations2.jakowski.lukasz.Vassal_GameData;
import age.of.civilizations2.jakowski.lukasz.WarReparations;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Civilization {
    protected static final int ADD_CIV_DEFAULT_TECH_LEVEL = 45;
    protected static final int MIN_MONEY_REQUIRED_TO_ENABLE_RESEARCH = -500;
    protected static int iNumOfTurnsForNuclearWeapon = 0;
    private int bordersWithEnemy;
    private boolean canExpandOnContinent;
    private Image civFlag;
    protected Save_Civ_GameData civGameData;
    protected List<AI_CivsInRange> civsInRange;
    protected List<AI_Influence> civsInfluenced;
    protected int civsInfluencedSize;
    protected List<Integer> civsIsAlliedIncludeVassal;
    private boolean controlledByPlayer;
    protected float fAverageDevelopment;
    protected float fStability;
    protected int holdLookingForFriends_UntilTurnID;
    protected int iAdministrationCosts;
    protected int iArmiesPositionSize;
    private int iArmyInAnotherProvinceSize;
    protected int iAveragePopulation;
    protected int iBorderWithCivsSize;
    protected int iBudget;
    private int iCivID;
    private int iCivNameHeight;
    private int iCivNameLength;
    private int iCivNameWidth;
    private int iCivRegionsSize;
    private int iHappiness;
    private int iIdeologyID;
    protected int iIncomeProduction;
    protected int iIncomeTaxation;
    protected int iLeague;
    private int iMigrateSize;
    protected float iMilitaryUpkeep_PERC;
    protected int iMilitaryUpkeep_Total;
    private int iMovePoints;
    private int iMoveUnitsSize;
    private int iMove_Units_PlunderSize;
    private int iNumOfNeighboringNeutralProvinces;
    private int iNumOfProvinces;
    private int iNumOfProvincesWithoutOccupied;
    private int iNumOfUnits;
    protected int iNumOf_Armories;
    public int iNumOf_Bunkers;
    protected int iNumOf_Farms;
    protected int iNumOf_Farms_ProvincesPossibleToBuild;
    protected int iNumOf_Forts;
    protected int iNumOf_Libraries;
    public int iNumOf_NuclearReactors;
    protected int iNumOf_Ports;
    protected int iNumOf_SuppliesCamp;
    protected int iNumOf_Towers;
    protected int iNumOf_Workshops;
    private int iRankPosition;
    private int iRankScore;
    private int iRecruitArmySize;
    protected int isAssimilateProvincesPlayer;
    private boolean isAtNuclearWar;
    private boolean isAtWar;
    protected List<Integer> isAtWarWithCivs;
    private boolean isAvailable;
    protected int isBuildBuildingsForPlayer;
    protected int isMoveAtWarPlayer;
    protected int isRegroupArmyForPlayer;
    protected List<Integer> lArmiesPosition;
    private List<Integer> lArmyInAnotherProvince;
    protected List<AI_BordersWith> lBorderWithCivs;
    protected List<Integer> lBordersWithNeutralProvincesID;
    protected List<Integer> lBordersWithWastelandProvincesID;
    private List<Character> lCivNameChars;
    private List<Civilization_Region> lCivRegions;
    private List<List<MoveUnits_Line>> lCurrentRegroupArmyLine;
    protected List<Integer> lDefensivePact;
    private List<Integer> lEventsToRun;
    protected List<Byte> lGuarantee;
    private List<Move_Units> lMigrate;
    protected List<Byte> lMilitirayAccess;
    private List<Move_Units> lMoveUnits;
    private List<Move_Units_Plunder> lMove_Units_Plunder;
    protected List<Integer> lNonAggressionPact;
    protected List<Integer> lOpt_DefensivePact;
    protected List<Integer> lOpt_Guarantee;
    protected List<Integer> lOpt_MilitirayAccess;
    protected List<Integer> lOpt_NonAggressionPact;
    protected List<Integer> lOpt_Truce;
    private List<Integer> lProvinces;
    protected List<Integer> lProvincesWithHighRevRisk;
    protected List<Integer> lProvincesWithLowHappiness;
    protected List<Integer> lProvincesWithLowStability;
    protected List<Integer> lProvincesWithMoreRecruitableArmy;
    private List<RecruitArmy_Request> lRecruitArmy;
    protected List<Integer> lTruce;
    private List<String> sTagsCanForm;
    private int seaAccess;
    private List<Integer> seaAccess_Port;
    private List<Integer> seaAccess_Provinces;
    private boolean updateRegions;

    protected Civilization(Save_Civ_GameData save_Civ_GameData, int n) {
        Save_Civ_GameData save_Civ_GameData2;
        this.civGameData = save_Civ_GameData2 = new Save_Civ_GameData();
        this.civsInfluenced = save_Civ_GameData2;
        this.civsInRange = save_Civ_GameData2;
        this.controlledByPlayer = false;
        this.isAvailable = true;
        this.iCivNameLength = 0;
        this.civsInfluencedSize = 0;
        this.holdLookingForFriends_UntilTurnID = 0;
        this.civFlag = null;
        this.sTagsCanForm = null;
        this.civsIsAlliedIncludeVassal = new ArrayList<Integer>();
        this.lEventsToRun = new ArrayList<Integer>();
        this.iIdeologyID = 0;
        this.lProvinces = new ArrayList<Integer>();
        this.lArmyInAnotherProvince = new ArrayList<Integer>();
        this.iArmyInAnotherProvinceSize = 0;
        this.lArmiesPosition = new ArrayList<Integer>();
        this.iArmiesPositionSize = 0;
        this.lBorderWithCivs = new ArrayList<AI_BordersWith>();
        this.iBorderWithCivsSize = 0;
        this.lBordersWithWastelandProvincesID = new ArrayList<Integer>();
        this.lBordersWithNeutralProvincesID = new ArrayList<Integer>();
        this.lCivRegions = new ArrayList<Civilization_Region>();
        this.updateRegions = false;
        this.iLeague = 0;
        this.iBudget = 0;
        this.iIncomeTaxation = 0;
        this.iIncomeProduction = 0;
        this.iAdministrationCosts = 0;
        this.iMilitaryUpkeep_Total = 0;
        this.iMilitaryUpkeep_PERC = 0.0f;
        this.iAveragePopulation = 0;
        this.lProvincesWithLowStability = new ArrayList<Integer>();
        this.lProvincesWithLowHappiness = new ArrayList<Integer>();
        this.lProvincesWithMoreRecruitableArmy = new ArrayList<Integer>();
        this.lProvincesWithHighRevRisk = new ArrayList<Integer>();
        this.fStability = 1.0f;
        this.fAverageDevelopment = 1.0f;
        this.iNumOf_Forts = 0;
        this.iNumOf_Towers = 0;
        this.iNumOf_Ports = 0;
        this.iNumOf_Farms = 0;
        this.iNumOf_NuclearReactors = 0;
        this.iNumOf_Bunkers = 0;
        this.iNumOf_Farms_ProvincesPossibleToBuild = 0;
        this.iNumOf_Workshops = 0;
        this.iNumOf_Libraries = 0;
        this.iNumOf_Armories = 0;
        this.iNumOf_SuppliesCamp = 0;
        this.lNonAggressionPact = new ArrayList<Integer>();
        this.lOpt_NonAggressionPact = new ArrayList<Integer>();
        this.lTruce = new ArrayList<Integer>();
        this.lOpt_Truce = new ArrayList<Integer>();
        this.lDefensivePact = new ArrayList<Integer>();
        this.lOpt_DefensivePact = new ArrayList<Integer>();
        this.lGuarantee = new ArrayList<Byte>();
        this.lOpt_Guarantee = new ArrayList<Integer>();
        this.lMilitirayAccess = new ArrayList<Byte>();
        this.lOpt_MilitirayAccess = new ArrayList<Integer>();
        this.seaAccess = 0;
        this.seaAccess_Provinces = new ArrayList<Integer>();
        this.seaAccess_Port = new ArrayList<Integer>();
        this.bordersWithEnemy = 0;
        this.isAtWar = false;
        this.isAtWarWithCivs = new ArrayList<Integer>();
        this.iNumOfNeighboringNeutralProvinces = 0;
        this.canExpandOnContinent = false;
        this.iRankPosition = 1;
        this.iRankScore = 1;
        this.lCurrentRegroupArmyLine = new ArrayList<List<MoveUnits_Line>>();
        this.setCivID(n);
        this.setCivName(save_Civ_GameData.sCivName);
        this.civGameData = save_Civ_GameData;
        this.updateCivilizationIdeology();
        this.sTagsCanForm = new ArrayList<String>();
        this.lMoveUnits = new ArrayList<Move_Units>();
        this.iMoveUnitsSize = 0;
        this.lMove_Units_Plunder = new ArrayList<Move_Units_Plunder>();
        this.iMove_Units_PlunderSize = 0;
        this.lRecruitArmy = new ArrayList<RecruitArmy_Request>();
        this.iRecruitArmySize = 0;
        this.lMigrate = new ArrayList<Move_Units>();
        this.iMigrateSize = 0;
        this.lCurrentRegroupArmyLine.clear();
        this.controlledByPlayer = false;
        this.isAvailable = true;
        this.iHappiness = 75;
        this.lEventsToRun.clear();
        this.lEventsToRun = new ArrayList<Integer>();
        this.civGameData.lEvents_DecisionsTaken.clear();
        this.civGameData.lEvents_DecisionsTaken = new ArrayList<String>();
        this.loadFlag();
    }

    protected Civilization(String string2, int n, int n2, int n3, int n4, int n5) {
        Save_Civ_GameData save_Civ_GameData;
        this.civGameData = save_Civ_GameData = new Save_Civ_GameData();
        this.civsInRange = save_Civ_GameData;
        this.controlledByPlayer = false;
        this.isAvailable = true;
        this.iCivNameLength = 0;
        this.holdLookingForFriends_UntilTurnID = 0;
        this.civFlag = null;
        this.sTagsCanForm = null;
        this.lEventsToRun = new ArrayList<Integer>();
        this.iIdeologyID = 0;
        this.lProvinces = new ArrayList<Integer>();
        this.lArmyInAnotherProvince = new ArrayList<Integer>();
        this.iArmyInAnotherProvinceSize = 0;
        this.lArmiesPosition = new ArrayList<Integer>();
        this.iArmiesPositionSize = 0;
        this.lBorderWithCivs = new ArrayList<AI_BordersWith>();
        this.iBorderWithCivsSize = 0;
        this.lBordersWithWastelandProvincesID = new ArrayList<Integer>();
        this.civsIsAlliedIncludeVassal = new ArrayList<Integer>();
        this.lBordersWithNeutralProvincesID = new ArrayList<Integer>();
        this.lCivRegions = new ArrayList<Civilization_Region>();
        this.updateRegions = false;
        this.iLeague = 0;
        this.iBudget = 0;
        this.iIncomeTaxation = 0;
        this.iIncomeProduction = 0;
        this.iAdministrationCosts = 0;
        this.iMilitaryUpkeep_Total = 0;
        this.iMilitaryUpkeep_PERC = 0.0f;
        this.iAveragePopulation = 0;
        this.lProvincesWithLowStability = new ArrayList<Integer>();
        this.lProvincesWithLowHappiness = new ArrayList<Integer>();
        this.lProvincesWithMoreRecruitableArmy = new ArrayList<Integer>();
        this.lProvincesWithHighRevRisk = new ArrayList<Integer>();
        this.fStability = 1.0f;
        this.fAverageDevelopment = 1.0f;
        this.iNumOf_Forts = 0;
        this.iNumOf_Towers = 0;
        this.iNumOf_Ports = 0;
        this.iNumOf_Farms = 0;
        this.iNumOf_Farms_ProvincesPossibleToBuild = 0;
        this.iNumOf_Workshops = 0;
        this.iNumOf_Libraries = 0;
        this.iNumOf_Armories = 0;
        this.iNumOf_NuclearReactors = 0;
        this.iNumOf_Bunkers = 0;
        this.iNumOf_SuppliesCamp = 0;
        this.lNonAggressionPact = new ArrayList<Integer>();
        this.lOpt_NonAggressionPact = new ArrayList<Integer>();
        this.lTruce = new ArrayList<Integer>();
        this.lOpt_Truce = new ArrayList<Integer>();
        this.lDefensivePact = new ArrayList<Integer>();
        this.lOpt_DefensivePact = new ArrayList<Integer>();
        this.lGuarantee = new ArrayList<Byte>();
        this.lOpt_Guarantee = new ArrayList<Integer>();
        this.lMilitirayAccess = new ArrayList<Byte>();
        this.lOpt_MilitirayAccess = new ArrayList<Integer>();
        this.seaAccess = 0;
        this.seaAccess_Provinces = new ArrayList<Integer>();
        this.seaAccess_Port = new ArrayList<Integer>();
        this.bordersWithEnemy = 0;
        this.isAtWar = false;
        this.isAtWarWithCivs = new ArrayList<Integer>();
        this.iNumOfNeighboringNeutralProvinces = 0;
        this.canExpandOnContinent = false;
        this.iRankPosition = 1;
        this.iRankScore = 1;
        this.lCurrentRegroupArmyLine = new ArrayList<List<MoveUnits_Line>>();
        this.setCivID(n5);
        this.initCivilization(string2, n, n2, n3, n4);
    }

    private final void applyBonusChanges(CivBonus_GameData civBonus_GameData) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_PopGrowth += civBonus_GameData.fModifier_PopGrowth;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_EconomyGrowth += civBonus_GameData.fModifier_EconomyGrowth;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_IncomeTaxation += civBonus_GameData.fModifier_IncomeTaxation;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_IncomeProduction += civBonus_GameData.fModifier_IncomeProduction;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_Research += civBonus_GameData.fModifier_Research;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_MilitaryUpkeep += civBonus_GameData.fModifier_MilitaryUpkeep;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_AttackBonus += civBonus_GameData.fModifier_AttackBonus;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_DefenseBonus += civBonus_GameData.fModifier_DefenseBonus;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_MovementPoints += civBonus_GameData.fModifier_MovementPoints;
    }

    private final void applyBonusChanges_Expired(CivBonus_GameData civBonus_GameData) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_PopGrowth -= civBonus_GameData.fModifier_PopGrowth;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_EconomyGrowth -= civBonus_GameData.fModifier_EconomyGrowth;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_IncomeTaxation -= civBonus_GameData.fModifier_IncomeTaxation;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_IncomeProduction -= civBonus_GameData.fModifier_IncomeProduction;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_Research -= civBonus_GameData.fModifier_Research;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_MilitaryUpkeep -= civBonus_GameData.fModifier_MilitaryUpkeep;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_AttackBonus -= civBonus_GameData.fModifier_AttackBonus;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_DefenseBonus -= civBonus_GameData.fModifier_DefenseBonus;
        save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fModifier_MovementPoints -= civBonus_GameData.fModifier_MovementPoints;
    }

    private final void buildCivilizationRegion(int n, int n2) {
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() != this.iCivID || CFG.game.getProvince((int)CFG.game.getProvince((int)n).getNeighboringProvinces((int)i)).was) continue;
            CFG.game.getProvince((int)CFG.game.getProvince((int)n).getNeighboringProvinces((int)i)).was = true;
            this.lCivRegions.get(n2).addProvince(CFG.game.getProvince(n).getNeighboringProvinces(i));
            CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).setCivRegionID(n2);
            this.buildCivilizationRegion(CFG.game.getProvince(n).getNeighboringProvinces(i), n2);
        }
    }

    private final void initCivilization(String object, int n, int n2, int n3, int n4) {
        this.setCivName(CFG.langManager.getCiv((String)object));
        this.civGameData.sCivTag = object;
        this.updateCivilizationIdeology();
        this.civGameData.iCapitalProvinceID = n4;
        if (n4 >= 0) {
            CFG.game.getProvince(n4).setIsCapital(true);
        }
        object = this.civGameData;
        ((Save_Civ_GameData)object).iR = (short)n;
        ((Save_Civ_GameData)object).iG = (short)n2;
        ((Save_Civ_GameData)object).iB = (short)n3;
        ((Save_Civ_GameData)object).civilization_Diplomacy_GameData = new Civilization_Diplomacy_GameData();
        this.buildCivPersonality();
        this.sTagsCanForm = new ArrayList<String>();
        this.civGameData.lLoansTaken = new ArrayList<Loan_GameData>();
        this.civGameData.lWarReparationsGets = new ArrayList<WarReparations>();
        this.civGameData.lWarReparationsPay = new ArrayList<WarReparations>();
        this.lMoveUnits = new ArrayList<Move_Units>();
        this.iMoveUnitsSize = 0;
        this.lMove_Units_Plunder = new ArrayList<Move_Units_Plunder>();
        this.iMove_Units_PlunderSize = 0;
        this.lRecruitArmy = new ArrayList<RecruitArmy_Request>();
        this.iRecruitArmySize = 0;
        this.civGameData.lRegroupArmy = new ArrayList<RegroupArmy_Data>();
        this.civGameData.iRegroupArmySize = 0;
        this.lMigrate = new ArrayList<Move_Units>();
        this.iMigrateSize = 0;
        this.lCurrentRegroupArmyLine.clear();
        this.controlledByPlayer = false;
        this.isAvailable = true;
        this.civGameData.fTechnologyLevel = 45;
        this.iHappiness = 75;
        this.lEventsToRun.clear();
        this.lEventsToRun = new ArrayList<Integer>();
        this.civGameData.lEvents_DecisionsTaken.clear();
        this.civGameData.lEvents_DecisionsTaken = new ArrayList<String>();
        this.loadFlag();
    }

    private final void removeCivRegionID(int n) {
        int n2 = 0;
        for (int i = 0; i < this.lCivRegions.get(n).getProvincesSize(); ++i) {
            CFG.game.getProvince(this.lCivRegions.get(n).getProvince(i)).setCivRegionID(-1);
        }
        this.lCivRegions.remove(n);
        this.iCivRegionsSize = this.lCivRegions.size();
        for (n = n2; n < this.iCivRegionsSize; ++n) {
            this.lCivRegions.get(n).setRegionID(n);
        }
    }

    protected final void addArmyInAnotherProvince(int n) {
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("addArmyInAnotherProvince: ");
        stringBuilder.append(this.getCivName());
        stringBuilder.append(", nProvinceID: ");
        stringBuilder.append(n);
        stringBuilder.append(" -> ");
        stringBuilder.append(CFG.game.getProvince(n).getName());
        stringBuilder.append(", ");
        stringBuilder.append(this.iArmyInAnotherProvinceSize);
        application.log("AoC", stringBuilder.toString());
        for (int i = 0; i < this.getArmyInAnotherProvinceSize(); ++i) {
            if (this.getArmyInAnotherProvince(i) != n) continue;
            return;
        }
        this.lArmyInAnotherProvince.add(n);
        this.iArmyInAnotherProvinceSize = this.lArmyInAnotherProvince.size();
    }

    protected final boolean addAssimilate(CivFestival civFestival) {
        for (int i = 0; i < this.civGameData.lAssimilates.size(); ++i) {
            if (civFestival.iProvinceID != this.civGameData.lAssimilates.get((int)i).iProvinceID) continue;
            return false;
        }
        this.civGameData.lAssimilates.add(civFestival);
        return true;
    }

    protected final void addBordersWithCivID(int n) {
        for (int i = 0; i < this.iBorderWithCivsSize; ++i) {
            if (this.lBorderWithCivs.get((int)i).iWithCivID != n) continue;
            AI_BordersWith aI_BordersWith = this.lBorderWithCivs.get(i);
            ++aI_BordersWith.iNumOfConnections;
            return;
        }
        this.lBorderWithCivs.add(new AI_BordersWith(n));
        ++this.iBorderWithCivsSize;
    }

    protected final void addEventToRunID(int n) {
        this.lEventsToRun.add(n);
    }

    protected final void addEvent_DecisionTaken(String string2) {
        this.civGameData.lEvents_DecisionsTaken.add(string2);
    }

    protected final boolean addFestival(CivFestival civFestival) {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            if (civFestival.iProvinceID != this.civGameData.lFestivals.get((int)i).iProvinceID) continue;
            return false;
        }
        this.civGameData.lFestivals.add(civFestival);
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean addFriendlyCiv(int n) {
        for (int i = 0; i < this.civGameData.lFriendlyCivs.size(); ++i) {
            if (n != this.civGameData.lFriendlyCivs.get((int)i).iCivID) continue;
            return false;
        }
        this.civGameData.lFriendlyCivs.add(new Civilization_Friends_GameData(n, Game_Calendar.TURN_ID));
        this.getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Relations_Friendly(n));
        try {
            HistoryManager historyManager = CFG.historyManager;
            HistoryLog_FriendlyCivs historyLog_FriendlyCivs = new HistoryLog_FriendlyCivs(this.getCivID(), n);
            historyManager.addHistoryLog(historyLog_FriendlyCivs);
            return true;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return true;
        }
    }

    protected final boolean addHatedCiv(int n) {
        for (int i = 0; i < this.getHatedCivsSize(); ++i) {
            if (n != this.civGameData.lHatedCivs.get((int)i).iCivID) continue;
            return false;
        }
        CFG.game.getCiv(n).addHatedCiv_By(this.getCivID());
        this.civGameData.lHatedCivs.add(new Civilization_Hated_GameData(n));
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iHatedCivsSize = save_Civ_GameData.lHatedCivs.size();
        return true;
    }

    protected final void addHatedCiv_By(int n) {
        for (int i = 0; i < this.getHatedCivs_BySize(); ++i) {
            if (this.civGameData.lHatedCivs_By.get(i) != n) continue;
            return;
        }
        this.civGameData.lHatedCivs_By.add(n);
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iHatedCivs_BySize = save_Civ_GameData.lHatedCivs_By.size();
    }

    protected final boolean addInvest(CivInvest civInvest) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (civInvest.iProvinceID != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            return false;
        }
        this.civGameData.lInvest.add(civInvest);
        return true;
    }

    protected final boolean addInvest_Development(CivInvest_Development civInvest_Development) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (civInvest_Development.iProvinceID != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            return false;
        }
        this.civGameData.lInvest_Development.add(civInvest_Development);
        return true;
    }

    protected final void addLoan(int n, int n2) {
        this.civGameData.lLoansTaken.add(new Loan_GameData(n, n2));
    }

    protected final boolean addNewBonus(CivBonus_GameData civBonus_GameData) {
        if (civBonus_GameData.BONUS_TYPE == CivBonus_Type.GOLDEN_AGE_PROSPERITY) {
            for (int i = 0; i < this.civGameData.lBonuses.size(); ++i) {
                if (this.civGameData.lBonuses.get((int)i).BONUS_TYPE != CivBonus_Type.GOLDEN_AGE_PROSPERITY) continue;
                return false;
            }
        } else if (civBonus_GameData.BONUS_TYPE == CivBonus_Type.GOLDEN_AGE_SCIENCE) {
            for (int i = 0; i < this.civGameData.lBonuses.size(); ++i) {
                if (this.civGameData.lBonuses.get((int)i).BONUS_TYPE != CivBonus_Type.GOLDEN_AGE_SCIENCE) continue;
                return false;
            }
        } else if (civBonus_GameData.BONUS_TYPE == CivBonus_Type.GOLDEN_AGE_MILITARY) {
            for (int i = 0; i < this.civGameData.lBonuses.size(); ++i) {
                if (this.civGameData.lBonuses.get((int)i).BONUS_TYPE != CivBonus_Type.GOLDEN_AGE_MILITARY) continue;
                return false;
            }
        }
        this.civGameData.lBonuses.add(civBonus_GameData);
        this.applyBonusChanges(civBonus_GameData);
        return true;
    }

    protected final void addNewConstruction(Construction_GameData construction_GameData) {
        for (int i = 0; i < this.civGameData.lConstructions.size(); ++i) {
            if (this.civGameData.lConstructions.get((int)i).iProvinceID != construction_GameData.iProvinceID || this.civGameData.lConstructions.get((int)i).constructionType != construction_GameData.constructionType) continue;
            return;
        }
        this.civGameData.lConstructions.add(construction_GameData);
    }

    protected final void addProvince(int n) {
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            if (this.lProvinces.get(i) != n) continue;
            return;
        }
        this.lProvinces.add(n);
        this.iNumOfProvinces = this.lProvinces.size();
        CFG.game.getProvince(n).setCivRegionID(-1);
    }

    protected final void addProvince_Just(int n) {
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            if (this.lProvinces.get(i) != n) continue;
            return;
        }
        this.lProvinces.add(n);
        this.iNumOfProvinces = this.lProvinces.size();
    }

    protected final void addRegroupArmy(RegroupArmy_Data regroupArmy_Data) {
        this.civGameData.lRegroupArmy.add(regroupArmy_Data);
        Serializable serializable = this.civGameData;
        ((Save_Civ_GameData)serializable).iRegroupArmySize = ((Save_Civ_GameData)serializable).lRegroupArmy.size();
        serializable = new ArrayList();
        int n = regroupArmy_Data.getFromProvinceID();
        int n2 = 0;
        serializable.add(new MoveUnits_Line_Highlighted(n, regroupArmy_Data.getRoute(0)));
        while (n2 < regroupArmy_Data.getRouteSize() - 1) {
            n = regroupArmy_Data.getRoute(n2);
            serializable.add(new MoveUnits_Line_Highlighted(n, regroupArmy_Data.getRoute(++n2)));
        }
        this.lCurrentRegroupArmyLine.add((List<MoveUnits_Line>)((Object)serializable));
    }

    protected final void addResearchProgress(float f) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fResearchProgress += f;
    }

    protected final void addSeaAccess_PortProvinces(int n) {
        this.seaAccess_Port.add(n);
    }

    protected final void addSeaAccess_Provinces(int n) {
        this.seaAccess_Provinces.add(n);
    }

    protected final void addSentMessages(Civilization_SentMessages civilization_SentMessages) {
        for (int i = this.civGameData.lSentMessages.size() - 1; i >= 0; --i) {
            if (this.civGameData.lSentMessages.get((int)i).iToCivID != civilization_SentMessages.iToCivID || this.civGameData.lSentMessages.get((int)i).messageType != civilization_SentMessages.messageType) continue;
            this.civGameData.lSentMessages.get((int)i).iSentInTurnID = Game_Calendar.TURN_ID;
            return;
        }
        this.civGameData.lSentMessages.add(civilization_SentMessages);
    }

    protected final void addTagsCanForm(String string2) {
        for (int i = 0; i < this.sTagsCanForm.size(); ++i) {
            if (!this.sTagsCanForm.get(i).equals(string2)) continue;
            return;
        }
        this.sTagsCanForm.add(string2);
    }

    protected final void addVassal(int n) {
        for (int i = 0; i < this.civGameData.lVassals.size(); ++i) {
            if (this.civGameData.lVassals.get((int)i).iCivID != n) continue;
            return;
        }
        this.civGameData.lVassals.add(new Vassal_GameData(n));
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iVassalsSize = save_Civ_GameData.lVassals.size();
    }

    protected final void addWarReparationsGets(int n) {
        for (int i = 0; i < this.civGameData.lWarReparationsGets.size(); ++i) {
            if (this.civGameData.lWarReparationsGets.get((int)i).iFromCivID != n) continue;
            this.civGameData.lWarReparationsGets.get((int)i).iTurnsLeft = 12;
            return;
        }
        this.civGameData.lWarReparationsGets.add(new WarReparations(n, 12));
    }

    protected final void addWarReparationsPay(int n) {
        for (int i = 0; i < this.civGameData.lWarReparationsPay.size(); ++i) {
            if (this.civGameData.lWarReparationsPay.get((int)i).iFromCivID != n) continue;
            this.civGameData.lWarReparationsPay.get((int)i).iTurnsLeft = 12;
            return;
        }
        this.civGameData.lWarReparationsPay.add(new WarReparations(n, 12));
    }

    protected final void buildCivPersonality() {
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("buildCivPersonality: ");
        stringBuilder.append(this.getCivName());
        application.log("AoC", stringBuilder.toString());
        this.civGameData.civPersonality.WAR_CLOSE_REGION_PROVINCES = CFG.oR.nextInt(4) + 3;
        this.civGameData.civPersonality.WAR_CLOSE_REGION_EXTRA_SCORE = (float)CFG.oR.nextInt(675) / 1000.0f + 1.115f;
        this.civGameData.civPersonality.MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY = CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY_DEFAULT + (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY_RANDOM) / 100.0f;
        this.buildCivPersonality_MoreOften();
        this.civGameData.civPersonality.TREASURY_RESERVE = (float)CFG.oR.nextInt(625) / 100.0f + 3.85f;
        this.civGameData.civPersonality.TREASURY_RESERVE_MODIFIER = (float)CFG.oR.nextInt(150) / 1000.0f + 0.05f;
        this.civGameData.civPersonality.PLUNDER_CHANCE = (float)CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_PLUNDER_MIN + (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_PLUNDER_RANDOM) / 1000.0f;
        this.civGameData.civPersonality.WAR_POTENTIAL = (float)CFG.oR.nextInt(375) / 1000.0f + 0.275f;
        this.civGameData.civPersonality.WAR_DANGER = (float)CFG.oR.nextInt(525) / 1000.0f + 0.525f;
        this.civGameData.civPersonality.WAR_REGION_NUM_OF_PROVINCES = (float)CFG.oR.nextInt(275) / 1000.0f + 0.0375f;
        this.civGameData.civPersonality.WAR_REGION_POTENTIAL = (float)CFG.oR.nextInt(625) / 1000.0f + 0.425f;
        this.civGameData.civPersonality.WAR_NUM_OF_UNITS = 0.925f - (float)CFG.oR.nextInt(725) / 1000.0f;
        this.civGameData.civPersonality.WAR_ATTACK_NAVAL_DISTANCE = 0.695f - (float)CFG.oR.nextInt(335) / 1000.0f;
        this.civGameData.civPersonality.WAR_ATTACK_DISTANCE = 0.625f - (float)CFG.oR.nextInt(275) / 1000.0f;
        this.civGameData.civPersonality.WAR_ATTACK_SCORE_ARMY = 0.315f - (float)CFG.oR.nextInt(350) / 1000.0f;
        this.civGameData.civPersonality.WAR_ATTACK_SCORE_POTENTIAL = 0.325f - (float)CFG.oR.nextInt(350) / 1000.0f;
        this.civGameData.civPersonality.WAR_ATTACK_SCORE_WAS_CONQUERED = 0.275f - (float)CFG.oR.nextInt(725) / 1000.0f;
        this.civGameData.civPersonality.WAR_REGROUP_SPLIT_MIN = CFG.oR.nextInt(2) + 1;
        this.civGameData.civPersonality.WAR_REGROUP_SPLIT_EXTRA = CFG.oR.nextInt(3) + 1;
        this.civGameData.civPersonality.VALUABLE_POTENTIAL = (float)CFG.oR.nextInt(375) / 1000.0f + 0.275f;
        this.civGameData.civPersonality.VALUABLE_POTENTIAL_MODIFIED_OWN_LOST_PROVINCE = (float)CFG.oR.nextInt(1750) / 1000.0f + 1.625f;
        this.civGameData.civPersonality.VALUABLE_DANGER = (float)CFG.oR.nextInt(625) / 1000.0f + 0.575f;
        this.civGameData.civPersonality.VALUABLE_REGION_NUM_OF_PROVINCES = (float)CFG.oR.nextInt(175) / 1000.0f + 0.025f;
        this.civGameData.civPersonality.VALUABLE_REGION_POTENTIAL = (float)CFG.oR.nextInt(625) / 1000.0f + 0.275f;
        this.civGameData.civPersonality.VALUABLE_NUM_OF_UNITS = 0.925f - (float)CFG.oR.nextInt(425) / 1000.0f;
        this.civGameData.civPersonality.VALUABLE_NUM_OF_UNITS_RECRUITMENT = 0.0f - (float)CFG.oR.nextInt(475) / 1000.0f;
        this.civGameData.civPersonality.MIN_MILITARY_SPENDINGS = CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT + (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM) / 100.0f;
        this.civGameData.civPersonality.VALUABLE_RECRUIT_FROM_FAR_AWAY_CHANCE = CFG.oR.nextInt(54) + 1;
        this.civGameData.civPersonality.AGGRESSION = CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_AGGRESION_DEFAULT + (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_AGGRESION_RANDOM) / 100.0f;
        this.civGameData.civPersonality.MIN_MILITARY_SPENDINGS_RECRUIT_AT_WAR = (float)CFG.oR.nextInt(675) / 1000.0f + 0.905f;
        this.civGameData.civPersonality.MIN_MILITARY_SPENDINGS_NOT_BORDERING_WITH_ENEMY = (float)CFG.oR.nextInt(260) / 1000.0f + 0.49f;
        this.civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR_MODIFIER = (float)CFG.oR.nextInt(165) / 1000.0f + 1.02f;
        this.civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV = CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_HAPPINESS_DEFAULT + CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_MIN_HAPPINESS_RANDOM);
        this.civGameData.civPersonality.MIN_HAPPINESS_CRISIS = CFG.oR.nextInt(12) + 54;
        this.civGameData.civPersonality.MIN_PROVINCE_HAPPINESS_RUN_FESTIVAL = Game_Action.RISE_REVOLT_RISK_HAPPINESS + (float)CFG.oR.nextInt(23) / 100.0f;
        this.civGameData.civPersonality.DEFENSE = CFG.oR.nextInt(40) + 20;
        this.civGameData.civPersonality.FORGIVENESS = CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_FORGIVNESS_DEFAULT + (float)(CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_FORGIVNESS_RANDOM) - CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_FORGIVNESS_RANDOM / 2) / 100.0f;
        this.civGameData.civPersonality.MIN_PROVINCE_STABILITY = this.getControlledByPlayer() ? 0.71f : (float)CFG.oR.nextInt(58) / 100.0f + 0.42f;
        this.civGameData.civPersonality.MIN_HAPPINESS_TO_ASSMILIATE_PROVINCE = (float)CFG.oR.nextInt(20) / 100.0f + 0.45f;
        this.civGameData.civPersonality.ASSIMILATE_PERC_DISTANCE_SCORE = (float)CFG.oR.nextInt(65) / 100.0f + 0.1f;
        this.civGameData.civPersonality.ASSIMILATE_PERC_LOW_STABILITY_SCORE = (float)CFG.oR.nextInt(65) / 100.0f + 0.1f;
        this.civGameData.civPersonality.ASSIMILATE_PERC_POPULATION_SCORE = (float)CFG.oR.nextInt(75) / 100.0f + 0.1f;
        this.civGameData.civPersonality.RESPONSE_MILITARY_ACCESS_DISTANCE_SCORE = (float)CFG.oR.nextInt(90) / 100.0f + 6.95f;
        this.civGameData.civPersonality.RESPONSE_MILITARY_ACCESS_RELATION_SCORE = (float)CFG.oR.nextInt(28) + 32.325f;
        this.civGameData.civPersonality.RESPONSE_MILITARY_ACCESS_RANK_SCORE = (float)CFG.oR.nextInt(65) / 10.0f + 5.15f;
        this.civGameData.civPersonality.RESPONSE_MILITARY_ACCESS_RANK_OWN_SCORE = (float)CFG.oR.nextInt(65) / 10.0f + 5.25f;
        this.civGameData.civPersonality.RESPONSE_MILITARY_ACCESS_DEFENSIVE_PACT_SCORE = (float)CFG.oR.nextInt(150) / 10.0f + 16.25f;
        this.civGameData.civPersonality.HRE_VOTE_FOR_RANK = (float)CFG.oR.nextInt(16) + 14.0f;
        this.civGameData.civPersonality.HRE_VOTE_FOR_PROVINCES = (float)CFG.oR.nextInt(16) + 16.0f;
        this.civGameData.civPersonality.RESPONSE_ALLIANCE_OPINION = (float)CFG.oR.nextInt(220) / 10.0f + 32.5f;
        this.civGameData.civPersonality.RESPONSE_ALLIANCE_STRENTGH = (float)CFG.oR.nextInt(265) / 10.0f + 25.75f;
        this.civGameData.civPersonality.BUILD_MIN_STABILITY = (float)CFG.oR.nextInt(26) / 100.0f + 0.64f;
        this.civGameData.civPersonality.BUILD_STABILITY_SCORE = (float)CFG.oR.nextInt(36) / 100.0f + 0.52f;
        this.civGameData.civPersonality.BUILD_MAX_REV_RISK = (float)CFG.oR.nextInt(10) / 100.0f + 0.0f;
        this.civGameData.civPersonality.BUILD_DANGER_SCORE = (float)CFG.oR.nextInt(34) / 100.0f + 0.01f;
        this.buildCivPersonality_Buildings();
        this.buildCivPersonality_Colonization();
        this.civGameData.civPersonality.TECH_POP = (float)CFG.oR.nextInt(85) / 100.0f + 0.15f;
        this.civGameData.civPersonality.TECH_ECO = (float)CFG.oR.nextInt(85) / 100.0f + 0.15f;
        this.civGameData.civPersonality.TECH_TAXATION = (float)CFG.oR.nextInt(90) / 100.0f + 0.1f;
        this.civGameData.civPersonality.TECH_PRODUCTION = (float)CFG.oR.nextInt(90) / 100.0f + 0.1f;
        this.civGameData.civPersonality.TECH_ADMINISTARTION = (float)CFG.oR.nextInt(75) / 100.0f + 0.01f;
        this.civGameData.civPersonality.TECH_MILITARY_UPKEEP = (float)CFG.oR.nextInt(75) / 100.0f + 0.01f;
        this.civGameData.civPersonality.TECH_RESEARCH = (float)CFG.oR.nextInt(70) / 100.0f + 0.01f;
        this.civGameData.civPersonality.LIBERITY_DECLARATION = CFG.oR.nextInt(32) + 66;
        this.civGameData.civPersonality.LIBERITY_ACCEPTABLE_TRIBUTE = (float)CFG.oR.nextInt(40) / 100.0f + 0.45f;
        this.civGameData.civPersonality.VASSALS_TRIBUTE_PERC = (float)CFG.oR.nextInt(60) / 100.0f + 0.1f;
        this.civGameData.civPersonality.VASSALS_TRIBUTE_PERC_RAND = (float)CFG.oR.nextInt(60) / 100.0f + 0.05f;
        this.civGameData.civPersonality.VASSALS_TRIBUTE_PERC_FRIENDLY = (float)CFG.oR.nextInt(65) / 100.0f + 0.3f;
        this.civGameData.civPersonality.POTENTIAL_POPULATION = (float)CFG.oR.nextInt(9999) / 1000.0f + 24.25f;
        this.civGameData.civPersonality.POTENTIAL_ECONOMY = (float)CFG.oR.nextInt(9999) / 1000.0f + 21.5f;
        this.civGameData.civPersonality.DANGER_EXTRA_KEY_REGION = (float)CFG.oR.nextInt(325) / 1000.0f + 1.825f;
        this.civGameData.civPersonality.DANGER_EXTRA_PER_OWN_PROVINCE = (float)CFG.oR.nextInt(175) / 1000.0f + 0.025f;
        this.civGameData.civPersonality.DANGER_PERC_OF_UNITS = (float)CFG.oR.nextInt(425) / 1000.0f + 0.35f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_CAPITAL = (float)CFG.oR.nextInt(25250) / 1000.0f + 14.25f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_OWN_PROVINCE = (float)CFG.oR.nextInt(9500) / 1000.0f + 7.25f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_MORE_NEUTRAL = (float)CFG.oR.nextInt(8000) / 1000.0f + 2.75f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_OTHER_CIV = (float)CFG.oR.nextInt(8750) / 1000.0f + 2.5f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_GROWTH_RATE = (float)CFG.oR.nextInt(50000) / 1000.0f + 41.75f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_LAST_PROVINCE = (float)CFG.oR.nextInt(50000) / 1000.0f + 46.75f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_SEA_ACCESS = (float)CFG.oR.nextInt(19000) / 1000.0f + 8.75f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_SEA_ACCESS_EXTRA = (float)CFG.oR.nextInt(3500) / 1000.0f + 1.75f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_NEIGHBORING_PROVINCES = (float)CFG.oR.nextInt(3750) / 1000.0f + 1.65f;
        this.civGameData.civPersonality.NEUTRAL_EXPAND_NEIGHBORING_PROVINCES_POTENITAL = (float)CFG.oR.nextInt(25000) / 1000.0f + 17.85f;
    }

    protected final void buildCivPersonality_Buildings() {
        this.civGameData.civPersonality.BUILD_FORT = this.getControlledByPlayer() ? 0.0f : 0.001f + (float)CFG.oR.nextInt(100) / 100.0f;
        this.civGameData.civPersonality.BUILD_TOWER = this.getControlledByPlayer() ? 0.0f : 2.5E-4f + (float)CFG.oR.nextInt(6) / 100.0f;
        this.civGameData.civPersonality.BUILD_PORT = this.getControlledByPlayer() ? 0.0f : (float)CFG.oR.nextInt(18) / 100.0f + 0.01f;
        this.civGameData.civPersonality.BUILD_FARM = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : (float)CFG.oR.nextInt(100) / 100.0f + 0.1f;
        this.civGameData.civPersonality.BUILD_WORKSHOP = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : (float)CFG.oR.nextInt(95) / 100.0f + 0.1f;
        this.civGameData.civPersonality.BUILD_WORKSHOP_POP_SCORE = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : 0.51f + (float)CFG.oR.nextInt(42) / 100.0f;
        this.civGameData.civPersonality.BUILD_WORKSHOP_ECO_SCORE = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : 0.82f + (float)CFG.oR.nextInt(35) / 100.0f;
        this.civGameData.civPersonality.BUILD_LIBRARY = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : 0.075f + (float)CFG.oR.nextInt(90) / 100.0f;
        this.civGameData.civPersonality.BUILD_ARMOURY = this.getControlledByPlayer() ? 0.0f : 0.02f + (float)CFG.oR.nextInt(30) / 100.0f;
        this.civGameData.civPersonality.BUILD_ARMOURY_RECRUITABLE_SCORE = this.getControlledByPlayer() ? 0.0f : 0.375f + (float)CFG.oR.nextInt(325) / 1000.0f;
        this.civGameData.civPersonality.BUILD_SUPPLYLINE = this.getControlledByPlayer() ? 0.0f : (float)CFG.oR.nextInt(20) / 100.0f + 0.01f;
        this.civGameData.civPersonality.BUILD_INVEST = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : 0.125f + (float)CFG.oR.nextInt(100) / 100.0f;
        this.civGameData.civPersonality.BUILD_INVEST_DEVELOPMENT = this.getControlledByPlayer() ? (float)CFG.oR.nextInt(100) / 100.0f + 0.1f : 0.0125f + (float)CFG.oR.nextInt(75) / 100.0f;
        this.civGameData.civPersonality.BUILD_INVEST_POP_SCORE = this.getControlledByPlayer() ? 0.25f : 0.0f + (float)CFG.oR.nextInt(2) / 1000.0f;
        this.civGameData.civPersonality.BUILD_INVEST_DEVELOPMENT_SCORE = this.getControlledByPlayer() ? 0.25f : 0.0f + (float)CFG.oR.nextInt(100) / 1000.0f;
        this.civGameData.civPersonality.BUILD_INVEST_POP_ECO_DIFFERENCE_SCORE = this.getControlledByPlayer() ? 1.0f : 1.0f + (float)CFG.oR.nextInt(2825) / 1000.0f;
        this.civGameData.civPersonality.BUILD_INVEST_SECOND_INVEST_MAX_PERC = this.getControlledByPlayer() ? 1 : CFG.oR.nextInt(10) + 1;
        this.civGameData.civPersonality.BUILD_INVEST_SECOND_INVEST_CHANCE = this.getControlledByPlayer() ? 1 : CFG.oR.nextInt(10) + 90;
        this.civGameData.civPersonality.BUILD_RESRVE_RAND = this.getControlledByPlayer() ? 5 : CFG.oR.nextInt(4) + 1;
    }

    protected final void buildCivPersonality_Colonization() {
        this.civGameData.civPersonality.COLONIZATION_SEA = CFG.oR.nextInt(14) / Math.max(this.civGameData.lColonies_Founded.size(), 1) + 4;
        this.civGameData.civPersonality.COLONIZATION_OWN_PROVINCES = 30.0f + (float)CFG.oR.nextInt(40);
        this.civGameData.civPersonality.COLONIZATION_GROWTH_RATE = 12.0f + (float)CFG.oR.nextInt(11);
        this.civGameData.civPersonality.COLONIZATION_DISTANCE = 4.0f + (float)CFG.oR.nextInt(11);
    }

    protected final void buildCivPersonality_MoreOften() {
        this.civGameData.civPersonality.REBUILD_PERSONALITY_MORE_OFTEN = CFG.oR.nextInt(15) + 7;
        this.civGameData.civPersonality.TAXATION_LEVEL = (float)CFG.oR.nextInt(100) / 1000.0f + 0.9f;
        this.civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS = (float)CFG.oAI.getAI_Style((int)this.getAI_Style()).USE_OF_BUDGET_FOR_SPENDINGS / 100.0f + (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).USE_OF_BUDGET_FOR_SPENDINGS_RANDOM * 10) / 1000.0f;
        this.civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET = (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_GOODS_RANDOM) / 100.0f + 0.04f;
        this.civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET = (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_INVESTMENTS_RANDOM) / 100.0f + 0.04f;
        this.civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET = (float)CFG.oR.nextInt(CFG.oAI.getAI_Style((int)this.getAI_Style()).PERSONALITY_RESEARCH_RANDOM) / 100.0f + 0.0f;
    }

    protected final void buildDiplomacy(boolean bl) {
        int n;
        if (bl) {
            this.civGameData.lRelation.clear();
            for (n = 1; n < CFG.game.getCivsSize(); ++n) {
                this.civGameData.lRelation.add(Float.valueOf(0.0f));
            }
        }
        this.lGuarantee.clear();
        this.lMilitirayAccess.clear();
        this.lNonAggressionPact.clear();
        this.lTruce.clear();
        this.lDefensivePact.clear();
        this.lOpt_Truce.clear();
        this.lOpt_MilitirayAccess.clear();
        this.lOpt_DefensivePact.clear();
        this.lOpt_Guarantee.clear();
        this.lOpt_NonAggressionPact.clear();
        if (bl) {
            this.civGameData.iAllianceID = 0;
        }
        for (n = 1; n < CFG.game.getCivsSize(); ++n) {
            this.lGuarantee.add((byte)0);
            this.lMilitirayAccess.add((byte)0);
        }
        for (n = this.iCivID + 1; n < CFG.game.getCivsSize(); ++n) {
            this.lNonAggressionPact.add(0);
            this.lTruce.add(0);
            this.lDefensivePact.add(0);
        }
    }

    protected final void buildNumOfUnits() {
        int n;
        int n2 = 0;
        this.iNumOfUnits = 0;
        for (n = 0; n < this.getNumOfProvinces(); ++n) {
            this.iNumOfUnits += CFG.game.getProvince(this.getProvinceID(n)).getArmyCivID(this.getCivID());
        }
        n = 0;
        while (true) {
            if (n >= this.getMoveUnitsSize()) break;
            this.iNumOfUnits += this.getMoveUnits(n).getNumOfUnits();
            ++n;
        }
        for (int i = n2; i < this.getArmyInAnotherProvinceSize(); ++i) {
            this.iNumOfUnits += CFG.game.getProvince(this.getArmyInAnotherProvince(i)).getArmyCivID(this.getCivID());
        }
    }

    protected final void buildRegroupLines_AfterLoading() {
        for (int i = 0; i < this.civGameData.iRegroupArmySize; ++i) {
            ArrayList<MoveUnits_Line_Highlighted> arrayList = new ArrayList<MoveUnits_Line_Highlighted>();
            arrayList.add(new MoveUnits_Line_Highlighted(this.civGameData.lRegroupArmy.get(i).getFromProvinceID(), this.civGameData.lRegroupArmy.get(i).getRoute(0)));
            int n = 0;
            while (n < this.civGameData.lRegroupArmy.get(i).getRouteSize() - 1) {
                int n2 = this.civGameData.lRegroupArmy.get(i).getRoute(n);
                RegroupArmy_Data regroupArmy_Data = this.civGameData.lRegroupArmy.get(i);
                arrayList.add(new MoveUnits_Line_Highlighted(n2, regroupArmy_Data.getRoute(++n)));
            }
            this.lCurrentRegroupArmyLine.add(arrayList);
        }
    }

    protected final boolean civRegionsContainsProvince(int n) {
        for (int i = 0; i < this.iCivRegionsSize; ++i) {
            if (!this.lCivRegions.get(i).containsProvince(n)) continue;
            return true;
        }
        return false;
    }

    protected final void clearCivRegions() {
        for (int i = 0; i < this.getNumOfProvinces(); ++i) {
            CFG.game.getProvince(this.getProvinceID(i)).setCivRegionID(-1);
        }
        this.lCivRegions.clear();
        this.iCivRegionsSize = 0;
    }

    protected final void clearConstructions() {
        this.civGameData.lConstructions.clear();
    }

    protected final void clearFreidnlyCivs() {
        this.civGameData.lFriendlyCivs.clear();
    }

    protected final void clearHatedCivs() {
        for (int i = 0; i < this.getHatedCivsSize(); ++i) {
            CFG.game.getCiv(this.civGameData.lHatedCivs.get((int)i).iCivID).removeHatedCiv_BY(this.getCivID());
        }
        this.civGameData.lHatedCivs.clear();
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iHatedCivsSize = save_Civ_GameData.lHatedCivs.size();
    }

    protected final void clearLoans() {
        this.civGameData.lLoansTaken.clear();
    }

    protected final void clearMigrate() {
        this.lMigrate.clear();
        this.iMigrateSize = this.lMigrate.size();
    }

    protected final void clearMoveUnits() {
        this.lMoveUnits.clear();
        this.iMoveUnitsSize = this.lMoveUnits.size();
    }

    protected final void clearMoveUnits_Plunder() {
        this.lMove_Units_Plunder.clear();
        this.iMove_Units_PlunderSize = this.lMove_Units_Plunder.size();
    }

    protected final void clearProvinces_FillTheMap(boolean bl) {
        this.lCivRegions.clear();
        this.iCivRegionsSize = 0;
        this.lProvinces.clear();
        if (bl) {
            this.lProvinces.add(this.getCapitalProvinceID());
            this.iNumOfProvinces = this.lProvinces.size();
            this.createCivilizationRegion(this.getCapitalProvinceID());
        } else {
            this.iNumOfProvinces = this.lProvinces.size();
        }
    }

    protected final void clearRecruitArmy() {
        this.lRecruitArmy.clear();
        this.iRecruitArmySize = this.lRecruitArmy.size();
    }

    protected final void clearRegroupArmy() {
        this.civGameData.lRegroupArmy.clear();
        this.lCurrentRegroupArmyLine.clear();
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iRegroupArmySize = save_Civ_GameData.lRegroupArmy.size();
    }

    protected final void clearSeaAccess_PortProvinces() {
        this.seaAccess_Port.clear();
    }

    protected final void clearSeaAccess_Provinces() {
        this.seaAccess_Provinces.clear();
    }

    protected final void clearSentMessages() {
        this.civGameData.lSentMessages.clear();
    }

    protected final void clearTagsCanForm() {
        this.sTagsCanForm.clear();
    }

    protected final boolean controlsProvince(int n) {
        for (int i = 0; i < this.getNumOfProvinces(); ++i) {
            if (n != this.getProvinceID(i)) continue;
            return true;
        }
        return false;
    }

    protected final int countEconomy() {
        int n = 0;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            n += CFG.game.getProvince(this.getProvinceID(i)).getEconomy();
        }
        return n;
    }

    protected final int countEconomy_WithoutOccupied() {
        int n = 0;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            int n2 = n;
            if (!CFG.game.getProvince(this.getProvinceID(i)).isOccupied()) {
                n2 = n + CFG.game.getProvince(this.getProvinceID(i)).getEconomy();
            }
            n = n2;
        }
        return n;
    }

    protected final void countNumOfProvinces() {
        this.iNumOfProvinces = this.lProvinces.size();
    }

    protected final int countNumOfProvinces_WithoutOccupied() {
        int n = 0;
        for (int i = 0; i < this.getNumOfProvinces(); ++i) {
            int n2 = n;
            if (!CFG.game.getProvince(this.getProvinceID(i)).isOccupied()) {
                n2 = n + 1;
            }
            n = n2;
        }
        this.iNumOfProvincesWithoutOccupied = n;
        return n;
    }

    protected final int countPopulation() {
        int n = 0;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            n += CFG.game.getProvince(this.getProvinceID(i)).getPopulationData().getPopulation();
        }
        return n;
    }

    protected final int countPopulation_WithoutOccupied() {
        int n = 0;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            int n2 = n;
            if (!CFG.game.getProvince(this.getProvinceID(i)).isOccupied()) {
                n2 = n + CFG.game.getProvince(this.getProvinceID(i)).getPopulationData().getPopulation();
            }
            n = n2;
        }
        return n;
    }

    protected final float countRevolutionaryRisks_WithoutOccupied() {
        float f = 0.0f;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            float f2 = f;
            if (!CFG.game.getProvince(this.getProvinceID(i)).isOccupied()) {
                f2 = f + CFG.game.getProvince(this.getProvinceID(i)).getRevolutionaryRisk();
            }
            f = f2;
        }
        return f / (float)this.iNumOfProvincesWithoutOccupied;
    }

    protected final void createCivilizationRegion(int n) {
        this.lCivRegions.add(new Civilization_Region(n, this.iCivRegionsSize));
        this.iCivRegionsSize = this.lCivRegions.size();
        CFG.game.getProvince(n).setCivRegionID(this.iCivRegionsSize - 1);
        CFG.game.getProvince((int)n).was = true;
        this.buildCivilizationRegion(n, this.iCivRegionsSize - 1);
        for (n = 0; n < this.getNumOfProvinces(); ++n) {
            CFG.game.getProvince((int)this.getProvinceID((int)n)).was = false;
        }
    }

    protected final void disposeFlag() {
        Image image = this.civFlag;
        if (image != null) {
            image.getTexture().dispose();
            this.civFlag = null;
        }
    }

    protected final int getAI_Style() {
        return this.civGameData.iAI_Style;
    }

    protected final int getAllianceID() {
        return this.civGameData.iAllianceID;
    }

    protected final int getArmyInAnotherProvince(int n) {
        try {
            n = this.lArmyInAnotherProvince.get(n);
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (CFG.LOGS) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            return -1;
        }
    }

    protected final int getArmyInAnotherProvinceSize() {
        return this.iArmyInAnotherProvinceSize;
    }

    protected final CivFestival getAssimilate(int n) {
        return this.civGameData.lAssimilates.get(n);
    }

    protected final int getAssimilatesSize() {
        return this.civGameData.lAssimilates.size();
    }

    protected final int getB() {
        return this.civGameData.iB;
    }

    protected final CivBonus_GameData getBonus(int n) {
        return this.civGameData.lBonuses.get(n);
    }

    protected final int getBonusesSize() {
        return this.civGameData.lBonuses.size();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean getBordersWithCiv(int n) {
        boolean bl = false;
        int n2 = 0;
        while (true) {
            boolean bl2 = bl;
            if (n2 >= this.iBorderWithCivsSize) return bl2;
            if (this.lBorderWithCivs.get((int)n2).iWithCivID == n) return true;
            ++n2;
        }
    }

    protected final int getBordersWithEnemy() {
        return this.bordersWithEnemy;
    }

    protected final int getBordersWithHatedCivsSize() {
        int n = 0;
        for (int i = 0; i < this.iBorderWithCivsSize; ++i) {
            int n2 = n;
            if (this.isHatedCivBy(this.lBorderWithCivs.get((int)i).iWithCivID)) {
                n2 = n + 1;
            }
            n = n2;
        }
        return n;
    }

    protected final float getBoundaryDistance(int n) {
        float f = 0.0f;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            for (int j = 0; j < CFG.game.getCiv((int)n).iNumOfProvinces; ++j) {
                int n2 = CFG.game.getCiv(n).getProvinceID(j);
                int n3 = this.getProvinceID(i);
                f = Math.min(CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(n2, n3), f);
            }
        }
        return f;
    }

    protected final boolean getCanExpandOnContinent() {
        return this.canExpandOnContinent;
    }

    protected final int getCapitalMoved_LastTurnID() {
        return this.civGameData.iCapitalMoved_LastTurnID;
    }

    protected final int getCapitalProvinceID() {
        return this.civGameData.iCapitalProvinceID;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final String getChangeGovermentStatus() {
        int n = this.iIdeologyID;
        if (CFG.ideologiesManager.getIdeology((int)n).ELECTION_PERIOD > 0) {
            if (Game_Calendar.TURN_ID < this.getNextElection()) return "z13";
            return "z12";
        }
        n = this.iIdeologyID;
        if (CFG.ideologiesManager.getIdeology((int)n).REFORMATION_PERIOD <= 0) return "ChangeTypeOfGovernment";
        if (this.getInReformation() > 0) {
            return "z14";
        }
        n = this.civGameData.iChangeGoverment_SinceTurn;
        if (Game_Calendar.TURN_ID < n) return "z16";
        return "z15";
    }

    protected final int getCivBuildArmyCost() {
        int n = this.getManPower_ThisTurn() * 2 / 50;
        int n2 = this.iIncomeTaxation;
        n = this.iAdministrationCosts;
        float f = (float)(this.iIncomeProduction + (n2 - n)) * (1.0f - (CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).MIN_INVESTMENTS + CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).MIN_GOODS)) / 5.0f;
        float f2 = this.getManPowerIncreasing() * 2 + n;
        f2 = f < f2 ? f / f2 * 5.0f : Math.max((float)Math.pow(f / f2 * 5.0f, 0.85), 5.0f);
        return Math.max((int)f2, 1);
    }

    protected final float getCivCommercePower() {
        float f = this.iNumOfProvinces;
        float f2 = this.civGameData.fTechnologyLevel;
        float f3 = CFG.gameAges.getAge_TechStandard(Game_Calendar.CURRENT_AGEID);
        int n = this.iAdministrationCosts;
        int n2 = this.iIncomeTaxation;
        return Math.max((f + (f2 - f3) * 3.0f) * Math.max((float)Math.max(this.iIncomeProduction + (n2 - n), 0) / Game_NextTurnUpdate.LEAGUE_BUDGET, 0.75f) + this.getCivCommercePower_CountBuildings(), 1.0f);
    }

    protected final float getCivCommercePower_CountBuildings() {
        int n = 0;
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            Province province = CFG.game.getProvince(this.getProvinceID(i));
            n += Math.max(0, province.getLevelOfFarm()) * 2 + Math.max(0, province.getLevelOfFort()) * 3 + Math.max(0, province.getLevelOfPort()) * 3;
        }
        return n;
    }

    protected final float getCivCommercePower_GDP() {
        return Math.max((float)(this.iIncomeTaxation + this.iIncomeProduction) / 50.0f, 0.0f);
    }

    protected final float getCivCommercePower_Other() {
        float f = 1.0f;
        if (this.isAtWar) {
            f = 0.25f;
        }
        float f2 = f;
        if (this.civGameData.closingTheCommerce) {
            f2 = f * 0.125f;
        }
        return f2;
    }

    protected final int getCivID() {
        return this.iCivID;
    }

    protected final String getCivName() {
        return this.civGameData.sCivName;
    }

    protected final char getCivNameCharacter(int n) {
        return this.lCivNameChars.get(n).charValue();
    }

    protected final int getCivNameHeight() {
        return this.iCivNameHeight;
    }

    protected final int getCivNameLength() {
        return this.iCivNameLength;
    }

    protected final int getCivNameWidth() {
        return this.iCivNameWidth;
    }

    protected final CivPersonality getCivPersonality() {
        return this.civGameData.civPersonality;
    }

    protected final CivPlans getCivPlans() {
        return this.civGameData.civPlans;
    }

    protected final Civilization_Region getCivRegion(int n) {
        try {
            Civilization_Region civilization_Region = this.lCivRegions.get(n);
            return civilization_Region;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.updateRegions = true;
            return new Civilization_Region();
        }
    }

    protected final int getCivRegionsSize() {
        return this.iCivRegionsSize;
    }

    protected final String getCivTag() {
        return this.civGameData.sCivTag;
    }

    protected final Civilization_Diplomacy_GameData getCivilization_Diplomacy_GameData() {
        return this.civGameData.civilization_Diplomacy_GameData;
    }

    protected final boolean getClosingTheCommerce() {
        return this.civGameData.closingTheCommerce;
    }

    protected final Construction_GameData getConstruction(int n) {
        return this.civGameData.lConstructions.get(n);
    }

    protected final int getConstructionsSize() {
        return this.civGameData.lConstructions.size();
    }

    protected final boolean getControlledByPlayer() {
        boolean bl = !CFG.SPECTATOR_MODE && this.controlledByPlayer;
        return bl;
    }

    protected final int getCoreCapitalProvinceID() {
        return this.civGameData.iCoreCapitalProvinceID;
    }

    protected final List<MoveUnits_Line> getCurrentRegroupArmyLine(int n) {
        return this.lCurrentRegroupArmyLine.get(n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final String getDeclareWarStatus(int n) {
        if (!DiplomacyManager.getCivIsInRange_War(this.iCivID, n)) return "z23";
        int n2 = this.iCivID;
        if (CFG.game.getCivsAreAllied_IncludeVassal(n2, n, true)) {
            return "z17";
        }
        if (!CFG.ideologiesManager.getIdeology((int)this.getIdeologyID()).HIGH_AUTONOMY && this.getPuppetOfCivID() != this.iCivID) {
            n2 = this.getIdeologyID();
            if (!CFG.ideologiesManager.getIdeology((int)n2).VASSAL_CAN_DECLARE_WAR) {
                return "z18";
            }
        }
        if (CFG.game.getCivRelation_OfCivB(n2 = this.iCivID, n) > 50.0f) {
            return "z19";
        }
        n2 = this.iCivID;
        if (CFG.game.getCivTruce(n2, n) > 0) {
            return "z20";
        }
        n2 = this.iCivID;
        if (CFG.game.getCivNonAggressionPact(n2, n) <= 0) return "z22";
        return "z21";
    }

    protected final int getDefensivePact(int n) {
        try {
            n = this.lDefensivePact.get(n);
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.lDefensivePact.add(0);
            return 0;
        }
    }

    protected final int getDiplomacyPoints() {
        return this.civGameData.iDiplomacyPoints;
    }

    protected final String getDiplomacyStatus_Ally(int n) {
        String string2 = DiplomacyManager.getCivIsInRange(this.iCivID, n) ? "z24" : "z25";
        return string2;
    }

    protected final String getDiplomacyStatus_Improvement(int n) {
        String string2 = DiplomacyManager.getCivIsInRange(this.iCivID, n) ? "z26" : "z27";
        return string2;
    }

    protected final String getDiplomacyStatus_Insult(int n) {
        String string2 = DiplomacyManager.getCivIsInRange(this.iCivID, n) ? "z28" : "z29";
        return string2;
    }

    protected final boolean getEvent_TookDecision(String string2) {
        for (int i = 0; i < this.civGameData.lEvents_DecisionsTaken.size(); ++i) {
            if (!this.civGameData.lEvents_DecisionsTaken.get(i).equals(string2)) continue;
            return true;
        }
        return false;
    }

    protected final int getEventsToRun(int n) {
        return this.lEventsToRun.get(n);
    }

    protected final int getEventsToRunSize() {
        return this.lEventsToRun.size();
    }

    protected final CivFestival getFestival(int n) {
        return this.civGameData.lFestivals.get(n);
    }

    protected final int getFestivalsSize() {
        return this.civGameData.lFestivals.size();
    }

    protected final Image getFlag() {
        Image image;
        Image image2 = image = this.civFlag;
        if (image == null) {
            image2 = ImageManager.getImage(Images.randomCivilizationFlag);
        }
        return image2;
    }

    protected final boolean getFlag_IsNull() {
        boolean bl = this.civFlag == null;
        return bl;
    }

    protected final Civilization_Friends_GameData getFriendlyCiv(int n) {
        return this.civGameData.lFriendlyCivs.get(n);
    }

    protected final int getFriendlyCivsSize() {
        return this.civGameData.lFriendlyCivs.size();
    }

    protected final int getG() {
        return this.civGameData.iG;
    }

    public int getGoldenAge_Military() {
        return this.civGameData.iGoldenAge_Military;
    }

    public int getGoldenAge_Prosperity() {
        return this.civGameData.iGoldenAge_Prosperity;
    }

    public int getGoldenAge_Science() {
        return this.civGameData.iGoldenAge_Science;
    }

    protected final int getGuarantee(int n) {
        try {
            n = this.lGuarantee.get(n).byteValue();
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.lGuarantee.add((byte)0);
            return 0;
        }
    }

    protected final int getHappiness() {
        return this.iHappiness;
    }

    protected final float getHappiness_10Turn() {
        return this.civGameData.iHappiness_10Turn;
    }

    protected final Civilization_Hated_GameData getHatedCiv(int n) {
        return this.civGameData.lHatedCivs.get(n);
    }

    protected final int getHatedCiv_By(int n) {
        return this.civGameData.lHatedCivs_By.get(n);
    }

    protected final int getHatedCivsSize() {
        return this.civGameData.iHatedCivsSize;
    }

    protected final int getHatedCivs_BySize() {
        return this.civGameData.iHatedCivs_BySize;
    }

    protected final int getIdeologyID() {
        return this.iIdeologyID;
    }

    protected final int getInReformation() {
        return this.civGameData.iInReformation;
    }

    protected final CivInvest getInvest(int n) {
        return this.civGameData.lInvest.get(n);
    }

    protected final CivInvest_Development getInvest_Development(int n) {
        return this.civGameData.lInvest_Development.get(n);
    }

    protected final int getInvestsSize() {
        return this.civGameData.lInvest.size();
    }

    protected final int getInvestsSize_Development() {
        return this.civGameData.lInvest_Development.size();
    }

    protected final boolean getIsAlliedWithPlayer() {
        return this.civGameData.isAlliedWithPlayer;
    }

    protected final boolean getIsAvailable() {
        return this.isAvailable;
    }

    protected final boolean getIsPartOfHolyRomanEmpire() {
        return this.civGameData.isPartOfHolyRomaEmpire;
    }

    protected final boolean getIsPupet() {
        boolean bl = this.iCivID != this.civGameData.iPuppetOfCivID;
        return bl;
    }

    protected final Loan_GameData getLoan(int n) {
        return this.civGameData.lLoansTaken.get(n);
    }

    protected final int getLoansSize() {
        return this.civGameData.lLoansTaken.size();
    }

    protected final int getLoans_GoldTotalPerTurn() {
        int n = 0;
        for (int i = 0; i < this.civGameData.lLoansTaken.size(); ++i) {
            n += this.civGameData.lLoansTaken.get((int)i).iGoldPerTurn;
        }
        return n;
    }

    protected final int getManPower() {
        return this.civGameData.iManPower;
    }

    protected final int getManPowerIncreasing() {
        return this.civGameData.iManPowerIncreasing_PerTurn;
    }

    protected final int getManPower_ThisTurn() {
        return Math.max(0, this.civGameData.iManPower_InThisTurn);
    }

    protected final Move_Units getMigrate(int n) {
        return this.lMigrate.get(n);
    }

    protected final int getMigrateSize() {
        return this.iMigrateSize;
    }

    protected final int getMilitaryAccess(int n) {
        try {
            n = this.lMilitirayAccess.get(n).byteValue();
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.lMilitirayAccess.add((byte)0);
            return 0;
        }
    }

    protected final float getModifier_Administation() {
        return this.civGameData.fModifier_Administration;
    }

    protected final float getModifier_AttackBonus() {
        return this.civGameData.fModifier_AttackBonus;
    }

    protected final float getModifier_AttackBonus_GoldenAge() {
        return this.civGameData.fModifier_AttackBonus_GoldenAge;
    }

    protected final float getModifier_AttackBonus_Leader() {
        return this.civGameData.fModifier_AttackBonus_Leader;
    }

    protected final float getModifier_DefenseBonus() {
        return this.civGameData.fModifier_DefenseBonus;
    }

    protected final float getModifier_DefenseBonus_GoldenAge() {
        return this.civGameData.fModifier_DefenseBonus_GoldenAge;
    }

    protected final float getModifier_DefenseBonus_Leader() {
        return this.civGameData.fModifier_DefenseBonus_Leader;
    }

    protected final float getModifier_EconomyGrowth() {
        return this.civGameData.fModifier_EconomyGrowth;
    }

    protected final float getModifier_IncomeProduction() {
        return this.civGameData.fModifier_IncomeProduction;
    }

    protected final float getModifier_IncomeTaxation() {
        return this.civGameData.fModifier_IncomeTaxation;
    }

    protected final float getModifier_MilitaryUpkeep() {
        return this.civGameData.fModifier_MilitaryUpkeep;
    }

    protected final float getModifier_MovementPoints() {
        return this.civGameData.fModifier_MovementPoints;
    }

    protected final float getModifier_PopGrowth() {
        return this.civGameData.fModifier_PopGrowth;
    }

    protected final float getModifier_Research() {
        return this.civGameData.fModifier_Research;
    }

    protected final long getMoney() {
        return this.civGameData.iMoney;
    }

    protected final int getMovePoints() {
        return this.iMovePoints;
    }

    protected final Move_Units getMoveUnits(int n) {
        return this.lMoveUnits.get(n);
    }

    protected final int getMoveUnitsPlunderSize() {
        return this.iMove_Units_PlunderSize;
    }

    protected final int getMoveUnitsSize() {
        return this.iMoveUnitsSize;
    }

    protected final Move_Units_Plunder getMoveUnits_Plunder(int n) {
        return this.lMove_Units_Plunder.get(n);
    }

    protected final int getNextElection() {
        return this.civGameData.iNextElection;
    }

    protected final int getNonAggressionPact(int n) {
        try {
            n = this.lNonAggressionPact.get(n);
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.lNonAggressionPact.add(0);
            return 0;
        }
    }

    protected final int getNuclearWeapons() {
        return this.civGameData.iNuclearWeapons;
    }

    protected final int getNuclearWeaponsPerTurn() {
        return this.civGameData.iNuclearWeaponsPerTurn;
    }

    protected final int getNuclearWeaponsTurn() {
        return this.civGameData.iNuclearWeaponsTurn;
    }

    protected final int getNumOfNeighboringNeutralProvinces() {
        return this.iNumOfNeighboringNeutralProvinces;
    }

    protected final int getNumOfProvinces() {
        return this.iNumOfProvinces;
    }

    protected final int getNumOfProvincesWithoutOccupied() {
        return this.iNumOfProvincesWithoutOccupied;
    }

    protected final int getNumOfUnits() {
        return this.iNumOfUnits;
    }

    protected final int getProvinceID(int n) {
        try {
            n = this.lProvinces.get(n);
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (CFG.LOGS) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            return -1;
        }
    }

    protected final int getPuppetOfCivID() {
        return this.civGameData.iPuppetOfCivID;
    }

    protected final int getR() {
        return this.civGameData.iR;
    }

    protected final Color getRGB() {
        return this.getRGB(1.0f);
    }

    protected final Color getRGB(float f) {
        return new Color((float)this.getR() / 255.0f, (float)this.getG() / 255.0f, (float)this.getB() / 255.0f, f);
    }

    protected final int getRankPosition() {
        return this.iRankPosition;
    }

    protected final int getRankScore() {
        return this.iRankScore;
    }

    protected final RecruitArmy_Request getRecruitArmy(int n) {
        return this.lRecruitArmy.get(n);
    }

    protected final int getRecruitArmySize() {
        return this.iRecruitArmySize;
    }

    protected final int getRecruitArmy_BasedOnProvinceID(int n) {
        for (int i = 0; i < this.iRecruitArmySize; ++i) {
            if (this.lRecruitArmy.get(i).getProvinceID() != n) continue;
            return this.lRecruitArmy.get(i).getArmy();
        }
        return 0;
    }

    protected final RegroupArmy_Data getRegroupArmy(int n) {
        return this.civGameData.lRegroupArmy.get(n);
    }

    protected final int getRegroupArmySize() {
        return this.civGameData.iRegroupArmySize;
    }

    protected final float getRelation(int n) {
        try {
            float f = this.civGameData.lRelation.get(n).floatValue();
            return f;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.civGameData.lRelation.add(Float.valueOf(0.0f));
            return 0.0f;
        }
    }

    protected final float getResearchProgress() {
        return this.civGameData.fResearchProgress;
    }

    protected final int getSeaAccess() {
        return this.seaAccess;
    }

    protected final List<Integer> getSeaAccess_PortProvinces() {
        return this.seaAccess_Port;
    }

    protected final int getSeaAccess_PortProvinces_Size() {
        return this.seaAccess_Port.size();
    }

    protected final List<Integer> getSeaAccess_Provinces() {
        return this.seaAccess_Provinces;
    }

    protected final int getSeaAccess_Provinces_Size() {
        return this.seaAccess_Provinces.size();
    }

    protected final Civilization_SentMessages getSentMessage(int n) {
        return this.civGameData.lSentMessages.get(n);
    }

    protected final int getSentMessagesSize() {
        return this.civGameData.lSentMessages.size();
    }

    protected final float getSpendings_Goods() {
        return this.civGameData.fSpendings_Goods;
    }

    protected final float getSpendings_Investments() {
        return this.civGameData.fSpendings_Investments;
    }

    protected final float getSpendings_Research() {
        return this.civGameData.fSpendings_Research;
    }

    protected final float getSpendings_attackbonus() {
        return this.civGameData.fModifier_AttackBonus;
    }

    protected final float getStability() {
        return this.fStability;
    }

    protected final float getSupportRate() {
        return this.civGameData.iSupport_Rate;
    }

    protected final String getTagsCanForm(int n) {
        return this.sTagsCanForm.get(n);
    }

    protected final int getTagsCanFormSize() {
        return this.sTagsCanForm.size();
    }

    protected final float getTaxationLevel() {
        return this.civGameData.fTaxationLevel;
    }

    protected final float getTechnologyLevel() {
        return (float)this.civGameData.fTechnologyLevel / 100.0f;
    }

    protected final int getTechnologyLevel_INT() {
        return this.civGameData.fTechnologyLevel;
    }

    protected final int getTruce(int n) {
        try {
            n = this.lTruce.get(n);
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.lTruce.add(0);
            return 0;
        }
    }

    protected final boolean getUpdateRegions() {
        return this.updateRegions;
    }

    protected final float getVassalLiberityDesire() {
        return this.civGameData.fVassalLiberityDisere;
    }

    protected final int getVassal_Tribute(int n) {
        for (int i = 0; i < this.civGameData.lVassals.size(); ++i) {
            if (this.civGameData.lVassals.get((int)i).iCivID != n) continue;
            return this.civGameData.lVassals.get((int)i).iTribute;
        }
        this.civGameData.lVassals.add(new Vassal_GameData(n));
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iVassalsSize = save_Civ_GameData.lVassals.size();
        return 25;
    }

    protected final WarReparations getWarReparationsGets(int n) {
        return this.civGameData.lWarReparationsGets.get(n);
    }

    protected final int getWarReparationsGetsSize() {
        return this.civGameData.lWarReparationsGets.size();
    }

    protected final int getWarReparationsGets_TurnsLeft(int n) {
        for (int i = 0; i < this.civGameData.lWarReparationsGets.size(); ++i) {
            if (this.civGameData.lWarReparationsGets.get((int)i).iFromCivID != n) continue;
            return this.civGameData.lWarReparationsGets.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final WarReparations getWarReparationsPays(int n) {
        return this.civGameData.lWarReparationsPay.get(n);
    }

    protected final int getWarReparationsPaysSize() {
        return this.civGameData.lWarReparationsPay.size();
    }

    protected final int getWarReparationsPays_TurnsLeft(int n) {
        for (int i = 0; i < this.civGameData.lWarReparationsPay.size(); ++i) {
            if (this.civGameData.lWarReparationsPay.get((int)i).iFromCivID != n) continue;
            return this.civGameData.lWarReparationsPay.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final float getWarWeariness() {
        return this.civGameData.fWarWeariness;
    }

    protected final int isAssimialateOrganized_TurnsLeft(int n) {
        for (int i = 0; i < this.civGameData.lAssimilates.size(); ++i) {
            if (n != this.civGameData.lAssimilates.get((int)i).iProvinceID) continue;
            return this.civGameData.lAssimilates.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final boolean isAssimilateOrganized(int n) {
        for (int i = 0; i < this.civGameData.lAssimilates.size(); ++i) {
            if (n != this.civGameData.lAssimilates.get((int)i).iProvinceID) continue;
            return true;
        }
        return false;
    }

    protected final CivFestival isAssimilateOrganized_GET(int n) {
        for (int i = 0; i < this.civGameData.lAssimilates.size(); ++i) {
            if (n != this.civGameData.lAssimilates.get((int)i).iProvinceID) continue;
            return this.civGameData.lAssimilates.get(i);
        }
        return null;
    }

    public boolean isAtNuclearWar() {
        return this.isAtNuclearWar;
    }

    protected final boolean isAtWar() {
        return this.isAtWar;
    }

    protected final boolean isFestivalOrganized(int n) {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            if (n != this.civGameData.lFestivals.get((int)i).iProvinceID) continue;
            return true;
        }
        return false;
    }

    protected final CivFestival isFestivalOrganized_GET(int n) {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            if (n != this.civGameData.lFestivals.get((int)i).iProvinceID) continue;
            return this.civGameData.lFestivals.get(i);
        }
        return null;
    }

    protected final int isFestivalOrganized_TurnsLeft(int n) {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            if (n != this.civGameData.lFestivals.get((int)i).iProvinceID) continue;
            return this.civGameData.lFestivals.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final boolean isFirstReactor() {
        return this.civGameData.iFirstReactor;
    }

    protected final int isFriendlyCiv(int n) {
        for (int i = this.civGameData.lFriendlyCivs.size() - 1; i >= 0; --i) {
            if (this.civGameData.lFriendlyCivs.get((int)i).iCivID != n) continue;
            return (int)Math.ceil(this.civGameData.lFriendlyCivs.get((int)i).iSinceTurnID);
        }
        return -1;
    }

    protected final boolean isHatedCiv(int n) {
        for (int i = this.getHatedCivsSize() - 1; i >= 0; --i) {
            if (this.civGameData.lHatedCivs.get((int)i).iCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final boolean isHatedCivBy(int n) {
        for (int i = this.getHatedCivsSize() - 1; i >= 0; --i) {
            if (this.civGameData.lHatedCivs.get((int)i).iCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final int isInConstruction(int n, ConstructionType constructionType) {
        for (int i = 0; i < this.civGameData.lConstructions.size(); ++i) {
            if (this.civGameData.lConstructions.get((int)i).iProvinceID != n || this.civGameData.lConstructions.get((int)i).constructionType != constructionType) continue;
            return this.civGameData.lConstructions.get((int)i).iNumOfTurnsLeft;
        }
        return 0;
    }

    protected final boolean isInvestOrganized(int n) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (n != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            return true;
        }
        return false;
    }

    protected final boolean isInvestOrganized_Development(int n) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (n != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            return true;
        }
        return false;
    }

    protected final int isInvestOrganized_EconomyLeft(int n) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (n != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest.get((int)i).iEconomyLeft;
        }
        return 0;
    }

    protected final float isInvestOrganized_EconomyLeft_Development(int n) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (n != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest_Development.get((int)i).iDevelopemntLeft;
        }
        return 0.0f;
    }

    protected final CivInvest isInvestOrganized_GET(int n) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (n != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest.get(i);
        }
        return null;
    }

    protected final CivInvest_Development isInvestOrganized_GET_Development(int n) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (n != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest_Development.get(i);
        }
        return null;
    }

    protected final int isInvestOrganized_TurnsLeft(int n) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (n != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final int isInvestOrganized_TurnsLeft_Development(int n) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (n != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            return this.civGameData.lInvest_Development.get((int)i).iTurnsLeft;
        }
        return 0;
    }

    protected final boolean isMovingUnitsFromProvinceID(int n) {
        for (int i = 0; i < this.getMoveUnitsSize(); ++i) {
            if (this.getMoveUnits(i).getFromProvinceID() != n) continue;
            return true;
        }
        return false;
    }

    protected final boolean isMovingUnitsToProvinceID(int n) {
        for (int i = 0; i < this.getMoveUnitsSize(); ++i) {
            if (this.getMoveUnits(i).getToProvinceID() != n) continue;
            return true;
        }
        return false;
    }

    protected final int isMovingUnitsToProvinceID_Num(int n) {
        for (int i = 0; i < this.getMoveUnitsSize(); ++i) {
            if (this.getMoveUnits(i).getToProvinceID() != n) continue;
            return this.getMoveUnits(i).getNumOfUnits();
        }
        return 0;
    }

    protected final boolean isPlundred(int n) {
        for (int i = 0; i < this.iMove_Units_PlunderSize; ++i) {
            if (this.lMove_Units_Plunder.get(i).getFromProvinceID() != n) continue;
            return true;
        }
        return false;
    }

    protected final int isRecruitingArmyInProvinceID(int n) {
        for (int i = 0; i < this.iRecruitArmySize; ++i) {
            if (this.lRecruitArmy.get(i).getProvinceID() != n) continue;
            return i;
        }
        return -1;
    }

    protected final int isRegoupingArmy_ToProvinceID(int n) {
        for (int i = 0; i < this.civGameData.iRegroupArmySize; ++i) {
            if (this.civGameData.lRegroupArmy.get(i).getToProvinceID() != n) continue;
            return this.civGameData.lRegroupArmy.get(i).getNumOfUnits();
        }
        return 0;
    }

    /*
     * Exception decompiling
     */
    protected final boolean loadFlag() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 14[CATCHBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean messageWasSent(int n) {
        for (int i = this.civGameData.lSentMessages.size() - 1; i >= 0; --i) {
            if (this.civGameData.lSentMessages.get((int)i).iToCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final boolean messageWasSent(int n, Message_Type message_Type) {
        for (int i = this.civGameData.lSentMessages.size() - 1; i >= 0; --i) {
            if (this.civGameData.lSentMessages.get((int)i).iToCivID != n || this.civGameData.lSentMessages.get((int)i).messageType != message_Type) continue;
            return true;
        }
        return false;
    }

    protected final boolean messageWasSent(Message_Type message_Type) {
        for (int i = this.civGameData.lSentMessages.size() - 1; i >= 0; --i) {
            if (this.civGameData.lSentMessages.get((int)i).messageType != message_Type) continue;
            return true;
        }
        return false;
    }

    protected final boolean migratesFromProvinceID(int n) {
        for (int i = 0; i < this.iMigrateSize; ++i) {
            if (this.lMigrate.get(i).getFromProvinceID() != n) continue;
            return true;
        }
        return false;
    }

    protected final void moveRegroupArmy() {
        int n = 0;
        while (n < this.civGameData.iRegroupArmySize) {
            int n2;
            block12: {
                block11: {
                    if (!RegroupArmy_Data.canBeUsedInPath(this.getCivID(), this.civGameData.lRegroupArmy.get(n).getRoute(0), false, this.civGameData.lRegroupArmy.get(n).getToProvinceID())) {
                        this.removeRegroupArmy(n);
                        break block11;
                    }
                    if (!this.civGameData.lRegroupArmy.get(n).continueMovingArmy(this.getCivID())) {
                        this.removeRegroupArmy(n);
                        break block11;
                    }
                    if (this.civGameData.lRegroupArmy.get(n).getObsolate() < 0) {
                        this.removeRegroupArmy(n);
                        break block11;
                    }
                    this.civGameData.lRegroupArmy.get(n).updateObsolate();
                    if (CFG.game.getProvince(this.civGameData.lRegroupArmy.get(n).getFromProvinceID()).getArmyCivID(this.getCivID()) <= this.civGameData.lRegroupArmy.get(n).getNumOfUnits()) {
                        if (CFG.game.getProvince(this.civGameData.lRegroupArmy.get(n).getFromProvinceID()).getArmyCivID(this.getCivID()) <= 0) {
                            this.removeRegroupArmy(n);
                            break block11;
                        }
                        this.civGameData.lRegroupArmy.get(n).setNumOfUnits(CFG.game.getProvince(this.civGameData.lRegroupArmy.get(n).getFromProvinceID()).getArmyCivID(this.getCivID()));
                    }
                    n2 = n;
                    if (!CFG.gameAction.moveArmy(this.civGameData.lRegroupArmy.get(n).getFromProvinceID(), this.civGameData.lRegroupArmy.get(n).getRoute(0), this.civGameData.lRegroupArmy.get(n).getNumOfUnits(), this.getCivID(), true, true)) break block12;
                    this.civGameData.lRegroupArmy.get(n).setFromProvinceID(this.civGameData.lRegroupArmy.get(n).getRoute(0));
                    this.civGameData.lRegroupArmy.get(n).removeRoute(0);
                    this.lCurrentRegroupArmyLine.get(n).remove(0);
                    n2 = n;
                    try {
                        if (this.civGameData.lRegroupArmy.get(n).getRouteSize() != 0) break block12;
                        this.removeRegroupArmy(n);
                    }
                    catch (NullPointerException nullPointerException) {
                        this.removeRegroupArmy(n);
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        this.removeRegroupArmy(n);
                    }
                }
                n2 = n - 1;
            }
            n = n2 + 1;
        }
    }

    protected final void newMigrate(int n, int n2, boolean bl) {
        for (int i = 0; i < this.iMigrateSize; ++i) {
            if (this.lMigrate.get(i).getFromProvinceID() != n) continue;
            this.removeMigrate(i);
            this.setMovePoints(this.getMovePoints() + CFG.ideologiesManager.getIdeology((int)this.getIdeologyID()).COST_OF_MOVE);
            break;
        }
        this.lMigrate.add(new Move_Units(n, n2, CFG.game.getProvince(n).getPopulationData().getPopulation(), bl, true));
        this.iMigrateSize = this.lMigrate.size();
    }

    protected final void newMove(int n, int n2, int n3, boolean bl) {
        this.lMoveUnits.add(new Move_Units(n, n2, n3, bl));
        this.iMoveUnitsSize = this.lMoveUnits.size();
    }

    protected final void newPlunder(int n, int n2) {
        for (int i = 0; i < this.iMove_Units_PlunderSize; ++i) {
            if (this.lMove_Units_Plunder.get(i).getFromProvinceID() != n) continue;
            this.lMove_Units_Plunder.get(i).setNumOfUnits(n2);
            return;
        }
        this.lMove_Units_Plunder.add(new Move_Units_Plunder(n, n2));
        this.iMove_Units_PlunderSize = this.lMove_Units_Plunder.size();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean recruitArmy(int n, int n2) {
        int n3 = n2;
        if (n2 >= CFG.gameAction.getRecruitableArmy(n)) {
            n3 = CFG.gameAction.getRecruitableArmy(n);
        }
        for (n2 = 0; n2 < this.iRecruitArmySize; ++n2) {
            if (this.lRecruitArmy.get(n2).getProvinceID() != n) continue;
            if (n3 == 0 && this.lRecruitArmy.get(n2).getArmy() > 0) {
                CFG.game.getCiv(this.getCivID()).setMovePoints(CFG.game.getCiv(this.getCivID()).getMovePoints() + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT);
                CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() + (long)(this.lRecruitArmy.get(n2).getArmy() * CFG.getCostOfRecruitArmyMoney(n)));
                this.setManPower(this.getManPower() + this.lRecruitArmy.get(n2).getArmy());
                this.removeRecruitArmy(n2);
                return true;
            }
            int n4 = this.lRecruitArmy.get(n2).getArmy() - n3;
            this.lRecruitArmy.get(n2).setArmy(n3);
            CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() + (long)(CFG.getCostOfRecruitArmyMoney(n) * n4));
            this.setManPower(this.getManPower() + n4);
            return true;
        }
        if (this.getManPower() <= 0) return false;
        if (CFG.game.getCiv(this.getCivID()).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT) {
            Gdx.app.log("AoC", "RECRUIT NO MOVEMNETS POINTS 1111");
            return false;
        }
        n2 = n3;
        if ((long)n3 >= CFG.game.getCiv(this.getCivID()).getMoney() / (long)CFG.getCostOfRecruitArmyMoney(n)) {
            n2 = (int)CFG.game.getCiv(this.getCivID()).getMoney() / CFG.getCostOfRecruitArmyMoney(n);
        }
        if (n2 <= 0) {
            return false;
        }
        CFG.game.getCiv(this.getCivID()).setMovePoints(CFG.game.getCiv(this.getCivID()).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT);
        CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() - (long)(CFG.getCostOfRecruitArmyMoney(n) * n2));
        this.setManPower(this.getManPower() - n2);
        this.lRecruitArmy.add(new RecruitArmy_Request(n, n2));
        this.iRecruitArmySize = this.lRecruitArmy.size();
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean recruitArmyAutoPlan(int n, int n2) {
        int n3 = n2;
        if (n2 >= CFG.gameAction.getRecruitableArmyAutoplan(n)) {
            n3 = CFG.gameAction.getRecruitableArmyAutoplan(n);
        }
        for (n2 = 0; n2 < this.iRecruitArmySize; ++n2) {
            if (this.lRecruitArmy.get(n2).getProvinceID() != n) continue;
            if (n3 == 0 && this.lRecruitArmy.get(n2).getArmy() > 0) {
                CFG.game.getCiv(this.getCivID()).setMovePoints(CFG.game.getCiv(this.getCivID()).getMovePoints() + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT);
                CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() + (long)(this.lRecruitArmy.get(n2).getArmy() * CFG.getCostOfRecruitArmyMoneyAutoplan(n)));
                this.setManPower(this.getManPower() + this.lRecruitArmy.get(n2).getArmy());
                this.removeRecruitArmy(n2);
                return true;
            }
            int n4 = this.lRecruitArmy.get(n2).getArmy() - n3;
            this.lRecruitArmy.get(n2).setArmy(n3);
            CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() + (long)(CFG.getCostOfRecruitArmyMoneyAutoplan(n) * n4));
            this.setManPower(this.getManPower() + n4);
            return true;
        }
        if (this.getManPower() <= 0) return false;
        if (CFG.game.getCiv(this.getCivID()).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT) {
            Gdx.app.log("AoC", "RECRUIT NO MOVEMNETS POINTS 1111");
            return false;
        }
        n2 = n3;
        if ((long)n3 >= CFG.game.getCiv(this.getCivID()).getMoney() / (long)CFG.getCostOfRecruitArmyMoneyAutoplan(n)) {
            n2 = (int)CFG.game.getCiv(this.getCivID()).getMoney() / CFG.getCostOfRecruitArmyMoneyAutoplan(n);
        }
        if (n2 <= 0) {
            return false;
        }
        CFG.game.getCiv(this.getCivID()).setMovePoints(CFG.game.getCiv(this.getCivID()).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.getCivID()).getIdeologyID()).COST_OF_RECRUIT);
        CFG.game.getCiv(this.getCivID()).setMoney(CFG.game.getCiv(this.getCivID()).getMoney() - (long)(CFG.getCostOfRecruitArmyMoneyAutoplan(n) * n2));
        this.setManPower(this.getManPower() - n2);
        this.lRecruitArmy.add(new RecruitArmy_Request(n, n2));
        this.iRecruitArmySize = this.lRecruitArmy.size();
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean recruitArmyAutoplan_AI(int n, int n2) {
        int n3 = 0;
        while (n3 < this.iRecruitArmySize) {
            if (this.lRecruitArmy.get(n3).getProvinceID() == n) {
                return this.recruitArmyAutoPlan(n, Math.max(this.lRecruitArmy.get(n3).getArmy(), n2));
            }
            ++n3;
        }
        return this.recruitArmyAutoPlan(n, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean recruitArmy_AI(int n, int n2) {
        int n3 = 0;
        while (n3 < this.iRecruitArmySize) {
            if (this.lRecruitArmy.get(n3).getProvinceID() == n) {
                return this.recruitArmy(n, Math.max(this.lRecruitArmy.get(n3).getArmy(), n2));
            }
            ++n3;
        }
        return this.recruitArmy(n, n2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void recruitArmy_NewTurn() {
        int n = 0;
        while (true) {
            block7: {
                if (n >= this.iRecruitArmySize) {
                    this.clearRecruitArmy();
                    return;
                }
                try {
                    if (CFG.game.getProvince(this.lRecruitArmy.get(n).getProvinceID()).getCivID() == this.getCivID()) {
                        CFG.gameAction.recruitArmy(this.lRecruitArmy.get(n).getProvinceID(), this.lRecruitArmy.get(n).getArmy(), this.getCivID());
                        break block7;
                    }
                    Civilization civilization = CFG.game.getCiv(this.getCivID());
                    long l = CFG.game.getCiv(this.getCivID()).getMoney();
                    int n2 = this.lRecruitArmy.get(n).getArmy();
                    civilization.setMoney(l + (long)((int)((float)(CFG.getCostOfRecruitArmyMoney(this.lRecruitArmy.get(n).getProvinceID()) * n2) * 0.725f)));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
            }
            ++n;
        }
    }

    protected final void removeArmyInAnotherProvince(int n) {
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("removeArmyInAnotherProvince: ");
        stringBuilder.append(this.getCivName());
        stringBuilder.append(", nProvinceID: ");
        stringBuilder.append(n);
        stringBuilder.append(" -> ");
        stringBuilder.append(CFG.game.getProvince(n).getName());
        stringBuilder.append(", , ");
        stringBuilder.append(this.iArmyInAnotherProvinceSize);
        application.log("AoC", stringBuilder.toString());
        for (int i = 0; i < this.getArmyInAnotherProvinceSize(); ++i) {
            if (this.getArmyInAnotherProvince(i) != n) continue;
            this.lArmyInAnotherProvince.remove(i);
            this.iArmyInAnotherProvinceSize = this.lArmyInAnotherProvince.size();
            return;
        }
    }

    protected final void removeAssimilate(int n) {
        this.civGameData.lAssimilates.remove(n);
    }

    protected final void removeAssimilate_ProvinceID(int n) {
        for (int i = 0; i < this.civGameData.lAssimilates.size(); ++i) {
            if (n != this.civGameData.lAssimilates.get((int)i).iProvinceID) continue;
            this.civGameData.lAssimilates.remove(i);
            break;
        }
    }

    protected final void removeEventToRun(int n) {
        this.lEventsToRun.remove(n);
    }

    protected final void removeFestival(int n) {
        this.civGameData.lFestivals.remove(n);
    }

    protected final void removeFestival_ProvinceID(int n) {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            if (n != this.civGameData.lFestivals.get((int)i).iProvinceID) continue;
            this.civGameData.lFestivals.remove(i);
            break;
        }
    }

    protected final void removeFriendlyCiv(int n) {
        for (int i = this.civGameData.lFriendlyCivs.size() - 1; i >= 0; --i) {
            if (this.civGameData.lFriendlyCivs.get((int)i).iCivID != n) continue;
            this.civGameData.lFriendlyCivs.remove(i);
            return;
        }
    }

    protected final void removeHatedCiv(int n) {
        for (int i = this.getHatedCivsSize() - 1; i >= 0; --i) {
            if (this.civGameData.lHatedCivs.get((int)i).iCivID != n) continue;
            CFG.game.getCiv(this.civGameData.lHatedCivs.get((int)i).iCivID).removeHatedCiv_BY(this.getCivID());
            this.civGameData.lHatedCivs.remove(i);
            Save_Civ_GameData save_Civ_GameData = this.civGameData;
            save_Civ_GameData.iHatedCivsSize = save_Civ_GameData.lHatedCivs.size();
            return;
        }
    }

    protected final void removeHatedCiv_BY(int n) {
        for (int i = this.getHatedCivs_BySize() - 1; i >= 0; --i) {
            if (this.civGameData.lHatedCivs_By.get(i) != n) continue;
            this.civGameData.lHatedCivs_By.remove(i);
            Save_Civ_GameData save_Civ_GameData = this.civGameData;
            save_Civ_GameData.iHatedCivs_BySize = save_Civ_GameData.lHatedCivs_By.size();
            return;
        }
    }

    protected final void removeInvest(int n) {
        this.civGameData.lInvest.remove(n);
    }

    protected final void removeInvest_Development(int n) {
        this.civGameData.lInvest_Development.remove(n);
    }

    protected final void removeInvest_ProvinceID(int n) {
        for (int i = 0; i < this.civGameData.lInvest.size(); ++i) {
            if (n != this.civGameData.lInvest.get((int)i).iProvinceID) continue;
            this.civGameData.lInvest.remove(i);
            break;
        }
    }

    protected final void removeInvest_ProvinceID_Development(int n) {
        for (int i = 0; i < this.civGameData.lInvest_Development.size(); ++i) {
            if (n != this.civGameData.lInvest_Development.get((int)i).iProvinceID) continue;
            this.civGameData.lInvest_Development.remove(i);
            break;
        }
    }

    protected final void removeLoan(int n) {
        this.civGameData.lLoansTaken.remove(n);
    }

    protected final void removeMigrate(int n) {
        this.lMigrate.remove(n);
        this.iMigrateSize = this.lMigrate.size();
    }

    protected final void removeMove(int n) {
        this.lMoveUnits.remove(n);
        this.iMoveUnitsSize = this.lMoveUnits.size();
    }

    protected final void removePlunder(int n) {
        this.lMove_Units_Plunder.remove(n);
        this.iMove_Units_PlunderSize = this.lMove_Units_Plunder.size();
    }

    protected final void removePlunder_ProvinceID(int n) {
        for (int i = 0; i < this.iMove_Units_PlunderSize; ++i) {
            if (this.lMove_Units_Plunder.get(i).getFromProvinceID() != n) continue;
            CFG.game.getProvince(this.lMove_Units_Plunder.get(i).getFromProvinceID()).updateArmy(this.getCivID(), CFG.game.getProvince(this.lMove_Units_Plunder.get(i).getFromProvinceID()).getArmyCivID(this.getCivID()) + this.lMove_Units_Plunder.get(i).getNumOfUnits());
            this.lMove_Units_Plunder.remove(i);
            this.iMove_Units_PlunderSize = this.lMove_Units_Plunder.size();
            return;
        }
    }

    protected final void removeProvince(int n) {
        for (int i = 0; i < this.iNumOfProvinces; ++i) {
            if (this.lProvinces.get(i) != n) continue;
            this.lProvinces.remove(i);
            this.iNumOfProvinces = this.lProvinces.size();
            break;
        }
        CFG.game.getProvince(n).setCivRegionID(-1);
    }

    protected final void removeRecruitArmy(int n) {
        this.lRecruitArmy.remove(n);
        this.iRecruitArmySize = this.lRecruitArmy.size();
    }

    protected final void removeRegroupArmy(int n) {
        this.civGameData.lRegroupArmy.remove(n);
        this.lCurrentRegroupArmyLine.remove(n);
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iRegroupArmySize = save_Civ_GameData.lRegroupArmy.size();
    }

    protected final void removeSentMessage(int n) {
        this.civGameData.lSentMessages.remove(n);
    }

    protected final void removeSentMessages(Message_Type message_Type) {
        for (int i = this.civGameData.lSentMessages.size() - 1; i >= 0; --i) {
            if (this.civGameData.lSentMessages.get((int)i).messageType != message_Type) continue;
            this.civGameData.lSentMessages.remove(i);
        }
    }

    protected final void removeTagsCanForm(int n) {
        this.sTagsCanForm.remove(n);
    }

    protected final void removeTagsCanForm(String string2) {
        for (int i = 0; i < this.sTagsCanForm.size(); ++i) {
            if (!this.sTagsCanForm.get(i).equals(string2)) continue;
            this.sTagsCanForm.remove(i);
            return;
        }
    }

    protected final void removeVassal(int n) {
        for (int i = 0; i < this.civGameData.lVassals.size(); ++i) {
            if (this.civGameData.lVassals.get((int)i).iCivID != n) continue;
            this.civGameData.lVassals.remove(i);
            Save_Civ_GameData save_Civ_GameData = this.civGameData;
            save_Civ_GameData.iVassalsSize = save_Civ_GameData.lVassals.size();
            return;
        }
    }

    protected final void runAssimilates() {
        int n = 0;
        while (n < this.civGameData.lAssimilates.size()) {
            int n2;
            block7: {
                block8: {
                    List<CivFestival> list;
                    block6: {
                        int n3;
                        int n4;
                        if (CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getCivID() != this.getCivID()) break block6;
                        list = this.civGameData.lAssimilates.get(n);
                        --((CivFestival)list).iTurnsLeft;
                        int n5 = CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getPopulationOfCivID(this.getCivID()) + 1;
                        n2 = 0;
                        for (n4 = 0; n4 < CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getNationalitiesSize(); ++n4) {
                            n3 = n2;
                            if (CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getCivID(n4) != CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getCivID()) {
                                n3 = n2 + CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getPopulationID(n4);
                            }
                            n2 = n3;
                        }
                        n4 = 0;
                        for (n3 = CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getNationalitiesSize() - 1; n3 >= 0; --n3) {
                            int n6 = n4;
                            if (CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getCivID(n3) != CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getCivID()) {
                                int n7;
                                float f = (float)CFG.oR.nextInt(1087) / 10000.0f;
                                float f2 = (float)n5 / (float)(n2 + n5);
                                float f3 = (float)Math.pow(f2, 2.0);
                                float f4 = CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getHappiness();
                                float f5 = Math.min(1.0f - CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getDevelopmentLevel() / 3.75f, 1.0f);
                                float f6 = CFG.game.getCiv(this.getCivID()).getStability();
                                float f7 = CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getRevolutionaryRisk();
                                n6 = this.getCivID();
                                float f8 = CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n6).getIdeologyID()).ASSIMILATE_RATE;
                                float f9 = CFG.gameAges.getAge_AssimilateRate(Game_Calendar.CURRENT_AGEID);
                                n6 = n7 = (int)((float)CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getPopulationID(n3) * (((f + 0.04971f) * (f2 * 4.222176f + f3 * -4.44444f + 0.29999998f) * f4 * f5 + 0.00425f) * (1.0f - (1.0f - f6) * 0.225f - f7 * 0.075f) * 0.31640625f * f8 * f9));
                                if (n7 == 0) {
                                    n6 = 1;
                                }
                                n4 += n6;
                                CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().setPopulationOfCivID(CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getCivID(n3), CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getPopulationID(n3) - n6);
                                n6 = n4;
                            }
                            n4 = n6;
                        }
                        CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().setPopulationOfCivID(this.getCivID(), CFG.game.getProvince(this.civGameData.lAssimilates.get((int)n).iProvinceID).getPopulationData().getPopulationOfCivID(this.getCivID()) + n4);
                        n2 = n;
                        if (this.civGameData.lAssimilates.get((int)n).iTurnsLeft > 0) break block7;
                        CFG.game.getCiv((int)this.iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_AssimilationEnd(this.iCivID, this.civGameData.lAssimilates.get((int)n).iProvinceID));
                        list = this.civGameData.lAssimilates;
                        n2 = n - 1;
                        list.remove(n);
                        n = n2;
                        break block8;
                    }
                    list = this.civGameData.lAssimilates;
                    n2 = n - 1;
                    list.remove(n);
                    n = n2;
                }
                n2 = n;
            }
            n = n2 + 1;
        }
    }

    protected final void runCommerce() {
        if (!this.civGameData.closingTheCommerce && this.iNumOfProvinces > 0) {
            for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
                long l;
                long l2;
                Civilization civilization = CFG.game.getCiv(i);
                if (civilization.iNumOfProvinces <= 0) continue;
                float f = CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).COMMERCE_RANGE;
                float f2 = CFG.gameAges.getAge_CommerceRange(Game_Calendar.CURRENT_AGEID);
                if (!(CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(civilization.getCapitalProvinceID(), this.getCapitalProvinceID()) <= f * f2)) continue;
                f = civilization.getCivCommercePower();
                f2 = this.getCivCommercePower() / f;
                f = civilization.getCivCommercePower_GDP();
                long l3 = (long)(Math.min(f, f2 * f) * civilization.getCivCommercePower_Other() * this.getCivCommercePower_Other());
                int n = this.iCivID;
                if (CFG.game.getCivRelation_OfCivB(i, n) > 30.0f) {
                    l2 = civilization.civGameData.iMoney;
                    l = l3 / 2L;
                    civilization.civGameData.iMoney = l2 - l;
                    l = this.civGameData.iMoney;
                    this.civGameData.iMoney = l + l3 * 3L;
                    continue;
                }
                l = civilization.civGameData.iMoney;
                l2 = l3 / 2L;
                civilization.civGameData.iMoney = l - l2;
                l = this.civGameData.iMoney;
                this.civGameData.iMoney = l + l3;
            }
        }
    }

    protected final void runConstruction() {
        for (int i = 0; i < this.civGameData.lConstructions.size(); ++i) {
            int n;
            List<Construction_GameData> list;
            if (CFG.game.getProvince(this.civGameData.lConstructions.get((int)i).iProvinceID).getCivID() != this.getCivID()) {
                list = this.civGameData.lConstructions;
                n = i - 1;
                list.remove(i);
                i = n;
                continue;
            }
            list = this.civGameData.lConstructions.get(i);
            --((Construction_GameData)list).iNumOfTurnsLeft;
            if (this.civGameData.lConstructions.get((int)i).iNumOfTurnsLeft > 0) continue;
            this.civGameData.lConstructions.get(i).onConstructed(this.getCivID());
            list = this.civGameData.lConstructions;
            n = i - 1;
            list.remove(i);
            i = n;
        }
    }

    protected final void runFestivals() {
        for (int i = 0; i < this.civGameData.lFestivals.size(); ++i) {
            int n;
            List<CivFestival> list;
            if (CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).getCivID() == this.getCivID()) {
                list = this.civGameData.lFestivals.get(i);
                --((CivFestival)list).iTurnsLeft;
                CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).setHappiness(CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).getHappiness() + DiplomacyManager.festivalHappinessPerTurn(this.civGameData.lFestivals.get((int)i).iProvinceID));
                for (n = 0; n < CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).getNeighboringProvincesSize(); ++n) {
                    CFG.game.getProvince(CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).getNeighboringProvinces(n)).setHappiness(CFG.game.getProvince(CFG.game.getProvince(this.civGameData.lFestivals.get((int)i).iProvinceID).getNeighboringProvinces(n)).getHappiness() + DiplomacyManager.festivalHappinessPerTurn_NeighboringProvinces());
                }
                if (this.civGameData.lFestivals.get((int)i).iTurnsLeft > 0) continue;
                CFG.game.getCiv((int)this.iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_FestivalIsOver(this.iCivID, this.civGameData.lFestivals.get((int)i).iProvinceID));
                list = this.civGameData.lFestivals;
                n = i - 1;
                list.remove(i);
                i = n;
                continue;
            }
            list = this.civGameData.lFestivals;
            n = i - 1;
            list.remove(i);
            i = n;
        }
    }

    protected final void runInvests() {
        int n = 0;
        while (n < this.civGameData.lInvest.size()) {
            int n2;
            block4: {
                block5: {
                    List<CivInvest> list;
                    block2: {
                        block3: {
                            if (CFG.game.getProvince(this.civGameData.lInvest.get((int)n).iProvinceID).getCivID() != this.getCivID()) break block2;
                            list = this.civGameData.lInvest.get(n);
                            --((CivInvest)list).iTurnsLeft;
                            n2 = Math.min(this.civGameData.lInvest.get((int)n).iEconomyPerTurn, this.civGameData.lInvest.get((int)n).iEconomyLeft);
                            if (this.civGameData.lInvest.get((int)n).iTurnsLeft == 0) {
                                n2 = this.civGameData.lInvest.get((int)n).iEconomyLeft;
                            }
                            CFG.game.getProvince(this.civGameData.lInvest.get((int)n).iProvinceID).setEconomy(CFG.game.getProvince(this.civGameData.lInvest.get((int)n).iProvinceID).getEconomy() + n2);
                            list = this.civGameData.lInvest.get(n);
                            ((CivInvest)list).iEconomyLeft -= n2;
                            if (this.civGameData.lInvest.get((int)n).iTurnsLeft <= 0) break block3;
                            n2 = n;
                            if (this.civGameData.lInvest.get((int)n).iEconomyLeft > 0) break block4;
                        }
                        CFG.game.getCiv((int)this.iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_InvestDone(this.iCivID, this.civGameData.lInvest.get((int)n).iProvinceID));
                        list = this.civGameData.lInvest;
                        n2 = n - 1;
                        list.remove(n);
                        n = n2;
                        break block5;
                    }
                    list = this.civGameData.lInvest;
                    n2 = n - 1;
                    list.remove(n);
                    n = n2;
                }
                n2 = n;
            }
            n = n2 + 1;
        }
    }

    protected final void runInvests_Development() {
        int n = 0;
        while (n < this.civGameData.lInvest_Development.size()) {
            int n2;
            block4: {
                block5: {
                    List<CivInvest_Development> list;
                    block2: {
                        block3: {
                            if (CFG.game.getProvince(this.civGameData.lInvest_Development.get((int)n).iProvinceID).getCivID() != this.getCivID()) break block2;
                            list = this.civGameData.lInvest_Development.get(n);
                            --((CivInvest_Development)list).iTurnsLeft;
                            float f = Math.min(this.civGameData.lInvest_Development.get((int)n).iDevelopemntPerTurn, this.civGameData.lInvest_Development.get((int)n).iDevelopemntLeft);
                            if (this.civGameData.lInvest_Development.get((int)n).iTurnsLeft == 0) {
                                f = this.civGameData.lInvest_Development.get((int)n).iDevelopemntLeft;
                            }
                            CFG.game.getProvince(this.civGameData.lInvest_Development.get((int)n).iProvinceID).setDevelopmentLevel(CFG.game.getProvince(this.civGameData.lInvest_Development.get((int)n).iProvinceID).getDevelopmentLevel() + f);
                            list = this.civGameData.lInvest_Development.get(n);
                            ((CivInvest_Development)list).iDevelopemntLeft -= f;
                            if (this.civGameData.lInvest_Development.get((int)n).iTurnsLeft <= 0) break block3;
                            n2 = n;
                            if (!(this.civGameData.lInvest_Development.get((int)n).iDevelopemntLeft <= 0.0f)) break block4;
                        }
                        CFG.game.getCiv((int)this.iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_InvestDone_Development(this.iCivID, this.civGameData.lInvest_Development.get((int)n).iProvinceID));
                        list = this.civGameData.lInvest_Development;
                        n2 = n - 1;
                        list.remove(n);
                        n = n2;
                        break block5;
                    }
                    list = this.civGameData.lInvest_Development;
                    n2 = n - 1;
                    list.remove(n);
                    n = n2;
                }
                n2 = n;
            }
            n = n2 + 1;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void runNextEvent() {
        block18: {
            if (!this.getControlledByPlayer()) break block18;
            if (this.getEventsToRunSize() <= 0) return;
            Menu_InGame_Event.EVENT_ID = this.getEventsToRun(0);
            this.removeEventToRun(0);
            CFG.menuManager.rebuildInGame_Event();
            return;
        }
        for (var1_1 = this.getEventsToRunSize() - 1; var1_1 >= 0; --var1_1) {
            block19: {
                var2_2 = new StringBuilder();
                var2_2.append("runEvent: ");
                var2_2.append(this.getCivName());
                var2_2.append(": ");
                var2_2.append(CFG.eventsManager.getEvent(this.getEventsToRun(var1_1)).getEventName());
                Commands.addMessage(var2_2.toString());
                var3_5 = 0;
                var4_6 = 0;
                while (true) {
                    if (var3_5 >= CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.size()) break;
                    var4_6 += CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.get((int)var3_5).iAIChance;
                    ++var3_5;
                    continue;
                    break;
                }
                var5_7 = CFG.oR.nextInt(var4_6);
                var4_6 = 0;
                var3_5 = 0;
                while (true) {
                    if (var4_6 >= CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.size()) break;
                    if (var5_7 < var3_5) ** GOTO lbl39
                    if (var5_7 < CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.get((int)var4_6).iAIChance + var3_5) break block19;
lbl39:
                    // 2 sources

                    var3_5 += CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.get((int)var4_6).iAIChance;
                    ++var4_6;
                    continue;
                    break;
                }
                var4_6 = 0;
            }
            try {
                if (CFG.eventsManager.getEvent(this.getEventsToRun(var1_1)).getCivID() >= 0) {
                    var2_2 = CFG.game.getCiv(CFG.eventsManager.getEvent(this.getEventsToRun(var1_1)).getCivID());
                    var6_8 = new StringBuilder();
                    var6_8.append(CFG.eventsManager.getEvent(this.getEventsToRun(var1_1)).getEventTag());
                    var6_8.append("_");
                    var6_8.append(var4_6);
                    var2_2.addEvent_DecisionTaken(var6_8.toString());
                }
                var2_2 = new StringBuilder();
                var2_2.append("runEvent: ");
                var2_2.append(this.getCivName());
                var2_2.append(": Decision: ");
                var2_2.append(CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.get((int)var4_6).sTitle);
                Commands.addMessage(var2_2.toString());
                CFG.eventsManager.getEvent((int)this.getEventsToRun((int)var1_1)).lDecisions.get(var4_6).executeDecision();
                this.removeEventToRun(0);
                continue;
            }
            catch (IndexOutOfBoundsException var2_3) {
                CFG.exceptionStack(var2_3);
            }
        }
        return;
        {
            catch (IllegalArgumentException | IndexOutOfBoundsException | NullPointerException | StackOverflowError var2_4) {
                return;
            }
        }
    }

    protected final void runWarReparations() {
        int n;
        WarReparations warReparations;
        int n2;
        for (n2 = this.civGameData.lWarReparationsPay.size() - 1; n2 >= 0; --n2) {
            warReparations = this.civGameData.lWarReparationsPay.get(n2);
            n = warReparations.iTurnsLeft;
            warReparations.iTurnsLeft = n - 1;
            if (n > 0) continue;
            this.getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_WarReparationsRepaid_Green(this.civGameData.lWarReparationsPay.get((int)n2).iFromCivID));
            this.civGameData.lWarReparationsPay.remove(n2);
        }
        for (n2 = this.civGameData.lWarReparationsGets.size() - 1; n2 >= 0; --n2) {
            warReparations = this.civGameData.lWarReparationsGets.get(n2);
            n = warReparations.iTurnsLeft;
            warReparations.iTurnsLeft = n - 1;
            if (n > 0) continue;
            this.getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_WarReparationsRepaid(this.civGameData.lWarReparationsGets.get((int)n2).iFromCivID));
            this.civGameData.lWarReparationsGets.remove(n2);
        }
    }

    protected final void setAI_Style(int n) {
        this.civGameData.iAI_Style = n;
    }

    protected final void setAllianceID(int n) {
        this.civGameData.iAllianceID = n;
    }

    public void setAtNuclearWar() {
        this.isAtNuclearWar = true;
    }

    protected final void setB(int n) {
        this.civGameData.iB = (short)n;
    }

    protected final void setBordersWithEnemy(int n) {
        this.bordersWithEnemy = n;
    }

    protected final void setCanExpandOnContinent(boolean bl) {
        this.canExpandOnContinent = bl;
    }

    protected final void setCapitalMoved_LastTurnID(int n) {
        this.civGameData.iCapitalMoved_LastTurnID = n;
    }

    protected final void setCapitalProvinceID(int n) {
        this.civGameData.iCapitalProvinceID = n;
    }

    protected final void setCivID(int n) {
        this.iCivID = n;
        this.civGameData.iPuppetOfCivID = n;
        this.iRankPosition = n;
    }

    protected final void setCivID_Just(int n) {
        this.iCivID = n;
    }

    protected final void setCivName(String string2) {
        String string3 = string2;
        if (string2.length() <= 0) {
            string3 = "A";
        }
        this.civGameData.sCivName = string3;
        CFG.glyphLayout.setText(CFG.fontMain, string3);
        this.iCivNameWidth = (int)CFG.glyphLayout.width;
        this.iCivNameHeight = (int)CFG.glyphLayout.height;
        this.lCivNameChars = new ArrayList<Character>();
        string2 = string3.toUpperCase();
        for (int i = 0; i < this.civGameData.sCivName.length(); ++i) {
            this.lCivNameChars.add(Character.valueOf(string2.charAt(i)));
        }
        this.iCivNameLength = this.lCivNameChars.size();
    }

    protected final void setCivTag(String string2) {
        this.civGameData.sCivTag = string2;
        if (string2.indexOf(59) > 0) {
            String[] arrstring = string2.split(";");
            string2 = "";
            for (int i = 0; i < arrstring.length; ++i) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append(CFG.langManager.getCiv(arrstring[i]));
                string2 = i < arrstring.length - 1 ? " \u0438 " : "";
                stringBuilder.append(string2);
                string2 = stringBuilder.toString();
            }
            this.setCivName(string2);
        } else {
            this.setCivName(CFG.langManager.getCiv(string2));
        }
    }

    protected final void setClosingTheCommerce(boolean bl) {
        this.civGameData.closingTheCommerce = bl;
    }

    protected final void setControlledByPlayer(boolean bl) {
        this.controlledByPlayer = bl;
    }

    protected final void setCoreCapitalProvinceID(int n) {
        this.civGameData.iCoreCapitalProvinceID = n;
    }

    protected final boolean setDefensivePact(int n, int n2) {
        block13: {
            int n3;
            if (n2 < 0) {
                n3 = 0;
            } else {
                n3 = n2;
                if (n2 > 200) {
                    n3 = 200;
                }
            }
            this.lDefensivePact.set(n, n3);
            if (n3 <= 0) break block13;
            n2 = 0;
            while (true) {
                if (n2 >= this.lOpt_DefensivePact.size()) break;
                if (this.lOpt_DefensivePact.get(n2) == n) {
                    return false;
                }
                ++n2;
                continue;
                break;
            }
            try {
                this.lOpt_DefensivePact.add(n);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                this.lDefensivePact.add(0);
            }
        }
        n2 = 0;
        while (true) {
            if (n2 < this.lOpt_DefensivePact.size()) {
                if (this.lOpt_DefensivePact.get(n2) == n) {
                    this.lOpt_DefensivePact.remove(n2);
                    return true;
                }
                ++n2;
                continue;
            }
            break;
        }
        return false;
    }

    protected final void setDiplomacyPoints(int n) {
        int n2 = n;
        if ((float)n > this.getTechnologyLevel() * 85.0f / 4.0f + 85.0f) {
            n2 = n;
            if (n > this.civGameData.iDiplomacyPoints) {
                n2 = n = this.civGameData.iDiplomacyPoints + 1;
                if (n > 500) {
                    n2 = 500;
                }
            }
        }
        this.civGameData.iDiplomacyPoints = n2;
    }

    protected final void setFirstReactor(boolean bl) {
        this.civGameData.iFirstReactor = bl;
    }

    protected final void setFlag(Image image) {
        this.disposeFlag();
        this.civFlag = image;
    }

    protected final void setG(int n) {
        this.civGameData.iG = (short)n;
    }

    public void setGoldenAge_Military(int n) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iGoldenAge_Military = save_Civ_GameData.iGoldenAge_Military;
    }

    public void setGoldenAge_Prosperity(int n) {
        this.civGameData.iGoldenAge_Prosperity = n;
    }

    public void setGoldenAge_Science(int n) {
        this.civGameData.iGoldenAge_Science = n;
    }

    protected final boolean setGuarantee(int n, int n2) {
        block13: {
            int n3;
            if (n2 < 0) {
                n3 = 0;
            } else {
                n3 = n2;
                if (n2 > 125) {
                    n3 = 125;
                }
            }
            this.lGuarantee.set(n, (byte)n3);
            if (n3 <= 0) break block13;
            n2 = 0;
            while (true) {
                if (n2 >= this.lOpt_Guarantee.size()) break;
                if (this.lOpt_Guarantee.get(n2) == n) {
                    return false;
                }
                ++n2;
                continue;
                break;
            }
            try {
                this.lOpt_Guarantee.add(n);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                this.lGuarantee.add((byte)0);
            }
        }
        n2 = 0;
        while (true) {
            if (n2 < this.lOpt_Guarantee.size()) {
                if (this.lOpt_Guarantee.get(n2) == n) {
                    this.lOpt_Guarantee.remove(n2);
                    return true;
                }
                ++n2;
                continue;
            }
            break;
        }
        return false;
    }

    protected final void setHappiness(int n) {
        this.iHappiness = n;
        if ((n = this.iHappiness) > 100) {
            this.iHappiness = 100;
        } else if (n < 0) {
            this.iHappiness = 0;
        }
    }

    protected final void setHappiness_10Turn(float f) {
        this.civGameData.iHappiness_10Turn = f;
    }

    protected final void setIdeologyID(int n) {
        this.iIdeologyID = n;
        this.setAI_Style(CFG.oAI.getAIStyle_ByTag(CFG.ideologiesManager.getIdeology((int)this.getIdeologyID()).AI_TYPE));
    }

    protected final void setInReformation(int n) {
        this.civGameData.iInReformation = n;
    }

    protected final void setIsAlliedWithPlayer(boolean bl) {
        this.civGameData.isAlliedWithPlayer = bl;
    }

    protected final void setIsAtWar(boolean bl) {
        this.isAtWar = bl;
    }

    protected final void setIsAvailable(boolean bl) {
        this.isAvailable = bl;
    }

    protected final void setIsPartOfHolyRomanEmpire(boolean bl) {
        this.civGameData.isPartOfHolyRomaEmpire = bl;
    }

    protected final void setManPower(int n) {
        this.civGameData.iManPower = n;
    }

    protected final void setManPowerPerTurn(int n) {
        this.civGameData.iManPowerIncreasing_PerTurn = n;
    }

    protected final void setManPower_ThisTurn(int n) {
        this.civGameData.iManPower_InThisTurn = n;
    }

    protected final boolean setMilitaryAccess(int n, int n2) {
        block13: {
            int n3;
            if (n2 < 0) {
                n3 = 0;
            } else {
                n3 = n2;
                if (n2 > 200) {
                    n3 = 200;
                }
            }
            this.lMilitirayAccess.set(n, (byte)n3);
            if (n3 <= 0) break block13;
            n2 = 0;
            while (true) {
                if (n2 >= this.lOpt_MilitirayAccess.size()) break;
                if (this.lOpt_MilitirayAccess.get(n2) == n) {
                    return false;
                }
                ++n2;
                continue;
                break;
            }
            try {
                this.lOpt_MilitirayAccess.add(n);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                this.lMilitirayAccess.add((byte)0);
            }
        }
        n2 = 0;
        while (true) {
            if (n2 < this.lOpt_MilitirayAccess.size()) {
                if (this.lOpt_MilitirayAccess.get(n2) == n) {
                    this.lOpt_MilitirayAccess.remove(n2);
                    return true;
                }
                ++n2;
                continue;
            }
            break;
        }
        return false;
    }

    protected final void setModifier_AttackBonus(float f) {
        this.civGameData.fModifier_AttackBonus = f;
    }

    protected final void setModifier_DefenseBonus(float f) {
        this.civGameData.fModifier_DefenseBonus = f;
    }

    protected final void setModifier_EconomyGrowth(float f) {
        this.civGameData.fModifier_EconomyGrowth = f;
    }

    protected final void setModifier_IncomeProduction(float f) {
        this.civGameData.fModifier_IncomeProduction = f;
    }

    protected final void setModifier_IncomeTaxation(float f) {
        this.civGameData.fModifier_IncomeTaxation = f;
    }

    protected final void setModifier_MilitaryUpkeep(float f) {
        this.civGameData.fModifier_MilitaryUpkeep = f;
    }

    protected final void setModifier_MovementPoints(float f) {
        this.civGameData.fModifier_MovementPoints = f;
    }

    protected final void setModifier_PopGrowth(float f) {
        this.civGameData.fModifier_PopGrowth = f;
    }

    protected final void setModifier_Research(float f) {
        this.civGameData.fModifier_Research = f;
    }

    protected final void setMoney(long l) {
        this.civGameData.iMoney = l;
    }

    protected final void setMovePoints(int n) {
        this.iMovePoints = n;
    }

    protected final void setNextElection(int n) {
        this.civGameData.iNextElection = n;
    }

    protected final boolean setNonAggressionPact(int n, int n2) {
        block13: {
            int n3;
            if (n2 < 0) {
                n3 = 0;
            } else {
                n3 = n2;
                if (n2 > 200) {
                    n3 = 200;
                }
            }
            this.lNonAggressionPact.set(n, n3);
            if (n3 <= 0) break block13;
            n2 = 0;
            while (true) {
                if (n2 >= this.lOpt_NonAggressionPact.size()) break;
                if (this.lOpt_NonAggressionPact.get(n2) == n) {
                    return false;
                }
                ++n2;
                continue;
                break;
            }
            try {
                this.lOpt_NonAggressionPact.add(n);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                this.lNonAggressionPact.add(0);
            }
        }
        n2 = 0;
        while (true) {
            if (n2 < this.lOpt_NonAggressionPact.size()) {
                if (this.lOpt_NonAggressionPact.get(n2) == n) {
                    this.lOpt_NonAggressionPact.remove(n2);
                    return true;
                }
                ++n2;
                continue;
            }
            break;
        }
        return false;
    }

    protected final void setNuclearWeapons(int n) {
        int n2 = n;
        if (n <= 0) {
            n2 = 0;
        }
        this.civGameData.iNuclearWeapons = n2;
    }

    protected final void setNuclearWeaponsPerTurn(int n) {
        this.civGameData.iNuclearWeaponsPerTurn = n;
    }

    protected final void setNuclearWeaponsTurn(int n) {
        this.civGameData.iNuclearWeaponsTurn = n;
    }

    protected final void setNumOfNeighboringNeutralProvinces(int n) {
        this.iNumOfNeighboringNeutralProvinces = n;
    }

    protected final void setNumOfProvincesWithoutOccupied(int n) {
        this.iNumOfProvincesWithoutOccupied = n;
    }

    protected final void setNumOfUnits(int n) {
        this.iNumOfUnits = Math.max(n, 0);
    }

    protected final void setPuppetOfCivID(int n) {
        if (this.civGameData.iPuppetOfCivID != this.iCivID && this.civGameData.iPuppetOfCivID != n) {
            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
        }
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iPuppetOfCivID = n;
        if (save_Civ_GameData.iPuppetOfCivID != this.iCivID) {
            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).addVassal(this.iCivID);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void setPuppetOfCivID(int n, boolean bl) {
        Object object;
        int n2;
        block10: {
            block11: {
                Object object2;
                block8: {
                    block9: {
                        block6: {
                            block7: {
                                int n3;
                                if (bl) break block6;
                                if (this.getPuppetOfCivID() != this.iCivID && (n3 = this.getAllianceID()) == CFG.game.getCiv(n2 = this.getPuppetOfCivID()).getAllianceID()) {
                                    DiplomacyManager.leaveAlliance(this.iCivID);
                                }
                                if (this.iCivID == n) break block6;
                                for (n2 = 0; n2 < CFG.game.getCivsSize(); ++n2) {
                                    if (this.iCivID == n2 || n == n2) continue;
                                    object = CFG.game;
                                    n3 = this.iCivID;
                                    ((Game)object).setCivRelation_OfCivB(n2, n3, 0.0f);
                                    ((Game)object).setCivRelation_OfCivB(n3, n2, 0.0f);
                                }
                                for (n2 = 0; (n3 = this.civGameData.lVassals.size()) != 0 && n2 <= n3; ++n2) {
                                    n3 = this.civGameData.lVassals.get((int)n2).iCivID;
                                    CFG.game.getCiv(n3).setPuppetOfCivID(n3, false);
                                }
                                if (CFG.game.getCiv(n).getPuppetOfCivID() != n) break block7;
                                CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                                this.civGameData.iPuppetOfCivID = n;
                                if (this.civGameData.iPuppetOfCivID == this.iCivID) return;
                                object2 = CFG.game;
                                object = CFG.game;
                                object = CFG.ideologiesManager;
                                object2 = ((Game)object2).getCiv(this.civGameData.iPuppetOfCivID);
                                n = ((Civilization)object2).getIdeologyID();
                                n2 = this.iCivID;
                                if (object.getIdeology((int)n).CANT_CHANGE_GOV_OF_VASSAL) break block8;
                                CFG.game.updateCivilizationIdeology(n2, CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n2).getCivTag()) + CFG.ideologiesManager.getIdeology(n).getExtraTag());
                                CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n2);
                                break block9;
                            }
                            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                            this.civGameData.iPuppetOfCivID = CFG.game.getCiv(n).getPuppetOfCivID();
                            if (this.civGameData.iPuppetOfCivID == this.iCivID) return;
                            object = CFG.game;
                            Object object3 = CFG.game;
                            object3 = CFG.ideologiesManager;
                            object = ((Game)object).getCiv(this.civGameData.iPuppetOfCivID);
                            n = ((Civilization)object).getIdeologyID();
                            n2 = this.iCivID;
                            if (object3.getIdeology((int)n).CANT_CHANGE_GOV_OF_VASSAL) break block10;
                            CFG.game.updateCivilizationIdeology(n2, CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n2).getCivTag()) + CFG.ideologiesManager.getIdeology(n).getExtraTag());
                            CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n2);
                            break block11;
                        }
                        if (this.civGameData.iPuppetOfCivID != this.iCivID && this.civGameData.iPuppetOfCivID != n) {
                            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                        }
                        this.civGameData.iPuppetOfCivID = n;
                        if (this.civGameData.iPuppetOfCivID == this.iCivID) return;
                        CFG.game.getCiv(this.civGameData.iPuppetOfCivID).addVassal(this.iCivID);
                        return;
                    }
                    for (n = 0; n < CFG.game.getPlayersSize(); ++n) {
                        if (CFG.game.getPlayer(n).getCivID() != n2) continue;
                        CFG.game.getPlayer(n).loadPlayersFlag();
                        break;
                    }
                }
                DiplomacyManager.leaveAlliance(n2);
                ((Civilization)object2).addVassal(n2);
                n = this.civGameData.iPuppetOfCivID;
                DiplomacyManager.acceptAllianceProposal(this.iCivID, n);
                return;
            }
            for (n = 0; n < CFG.game.getPlayersSize(); ++n) {
                if (CFG.game.getPlayer(n).getCivID() != n2) continue;
                CFG.game.getPlayer(n).loadPlayersFlag();
                break;
            }
        }
        DiplomacyManager.leaveAlliance(n2);
        ((Civilization)object).addVassal(n2);
        n = this.civGameData.iPuppetOfCivID;
        DiplomacyManager.acceptAllianceProposal(this.iCivID, n);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void setPuppetOfCivID_Empire(int n, boolean bl) {
        if (CFG.game.getCivsAtWar(this.iCivID, n)) return;
        if (!bl) {
            int n2;
            int n3;
            if (this.getPuppetOfCivID() != this.iCivID && (n3 = this.getAllianceID()) == CFG.game.getCiv(n2 = this.getPuppetOfCivID()).getAllianceID()) {
                DiplomacyManager.leaveAlliance(this.iCivID);
            }
            if (this.iCivID != n) {
                while (this.civGameData.lVassals.size() != 0) {
                    n2 = this.civGameData.lVassals.get((int)0).iCivID;
                    CFG.game.getCiv(n2).setPuppetOfCivID_Empire(n2, false);
                }
                if (CFG.game.getCiv(n).getPuppetOfCivID() == n) {
                    CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                    this.civGameData.iPuppetOfCivID = n;
                    Civilization civilization = CFG.game.getCiv(this.civGameData.iPuppetOfCivID);
                    n = this.iCivID;
                    DiplomacyManager.leaveAlliance(n);
                    civilization.addVassal(n);
                    return;
                }
                CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                this.civGameData.iPuppetOfCivID = CFG.game.getCiv(n).getPuppetOfCivID();
                Civilization civilization = CFG.game.getCiv(this.civGameData.iPuppetOfCivID);
                n = this.iCivID;
                DiplomacyManager.leaveAlliance(n);
                civilization.addVassal(n);
                return;
            }
        }
        if (this.civGameData.iPuppetOfCivID != this.iCivID && this.civGameData.iPuppetOfCivID != n) {
            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
        }
        this.civGameData.iPuppetOfCivID = n;
        if (this.civGameData.iPuppetOfCivID == this.iCivID) return;
        CFG.game.getCiv(this.civGameData.iPuppetOfCivID).addVassal(this.iCivID);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void setPuppetOfCivID_PeaceTreaty(int n, boolean bl) {
        Object object;
        int n2;
        block11: {
            block12: {
                Object object2;
                block9: {
                    block10: {
                        block7: {
                            block8: {
                                int n3;
                                if (bl) break block7;
                                if (this.getPuppetOfCivID() != this.iCivID && (n3 = this.getAllianceID()) == CFG.game.getCiv(n2 = this.getPuppetOfCivID()).getAllianceID()) {
                                    DiplomacyManager.leaveAlliance(this.iCivID);
                                }
                                if (this.iCivID == n) break block7;
                                for (n2 = 0; n2 < CFG.game.getCivsSize(); ++n2) {
                                    if (this.iCivID == n2 || n == n2) continue;
                                    object = CFG.game;
                                    n3 = this.iCivID;
                                    if (((Game)object).getCivsAtWar(n2, n3)) {
                                        DiplomacyManager.controlOccupiedProvinceFrom(n2, n3);
                                    }
                                    ((Game)object).setCivRelation_OfCivB(n2, n3, 0.0f);
                                    ((Game)object).setCivRelation_OfCivB(n3, n2, 0.0f);
                                }
                                while (this.civGameData.lVassals.size() != 0) {
                                    n2 = this.civGameData.lVassals.get((int)0).iCivID;
                                    CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
                                }
                                if (CFG.game.getCiv(n).getPuppetOfCivID() != n) break block8;
                                CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                                this.civGameData.iPuppetOfCivID = n;
                                object2 = CFG.game;
                                object = CFG.game;
                                object = CFG.ideologiesManager;
                                object2 = ((Game)object2).getCiv(this.civGameData.iPuppetOfCivID);
                                n = ((Civilization)object2).getIdeologyID();
                                n2 = this.iCivID;
                                if (object.getIdeology((int)n).CANT_CHANGE_GOV_OF_VASSAL) break block9;
                                CFG.game.updateCivilizationIdeology(n2, CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n2).getCivTag()) + CFG.ideologiesManager.getIdeology(n).getExtraTag());
                                CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n2);
                                break block10;
                            }
                            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                            this.civGameData.iPuppetOfCivID = CFG.game.getCiv(n).getPuppetOfCivID();
                            object = CFG.game;
                            Object object3 = CFG.game;
                            object3 = CFG.ideologiesManager;
                            object = ((Game)object).getCiv(this.civGameData.iPuppetOfCivID);
                            n = ((Civilization)object).getIdeologyID();
                            n2 = this.iCivID;
                            if (object3.getIdeology((int)n).CANT_CHANGE_GOV_OF_VASSAL) break block11;
                            CFG.game.updateCivilizationIdeology(n2, CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n2).getCivTag()) + CFG.ideologiesManager.getIdeology(n).getExtraTag());
                            CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n2);
                            break block12;
                        }
                        if (this.civGameData.iPuppetOfCivID != this.iCivID && this.civGameData.iPuppetOfCivID != n) {
                            CFG.game.getCiv(this.civGameData.iPuppetOfCivID).removeVassal(this.iCivID);
                        }
                        this.civGameData.iPuppetOfCivID = n;
                        if (this.civGameData.iPuppetOfCivID == this.iCivID) return;
                        CFG.game.getCiv(this.civGameData.iPuppetOfCivID).addVassal(this.iCivID);
                        return;
                    }
                    for (n = 0; n < CFG.game.getPlayersSize(); ++n) {
                        if (CFG.game.getPlayer(n).getCivID() != n2) continue;
                        CFG.game.getPlayer(n).loadPlayersFlag();
                        break;
                    }
                }
                DiplomacyManager.leaveAlliance(n2);
                ((Civilization)object2).addVassal(n2);
                n = ((Civilization)object2).iCivID;
                object = CFG.holyRomanEmpire_Manager.getHRE();
                if (!((HolyRomanEmpire_GameData)object).getIsEmperor(n)) return;
                ((HolyRomanEmpire_GameData)object).addPrince(n2);
                return;
            }
            for (n = 0; n < CFG.game.getPlayersSize(); ++n) {
                if (CFG.game.getPlayer(n).getCivID() != n2) continue;
                CFG.game.getPlayer(n).loadPlayersFlag();
                break;
            }
        }
        DiplomacyManager.leaveAlliance(n2);
        ((Civilization)object).addVassal(n2);
        n = ((Civilization)object).iCivID;
        object = CFG.holyRomanEmpire_Manager.getHRE();
        if (!((HolyRomanEmpire_GameData)object).getIsEmperor(n)) return;
        ((HolyRomanEmpire_GameData)object).addPrince(n2);
    }

    protected final void setR(int n) {
        this.civGameData.iR = (short)n;
    }

    protected final void setRankPosition(int n) {
        this.iRankPosition = n;
    }

    protected final void setRankScore(int n) {
        this.iRankScore = n;
    }

    protected final void setRelation(int n, float f) {
        float f2;
        if (f > 250.0f) {
            f2 = 250.0f;
        } else {
            f2 = f;
            if (f < -100.0f) {
                f2 = -100.0f;
            }
        }
        try {
            this.civGameData.lRelation.set(n, Float.valueOf(f2));
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.civGameData.lRelation.add(Float.valueOf(0.0f));
        }
    }

    protected final void setResearchProgress(float f) {
        this.civGameData.fResearchProgress = f;
    }

    protected final void setSeaAccess(int n) {
        this.seaAccess = n;
    }

    protected final void setSpendings_Goods(float f) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fSpendings_Goods = f;
        if (save_Civ_GameData.fSpendings_Goods < 0.0f) {
            this.civGameData.fSpendings_Goods = 0.0f;
        } else if (this.civGameData.fSpendings_Goods > 1.0f) {
            this.civGameData.fSpendings_Goods = 1.0f;
        }
    }

    protected final void setSpendings_Investments(float f) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fSpendings_Investments = f;
        if (save_Civ_GameData.fSpendings_Investments < 0.0f) {
            this.civGameData.fSpendings_Investments = 0.0f;
        } else if (this.civGameData.fSpendings_Investments > 1.0f) {
            this.civGameData.fSpendings_Investments = 1.0f;
        }
    }

    protected final void setSpendings_Research(float f) {
        if (this.getMoney() < -500L) {
            this.civGameData.fSpendings_Research = 0.0f;
        } else {
            Save_Civ_GameData save_Civ_GameData = this.civGameData;
            save_Civ_GameData.fSpendings_Research = f;
            if (save_Civ_GameData.fSpendings_Research < 0.0f) {
                this.civGameData.fSpendings_Research = 0.0f;
            } else if (this.civGameData.fSpendings_Research > 1.0f) {
                this.civGameData.fSpendings_Research = 1.0f;
            }
        }
    }

    protected final void setStability(float f) {
        this.fStability = Math.min(Math.max(f, 0.01f), 2.0f);
    }

    protected final void setSupportRate(float f) {
        this.civGameData.iSupport_Rate = f;
    }

    protected final void setTaxationLevel(float f) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fTaxationLevel = f;
        if (save_Civ_GameData.fTaxationLevel < 0.0f) {
            this.civGameData.fTaxationLevel = 0.0f;
        } else if (this.civGameData.fTaxationLevel > 1.0f) {
            this.civGameData.fTaxationLevel = 1.0f;
        }
    }

    protected final void setTechnologyLevel(float f) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fTechnologyLevel = (int)(f * 100.0f);
        if ((float)save_Civ_GameData.fTechnologyLevel > 1000.0f) {
            this.civGameData.fTechnologyLevel = 1000;
        }
    }

    protected final void setTechnologyLevel_INT(int n) {
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.fTechnologyLevel = n;
        if ((float)save_Civ_GameData.fTechnologyLevel > 1000.0f) {
            this.civGameData.fTechnologyLevel = 1000;
        }
    }

    protected final boolean setTruce(int n, int n2) {
        block13: {
            int n3;
            if (n2 < 0) {
                n3 = 0;
            } else {
                n3 = n2;
                if (n2 > 50) {
                    n3 = 50;
                }
            }
            this.lTruce.set(n, n3);
            if (n3 <= 0) break block13;
            n2 = 0;
            while (true) {
                if (n2 >= this.lOpt_Truce.size()) break;
                if (this.lOpt_Truce.get(n2) == n) {
                    return false;
                }
                ++n2;
                continue;
                break;
            }
            try {
                this.lOpt_Truce.add(n);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                this.lTruce.add(0);
            }
        }
        n2 = 0;
        while (true) {
            if (n2 < this.lOpt_Truce.size()) {
                if (this.lOpt_Truce.get(n2) == n) {
                    this.lOpt_Truce.remove(n2);
                    return true;
                }
                ++n2;
                continue;
            }
            break;
        }
        return false;
    }

    protected final void setUpdateRegions(boolean bl) {
        this.updateRegions = bl;
    }

    protected final void setVassalLiberityDesire(float f) {
        float f2;
        if (f < 0.0f) {
            f2 = 0.0f;
        } else {
            f2 = f;
            if (f > 100.0f) {
                f2 = 100.0f;
            }
        }
        this.civGameData.fVassalLiberityDisere = f2;
    }

    protected final void setVassal_Tribute(int n, int n2) {
        for (int i = 0; i < this.civGameData.lVassals.size(); ++i) {
            if (this.civGameData.lVassals.get((int)i).iCivID != n) continue;
            this.civGameData.lVassals.get(i).setTribute(n2);
            return;
        }
        this.civGameData.lVassals.add(new Vassal_GameData(n));
        Save_Civ_GameData save_Civ_GameData = this.civGameData;
        save_Civ_GameData.iVassalsSize = save_Civ_GameData.lVassals.size();
    }

    protected final void setWarWeariness(float f) {
        float f2;
        if (f > 1.0f) {
            f2 = 1.0f;
        } else {
            f2 = f;
            if (f < 0.0f) {
                f2 = 0.0f;
            }
        }
        this.civGameData.fWarWeariness = f2;
    }

    protected final void updateBonuses() {
        int n = 0;
        while (n < this.civGameData.lBonuses.size()) {
            CivBonus_GameData civBonus_GameData = this.civGameData.lBonuses.get(n);
            --civBonus_GameData.iTurnsLeft;
            int n2 = n;
            if (this.civGameData.lBonuses.get((int)n).iTurnsLeft <= 0) {
                this.applyBonusChanges_Expired(this.civGameData.lBonuses.get(n));
                this.civGameData.lBonuses.remove(n);
                n2 = n - 1;
            }
            n = n2 + 1;
        }
    }

    protected final void updateChangeGoverment() {
        int n = this.iIdeologyID;
        if (CFG.ideologiesManager.getIdeology((int)n).ELECTION_PERIOD > 0) {
            if (Game_Calendar.TURN_ID >= this.getNextElection() && !this.isAtWar()) {
                this.setSupportRate(Math.max(this.getSupportRate() - 1.0f, 0.0f));
            }
        } else {
            n = this.iIdeologyID;
            if (CFG.ideologiesManager.getIdeology((int)n).REFORMATION_PERIOD > 0) {
                int n2 = Game_Calendar.TURN_ID;
                n = this.getInReformation();
                if (n > 0 && n2 >= n) {
                    Civ_Mission_ChangeTypeOfGoverment civ_Mission_ChangeTypeOfGoverment;
                    n = this.iCivID;
                    this.civGameData.changeTypeOfGoverment = civ_Mission_ChangeTypeOfGoverment = new Civ_Mission_ChangeTypeOfGoverment(this.civGameData.iWillChangeToIdeologyID, n);
                    this.setInReformation(0);
                }
            }
        }
    }

    protected final void updateCivilizationIdeology() {
        this.setIdeologyID(CFG.ideologiesManager.getIdeologyID(this.getCivTag()));
    }

    protected final void updateCivilizationIdeology(String object, int n, int n2, int n3) {
        this.setCivTag((String)object);
        object = this.civGameData;
        ((Save_Civ_GameData)object).iR = (short)n;
        ((Save_Civ_GameData)object).iG = (short)n2;
        ((Save_Civ_GameData)object).iB = (short)n3;
        this.updateCivilizationIdeology();
        this.loadFlag();
    }

    protected final void updateDiplomacy_AfterAddingCivilization() {
        this.civGameData.lRelation.add(Float.valueOf(0.0f));
        List<Byte> list = this.lGuarantee;
        Byte by = 0;
        Integer n = 0;
        list.add(by);
        this.lMilitirayAccess.add(by);
        this.lNonAggressionPact.add(n);
        this.lTruce.add(n);
        this.lDefensivePact.add(n);
    }

    protected final void updateDiplomacy_AfterRemoveCivilization(int n) {
        int n2;
        int n3;
        this.lNonAggressionPact.remove(n);
        this.lTruce.remove(n);
        this.lDefensivePact.remove(n);
        int n4 = 0;
        for (n3 = 0; n3 < this.lOpt_Truce.size(); ++n3) {
            if (this.lOpt_Truce.get(n3) != n) continue;
            this.lOpt_Truce.remove(n3);
            break;
        }
        n3 = 0;
        while (true) {
            n2 = n4;
            if (n3 >= this.lOpt_DefensivePact.size()) break;
            if (this.lOpt_DefensivePact.get(n3) == n) {
                this.lOpt_DefensivePact.remove(n3);
                n2 = n4;
                break;
            }
            ++n3;
        }
        while (n2 < this.lOpt_NonAggressionPact.size()) {
            if (this.lOpt_NonAggressionPact.get(n2) == n) {
                this.lOpt_NonAggressionPact.remove(n2);
                break;
            }
            ++n2;
        }
    }

    protected final void updateDiplomacy_AfterRemoveCivilization_Relations(int n) {
        int n2;
        this.civGameData.lRelation.remove(n);
        this.lGuarantee.remove(n);
        this.lMilitirayAccess.remove(n);
        int n3 = 0;
        int n4 = 0;
        while (true) {
            n2 = n3;
            if (n4 >= this.lOpt_Guarantee.size()) break;
            if (this.lOpt_Guarantee.get(n4) == n) {
                this.lOpt_Guarantee.remove(n4);
                n2 = n3;
                break;
            }
            ++n4;
        }
        while (n2 < this.lOpt_MilitirayAccess.size()) {
            if (this.lOpt_MilitirayAccess.get(n2) == n) {
                this.lOpt_MilitirayAccess.remove(n2);
                break;
            }
            ++n2;
        }
    }

    protected final void updateFriendlyCiv() {
    }

    protected final void updateLoansNextTurn() {
        int n = 0;
        while (n < this.civGameData.lLoansTaken.size()) {
            Loan_GameData loan_GameData = this.civGameData.lLoansTaken.get(n);
            --loan_GameData.iTurnsLeft;
            int n2 = n;
            if (this.civGameData.lLoansTaken.get((int)n).iTurnsLeft <= 0) {
                this.civGameData.lLoansTaken.remove(n);
                this.getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Repaid(this.getCivID(), 0));
                n2 = n - 1;
            }
            n = n2 + 1;
        }
    }

    protected final void updateManPowerIncreasing() {
        int n = (int)Math.pow(this.countPopulation_WithoutOccupied(), 0.75);
        int n2 = n / 800;
        int n3 = this.iIdeologyID;
        float f = CFG.ideologiesManager.getIdeology((int)n3).MANPOWER_BONUS;
        float f2 = n2;
        f = Math.min(f + (float)this.civGameData.iNumOfTurnsAtWar / 100.0f, 3.0f);
        n2 = this.iCivID;
        n3 = Math.max((int)(f2 * f * CFG.gameAction.modifierManPower_CivID(n2)), 1);
        int n4 = this.iCivID;
        int n5 = this.getPuppetOfCivID();
        n2 = n3;
        if (n4 != n5) {
            Civilization civilization = CFG.game.getCiv(n5);
            n4 = (int)Math.pow(civilization.countPopulation_WithoutOccupied(), 0.75) / 8;
            n5 = civilization.getManPower();
            n2 = n3 / 5;
            f2 = Math.max(0.0f, (2000000.0f - (float)civilization.iNumOfUnits) / 2000000.0f);
            int n6 = (int)((float)n2 * f2);
            n2 = n3 - n6;
            civilization.setManPower(Math.min(n5 + n6, n4));
        }
        f2 = Math.max(0.0f, (2000000.0f - (float)this.iNumOfUnits) / 2000000.0f);
        this.civGameData.iManPowerIncreasing_PerTurn = n2 = (int)((float)n2 * f2);
        n2 = Math.min(this.getManPower() + n2, n / 8);
        this.setManPower(n2);
        this.setManPower_ThisTurn(n2);
    }

    protected final void updateNextElection_Start() {
        int n = this.iIdeologyID;
        n = CFG.ideologiesManager.getIdeology((int)n).ELECTION_PERIOD;
        if (n > 0) {
            this.setNextElection(Game_Calendar.TURN_ID + n);
        }
        this.setInReformation(0);
        this.setSupportRate(100.0f);
    }

    protected final void updateNextReformation_Start() {
        int n = this.iIdeologyID;
        int n2 = CFG.ideologiesManager.getIdeology((int)n).REFORMATION_PERIOD;
        if (n2 > 0) {
            n = Game_Calendar.TURN_ID;
            this.civGameData.iChangeGoverment_SinceTurn = n + n2;
        }
        this.setInReformation(0);
        this.setSupportRate(100.0f);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void updateNuclearWeapon() {
        int n3;
        int n2 = 0;
        boolean bl = false;
        for (int n3 : this.lProvinces) {
            if (CFG.game.getProvince(n3).getLevelOfNuclearReactor() <= 0) continue;
            ++n2;
            bl = true;
        }
        n3 = n2;
        if (n2 >= 40) {
            n3 = 39;
        }
        this.setNuclearWeaponsPerTurn(40 - n3);
        if (this.getNuclearWeaponsTurn() >= this.getNuclearWeaponsPerTurn()) {
            this.setNuclearWeaponsTurn(0);
            this.setNuclearWeapons(this.getNuclearWeapons() + 1);
            this.getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Producted_NuclearWeapon(this.iCivID, 0));
            return;
        }
        if (!bl) return;
        this.setNuclearWeaponsTurn(this.getNuclearWeaponsTurn() + 1);
    }

    protected final void updateStartingManPower() {
        int n = (int)Math.pow(this.countPopulation_WithoutOccupied(), 0.75) / 16;
        int n2 = this.iIdeologyID;
        float f = CFG.ideologiesManager.getIdeology((int)n2).MANPOWER_BONUS;
        float f2 = n;
        n = this.iCivID;
        this.setManPower(Math.max((int)(f2 * f * CFG.gameAction.modifierManPower_CivID(n)), 1));
    }

    protected final void updateSupport_Rate() {
        int n = this.iIdeologyID;
        float f = Math.min(CFG.ideologiesManager.getIdeology((int)n).SUPPORT_RATE_INCREASING, 2.0f);
        n = this.iIdeologyID;
        float f2 = CFG.ideologiesManager.getIdeology((int)n).SUPPORT_RATE_CHANGING;
        float f3 = this.getHappiness_10Turn();
        float f4 = this.getSupportRate();
        float f5 = CFG.gameAction.getCivHappiness_WithoutOccupied(this.iCivID);
        this.setHappiness_10Turn(f5);
        f2 = (f5 - f3) * f2 * 100.0f;
        f = !(f2 >= 0.0f) ? f2 * 2.0f : f2 * f;
        this.setSupportRate(Math.min(Math.max(f4 + Math.min(50.0f, Math.max(-50.0f, f)), 0.0f), 100.0f));
    }

    protected final void updateSupport_Rate_Start() {
        this.setSupportRate(100.0f);
        this.setHappiness_10Turn(-1000.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean updateTwoWaysAccess(int n) {
        int n2;
        int n3;
        boolean bl;
        boolean bl2 = bl = false;
        if (!this.isAtWar) return bl2;
        bl2 = bl;
        if (this.iNumOfProvinces <= 0) return bl2;
        bl2 = bl;
        if (CFG.game.getCivsAtWar(this.iCivID, n)) return bl2;
        for (n3 = 0; n3 < this.isAtWarWithCivs.size(); ++n3) {
            n2 = this.isAtWarWithCivs.get(n3);
            if (CFG.game.getMilitaryAccess_WithoutTwoWays(n2, n) > 0) return true;
        }
        for (n3 = 0; n3 < this.civGameData.lVassals.size(); ++n3) {
            n2 = this.civGameData.lVassals.get((int)n3).iCivID;
            if (CFG.game.getTrueMilitaryAccess(n2, n) > 0) return true;
        }
        n2 = this.civGameData.iAllianceID;
        Alliance alliance = CFG.game.getAlliance(n2);
        for (n3 = 0; n3 < alliance.getCivilizationsSize(); ++n3) {
            n2 = alliance.getCivilization(n3);
            if (CFG.game.getTrueMilitaryAccess(n2, n) > 0) return true;
        }
        n3 = this.civGameData.iPuppetOfCivID;
        if (CFG.game.getTrueMilitaryAccess(n3, n) > 0) return true;
        return bl;
    }
}

