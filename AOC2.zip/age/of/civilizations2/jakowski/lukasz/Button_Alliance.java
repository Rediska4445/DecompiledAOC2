/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Alliance
extends Button {
    private int iAllianceID = 0;

    protected Button_Alliance(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super.init(string2, n2, n3, n4, n5, n6, bl, true, false, false, null);
        this.iAllianceID = n;
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.75f));
        } else if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.8f));
        } else {
            spriteBatch.setColor(Color.WHITE);
        }
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btn_add).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth(), this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight());
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth() + n, this.getPosY() - ImageManager.getImage(Images.btn_add).getHeight() + n2, ImageManager.getImage(Images.btn_add).getWidth(), this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight(), true);
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight() * 2 + n2, this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth(), ImageManager.getImage(Images.btn_add).getHeight(), false, true);
        ImageManager.getImage(Images.btn_add).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight() + n2, true, true);
        int n3 = n;
        if (CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() * CFG.CIV_FLAG_WIDTH + (CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() + 1) * CFG.PADDING < this.getWidth()) {
            n3 = n + ((this.getWidth() - CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() * CFG.CIV_FLAG_WIDTH - (CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() - 1) * CFG.PADDING) / 2 - CFG.PADDING);
        }
        spriteBatch.setColor(new Color(CFG.game.getAlliance(this.iAllianceID).getColorOfAlliance().getR(), CFG.game.getAlliance(this.iAllianceID).getColorOfAlliance().getG(), CFG.game.getAlliance(this.iAllianceID).getColorOfAlliance().getB(), 1.0f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n3, this.getPosY() + this.getHeight() / 2 + this.getTextHeight() / 2 + CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 2 + CFG.CIV_COLOR_WIDTH - 1 + n2, CFG.PADDING, CFG.CIV_COLOR_WIDTH, true, false);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + CFG.PADDING + n3, this.getPosY() + this.getHeight() / 2 + this.getTextHeight() / 2 + CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 2 + CFG.CIV_COLOR_WIDTH - 1 + n2, CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() * CFG.CIV_FLAG_WIDTH + (CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() - 1) * CFG.PADDING - CFG.PADDING * 2, CFG.CIV_COLOR_WIDTH);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() * CFG.CIV_FLAG_WIDTH + (CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize() - 1) * CFG.PADDING - CFG.PADDING + n3, this.getPosY() + this.getHeight() / 2 + this.getTextHeight() / 2 + CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 2 + CFG.CIV_COLOR_WIDTH - 1 + n2, CFG.PADDING, CFG.CIV_COLOR_WIDTH);
        spriteBatch.setColor(Color.WHITE);
        n = 0;
        while (n < CFG.game.getAlliance(this.iAllianceID).getCivilizationsSize()) {
            Image image = CFG.game.getCiv(CFG.game.getAlliance(this.iAllianceID).getCivilization(n)).getFlag();
            int n4 = this.getPosX();
            int n5 = CFG.CIV_FLAG_WIDTH;
            int n6 = CFG.PADDING;
            int n7 = n + 1;
            image.draw(spriteBatch, n4 + n5 * n + n6 * n7 + n3, this.getPosY() + this.getHeight() / 2 + this.getTextHeight() / 2 + CFG.PADDING * 2 - CFG.game.getCiv(CFG.game.getAlliance(this.iAllianceID).getCivilization(n)).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.CIV_FLAG_WIDTH * n + CFG.PADDING * n7 + n3, this.getPosY() + this.getHeight() / 2 + this.getTextHeight() / 2 + CFG.PADDING * 2 + n2);
            n = n7;
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            String string2 = this.getTextToDraw();
            int n3 = this.getPosX();
            int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - this.getTextWidth() / 2 : this.getTextPos();
            CFG.drawText(spriteBatch, string2, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - this.getTextHeight() / 2 + n2, this.getColor(bl));
        } else {
            String string3 = this.getTextToDraw();
            int n5 = this.getPosX();
            int n6 = this.getTextPos() < 0 ? this.getWidth() / 2 - this.getTextWidth() / 2 : this.getTextPos();
            CFG.drawTextWithShadow(spriteBatch, string3, n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - this.getTextHeight() / 2 + n2, this.getColor(bl));
        }
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? new Color(0.82f, 0.82f, 0.82f, 1.0f) : new Color(0.7f, 0.7f, 0.7f, 1.0f)) : new Color(0.764f, 0.764f, 0.764f, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iAllianceID;
    }

    @Override
    public void setText(String string2) {
        super.setText(string2);
        if (this.getTextWidth() > this.getWidth() - CFG.PADDING * 2) {
            this.setWidth(this.getTextWidth() + CFG.PADDING * 2);
        }
    }
}

