/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Stats;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Stats_Image
extends Button_Stats {
    private int iImageID = 0;

    protected Button_Stats_Image(int n, String string2, float f, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, f, n2, n3, n4, n5, bl, bl2);
        this.iImageID = n;
    }

    private final float getImageScale() {
        return 1.0f;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() - (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale() / 2.0f) + n2, (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale()));
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + CFG.PADDING + (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale()) + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void setText(String string2) {
        this.sText = string2;
        this.setWidth(this.iMinWidth);
        try {
            CFG.glyphLayout.setText(CFG.fontMain, string2);
            this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
            this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            if (super.getWidth() < this.iTextWidth + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale())) {
                this.setWidth(this.iTextWidth + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale()));
            }
            return;
        }
        catch (IllegalArgumentException | NullPointerException runtimeException) {
            return;
        }
    }
}

