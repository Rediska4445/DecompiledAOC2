/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.PixmapIO;

class Editor_ProvinceTexture
extends Editor {
    private int button;
    private int iBrushScale = 1;
    private boolean theDoubleMode = false;

    Editor_ProvinceTexture() {
    }

    private final void dragged(int n, int n2, int n3, boolean bl) {
        if (n >= 0) {
            Object object;
            Object object2 = Gdx.files;
            Object object3 = new StringBuilder();
            ((StringBuilder)object3).append("map/");
            ((StringBuilder)object3).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object3).append("data/");
            ((StringBuilder)object3).append("scales/");
            ((StringBuilder)object3).append("provinces/");
            ((StringBuilder)object3).append(CFG.map.getMapBG().getMapScale());
            ((StringBuilder)object3).append("/");
            ((StringBuilder)object3).append(n);
            object2 = PixmapIO.readCIM(object2.local(((StringBuilder)object3).toString()));
            n2 = (int)((float)n2 / CFG.map.getMapScale().getCurrentScale());
            int n4 = (int)((float)n3 / CFG.map.getMapScale().getCurrentScale());
            object3 = null;
            for (n3 = 0; n3 < ((Pixmap)object2).getHeight(); ++n3) {
                for (int i = 0; i < ((Pixmap)object2).getWidth(); ++i) {
                    int n5;
                    int n6 = CFG.map.getMapCoordinates().getPosX();
                    if (i != n2 - n6 - (n5 = CFG.map.getMapCoordinates().getSecondSideOfMap() ? CFG.map.getMapBG().getWidth() : 0) - CFG.game.getProvince(n).getMinX() || n3 != n4 - CFG.map.getMapCoordinates().getPosY() - CFG.game.getProvince(n).getMinY()) continue;
                    if (bl) {
                        object = Gdx.files;
                        object3 = new StringBuilder();
                        ((StringBuilder)object3).append("map/");
                        ((StringBuilder)object3).append(CFG.map.getFile_ActiveMap_Path());
                        ((StringBuilder)object3).append("data/");
                        ((StringBuilder)object3).append("scales/");
                        ((StringBuilder)object3).append("provinces/");
                        ((StringBuilder)object3).append(CFG.map.getMapBG().getMapScale());
                        ((StringBuilder)object3).append("/");
                        ((StringBuilder)object3).append(n);
                        object3 = PixmapIO.readCIM(object.local(((StringBuilder)object3).toString()));
                        ((Pixmap)object3).setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
                        ((Pixmap)object3).drawPixel(i, n3);
                        continue;
                    }
                    object = new Pixmap(1, 1, Pixmap.Format.LuminanceAlpha);
                    ((Pixmap)object).setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
                    ((Pixmap)object).drawPixel(0, 0);
                    object3 = new Pixmap(((Pixmap)object2).getWidth(), ((Pixmap)object2).getHeight(), Pixmap.Format.LuminanceAlpha);
                    ((Pixmap)object3).setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
                    for (n5 = 0; n5 < ((Pixmap)object3).getHeight(); ++n5) {
                        for (n6 = 0; n6 < ((Pixmap)object3).getWidth(); ++n6) {
                            if (((Pixmap)object).getPixel(0, 0) != ((Pixmap)object2).getPixel(n6, n5) || n6 == i && n5 == n3) continue;
                            ((Pixmap)object3).drawPixel(n6, n5);
                        }
                    }
                }
            }
            if (object3 == null) {
                return;
            }
            CFG.game.getProvince(n).setBG((Pixmap)object3);
            object2 = Gdx.files;
            object = new StringBuilder();
            ((StringBuilder)object).append("map/");
            ((StringBuilder)object).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object).append("data/");
            ((StringBuilder)object).append("scales/");
            ((StringBuilder)object).append("provinces/");
            ((StringBuilder)object).append(CFG.map.getMapBG().getMapScale());
            ((StringBuilder)object).append("/");
            ((StringBuilder)object).append(n);
            PixmapIO.writeCIM(object2.local(((StringBuilder)object).toString()), (Pixmap)object3);
            CFG.game.setActiveProvinceID(n);
        }
    }

    @Override
    protected void keyDown(int n) {
        int n2;
        if (Gdx.input.isKeyPressed(19)) {
            this.theDoubleMode ^= true;
            if (CFG.game.getActiveProvinceID() != CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1) {
                CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = CFG.game.getActiveProvinceID();
            }
        }
        if (Gdx.input.isKeyPressed(67) || Gdx.input.isKeyPressed(66)) {
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = -1;
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = -1;
        }
        if (Gdx.input.isKeyPressed(44)) {
            CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID == 0 ? -1 : 0;
        }
        if (Gdx.input.isKeyPressed(21)) {
            --this.iBrushScale;
            if (this.iBrushScale < 1) {
                this.iBrushScale = 1;
            }
        } else if (Gdx.input.isKeyPressed(22)) {
            ++this.iBrushScale;
            if (this.iBrushScale > 3) {
                this.iBrushScale = 3;
            }
        }
        if (Gdx.input.isKeyPressed(62)) {
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = CFG.game.getActiveProvinceID();
        }
        if (Gdx.input.isKeyPressed(41)) {
            n = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = n;
        }
        if (Gdx.input.isKeyPressed(20) && CFG.game.getActiveProvinceID() != CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1) {
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = CFG.game.getActiveProvinceID();
        }
        if (Gdx.input.isKeyPressed(46) && CFG.game.getActiveProvinceID() >= 0) {
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).buildProvinceBG(true);
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).loadProvinceBG();
        }
        if (Gdx.input.isKeyPressed(49) && CFG.game.getActiveProvinceID() >= 0 && (n2 = CFG.game.getActiveProvinceID()) >= 0 && !CFG.game.getProvince(n2).getSeaProvince()) {
            Object object = Gdx.files;
            Object object2 = new StringBuilder();
            ((StringBuilder)object2).append("map/");
            ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object2).append("data/");
            ((StringBuilder)object2).append("scales/");
            ((StringBuilder)object2).append("provinces/");
            ((StringBuilder)object2).append(CFG.map.getMapDefaultScale(CFG.map.getActiveMapID()));
            ((StringBuilder)object2).append("/");
            ((StringBuilder)object2).append(n2);
            object = PixmapIO.readCIM(object.local(((StringBuilder)object2).toString()));
            object2 = Gdx.files;
            Object object3 = new StringBuilder();
            ((StringBuilder)object3).append("map/");
            ((StringBuilder)object3).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object3).append("data/");
            ((StringBuilder)object3).append("scales/");
            ((StringBuilder)object3).append("provinces/");
            ((StringBuilder)object3).append(CFG.map.getMapBG().getMapScale());
            ((StringBuilder)object3).append("/");
            ((StringBuilder)object3).append(n2);
            object2 = PixmapIO.readCIM(object2.local(((StringBuilder)object3).toString()));
            object3 = new Pixmap(1, 1, Pixmap.Format.LuminanceAlpha);
            ((Pixmap)object3).setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
            ((Pixmap)object3).drawPixel(0, 0);
            object2 = new Pixmap(((Pixmap)object2).getWidth(), ((Pixmap)object2).getHeight(), Pixmap.Format.LuminanceAlpha);
            ((Pixmap)object2).setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
            for (n = 0; n < ((Pixmap)object2).getHeight(); ++n) {
                for (int i = 0; i < ((Pixmap)object2).getWidth(); ++i) {
                    if (((Pixmap)object3).getPixel(0, 0) != ((Pixmap)object).getPixel((int)((float)i * ((float)CFG.map.getMapDefaultScale(CFG.map.getActiveMapID()) / (float)CFG.map.getMapBG().getMapScale())), (int)((float)n * ((float)CFG.map.getMapDefaultScale(CFG.map.getActiveMapID()) / (float)CFG.map.getMapBG().getMapScale())))) continue;
                    ((Pixmap)object2).drawPixel(i, n);
                }
            }
            CFG.game.getProvince(n2).setBG((Pixmap)object2);
            object = Gdx.files;
            object3 = new StringBuilder();
            ((StringBuilder)object3).append("map/");
            ((StringBuilder)object3).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object3).append("data/");
            ((StringBuilder)object3).append("scales/");
            ((StringBuilder)object3).append("provinces/");
            ((StringBuilder)object3).append(CFG.map.getMapBG().getMapScale());
            ((StringBuilder)object3).append("/");
            ((StringBuilder)object3).append(n2);
            PixmapIO.writeCIM(object.local(((StringBuilder)object3).toString()), (Pixmap)object2);
        }
    }

    @Override
    protected void setInUse(boolean bl) {
        CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = -1;
        CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = -1;
        CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = 0;
        this.theDoubleMode = false;
        this.iBrushScale = 1;
        super.setInUse(bl);
    }

    @Override
    public String toString() {
        CharSequence charSequence;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ACTIVE PROVINCE ID 1: ");
        stringBuilder.append(CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1);
        stringBuilder.append("\n");
        if (this.theDoubleMode) {
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("ID 2: ");
            ((StringBuilder)charSequence).append(CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2);
            ((StringBuilder)charSequence).append("\n");
            charSequence = ((StringBuilder)charSequence).toString();
        } else {
            charSequence = "";
        }
        stringBuilder.append((String)charSequence);
        stringBuilder.append("\nBRUSH SCALE: ");
        stringBuilder.append(this.iBrushScale);
        stringBuilder.append("\nSPACE -> SET ACTIVE PROVINCE 1\nDOWN -> SET ACTIVE PROVINCE 2\nBACKSPACE -> RESET ACTIVE PROVINCES\nP -> PAUSE: ");
        boolean bl = CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID < 0;
        stringBuilder.append(bl);
        stringBuilder.append("\nUP -> DOUBLE MODE\nLEFT, RIGHT -> BRUSH SCALE\n\nR -> REBUILD BACKGROUND\nU -> REBUILD BG BASED ON DEFAULT SCALE");
        return stringBuilder.toString();
    }

    @Override
    protected void touchDown(int n, int n2, int n3, int n4) {
        n3 = CFG.BUTTON_WIDTH;
        int n5 = CFG.PADDING;
        boolean bl = false;
        boolean bl2 = false;
        if (n <= n3 * 2 + n5 * 2 && n2 >= CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 || CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID < 0) {
            CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = -1;
            CFG.map.getMapCoordinates().setDisableMovingMap(false);
            return;
        }
        if (CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 >= 0 && CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID == 0) {
            CFG.map.getMapCoordinates().setDisableMovingMap(true);
        }
        this.button = n4;
        if (this.theDoubleMode) {
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
            bl = n4 == 1;
            this.dragged(n3, n, n2, bl);
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
            bl = bl2;
            if (n4 != 1) {
                bl = true;
            }
            this.dragged(n3, n, n2, bl);
        } else {
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
            if (n4 == 1) {
                bl = true;
            }
            this.dragged(n3, n, n2, bl);
        }
    }

    @Override
    protected void touchDragged(int n, int n2, int n3) {
        int n4 = CFG.BUTTON_WIDTH;
        n3 = CFG.PADDING;
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        if (n <= n4 * 2 + n3 * 2 && n2 >= CFG.GAME_HEIGHT - CFG.BUTTON_HEIGHT - CFG.PADDING * 2 || CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID < 0) {
            CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = -1;
            CFG.map.getMapCoordinates().setDisableMovingMap(false);
            return;
        }
        if (this.theDoubleMode) {
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
            boolean bl5 = this.button == 1;
            this.dragged(n3, n, n2, bl5);
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
            bl5 = this.button != 1;
            this.dragged(n3, n, n2, bl5);
            n3 = this.iBrushScale;
            if (n3 == 2) {
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                int n5 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n5, n2 - n3, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n, n2 - n3, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n5 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n5 + n, n2 - n4, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n3, n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n3 + n, n2, bl5);
                n5 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n5, n - n4, n3 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n, n4 + n2, bl5);
                n5 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n5, n4 + n, n3 + n2, bl5);
                n5 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n5, n - n4, n2 - n3, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n, n2 - n4, bl5);
                n5 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n5, n3 + n, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n - n4, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n4 + n, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n5 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n - n4, n5 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n, n3 + n2, bl5);
                n5 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = bl4;
                if (this.button != 1) {
                    bl5 = true;
                }
                this.dragged(n5, n + n4, n2 + n3, bl5);
            } else if (n3 == 3) {
                int n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n6, n - n3, n2 - n4, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n6, n2 - n3, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n6 + n, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n6 + n, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n - n4, n2 - n6, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n6, n - n3, n2 - n4, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n, n2 - n3, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n4 + n, n2 - n6, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n6 + n, n2 - n3, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n3, n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n3, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n4 + n, n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n3 + n, n2, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n6, n - n4, n3 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n6, n3 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n, n4 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n4 + n, n6 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n6 + n, n4 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n - n3, n6 + n2, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n6, n - n3, n4 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n3, n, n4 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n6 + n, n3 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button == 1;
                this.dragged(n4, n3 + n, n6 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n - n3, n2 - n6, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n - n3, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n, n2 - n4, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n4 + n, n2 - n3, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n6 + n, n2 - n3, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n - n6, n2 - n3, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n - n3, n2 - n6, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n, n2 - n4, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n3 + n, n2 - n4, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n4 + n, n2 - n6, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n - n4, n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n - n3, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n4 + n, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n4 + n, n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n - n6, n4 + n2, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n - n4, n3 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n, n3 + n2, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n4 + n, n3 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n3 + n, n6 + n2, bl5);
                n6 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n6, n - n3, n4 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n - n4, n6 + n2, bl5);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n3, n, n4 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = this.button != 1;
                this.dragged(n4, n6 + n, n3 + n2, bl5);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n6 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl5 = bl;
                if (this.button != 1) {
                    bl5 = true;
                }
                this.dragged(n4, n + n3, n2 + n6, bl5);
            }
        } else {
            n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
            boolean bl6 = this.button == 1;
            this.dragged(n3, n, n2, bl6);
            n3 = this.iBrushScale;
            if (n3 == 2) {
                int n7 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n7, n - n4, n2 - n3, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n, n2 - n4, bl6);
                n7 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n7, n3 + n, n2 - n4, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n - n4, n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n3 + n, n2, bl6);
                n7 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n7, n - n4, n3 + n2, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n, n4 + n2, bl6);
                n7 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = bl2;
                if (this.button == 1) {
                    bl6 = true;
                }
                this.dragged(n7, n + n3, n2 + n4, bl6);
            } else if (n3 == 3) {
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                int n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n - n4, n2 - n8, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n - n3, n2 - n8, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n, n2 - n4, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n8 + n, n2 - n3, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n8 + n, n2 - n4, bl6);
                n8 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n8, n - n4, n2 - n3, bl6);
                n8 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n8, n - n4, n2 - n3, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n, n2 - n4, bl6);
                n8 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n8, n4 + n, n2 - n3, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n4 + n, n2 - n8, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n - n3, n2, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n - n4, n2, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n4 + n, n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n3 + n, n2, bl6);
                n8 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n8, n - n3, n4 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n - n3, n8 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n, n3 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n8 + n, n3 + n2, bl6);
                n8 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                bl6 = this.button == 1;
                this.dragged(n8, n3 + n, n4 + n2, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n3, n - n8, n4 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n - n8, n3 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n, n3 + n2, bl6);
                n4 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 1.0f);
                n3 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = this.button == 1;
                this.dragged(n4, n8 + n, n3 + n2, bl6);
                n3 = CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1;
                n4 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                n8 = (int)(CFG.map.getMapScale().getCurrentScale() * 2.0f);
                bl6 = bl3;
                if (this.button == 1) {
                    bl6 = true;
                }
                this.dragged(n3, n + n4, n2 + n8, bl6);
            }
        }
    }

    @Override
    protected void touchUp(int n, int n2, int n3, int n4) {
        CFG.map.getMapCoordinates().setDisableMovingMap(false);
    }
}

