/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu_LR_MainMenu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Menu_LR_MainMenu_TextScale_Important
extends Button_Menu_LR_MainMenu {
    protected Button_Menu_LR_MainMenu_TextScale_Important(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_LR_MainMenu_TextScale_Important(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.9f);
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.9f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.9f / 2.0f) + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.9f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.9f / 2.0f) + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(1.0f);
        float f = CFG.COLOR_FLAG_FRAME.r;
        float f2 = CFG.COLOR_FLAG_FRAME.g;
        float f3 = CFG.COLOR_FLAG_FRAME.b;
        float f4 = 0.3f;
        float f5 = bl ? 0.0f : (this.getIsHovered() ? 0.3f : 0.25f);
        spriteBatch.setColor(new Color(f, f2, f3, f5));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)this.getTextWidth() * 0.9f) / 2 + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, false, false);
        f5 = bl ? 0.0f : (this.getIsHovered() ? f4 : 0.2f);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, f5));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() - 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)this.getTextWidth() * 0.9f) / 2 + CFG.PADDING * 2 + n, this.getPosY() - 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)this.getTextWidth() * 0.9f) / 2 + CFG.PADDING * 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - (int)((float)this.getTextWidth() * 0.9f) / 2, 1, false, false);
        spriteBatch.setColor(Color.WHITE);
    }
}

