/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_LR_MainMenu_Games
extends Button_Menu {
    private boolean backAnimation = false;
    private float fAlphaMod = 0.0f;
    private long lTime = System.currentTimeMillis();

    protected Button_Menu_LR_MainMenu_Games(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f;
        spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.55f);
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_menu_h).getWidth());
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_menu_h).getWidth() + n, this.getPosY() + n2, true);
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.485f));
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth());
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth() + n, this.getPosY() + n2, true);
        } else {
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth());
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth() + n, this.getPosY() + n2, true);
        }
        if (!bl) {
            if (this.lTime < System.currentTimeMillis() - 70L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod >= 0.35f) {
                        this.backAnimation = true;
                        this.fAlphaMod = 0.35f;
                    }
                }
                this.lTime = System.currentTimeMillis();
                CFG.setRender_3(true);
            }
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f - this.fAlphaMod));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 8);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - this.getHeight() / 8 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 8, false, true);
        }
        if (this.getClickable() && this.getIsHovered() && !bl && animationState >= 0) {
            if (animationState == 0) {
                f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu_LR_MainMenu_Games.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    ++animationState;
                    lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu_LR_MainMenu_Games.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    animationState = 0;
                    lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
        float f2 = CFG.COLOR_FLAG_FRAME.r;
        float f3 = CFG.COLOR_FLAG_FRAME.g;
        float f4 = CFG.COLOR_FLAG_FRAME.b;
        f = bl ? 0.0f : (this.getIsHovered() ? 0.3f : 0.2f);
        spriteBatch.setColor(new Color(f2, f3, f4, f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + this.getTextWidth() / 2 + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, false, false);
        f = bl ? 0.0f : (this.getIsHovered() ? 0.3f : 0.175f);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() - 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + this.getTextWidth() / 2 + CFG.PADDING * 2 + n, this.getPosY() - 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + this.getTextWidth() / 2 + CFG.PADDING * 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (this.getWidth() - CFG.PADDING * 8) / 2 - this.getTextWidth() / 2, 1, false, false);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawText(spriteBatch, n, n2, bl);
    }
}

