/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_CivInfo_War {
    protected int iCivID;

    protected AI_CivInfo_War(int n) {
        this.iCivID = n;
    }
}

