/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

public class AI_CivsInRange
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected float fRange;
    protected int iCivID;

    protected AI_CivsInRange(int n, float f) {
        this.iCivID = n;
        this.fRange = f;
    }
}

