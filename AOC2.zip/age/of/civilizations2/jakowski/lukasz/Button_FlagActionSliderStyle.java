/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_FlagActionSliderStyle
extends Button {
    protected static final float BUTTON_PERC_HEIGHT = 0.6f;

    protected Button_FlagActionSliderStyle(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false);
    }

    protected Button_FlagActionSliderStyle(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super.init(string2, n, n2, n3, n4, (int)((float)CFG.BUTTON_HEIGHT * 0.6f), bl, true, false, false);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        float f = CFG.COLOR_GRADIENT_TITLE_BLUE.r;
        float f2 = CFG.COLOR_GRADIENT_TITLE_BLUE.g;
        float f3 = CFG.COLOR_GRADIENT_TITLE_BLUE.b;
        float f4 = !this.getIsHovered() && !bl ? 0.375f : 0.5f;
        spriteBatch.setColor(new Color(f, f2, f3, f4));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + 1 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight());
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() - 1 + this.getWidth() - this.getWidth() / 4 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.125f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + 1 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 8, this.getHeight());
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() - 1 + this.getWidth() - this.getWidth() / 8 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 8, this.getHeight(), true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.1f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_NEW_GAME_EDGE_LINE.r, CFG.COLOR_NEW_GAME_EDGE_LINE.g, CFG.COLOR_NEW_GAME_EDGE_LINE.b, 0.7f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + 1 + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() - 1 + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight(), true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight(), true, true);
        if (this.getIsHovered() || bl) {
            spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.45f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
        CFG.drawText(spriteBatch, string2, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = this.getClickable() ? (bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_CIV_INFO_HOVER : CFG.COLOR_TEXT_CIV_INFO)) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.65f);
        return color2;
    }
}

