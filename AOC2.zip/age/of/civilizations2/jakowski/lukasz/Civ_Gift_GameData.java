/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Civ_Gift_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iFromCivID;
    protected int iTurnID;

    protected Civ_Gift_GameData(int n, int n2) {
        this.iFromCivID = n;
        this.iTurnID = n2;
    }
}

