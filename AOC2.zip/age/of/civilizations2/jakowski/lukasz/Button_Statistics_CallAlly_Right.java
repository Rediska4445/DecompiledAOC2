/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics_CallAlly;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Statistics_CallAlly_Right
extends Button_Statistics_CallAlly {
    private int iCallAllyWidth;
    private String sCallAll;

    protected Button_Statistics_CallAlly_Right(int n, int n2, int n3, int n4, boolean bl) {
        super(n, n2, n3, n4, bl);
        this.callAlly(bl);
    }

    protected Button_Statistics_CallAlly_Right(int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        super(n, n2, n3, n4, bl, bl2);
        this.callAlly(bl2);
    }

    private final void callAlly(boolean bl) {
        if (bl) {
            this.sCallAll = "";
            this.iCallAllyWidth = 0;
        } else {
            this.sCallAll = this.iCivID == CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID() ? CFG.langManager.get("JoinAWar") : CFG.langManager.get("CallAlly");
            CFG.glyphLayout.setText(CFG.fontMain, this.sCallAll);
            this.iCallAllyWidth = (int)(CFG.glyphLayout.width * 0.6f);
        }
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Statistics_CallAlly_Right.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.2f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.15f));
                    }
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, Button_Statistics_CallAlly_Right.this.getPosX() + n, Button_Statistics_CallAlly_Right.this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + 1 + n2, Button_Statistics_CallAlly_Right.this.getWidth(), Button_Statistics_CallAlly_Right.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Statistics_CallAlly_Right.this.getPosX() + n, Button_Statistics_CallAlly_Right.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Statistics_CallAlly_Right.this.getWidth(), Button_Statistics_CallAlly_Right.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Statistics_CallAlly_Right.this.getPosX() + n, Button_Statistics_CallAlly_Right.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Statistics_CallAlly_Right.this.getHeight() - 1 + n2 - Button_Statistics_CallAlly_Right.this.getHeight() / 4, Button_Statistics_CallAlly_Right.this.getWidth(), Button_Statistics_CallAlly_Right.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.6f);
        if (this.getClickable() && this.iCallAllyWidth > 0) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.175f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.iCallAllyWidth + CFG.PADDING * 4, this.getHeight());
            spriteBatch.setColor(Color.WHITE);
            CFG.drawTextWithShadow(spriteBatch, this.sCallAll, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + (int)(((float)this.getHeight() - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE);
        }
        try {
            Color color2 = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            spriteBatch.setColor(color2);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - 2 + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + this.getWidth() - CFG.PADDING * 3 - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)this.getTextWidth() * 0.6f) + n, this.getPosY() + (int)(((float)this.getHeight() - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }
}

