/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Conditions_NumOfVassals_Low
extends Event_Conditions {
    protected int iCivID = -1;
    protected int iValue = 0;

    Event_Conditions_NumOfVassals_Low() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFVASSALS_LOW);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("NumberOfVassals")).append(" < ").append(this.getValue()).append(", ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("NumberOfVassals");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        int n;
        boolean bl = false;
        int n2 = 0;
        int n3 = 0;
        while (true) {
            block7: {
                if (n3 >= CFG.game.getCivsSize()) break;
                n = n2;
                if (CFG.game.getCiv(n3).getPuppetOfCivID() != this.getCivID()) break block7;
                n = n2;
                if (n3 == this.getCivID()) break block7;
                n = n2 + 1;
            }
            ++n3;
            n2 = n;
        }
        try {
            n = this.getValue();
            if (n2 >= n) return bl;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

