/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

public enum Diplomacy {
    PEACE,
    ATWAR;

}

