/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_ExpandCheck;

public class CivArmyMission_ExpandNeutral_Check
extends CivArmyMission {
    protected int iTurnsRequiredToMoveToFrontLine = 1;

    protected CivArmyMission_ExpandNeutral_Check(int n, int n2, int n3, int n4) {
        this.iArmy = n4;
        this.iProvinceID = n2;
        this.toProvinceID = n3;
        this.MISSION_ID = -1;
        this.iTurnsRequiredToMoveToFrontLine = new RegroupArmy_Data(n, this.iProvinceID, n3).getRouteSize();
        this.MISSION_TYPE = CivArmyMission_Type.REGRUOP_AFTER_RECRUIT;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = 15;
    }

    @Override
    protected boolean action(int n) {
        RegroupArmy_Data_ExpandCheck regroupArmy_Data_ExpandCheck;
        if (this.iProvinceID != this.toProvinceID && (regroupArmy_Data_ExpandCheck = new RegroupArmy_Data_ExpandCheck(n, this.iProvinceID, this.toProvinceID)).getRouteSize() > 0) {
            if (regroupArmy_Data_ExpandCheck.getRouteSize() == 1) {
                return CFG.gameAction.moveArmy(this.iProvinceID, this.toProvinceID, this.iArmy, n, true, false);
            }
            if (CFG.gameAction.moveArmy(this.iProvinceID, regroupArmy_Data_ExpandCheck.getRoute(0), this.iArmy, n, true, false)) {
                regroupArmy_Data_ExpandCheck.setFromProvinceID(regroupArmy_Data_ExpandCheck.getRoute(0));
                regroupArmy_Data_ExpandCheck.removeRoute(0);
                regroupArmy_Data_ExpandCheck.setNumOfUnits(this.iArmy);
                CFG.game.getCiv(n).addRegroupArmy(regroupArmy_Data_ExpandCheck);
                return true;
            }
            return false;
        }
        return true;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        boolean bl = Game_Calendar.TURN_ID != this.TURN_ID;
        return bl;
    }
}

