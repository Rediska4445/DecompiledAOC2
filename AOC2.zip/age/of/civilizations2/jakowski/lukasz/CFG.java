/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI;
import age.of.civilizations2.jakowski.lukasz.Achievement_Data;
import age.of.civilizations2.jakowski.lukasz.Alliances_Names_GameData;
import age.of.civilizations2.jakowski.lukasz.AoCGame;
import age.of.civilizations2.jakowski.lukasz.City;
import age.of.civilizations2.jakowski.lukasz.Civilization_GameData3;
import age.of.civilizations2.jakowski.lukasz.ColorPicker_AoC;
import age.of.civilizations2.jakowski.lukasz.Color_GameData;
import age.of.civilizations2.jakowski.lukasz.Commands;
import age.of.civilizations2.jakowski.lukasz.Continent_GameData;
import age.of.civilizations2.jakowski.lukasz.CreateVassal_Data;
import age.of.civilizations2.jakowski.lukasz.Dialog;
import age.of.civilizations2.jakowski.lukasz.DiplomacyColors_GameData2;
import age.of.civilizations2.jakowski.lukasz.EditorManager;
import age.of.civilizations2.jakowski.lukasz.EventsManager;
import age.of.civilizations2.jakowski.lukasz.FlagManager;
import age.of.civilizations2.jakowski.lukasz.FormableCivs_GameData;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Game_Action;
import age.of.civilizations2.jakowski.lukasz.Game_Ages;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Game_NewGame;
import age.of.civilizations2.jakowski.lukasz.Game_NextTurnUpdate;
import age.of.civilizations2.jakowski.lukasz.Graph_Circle;
import age.of.civilizations2.jakowski.lukasz.Graph_CircleDraw;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_Union;
import age.of.civilizations2.jakowski.lukasz.HistoryManager;
import age.of.civilizations2.jakowski.lukasz.HolyRomanEmpire_Manager;
import age.of.civilizations2.jakowski.lukasz.Ideologies_Manager;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.Keyboard;
import age.of.civilizations2.jakowski.lukasz.LanguageManager;
import age.of.civilizations2.jakowski.lukasz.Leader_GameData;
import age.of.civilizations2.jakowski.lukasz.Line_GameData;
import age.of.civilizations2.jakowski.lukasz.LinesManager;
import age.of.civilizations2.jakowski.lukasz.Map;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuManager;
import age.of.civilizations2.jakowski.lukasz.Menu_FlagPixel_Color;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_Abadon;
import age.of.civilizations2.jakowski.lukasz.Package_ContinentsData;
import age.of.civilizations2.jakowski.lukasz.Package_RegionsData;
import age.of.civilizations2.jakowski.lukasz.PalletOfCivsColors_Data;
import age.of.civilizations2.jakowski.lukasz.Pallet_Manager;
import age.of.civilizations2.jakowski.lukasz.PeaceTreaty_Data;
import age.of.civilizations2.jakowski.lukasz.PlagueManager;
import age.of.civilizations2.jakowski.lukasz.Point_XY;
import age.of.civilizations2.jakowski.lukasz.Province_Cores_GameData;
import age.of.civilizations2.jakowski.lukasz.RandomGame_Manager;
import age.of.civilizations2.jakowski.lukasz.Region_GameData;
import age.of.civilizations2.jakowski.lukasz.Report_Data;
import age.of.civilizations2.jakowski.lukasz.SaveActiveMap_GameData;
import age.of.civilizations2.jakowski.lukasz.SaveActiveMap_Status_GameData;
import age.of.civilizations2.jakowski.lukasz.Scenario_GameData_Technology;
import age.of.civilizations2.jakowski.lukasz.ServiceRibbon_GameData;
import age.of.civilizations2.jakowski.lukasz.ServiceRibbon_Manager;
import age.of.civilizations2.jakowski.lukasz.SettingsManager;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import age.of.civilizations2.jakowski.lukasz.Start_The_Game_Data;
import age.of.civilizations2.jakowski.lukasz.TerrainTypesManager;
import age.of.civilizations2.jakowski.lukasz.Terrain_GameData3;
import age.of.civilizations2.jakowski.lukasz.TimelapseManager;
import age.of.civilizations2.jakowski.lukasz.Toast;
import age.of.civilizations2.jakowski.lukasz.TradeRequest_GameData;
import age.of.civilizations2.jakowski.lukasz.TutorialManager;
import age.of.civilizations2.jakowski.lukasz.Ultimatum_GameData;
import age.of.civilizations2.jakowski.lukasz.Undo_AssignProvinceCiv;
import age.of.civilizations2.jakowski.lukasz.UnionFlagsToGenerate;
import age.of.civilizations2.jakowski.lukasz.UnionFlagsToGenerate_Manager;
import age.of.civilizations2.jakowski.lukasz.UnionFlagsToGenerate_TypesOfAction;
import age.of.civilizations2.jakowski.lukasz.UnionsManager;
import age.of.civilizations2.jakowski.lukasz.ViewsManager;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Files;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.GdxRuntimeException;
import com.badlogic.gdx.utils.Json;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

class CFG {
    protected static int ACTIVE_PROVINCE_INFO = 0;
    protected static final String AGE_OF_CIVLIZATIONS = "Age of History II";
    protected static float ALPHA_DIPLOMACY = 0.0f;
    protected static final float ALPHA_PROVINCE_CONTINENTS = 0.7f;
    protected static final float ALPHA_PROVINCE_REGIONS = 0.45f;
    protected static final float ALPHA_PROVINCE_TRADEZONES = 0.65f;
    protected static int ARMY_BG_EXTRA_HEIGHT = 0;
    protected static int ARMY_BG_EXTRA_WIDTH = 0;
    protected static int ARMY_HEIGHT = 0;
    protected static final Color BACKGROUND_COLOR;
    protected static int BUTTON_HEIGHT = 0;
    protected static int BUTTON_WIDTH = 0;
    protected static final String CIVILIZATION_FLAG_NOT_FOUND = "ran.png";
    protected static int CIV_COLOR_WIDTH = 0;
    protected static int CIV_FLAG_HEIGHT = 0;
    protected static final int CIV_FLAG_HEIGHT_FINAL = 18;
    protected static int CIV_FLAG_WIDTH = 0;
    protected static final int CIV_FLAG_WIDTH_FINAL = 27;
    protected static int CIV_INFO_MENU_WIDTH = 0;
    protected static int CIV_NAME_BG_EXTRA_HEIGHT = 0;
    protected static int CIV_NAME_BG_EXTRA_HEIGHT_ARMY = 0;
    protected static int CIV_NAME_BG_EXTRA_WIDTH = 0;
    protected static int CIV_NAME_BG_EXTRA_WIDTH_ARMY = 0;
    protected static final Color COLOR_ARMY_BG;
    protected static final Color COLOR_ARMY_BG_ACTIVE;
    protected static final Color COLOR_ARMY_BG_ALLIANCE;
    protected static final Color COLOR_ARMY_BG_MOVEUNITS;
    protected static final Color COLOR_ARMY_BG_SEA;
    protected static final Color COLOR_ARMY_BG_VASSAL;
    protected static final Color COLOR_ARMY_CAPITAL_BG;
    protected static final Color COLOR_ARMY_TEXT;
    protected static final Color COLOR_ARMY_TEXT_ACTIVE;
    protected static final Color COLOR_ARMY_TEXT_ALLIANCE;
    protected static final Color COLOR_ARMY_TEXT_CAPITAL_ACTIVE;
    protected static final Color COLOR_ARMY_TEXT_SEA;
    protected static final Color COLOR_ARMY_TEXT_SEA_ACTIVE;
    protected static final Color COLOR_BG_GAME_MENU_SHADOW;
    protected static final Color COLOR_BUILT;
    protected static final Color COLOR_BUTTON_EXTRA_DESCRIPTION;
    protected static final Color COLOR_BUTTON_GAME_TEXT;
    protected static final Color COLOR_BUTTON_GAME_TEXT_ACTIVE;
    protected static final Color COLOR_BUTTON_GAME_TEXT_HOVERED;
    protected static final Color COLOR_BUTTON_GAME_TEXT_IMPORTANT;
    protected static final Color COLOR_BUTTON_GAME_TEXT_IMPORTANT_ACTIVE;
    protected static final Color COLOR_BUTTON_GAME_TEXT_IMPORTANT_HOVER;
    protected static final Color COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE;
    protected static final Color COLOR_BUTTON_MENU_ACTIVE_BG;
    protected static final Color COLOR_BUTTON_MENU_HOVER_BG;
    protected static final Color COLOR_BUTTON_MENU_TEXT;
    protected static final Color COLOR_BUTTON_MENU_TEXT_ACTIVE;
    protected static final Color COLOR_BUTTON_MENU_TEXT_HOVERED;
    protected static final Color COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE;
    protected static Color COLOR_CITY_NAME;
    protected static final Color COLOR_COLOR_PICKER_RGB_BG;
    protected static final Color COLOR_CREATE_NEW_GAME_BOX_PLAYERS;
    protected static final Color COLOR_DISTANCE_MAX;
    protected static final Color COLOR_DISTANCE_MIN;
    protected static Color[] COLOR_ECONOMY;
    protected static final Color COLOR_FLAG_FRAME;
    protected static final Color COLOR_FORTIFICATIONS_0;
    protected static final Color COLOR_FORTIFICATIONS_1;
    protected static final Color COLOR_FORTIFICATIONS_1_MOUNTAINS;
    protected static final Color COLOR_FORT_1;
    protected static final Color COLOR_FORT_2;
    protected static final Color COLOR_GRADIENT_DARK_BLUE;
    protected static final Color COLOR_GRADIENT_DIPLOMACY;
    protected static final Color COLOR_GRADIENT_LIGHTER_DARK_BLUE;
    protected static final Color COLOR_GRADIENT_TITLE_BLUE;
    protected static final Color COLOR_GRADIENT_TITLE_BLUE_LIGHT_ALLIANCE;
    protected static Color[] COLOR_GROWTH_RATE;
    protected static final Color COLOR_INFO_BOX_GRADIENT;
    protected static final Color COLOR_INGAME_DIPLOMACY_POINTS;
    protected static final Color COLOR_INGAME_DIPLOMACY_POINTS_ACTIVE;
    protected static final Color COLOR_INGAME_DIPLOMACY_POINTS_HOVER;
    protected static final Color COLOR_INGAME_GOLD;
    protected static final Color COLOR_INGAME_GOLD_ACTIVE;
    protected static final Color COLOR_INGAME_GOLD_HOVER;
    protected static final Color COLOR_INGAME_MOVEMENT;
    protected static final Color COLOR_INGAME_MOVEMENT_ACTIVE;
    protected static final Color COLOR_INGAME_MOVEMENT_HOVER;
    protected static final Color COLOR_INGAME_MOVEMENT_ZERO;
    protected static final Color COLOR_INGAME_MOVEMENT_ZERO_ACTIVE;
    protected static final Color COLOR_INGAME_MOVEMENT_ZERO_HOVER;
    protected static final Color COLOR_LOADING_SPLIT;
    protected static final Color COLOR_LOADING_SPLIT_ACTIVE;
    protected static final Color COLOR_MESSAGE_TITLE;
    protected static final Color COLOR_MINIMAP_BORDER;
    protected static final Color COLOR_NEW_GAME_EDGE_LINE;
    protected static Color[] COLOR_POPULATION;
    protected static final Color COLOR_PORT_0;
    protected static final Color COLOR_PORT_1;
    protected static final Color COLOR_PORT_m1;
    protected static Color COLOR_PROVINCE_ACTIVE_PROVINCE_BORDER;
    protected static final Color COLOR_PROVINCE_ARMY_MAX;
    protected static final Color COLOR_PROVINCE_ARMY_MIN;
    protected static final Color COLOR_PROVINCE_BORDER_CIV_REGION;
    protected static Color COLOR_PROVINCE_DASHED;
    protected static Color COLOR_PROVINCE_SEABYSEA;
    protected static Color COLOR_PROVINCE_STRAIGHT;
    protected static final Color COLOR_SLIDER_BORDER;
    protected static final Color COLOR_SLIDER_LEFT_BG;
    protected static final Color COLOR_SLIDER_LEFT_BG2;
    protected static final Color COLOR_SLIDER_LEFT_BG3;
    protected static final Color COLOR_SLIDER_LEFT_INSTANTLY;
    protected static final Color COLOR_SLIDER_RIGHT_BG;
    protected static final Color COLOR_STARTINGMONEY_0;
    protected static final Color COLOR_STARTINGMONEY_MAX;
    protected static final Color COLOR_STARTINGMONEY_MIN;
    protected static Color[] COLOR_TECHNOLOGY_LEVEL;
    protected static final Color COLOR_TEXT_CHECKBOX_FALSE;
    protected static final Color COLOR_TEXT_CHECKBOX_TRUE;
    protected static final Color COLOR_TEXT_CIV_INFO;
    protected static final Color COLOR_TEXT_CIV_INFO_ACTIVE;
    protected static final Color COLOR_TEXT_CIV_INFO_HOVER;
    protected static final Color COLOR_TEXT_CIV_INFO_TITLE;
    protected static final Color COLOR_TEXT_CIV_NAME;
    protected static final Color COLOR_TEXT_CIV_NAME_ACTIVE;
    protected static final Color COLOR_TEXT_CIV_NAME_HOVERED;
    protected static final Color COLOR_TEXT_CNG_TOP_SCENARIO_INFO;
    protected static final Color COLOR_TEXT_CNG_TOP_SCENARIO_NAME;
    protected static final Color COLOR_TEXT_CNG_TOP_SCENARIO_NAME_HOVER;
    protected static final Color COLOR_TEXT_DEVELOPMENT;
    protected static final Color COLOR_TEXT_ECONOMY;
    protected static final Color COLOR_TEXT_ECONOMY_ACTIVE;
    protected static final Color COLOR_TEXT_ECONOMY_HOVER;
    protected static final Color COLOR_TEXT_FREE_MOVE;
    protected static final Color COLOR_TEXT_FREE_MOVE_ACTIVE;
    protected static final Color COLOR_TEXT_FREE_MOVE_HOVER;
    protected static final Color COLOR_TEXT_GOLDEN_AGE;
    protected static final Color COLOR_TEXT_GREEN;
    protected static final Color COLOR_TEXT_HAPPINESS_ACTIVE;
    protected static final Color COLOR_TEXT_HAPPINESS_HOVER;
    protected static final Color COLOR_TEXT_HAPPINESS_MAX;
    protected static final Color COLOR_TEXT_HAPPINESS_MIN;
    protected static final Color COLOR_TEXT_MODIFIER_NEGATIVE;
    protected static final Color COLOR_TEXT_MODIFIER_NEGATIVE2;
    protected static final Color COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE;
    protected static final Color COLOR_TEXT_MODIFIER_NEGATIVE_HOVER;
    protected static final Color COLOR_TEXT_MODIFIER_NEUTRAL;
    protected static final Color COLOR_TEXT_MODIFIER_NEUTRAL2;
    protected static final Color COLOR_TEXT_MODIFIER_POSITIVE;
    protected static final Color COLOR_TEXT_MODIFIER_POSITIVE_ACTIVE;
    protected static final Color COLOR_TEXT_MODIFIER_POSITIVE_HOVER;
    protected static final Color COLOR_TEXT_NUM_OF_PROVINCES;
    protected static final Color COLOR_TEXT_OPTIONS_LEFT_NS;
    protected static final Color COLOR_TEXT_OPTIONS_LEFT_NS_ACTIVE;
    protected static final Color COLOR_TEXT_OPTIONS_LEFT_NS_HOVER;
    protected static final Color COLOR_TEXT_OPTIONS_NS;
    protected static final Color COLOR_TEXT_OPTIONS_NS_ACTIVE;
    protected static final Color COLOR_TEXT_OPTIONS_NS_HOVER;
    protected static final Color COLOR_TEXT_POPULATION;
    protected static final Color COLOR_TEXT_POPULATION_ACTIVE;
    protected static final Color COLOR_TEXT_POPULATION_GROWTHRATE_MAX;
    protected static final Color COLOR_TEXT_POPULATION_GROWTHRATE_MIN;
    protected static final Color COLOR_TEXT_POPULATION_HOVER;
    protected static final Color COLOR_TEXT_PROVINCE_OWNER;
    protected static final Color COLOR_TEXT_PROVINCE_OWNER_ACTIVE;
    protected static final Color COLOR_TEXT_PROVINCE_OWNER_HOVER;
    protected static final Color COLOR_TEXT_PROVINCE_STABILITY_MAX;
    protected static final Color COLOR_TEXT_PROVINCE_STABILITY_MIN;
    protected static final Color COLOR_TEXT_PROVINCE_STABILITY_MIN_0;
    protected static final Color COLOR_TEXT_PROVINCE_VALUE;
    protected static final Color COLOR_TEXT_PROVINCE_VALUE_ACTIVE;
    protected static final Color COLOR_TEXT_PROVINCE_VALUE_HOVER;
    protected static final Color COLOR_TEXT_RANK;
    protected static final Color COLOR_TEXT_RANK_ACTIVE;
    protected static final Color COLOR_TEXT_RANK_HOVER;
    protected static final Color COLOR_TEXT_RECRUITABLE_MAX;
    protected static final Color COLOR_TEXT_RECRUITABLE_MIN;
    protected static final Color COLOR_TEXT_RESEARCH;
    protected static final Color COLOR_TEXT_REVOLUTION_MAX;
    protected static final Color COLOR_TEXT_REVOLUTION_MIN;
    protected static final Color COLOR_TEXT_REVOLUTION_MIN_0;
    protected static final Color COLOR_TEXT_TECHNOLOGY;
    protected static final Color COLOR_TEXT_TOP_VIEWS;
    protected static final Color COLOR_TEXT_TOP_VIEWS_ACTIVE;
    protected static final Color COLOR_TEXT_TOP_VIEWS_HOVER;
    protected static final Color COLOR_TEXT_TOP_VIEWS_NOT_CLICKABLE;
    protected static final Color COLOR_WATCH_TOWER;
    protected static final int COST_OF_FORM_CIVILIZATION_DIPLOMACY_POINTS = 24;
    protected static final int COST_OF_FORM_CIVILIZATION_GOLD = 1000;
    protected static final int COST_OF_RECRUIT_ARMY_MONEY = 5;
    protected static String CREATE_PACKAGE_ALLIANCE_NAMES_GAME_DATA_TAG;
    protected static String CREATE_PACKAGE_CONTINENT_GAME_DATA_TAG;
    protected static int CREATE_SCENARIO_AGE = 0;
    protected static String CREATE_SCENARIO_AUTHOR;
    protected static String CREATE_SCENARIO_GAME_DATA_TAG;
    protected static boolean CREATE_SCENARIO_IS_PART_OF_CAMPAIGN = false;
    protected static String CREATE_SCENARIO_NAME;
    protected static String CREATE_SCENARIO_WIKI;
    protected static boolean DEBUG_MODE = true;
    protected static final int DEFAULT_ARMY = 750;
    protected static final int DEFAULT_ARMY_MAX = 25000;
    protected static final int DEFAULT_ARMY_NOT_SET_UPED = -1;
    protected static final int DEFAULT_ECONOMY = 32000;
    protected static final int DEFAULT_ECONOMY_MAX = 100000;
    protected static final float DEFAULT_GOODS_LEVEL = 0.2f;
    protected static final float DEFAULT_INVESTMENTS_LEVEL = 0.15f;
    protected static final int DEFAULT_MONEY = 4500;
    protected static final int DEFAULT_MONEY_MAX = 75000;
    protected static final int DEFAULT_MONEY_MAX2 = 100000;
    protected static final int DEFAULT_MONEY_MIN = -10000;
    protected static final int DEFAULT_MONEY_MIN2 = -100000;
    protected static final int DEFAULT_MONEY_NOT_SET_UPED = -999999;
    protected static final int DEFAULT_POPULATION = 65000;
    protected static final int DEFAULT_POPULATION_MAX = 200000;
    protected static final float DEFAULT_RESEARACH_LEVEL = 0.0f;
    protected static float DENSITY = 0.0f;
    protected static int DIFFICULTY = 0;
    protected static final int DIPLOMACY_MAX_NUMBER_OF_TURNS_FOR_DEFENSIVE_PACT = 40;
    protected static final int DIPLOMACY_MAX_NUMBER_OF_TURNS_FOR_GUARANTEE = 100;
    protected static final int DIPLOMACY_MAX_NUMBER_OF_TURNS_FOR_MILITARY_ACCESS = 40;
    protected static final int DIPLOMACY_MAX_NUMBER_OF_TURNS_FOR_PACT = 40;
    protected static final int DIPLOMACY_MAX_NUMBER_OF_TURNS_FOR_TRUCE = 50;
    protected static String EDITOR_ACTIVE_GAMEDATA_TAG;
    protected static int EDIT_ALLIANCE_NAMES_BUNDLE_ID = 0;
    protected static final String FILE_AGES_LIST = "Ages";
    protected static final String FILE_CONFIG = "config.ini";
    protected static final String FILE_GAME_ALLIANCE_NAMES_PATH = "alliance_names/";
    protected static final String FILE_GAME_CIVILIZATIONS_COLORS_PATH = "civilizations_colors/";
    protected static final String FILE_GAME_CIVILIZATIONS_EDITOR_NAME = "_NM";
    protected static final String FILE_GAME_CIVILIZATIONS_EDITOR_PATH = "civilizations_editor/";
    protected static final String FILE_GAME_CIVILIZATIONS_FLAGS_DATA_EXTRA_TAG = "_FD";
    protected static final String FILE_GAME_CIVILIZATIONS_FLAG_EXTRA_TAG = "_FL.png";
    protected static final String FILE_GAME_CIVILIZATIONS_FLAG_H_EXTRA_TAG = "_FLH.png";
    protected static final String FILE_GAME_CIVILIZATIONS_PATH = "civilizations/";
    protected static final String FILE_GAME_CIVILIZATIONS_WIKIPEDIA_INFO_PATH = "civilizations_informations/";
    protected static final String FILE_GAME_DIPLOMACY_COLORS_PACKAGES_PATH = "packages/";
    protected static final String FILE_GAME_DIPLOMACY_COLORS_PATH = "diplomacy_colors/";
    protected static final String FILE_GAME_FLAGSH_PATH = "flagsH/";
    protected static final String FILE_GAME_FLAGS_EDITOR_DIVISIONS_LIST = "divisions";
    protected static final String FILE_GAME_FLAGS_EDITOR_DIVISIONS_PATH = "divisions/";
    protected static final String FILE_GAME_FLAGS_EDITOR_OVERLAYS_LIST = "overlays";
    protected static final String FILE_GAME_FLAGS_EDITOR_OVERLAYS_PATH = "overlays/";
    protected static final String FILE_GAME_FLAGS_EDITOR_PATH = "flags_editor/";
    protected static final String FILE_GAME_FLAGS_PATH = "flags/";
    protected static final String FILE_GAME_LEADERS_IMG_PATH = "leadersIMG/";
    protected static final String FILE_GAME_LEADERS_PATH = "leaders/";
    protected static final String FILE_GAME_LINES_PATH = "lines/";
    protected static final String FILE_GAME_LIST = "Age_of_Civilizations";
    protected static final String FILE_GAME_LIST_ACTIVE = "_Active";
    protected static final String FILE_GAME_PALLETS_OF_CIVS_COLORS_PATH = "pallets_of_civs_colors/";
    protected static final String FILE_GAME_PATH = "game/";
    protected static final String FILE_GAME_RELIGIONS_PATH = "religions/";
    protected static final String FILE_GAME_SAVE_TIMELINE = "_T";
    protected static final String FILE_GAME_SAVE_TIMELINE_OWNERS = "_O";
    protected static final String FILE_GAME_SAVE_TIMELINE_PATH = "TS/";
    protected static final String FILE_GAME_SAVE_TIMELINE_STATS = "_S";
    protected static final String FILE_GAME_SAVE_TIMELINE_TURNCHANGES_PATH = "TURN/";
    protected static final String FILE_GAME_SAVE_TIMELINE_TURN_CHANGES = "_C";
    protected static final String FILE_GAME_SCENARIOS_ARMIES = "_A";
    protected static final String FILE_GAME_SCENARIOS_CORES = "_C";
    protected static final String FILE_GAME_SCENARIOS_DIPLOMACY = "_D";
    protected static final String FILE_GAME_SCENARIOS_EVENTS = "_E";
    protected static final String FILE_GAME_SCENARIOS_EVENTS_IMAGES = "events/";
    protected static final String FILE_GAME_SCENARIOS_HRE = "_HRE";
    protected static final String FILE_GAME_SCENARIOS_INFO = "_INFO";
    protected static final String FILE_GAME_SCENARIOS_PATH = "scenarios/";
    protected static final String FILE_GAME_SCENARIOS_PREVIEW = "preview.png";
    protected static final String FILE_GAME_SCENARIOS_PROVINCE = "_PD";
    protected static final String FILE_GAME_SCENARIOS_WASTELAND = "_W";
    protected static final String FILE_GAME_SERVICE_RIBBONS_PATH = "service_ribbons/";
    protected static final String FILE_GAME_STATISTICS_CIV_PATH = "saves/stats/civ/";
    protected static final String FILE_GAME_TERRAIN_TYPES_PATH = "terrain_types/";
    protected static final String FILE_GAME_UNIONS_DATA = "data";
    protected static final String FILE_GAME_UNIONS_PATH = "unions/";
    protected static final String FILE_IDEOLOGIES_LIST = "Governments";
    protected static final String FILE_LANGUAGES_CIVS_PATH = "languages/civilizations/Bundle";
    protected static final String FILE_LANGUAGES_EVENTS_PATH = "languages/events/Bundle";
    protected static final String FILE_LANGUAGES_JUST_PATH = "languages/";
    protected static final String FILE_LANGUAGES_LOADING_PATH = "languages/loading/Bundle";
    protected static final String FILE_LANGUAGES_PATH = "languages/Bundle";
    protected static final String FILE_MAPS_DATA_PATH = "data/";
    protected static final String FILE_MAP_ARMY_BOXES = "army_boxes/";
    protected static final String FILE_MAP_BACKGROUND_PATH = "backgrounds/";
    protected static final String FILE_MAP_CENTER_ARMY = "center";
    protected static final String FILE_MAP_CITIES = "cities/";
    protected static final String FILE_MAP_CITIES_0_JSON = "cities.json";
    protected static final String FILE_MAP_CITIES_1_JSON = "cities_1.json";
    protected static final String FILE_MAP_CITIES_2_JSON = "cities_2.json";
    protected static final String FILE_MAP_CITIES_3_JSON = "cities_3.json";
    protected static final String FILE_MAP_CITIES_4_JSON = "cities_4.json";
    protected static final String FILE_MAP_CITIES_EDITOR = "cities/";
    protected static final String FILE_MAP_CONTINENTS_PACKGES_DATA_PATH = "packges_data/";
    protected static final String FILE_MAP_CONTINENTS_PACKGES_PATH = "packges/";
    protected static final String FILE_MAP_CONTINENTS_PATH = "continents/";
    protected static final String FILE_MAP_DATA = "data/";
    protected static final String FILE_MAP_FORMABLE_CIVS_PATH = "formable_civs/";
    protected static final String FILE_MAP_ICON = "ico.png";
    protected static final String FILE_MAP_INFORMATIONS = "config";
    protected static final String FILE_MAP_MOUNTAINS_JSON = "mountains.json";
    protected static final String FILE_MAP_PATH = "map/";
    protected static final String FILE_MAP_PRE_DEFINED_BORDERS_PATH = "predefined_borders/";
    protected static final String FILE_MAP_PROVINCES = "provinces/";
    protected static final String FILE_MAP_PROVINCE_NAMES = "province_names/";
    protected static final String FILE_MAP_PROVINCE_NAMES_FILE = "names";
    protected static final String FILE_MAP_REGIONS = "regions";
    protected static final String FILE_MAP_REGIONS_PACKGES_DATA_PATH = "packges_data/";
    protected static final String FILE_MAP_REGIONS_PACKGES_PATH = "packges/";
    protected static final String FILE_MAP_REGIONS_PATH = "regions/";
    protected static final String FILE_MAP_ROUTES = "sea_routes/";
    protected static final String FILE_MAP_SCALES_BG = "scales/";
    protected static final String FILE_MAP_SCALE_PROVINCE_BG = "provinces/";
    protected static final String FILE_MAP_SUGGESTED_OWNERS_PATH = "suggested_owners/";
    protected static final String FILE_MAP_TRADE_ZONES_PATH = "trade_zones/";
    protected static final String FILE_MAP_TRADE_ZONES_ROUTES_PATH = "routes/";
    protected static final String FILE_MAP_TRADE_ZONES_UPDATES_PATH = "zones_updates/";
    protected static final String FILE_MAP_TRADE_ZONES_ZONES_PATH = "zones/";
    protected static final String FILE_MAP_UPDATE_PATH = "update/";
    protected static final String FILE_MAP_WASTELAND_MAPS_PATH = "wasteland_maps/";
    protected static final String FILE_MAP_WONDERS = "wonders/";
    protected static final String FILE_MAP_WONDERS_IMAGES = "images/";
    protected static final String FILE_MAP_WONDERS_JSON = "wonders.json";
    protected static final String FILE_MUSIC = "music/";
    protected static final String FILE_PLAGUES_LIST = "Diseases";
    protected static final String FILE_SAVES_PATH = "saves/games/";
    protected static final String FILE_SETTINGS = "settings";
    protected static final String FILE_SETTINGS_LAST_ACTIVE_MAP = "settings_map";
    protected static final String FILE_SETTINGS_LOADING_STATUS = "status";
    protected static final String FILE_SOUNDS = "sounds/";
    protected static final String FILE_UI_ARMY_PATH = "army/";
    protected static final String FILE_UI_BOTBAR_PATH = "bot/";
    protected static final String FILE_UI_BOTTOM_PATH = "bottom/";
    protected static final String FILE_UI_BUTTONS_PATH = "buttons/";
    protected static final String FILE_UI_CROWNS_PATH = "crowns/";
    protected static final String FILE_UI_DIALOG_PATH = "dialog/";
    protected static final String FILE_UI_DIFFICULTY_PATH = "difficulty/";
    protected static final String FILE_UI_EDITOR_PATH = "editor/";
    protected static final String FILE_UI_EVENTS_DEFAULT = "default.png";
    protected static final String FILE_UI_EVENTS_PATH = "events/";
    protected static final String FILE_UI_FLAGS_PATH = "flags/";
    protected static final String FILE_UI_FONTS_PATH = "fonts/";
    protected static final String FILE_UI_FONT_CHARACTERS_MAIN_PATH = "characters_main";
    protected static final String FILE_UI_GRAPH_PATH = "graph/";
    protected static final String FILE_UI_ICONS_PATH = "icons/";
    protected static final String FILE_UI_ICONS_RELIGIONS_PATH = "religions/";
    protected static final String FILE_UI_LINES_PATH = "lines/";
    protected static final String FILE_UI_LOADING_PATH = "loading/";
    protected static final String FILE_UI_MAIN_MENU_PATH = "main_menu/";
    protected static final String FILE_UI_MOVE_STYLES_PATH = "move_styles/";
    protected static final String FILE_UI_NEW_GAME_PATH = "new_game/";
    protected static final String FILE_UI_PATH = "UI/";
    protected static final String FILE_UI_PICKER_PATH = "picker/";
    protected static final String FILE_UI_SLIDE_PATH = "slide/";
    protected static final String FILE_UI_SR_OVER_PATH = "sr_over/";
    protected static final String FILE_UI_SR_PATH = "sr/";
    protected static final String FILE_UI_TERRAIN_PATH = "terrain/";
    protected static final String FILE_UI_TITLE_PATH = "title/";
    protected static final String FILE_UI_TOPBAR_PATH = "top/";
    protected static boolean FILL_THE_MAP = false;
    protected static boolean FLIP_Y_CIV_FLAG = false;
    protected static byte FLIP_Y_CIV_FLAG_COUNTER = 0;
    protected static final byte FLIP_Y_CIV_FLAG_COUNTER_TRIC = 3;
    protected static int FOG_OF_WAR = 0;
    protected static Menu_FlagPixel_Color FlagPixelColor;
    protected static int GAME_HEIGHT = 1;
    protected static int GAME_WIDTH = 1;
    protected static String GO_TO_LINK;
    protected static final float GRAPH_DESC_TEXT_SCALE = 0.7f;
    protected static float GUI_SCALE = 0.0f;
    protected static boolean LANDSCAPE = false;
    protected static final int LOADING_CHANGE_TEXT_TIME = 2500;
    protected static float LOADING_TEXT_FONT_SCALE = 0.0f;
    protected static boolean LOGS = false;
    protected static int MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = 0;
    protected static int MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = 0;
    protected static int MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = 0;
    protected static int MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID = 0;
    protected static int MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID2 = 0;
    protected static boolean MANAGE_DIPLOMACY_DRAW_HELP_LINE = false;
    protected static final int MAX_DIPLOMACY_POINTS = 85;
    protected static int MAX_PROVINCE_VALUE = 0;
    protected static final float MAX_SCALE_DASHED = 4.0f;
    protected static final int MIN_ECONOMY_IN_A_PROVINCE = 19;
    protected static final int MIN_NUM_OF_FPS = 22;
    protected static final int MIN_POPULATION_IN_A_PROVINCE = 92;
    protected static boolean NO_LIBERITY = false;
    public static int NUCLEARAGE = 0;
    protected static final int NUM_OF_GAMES_WON_TON_UNLOCK_SANDBOX_MODE = 3;
    protected static int NUM_OF_PROVINCES_IN_VIEW = 0;
    protected static int NUM_OF_REGIONS_IN_VIEW = 0;
    protected static int NUM_OF_SEA_PROVINCES_IN_VIEW = 0;
    protected static int NUM_OF_WASTELAND_PROVINCES_IN_VIEW = 0;
    protected static int PADDING = 0;
    protected static int PALETTE_ID = 0;
    protected static int PLAYER_TURNID = 0;
    protected static float PRESENTS_GAMES_SCALE = 0.0f;
    protected static float PRESENTS_GAMES_SCALE2 = 0.0f;
    protected static long PRESENTS_TIME = 0L;
    protected static final int PRESENTS_TIME_INVIEW = 3500;
    protected static int PREVIEW_HEIGHT = 0;
    protected static final float PROVINCE_ALPHA_ARMY = 0.575f;
    protected static final float PROVINCE_ALPHA_DISEASES = 0.725f;
    protected static final float PROVINCE_ALPHA_GROWTH_RATE = 0.75f;
    protected static final float PROVINCE_ALPHA_GROWTH_RATE_INGAME = 0.6f;
    protected static final float PROVINCE_ALPHA_HAPPINESS = 0.5f;
    protected static final float PROVINCE_ALPHA_POPULATION = 0.6f;
    protected static final float PROVINCE_ALPHA_PROVINCE_VALUE = 0.75f;
    protected static float PROVINCE_ALPHA_TECHNOLOGY_LEVEL = 0.0f;
    protected static final float PROVINCE_ALPHA_TERRAIN = 0.55f;
    protected static HashMap<String, Long> PROVINCE_BORDER_ANIMATION_TIME;
    protected static int PROVINCE_BORDER_DASHED_THICKNESS = 0;
    protected static int PROVINCE_BORDER_THICKNESS = 0;
    protected static final int PROVINCE_OWNER_COLOR_INTERVAL = 725;
    protected static final int PROVINCE_VIEW_COLOR_INTERVAL = 250;
    protected static String RANDOM_CIVILIZATION;
    protected static final Color RANDOM_CIVILIZATION_COLOR;
    protected static final String RANDOM_CIV_TAG = "ran";
    protected static boolean RANDOM_FILL = false;
    protected static boolean RANDOM_PLACMENT = false;
    protected static final int REBELS_FLAGS_SIZE = 6;
    protected static final int RELATION_AT_WAR = -100;
    protected static final int RELATION_WHITE_PEACE_AFTER = 0;
    protected static boolean RELOAD_SCENARIO = false;
    protected static boolean RENDER = false;
    protected static boolean RENDER2 = false;
    protected static boolean RENDER3 = false;
    protected static final int RESIZE_PADDING_XY = 6;
    protected static boolean SANDBOX_MODE = false;
    protected static int SERVICE_RIBBON_HEIGHT = 0;
    protected static int SERVICE_RIBBON_WIDTH = 0;
    protected static boolean SHOW_ALL_MOVES = false;
    protected static boolean SHOW_ONLY_COMBAT_MOVES = false;
    protected static boolean SPECTATOR_MODE = false;
    protected static int TEXT_HEIGHT = 0;
    protected static final float TEXT_SCALE_TOP_VIEWS = 0.6f;
    protected static boolean TOTAL_WAR_MODE = false;
    protected static final String VERSION = "1.2.2.1";
    protected static boolean VIEW_SHOW_VALUES = false;
    protected static final String WWW_AOC_FACEBOOK = "https://www.facebook.com/AgeofCivilizationsJakowski/";
    protected static final String WWW_LUKASZJAKOWSKI = "http://lukaszjakowski.pl";
    protected static final String WWW_WIKI = "https://en.wikipedia.org/wiki/";
    protected static boolean XHDPI = false;
    protected static boolean XXHDPI = false;
    protected static boolean XXXHDPI = false;
    protected static boolean XXXXHDPI = false;
    protected static Achievement_Data achievement_Data;
    private static Image activeCivFlag;
    private static int activeCivInfo = 0;
    protected static Image activeCivLeader;
    protected static int activeCivilizationArmyID = 0;
    protected static int activeProvince_BEFORE = 0;
    private static ByteArrayInputStream b;
    protected static boolean bSetWasteland_AvailableProvinces = false;
    protected static Menu backToMenu;
    protected static boolean brushTool = false;
    protected static boolean chooseProvinceMode = false;
    protected static boolean chooseProvinceMode_BEFORE = false;
    protected static int chosenProvinceID = 0;
    protected static String chosen_AlphabetCharachter;
    protected static CreateVassal_Data createVassal_Data;
    protected static Dialog dialogType;
    protected static DiplomacyColors_GameData2 diplomacyColors_GameData;
    protected static Alliances_Names_GameData editorAlliancesNames_GameData;
    protected static City editorCity;
    protected static Civilization_GameData3 editorCivilization_GameData;
    protected static Line_GameData editorLine_GameData;
    protected static EditorManager editorManager;
    protected static PalletOfCivsColors_Data editorPalletOfCivsColors_Data;
    protected static List<Color> editorServiceRibbon_Colors;
    protected static ServiceRibbon_GameData editorServiceRibbon_GameData;
    protected static Terrain_GameData3 editorTerrain_Data2;
    protected static Continent_GameData editor_Continent_GameData;
    protected static Package_ContinentsData editor_Package_ContinentsData;
    protected static Package_RegionsData editor_Package_RegionsData;
    protected static Region_GameData editor_Region_GameData;
    protected static EventsManager eventsManager;
    protected static float fMOVE_MENU_PERCENTAGE = 0.0f;
    protected static float fTerrainMode_LinePercentage = 0.0f;
    protected static int flagB = 0;
    protected static FlagEditorMode flagEditorMode;
    protected static int flagG = 0;
    protected static FlagManager flagManager;
    protected static int flagR = 0;
    protected static BitmapFont fontArmy;
    protected static BitmapFont fontBorder;
    protected static BitmapFont fontMain;
    protected static FormableCivs_GameData formableCivs_GameData;
    protected static Game game;
    protected static Game_Action gameAction;
    protected static Game_Ages gameAges;
    protected static Game_NewGame gameNewGame;
    protected static Game_NextTurnUpdate game_NextTurnUpdate;
    protected static GlyphLayout glyphLayout;
    protected static Menu goToMenu;
    protected static Menu goToMenu2;
    protected static Graph_CircleDraw graphCircleDraw;
    protected static HistoryManager historyManager;
    protected static HolyRomanEmpire_Manager holyRomanEmpire_Manager;
    protected static int iAgeOfCivilizationsWidth = -1;
    protected static int iCreateScenario_ActiveProvinceID = 0;
    protected static int iCreateScenario_AssignProvinces_Civ = 0;
    protected static int iJakowskiGamesWidth = 0;
    protected static int iJakowskiGames_PresentsWidth = 0;
    protected static int iLoadingTextWidth = 0;
    protected static int iLoadingWidth = 0;
    protected static int iNumOfAvailableProvinces = 0;
    protected static int iNumOfAvailableProvincesWidth = 0;
    protected static int iNumOfFPS = 60;
    protected static int iNumOfWastelandProvinces = 0;
    protected static int iNumOfWastelandProvincesWidth = 0;
    protected static int iProvinceNameWidth = 0;
    protected static int iSelectCivilizationPlayerID = 0;
    protected static Ideologies_Manager ideologiesManager;
    protected static Keyboard_Action keyboardDelete;
    protected static String keyboardMessage;
    protected static Keyboard_Action keyboardSave;
    protected static Keyboard_Action_Write keyboardWrite;
    protected static List<Integer> lCREATE_SCENARIO_IS_PART_OF_CAMPAIGN_CIVSIDS;
    protected static List<List<Scenario_GameData_Technology>> lCreateScenario_TechnologyBContinents;
    protected static List<Undo_AssignProvinceCiv> lCreateScenario_UndoAssignProvincesCivID;
    protected static List<Integer> lCreateScenario_UndoWastelandProvinces;
    protected static long lMOVE_MENU_TIME = 0L;
    protected static List<String> lRandomAlliancesNamesPackagesTags;
    protected static long lTerrainMode_LineTime = 0L;
    protected static LanguageManager langManager;
    protected static Leader_GameData leader_GameData;
    protected static LinesManager linesManager;
    protected static boolean loadedRobotoFont = false;
    protected static long loadingTime = 0L;
    protected static Map map;
    protected static MenuManager menuManager;
    protected static boolean migrateMode = false;
    private static ObjectInputStream o;
    protected static AI oAI;
    protected static Random oR;
    protected static Pallet_Manager palletManager;
    protected static PeaceTreaty_Data peaceTreatyData;
    protected static PlagueManager plagueManager;
    protected static Province_Cores_GameData province_Cores_GameData;
    protected static RandomGame_Manager randomGameManager;
    protected static boolean regroupArmyMode = false;
    private static RenderUpdate renderUpdate_3;
    protected static Report_Data reportData;
    protected static boolean reverseDirectionX = false;
    protected static boolean reverseDirectionY = false;
    protected static String sACTIVE_DIPLOMACY_COLORS_TAG;
    protected static String sAUTHOR;
    protected static String sAtWar;
    protected static String sDEBUG = "#";
    protected static final String sJakowski = "\u0141ukasz Jakowski";
    protected static final String sJakowskiGames = "\u0141ukasz Jakowski Games";
    protected static final String sJakowskiGames_2 = "Lukasz Jakowski Games";
    protected static final String sJakowskiGames_Presents = "presents";
    protected static final String sJakowski_2 = "Lukasz Jakowski";
    protected static String sLoading;
    protected static String sLoadingText;
    protected static String sSearch;
    protected static String sTOTAL;
    protected static String sTOTAL_WORLDS_POPULATION;
    protected static String sVERSION;
    protected static boolean selectMode;
    protected static ServiceRibbon_Manager serviceRibbon_Manager;
    protected static SettingsManager settingsManager;
    protected static int slidePosX;
    protected static int slidePosY;
    protected static SoundsManager soundsManager;
    protected static Start_The_Game_Data startTheGameData;
    protected static TerrainTypesManager terrainTypesManager;
    protected static TimelapseManager timelapseManager;
    protected static Toast toast;
    protected static TopBox topBox;
    protected static TradeRequest_GameData tradeRequest;
    protected static TutorialManager tutorialManager;
    protected static Ultimatum_GameData ultimatum;
    protected static UnionFlagsToGenerate_Manager unionFlagsToGenerate_Manager;
    protected static UnionsManager unionsManager;
    protected static ViewsManager viewsManager;

    static {
        NUCLEARAGE = 1600;
        LOGS = false;
        DEBUG_MODE = false;
        sDEBUG = "#";
        iAgeOfCivilizationsWidth = -1;
        LANDSCAPE = false;
        GAME_WIDTH = 1;
        GAME_HEIGHT = 1;
        iNumOfFPS = 60;
        BACKGROUND_COLOR = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        COLOR_MINIMAP_BORDER = new Color(0.251f, 0.192f, 0.09f, 1.0f);
        GUI_SCALE = 1.0f;
        DENSITY = 1.0f;
        XHDPI = false;
        XXHDPI = false;
        XXXHDPI = false;
        XXXXHDPI = false;
        RENDER = true;
        RENDER2 = true;
        RENDER3 = true;
        PALETTE_ID = 0;
        NUM_OF_PROVINCES_IN_VIEW = 0;
        NUM_OF_SEA_PROVINCES_IN_VIEW = 0;
        NUM_OF_WASTELAND_PROVINCES_IN_VIEW = 0;
        NUM_OF_REGIONS_IN_VIEW = 0;
        settingsManager = new SettingsManager();
        PADDING = 5;
        BUTTON_HEIGHT = 68;
        BUTTON_WIDTH = 90;
        PREVIEW_HEIGHT = 194;
        CIV_COLOR_WIDTH = 3;
        CIV_NAME_BG_EXTRA_WIDTH = 8;
        CIV_NAME_BG_EXTRA_HEIGHT = 5;
        CIV_NAME_BG_EXTRA_WIDTH_ARMY = 6;
        CIV_NAME_BG_EXTRA_HEIGHT_ARMY = 4;
        ARMY_BG_EXTRA_WIDTH = 3;
        ARMY_BG_EXTRA_HEIGHT = 2;
        COLOR_TEXT_PROVINCE_OWNER = new Color(0.988f, 1.0f, 0.796f, 1.0f);
        COLOR_TEXT_PROVINCE_OWNER_HOVER = new Color(0.825f, 0.825f, 0.615f, 1.0f);
        COLOR_TEXT_PROVINCE_OWNER_ACTIVE = new Color(0.72f, 0.74f, 0.54f, 1.0f);
        COLOR_TEXT_RESEARCH = new Color(0.4f, 0.6f, 0.8f, 1.0f);
        COLOR_TEXT_DEVELOPMENT = new Color(0.19607843f, 0.19607843f, 0.39215687f, 1.0f);
        COLOR_TEXT_POPULATION = new Color(0.392f, 0.533f, 0.251f, 1.0f);
        COLOR_TEXT_POPULATION_HOVER = new Color(0.595f, 0.743f, 0.427f, 1.0f);
        COLOR_TEXT_POPULATION_ACTIVE = new Color(0.4f, 0.51f, 0.3f, 1.0f);
        COLOR_TEXT_POPULATION_GROWTHRATE_MIN = new Color(0.17254902f, 0.67058825f, 0.19607843f, 1.0f);
        COLOR_TEXT_POPULATION_GROWTHRATE_MAX = new Color(0.16862746f, 0.44313726f, 0.20784314f, 1.0f);
        COLOR_TEXT_HAPPINESS_MIN = new Color(0.7411765f, 0.19215687f, 0.30588236f, 1.0f);
        COLOR_TEXT_HAPPINESS_MAX = new Color(0.9843137f, 0.9843137f, 0.019607844f, 1.0f);
        COLOR_TEXT_RECRUITABLE_MIN = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        COLOR_TEXT_RECRUITABLE_MAX = new Color(0.11764706f, 0.13725491f, 0.29411766f, 1.0f);
        COLOR_TEXT_REVOLUTION_MIN = new Color(0.8235294f, 0.5882353f, 0.29411766f, 1.0f);
        COLOR_TEXT_REVOLUTION_MIN_0 = new Color(0.09019608f, 0.39215687f, 0.078431375f, 0.25f);
        COLOR_TEXT_REVOLUTION_MAX = new Color(0.50980395f, 0.13725491f, 0.078431375f, 1.0f);
        COLOR_TEXT_PROVINCE_STABILITY_MIN = new Color(0.5686275f, 0.13725491f, 0.09803922f, 1.0f);
        COLOR_TEXT_PROVINCE_STABILITY_MIN_0 = new Color(0.09019608f, 0.39215687f, 0.078431375f, 0.25f);
        COLOR_TEXT_PROVINCE_STABILITY_MAX = new Color(0.23529412f, 0.49019608f, 0.11764706f, 1.0f);
        COLOR_DISTANCE_MIN = new Color(0.8627451f, 0.84313726f, 0.1764706f, 1.0f);
        COLOR_DISTANCE_MAX = new Color(0.43137255f, 0.09803922f, 0.09803922f, 1.0f);
        COLOR_TEXT_HAPPINESS_HOVER = new Color(0.99607843f, 0.5137255f, 0.007843138f, 1.0f);
        COLOR_TEXT_HAPPINESS_ACTIVE = new Color(0.9843137f, 0.6901961f, 0.003921569f, 1.0f);
        COLOR_TEXT_CHECKBOX_TRUE = new Color(0.55f, 0.8f, 0.0f, 0.25f);
        COLOR_TEXT_CHECKBOX_FALSE = new Color(0.8f, 0.137f, 0.0f, 0.25f);
        COLOR_TEXT_ECONOMY = new Color(0.776f, 0.518f, 0.227f, 1.0f);
        COLOR_TEXT_ECONOMY_HOVER = new Color(0.708f, 0.448f, 0.173f, 1.0f);
        COLOR_TEXT_ECONOMY_ACTIVE = new Color(0.552f, 0.36f, 0.141f, 1.0f);
        COLOR_TEXT_TECHNOLOGY = new Color(0.8f, 0.8f, 0.8f, 1.0f);
        COLOR_TEXT_CIV_INFO = new Color(0.40392157f, 0.41960785f, 0.43137255f, 1.0f);
        COLOR_TEXT_CIV_INFO_HOVER = new Color(0.575f, 0.575f, 0.575f, 1.0f);
        COLOR_TEXT_CIV_INFO_ACTIVE = new Color(0.66f, 0.66f, 0.66f, 1.0f);
        COLOR_TEXT_CIV_INFO_TITLE = new Color(0.6862745f, 0.6862745f, 0.6862745f, 1.0f);
        COLOR_TEXT_TOP_VIEWS = new Color(0.37254903f, 0.37254903f, 0.37254903f, 1.0f);
        COLOR_TEXT_TOP_VIEWS_HOVER = new Color(0.44705883f, 0.4509804f, 0.45490196f, 1.0f);
        COLOR_TEXT_TOP_VIEWS_ACTIVE = new Color(0.85490197f, 0.7490196f, 0.36862746f, 1.0f);
        COLOR_TEXT_TOP_VIEWS_NOT_CLICKABLE = new Color(0.18431373f, 0.19215687f, 0.20784314f, 0.7f);
        COLOR_COLOR_PICKER_RGB_BG = new Color(0.047058824f, 0.0627451f, 0.078431375f, 0.55f);
        COLOR_LOADING_SPLIT_ACTIVE = new Color(0.96862745f, 0.76862746f, 0.41960785f, 0.65f);
        COLOR_LOADING_SPLIT = new Color(0.77254903f, 0.6117647f, 0.2627451f, 0.35f);
        COLOR_NEW_GAME_EDGE_LINE = new Color(0.451f, 0.329f, 0.11f, 1.0f);
        COLOR_FLAG_FRAME = new Color(0.76862746f, 0.6117647f, 0.2627451f, 1.0f);
        COLOR_TEXT_CIV_NAME = new Color(0.985f, 0.985f, 0.985f, 1.0f);
        COLOR_TEXT_CIV_NAME_HOVERED = new Color(0.784f, 0.784f, 0.784f, 1.0f);
        COLOR_TEXT_CIV_NAME_ACTIVE = new Color(0.725f, 0.725f, 0.725f, 1.0f);
        COLOR_TEXT_RANK = new Color(0.819f, 0.819f, 0.819f, 1.0f);
        COLOR_TEXT_RANK_HOVER = new Color(0.628f, 0.628f, 0.645f, 1.0f);
        COLOR_TEXT_RANK_ACTIVE = new Color(0.584f, 0.584f, 0.599f, 1.0f);
        COLOR_SLIDER_LEFT_BG = new Color(0.11764706f, 0.13725491f, 0.23529412f, 1.0f);
        COLOR_SLIDER_RIGHT_BG = new Color(0.98039216f, 0.98039216f, 0.98039216f, 1.0f);
        COLOR_SLIDER_LEFT_BG2 = new Color(0.078431375f, 0.23529412f, 0.039215688f, 1.0f);
        COLOR_SLIDER_LEFT_BG3 = new Color(0.29411766f, 0.09803922f, 0.13725491f, 1.0f);
        COLOR_SLIDER_LEFT_INSTANTLY = new Color(0.09803922f, 0.23529412f, 0.15686275f, 1.0f);
        COLOR_CREATE_NEW_GAME_BOX_PLAYERS = new Color(0.4509804f, 0.32941177f, 0.10980392f, 1.0f);
        COLOR_GRADIENT_DARK_BLUE = new Color(0.025f, 0.04f, 0.08f, 0.75f);
        COLOR_GRADIENT_LIGHTER_DARK_BLUE = new Color(0.043f, 0.102f, 0.157f, 0.75f);
        COLOR_GRADIENT_DIPLOMACY = new Color(0.09019608f, 0.16078432f, 0.26666668f, 0.75f);
        COLOR_TEXT_MODIFIER_NEGATIVE = new Color(0.98039216f, 0.15686275f, 0.15686275f, 1.0f);
        COLOR_TEXT_MODIFIER_NEGATIVE2 = new Color(0.7490196f, 0.18431373f, 0.14117648f, 1.0f);
        COLOR_TEXT_MODIFIER_NEGATIVE_HOVER = new Color(0.70980394f, 0.17254902f, 0.1254902f, 1.0f);
        COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE = new Color(0.6509804f, 0.14117648f, 0.09411765f, 1.0f);
        COLOR_TEXT_MODIFIER_NEUTRAL = new Color(0.8f, 0.8f, 0.8f, 1.0f);
        COLOR_TEXT_MODIFIER_NEUTRAL2 = new Color(0.8627451f, 0.78431374f, 0.27450982f, 1.0f);
        COLOR_TEXT_MODIFIER_POSITIVE = new Color(0.007843138f, 0.5176471f, 0.011764706f, 1.0f);
        COLOR_TEXT_MODIFIER_POSITIVE_HOVER = new Color(0.003921569f, 0.4509804f, 0.007843138f, 1.0f);
        COLOR_TEXT_MODIFIER_POSITIVE_ACTIVE = new Color(0.003921569f, 0.4f, 0.007843138f, 1.0f);
        COLOR_TEXT_FREE_MOVE = new Color(0.8980392f, 0.9254902f, 0.02745098f, 1.0f);
        COLOR_TEXT_FREE_MOVE_ACTIVE = new Color(0.6745098f, 0.68235296f, 0.007843138f, 1.0f);
        COLOR_TEXT_FREE_MOVE_HOVER = new Color(0.7607843f, 0.7764706f, 0.015686275f, 1.0f);
        COLOR_TEXT_PROVINCE_VALUE = new Color(0.784f, 0.588f, 0.196f, 1.0f);
        COLOR_TEXT_PROVINCE_VALUE_HOVER = new Color(0.668f, 0.473f, 0.152f, 1.0f);
        COLOR_TEXT_PROVINCE_VALUE_ACTIVE = new Color(0.605f, 0.414f, 0.132f, 1.0f);
        COLOR_TEXT_GREEN = new Color(0.173f, 0.671f, 0.196f, 1.0f);
        COLOR_TEXT_CNG_TOP_SCENARIO_NAME = new Color(0.9f, 0.9f, 0.9f, 1.0f);
        COLOR_TEXT_CNG_TOP_SCENARIO_NAME_HOVER = new Color(0.78f, 0.78f, 0.78f, 1.0f);
        COLOR_TEXT_CNG_TOP_SCENARIO_INFO = new Color(0.56f, 0.56f, 0.56f, 1.0f);
        COLOR_TEXT_OPTIONS_NS = new Color(0.7372549f, 0.7490196f, 0.7647059f, 1.0f);
        COLOR_TEXT_OPTIONS_NS_HOVER = new Color(0.57254905f, 0.58431375f, 0.5921569f, 1.0f);
        COLOR_TEXT_OPTIONS_NS_ACTIVE = new Color(0.5019608f, 0.5137255f, 0.5294118f, 1.0f);
        COLOR_TEXT_OPTIONS_LEFT_NS = new Color(0.8392157f, 0.8392157f, 0.8392157f, 1.0f);
        COLOR_TEXT_OPTIONS_LEFT_NS_HOVER = new Color(0.7137255f, 0.7137255f, 0.7137255f, 1.0f);
        COLOR_TEXT_OPTIONS_LEFT_NS_ACTIVE = new Color(0.6509804f, 0.6509804f, 0.6509804f, 1.0f);
        COLOR_STARTINGMONEY_MIN = new Color(0.6f, 0.20392157f, 0.023529412f, 1.0f);
        COLOR_STARTINGMONEY_0 = new Color(0.84705883f, 0.9411765f, 0.6509804f, 1.0f);
        COLOR_STARTINGMONEY_MAX = new Color(0.1254902f, 0.5254902f, 0.27058825f, 1.0f);
        COLOR_BUTTON_MENU_HOVER_BG = new Color(1.0f, 1.0f, 1.0f, 0.9f);
        COLOR_BUTTON_MENU_ACTIVE_BG = new Color(1.0f, 1.0f, 1.0f, 0.8f);
        COLOR_BUTTON_MENU_TEXT = new Color(0.82f, 0.82f, 0.82f, 1.0f);
        COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE = new Color(0.78f, 0.78f, 0.78f, 0.4f);
        COLOR_BUTTON_MENU_TEXT_HOVERED = new Color(0.71f, 0.715f, 0.72f, 1.0f);
        COLOR_BUTTON_MENU_TEXT_ACTIVE = new Color(0.1f, 0.1f, 0.1f, 1.0f);
        COLOR_BUTTON_GAME_TEXT = new Color(0.376f, 0.388f, 0.376f, 1.0f);
        COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE = new Color(0.674f, 0.09f, 0.066f, 0.5f);
        COLOR_BUTTON_GAME_TEXT_ACTIVE = new Color(0.768f, 0.608f, 0.263f, 1.0f);
        COLOR_BUTTON_GAME_TEXT_HOVERED = new Color(0.445f, 0.445f, 0.445f, 1.0f);
        COLOR_BUTTON_GAME_TEXT_IMPORTANT = new Color(0.548f, 0.562f, 0.548f, 1.0f);
        COLOR_BUTTON_GAME_TEXT_IMPORTANT_HOVER = new Color(0.665f, 0.682f, 0.665f, 1.0f);
        COLOR_BUTTON_GAME_TEXT_IMPORTANT_ACTIVE = new Color(0.78f, 0.78f, 0.78f, 1.0f);
        COLOR_TEXT_NUM_OF_PROVINCES = new Color(0.8039216f, 0.59607846f, 0.0f, 1.0f);
        COLOR_TEXT_GOLDEN_AGE = new Color(0.9882353f, 0.8117647f, 0.2509804f, 1.0f);
        COLOR_GRADIENT_TITLE_BLUE = new Color(0.105882354f, 0.16078432f, 0.2901961f, 0.775f);
        COLOR_MESSAGE_TITLE = new Color(0.2f, 0.6f, 0.4f, 0.775f);
        COLOR_GRADIENT_TITLE_BLUE_LIGHT_ALLIANCE = new Color(0.0f, 0.21960784f, 0.61960787f, 0.775f);
        reverseDirectionX = true;
        reverseDirectionY = true;
        DIFFICULTY = 1;
        FOG_OF_WAR = 1;
        FILL_THE_MAP = true;
        RANDOM_PLACMENT = false;
        RANDOM_FILL = false;
        SANDBOX_MODE = false;
        SPECTATOR_MODE = false;
        TOTAL_WAR_MODE = false;
        NO_LIBERITY = false;
        RANDOM_CIVILIZATION_COLOR = new Color(0.03f, 0.03f, 0.05f, 1.0f);
        PLAYER_TURNID = 0;
        regroupArmyMode = false;
        chooseProvinceMode = false;
        chosenProvinceID = -1;
        migrateMode = false;
        chooseProvinceMode_BEFORE = false;
        activeProvince_BEFORE = -1;
        activeCivilizationArmyID = 0;
        VIEW_SHOW_VALUES = true;
        SHOW_ALL_MOVES = false;
        SHOW_ONLY_COMBAT_MOVES = true;
        RANDOM_CIVILIZATION = null;
        topBox = new TopBox();
        sLoading = "Loading";
        sVERSION = "vk.com/";
        sAUTHOR = null;
        oR = new Random();
        sLoadingText = "";
        iLoadingTextWidth = 0;
        loadingTime = 0L;
        LOADING_TEXT_FONT_SCALE = 0.7f;
        PRESENTS_GAMES_SCALE = 1.0f;
        PRESENTS_GAMES_SCALE2 = 0.7f;
        PRESENTS_TIME = 0L;
        activeCivInfo = 0;
        activeCivFlag = null;
        activeCivLeader = null;
        CIV_INFO_MENU_WIDTH = 240;
        province_Cores_GameData = null;
        formableCivs_GameData = null;
        leader_GameData = null;
        editorLine_GameData = null;
        editor_Region_GameData = null;
        editor_Continent_GameData = null;
        EDITOR_ACTIVE_GAMEDATA_TAG = null;
        GO_TO_LINK = "";
        editor_Package_ContinentsData = null;
        editor_Package_RegionsData = null;
        CREATE_PACKAGE_CONTINENT_GAME_DATA_TAG = null;
        COLOR_BUTTON_EXTRA_DESCRIPTION = new Color(1.0f, 1.0f, 1.0f, 0.4f);
        COLOR_GROWTH_RATE = new Color[]{new Color(1.0f, 0.9764706f, 0.64705884f, 0.75f), new Color(0.99607843f, 0.9607843f, 0.0f, 0.75f), new Color(0.99607843f, 0.8901961f, 0.0f, 0.75f), new Color(0.99607843f, 0.7490196f, 0.0f, 0.75f), new Color(0.99607843f, 0.60784316f, 0.0f, 0.75f), new Color(0.99607843f, 0.42352942f, 0.0f, 0.75f), new Color(0.99607843f, 0.23529412f, 0.0f, 0.75f), new Color(0.8627451f, 0.0f, 0.0f, 0.75f), new Color(0.54901963f, 0.0f, 0.0f, 0.75f), new Color(0.39215687f, 0.0f, 0.0f, 0.75f), new Color(0.3137255f, 0.0f, 0.0f, 0.75f)};
        COLOR_PROVINCE_ARMY_MIN = new Color(0.7058824f, 0.7058824f, 0.78431374f, 0.575f);
        COLOR_PROVINCE_ARMY_MAX = new Color(0.96862745f, 0.9372549f, 0.39215687f, 0.575f);
        MAX_PROVINCE_VALUE = 10;
        COLOR_POPULATION = new Color[]{new Color(0.8627451f, 0.93333334f, 0.78039217f, 0.6f), new Color(0.8f, 0.92941177f, 0.7372549f, 0.6f), new Color(0.6901961f, 0.89411765f, 0.59607846f, 0.6f), new Color(0.6117647f, 0.8666667f, 0.49019608f, 0.6f), new Color(0.5647059f, 0.87058824f, 0.3137255f, 0.6f), new Color(0.41568628f, 0.7921569f, 0.23529412f, 0.6f), new Color(0.37254903f, 0.7294118f, 0.19607843f, 0.6f), new Color(0.30588236f, 0.6039216f, 0.16078432f, 0.6f), new Color(0.2509804f, 0.49019608f, 0.13333334f, 0.6f), new Color(0.20392157f, 0.4f, 0.10980392f, 0.6f), new Color(0.14509805f, 0.28627452f, 0.078431375f, 0.6f)};
        COLOR_ECONOMY = new Color[]{new Color(1.0f, 0.92156863f, 0.8f, 0.6f), new Color(1.0f, 0.83137256f, 0.65882355f, 0.6f), new Color(1.0f, 0.77254903f, 0.56078434f, 0.6f), new Color(1.0f, 0.7294118f, 0.47843137f, 0.6f), new Color(1.0f, 0.63529414f, 0.3254902f, 0.6f), new Color(0.96862745f, 0.54509807f, 0.19215687f, 0.6f), new Color(0.9411765f, 0.4627451f, 0.019607844f, 0.6f), new Color(0.88235295f, 0.3882353f, 0.0627451f, 0.6f), new Color(0.7921569f, 0.24313726f, 0.02745098f, 0.6f), new Color(0.7137255f, 0.09803922f, 0.015686275f, 0.6f), new Color(0.654902f, 0.08627451f, 0.011764706f, 0.6f)};
        PROVINCE_ALPHA_TECHNOLOGY_LEVEL = 0.45f;
        COLOR_TECHNOLOGY_LEVEL = new Color[]{new Color(0.94509804f, 0.95686275f, 1.0f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.8784314f, 0.8784314f, 0.9647059f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.79607844f, 0.8039216f, 1.0f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.7019608f, 0.7137255f, 0.9019608f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.6117647f, 0.627451f, 0.9411765f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.49803922f, 0.5176471f, 0.9529412f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.34901962f, 0.38039216f, 0.9019608f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.21960784f, 0.2509804f, 0.8509804f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.07450981f, 0.101960786f, 0.5803922f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.05490196f, 0.08235294f, 0.52156866f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL), new Color(0.043137256f, 0.07058824f, 0.43137255f, PROVINCE_ALPHA_TECHNOLOGY_LEVEL)};
        ALPHA_DIPLOMACY = 0.35f;
        COLOR_SLIDER_BORDER = new Color(0.42745098f, 0.32941177f, 0.14901961f, 1.0f);
        COLOR_PORT_m1 = new Color(0.9607843f, 0.9607843f, 0.9607843f, 0.25f);
        COLOR_PORT_0 = new Color(0.7607843f, 0.7647059f, 0.8039216f, 0.25f);
        COLOR_PORT_1 = new Color(0.0f, 0.27450982f, 0.50980395f, 0.55f);
        COLOR_FORT_1 = new Color(0.972549f, 0.63529414f, 0.3372549f, 0.55f);
        COLOR_FORT_2 = new Color(0.9490196f, 0.52156866f, 0.14117648f, 0.55f);
        COLOR_WATCH_TOWER = new Color(0.11764706f, 0.21176471f, 0.3372549f, 0.55f);
        COLOR_BUILT = new Color(0.2f, 0.4f, 0.8f, 0.45f);
        COLOR_FORTIFICATIONS_0 = new Color(0.9019608f, 0.9019608f, 0.9019608f, 0.45f);
        COLOR_FORTIFICATIONS_1 = new Color(0.13725491f, 0.5882353f, 0.11764706f, 0.6f);
        COLOR_FORTIFICATIONS_1_MOUNTAINS = new Color(0.105882354f, 0.43137255f, 0.09019608f, 0.6f);
        PROVINCE_BORDER_THICKNESS = 1;
        PROVINCE_BORDER_DASHED_THICKNESS = 1;
        COLOR_PROVINCE_BORDER_CIV_REGION = new Color(0.9411765f, 0.7529412f, 0.15294118f, 1.0f);
        COLOR_PROVINCE_DASHED = new Color(0.04f, 0.04f, 0.04f, 0.64705884f);
        COLOR_PROVINCE_STRAIGHT = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        COLOR_PROVINCE_SEABYSEA = new Color(0.94f, 0.94f, 0.95f, 0.07f);
        COLOR_PROVINCE_ACTIVE_PROVINCE_BORDER = new Color(1.0f, 0.91764706f, 0.015686275f, 1.0f);
        backToMenu = Menu.eMAINMENU;
        goToMenu = Menu.eMAINMENU;
        goToMenu2 = Menu.eMAINMENU;
        CREATE_SCENARIO_GAME_DATA_TAG = null;
        CREATE_SCENARIO_IS_PART_OF_CAMPAIGN = false;
        lCREATE_SCENARIO_IS_PART_OF_CAMPAIGN_CIVSIDS = new ArrayList<Integer>();
        CREATE_SCENARIO_NAME = "";
        CREATE_SCENARIO_AUTHOR = "";
        CREATE_SCENARIO_WIKI = "";
        CREATE_SCENARIO_AGE = 0;
        iCreateScenario_AssignProvinces_Civ = -1;
        RELOAD_SCENARIO = false;
        chosen_AlphabetCharachter = null;
        sSearch = null;
        bSetWasteland_AvailableProvinces = true;
        iNumOfAvailableProvinces = 0;
        iNumOfAvailableProvincesWidth = 0;
        iNumOfWastelandProvinces = 0;
        iNumOfWastelandProvincesWidth = 0;
        MANAGE_DIPLOMACY_DRAW_HELP_LINE = true;
        MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = 1;
        MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID = 1;
        MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID2 = 0;
        MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = -1;
        MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = -1;
        sAtWar = null;
        reportData = null;
        flagManager = new FlagManager();
        randomGameManager = null;
        holyRomanEmpire_Manager = null;
        unionFlagsToGenerate_Manager = new UnionFlagsToGenerate_Manager();
        timelapseManager = new TimelapseManager();
        tutorialManager = new TutorialManager();
        peaceTreatyData = new PeaceTreaty_Data();
        createVassal_Data = null;
        tradeRequest = new TradeRequest_GameData();
        ultimatum = new Ultimatum_GameData();
        brushTool = false;
        selectMode = true;
        COLOR_CITY_NAME = new Color(0.9137255f, 0.9137255f, 0.9137255f, 0.85f);
        glyphLayout = new GlyphLayout();
        fontMain = null;
        fontArmy = null;
        fontBorder = null;
        loadedRobotoFont = false;
        ARMY_HEIGHT = 1;
        TEXT_HEIGHT = 1;
        iProvinceNameWidth = -1;
        COLOR_ARMY_BG = new Color(0.0f, 0.0f, 0.0f, 0.8f);
        COLOR_ARMY_CAPITAL_BG = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        COLOR_ARMY_BG_ACTIVE = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        COLOR_ARMY_BG_SEA = new Color(0.05490196f, 0.1254902f, 0.23529412f, 1.0f);
        COLOR_ARMY_BG_ALLIANCE = new Color(0.019607844f, 0.09803922f, 0.1764706f, 1.0f);
        COLOR_ARMY_TEXT_ALLIANCE = new Color(0.98039216f, 0.99607843f, 0.99607843f, 1.0f);
        COLOR_ARMY_BG_VASSAL = new Color(0.078431375f, 0.23529412f, 0.10980392f, 1.0f);
        COLOR_ARMY_BG_MOVEUNITS = new Color(0.129f, 0.078f, 0.063f, 0.9f);
        COLOR_ARMY_TEXT = new Color(0.88235295f, 0.88235295f, 0.27450982f, 1.0f);
        COLOR_ARMY_TEXT_ACTIVE = new Color(0.12156863f, 0.12156863f, 0.12156863f, 1.0f);
        COLOR_ARMY_TEXT_CAPITAL_ACTIVE = new Color(0.99215686f, 0.99607843f, 0.99607843f, 1.0f);
        COLOR_ARMY_TEXT_SEA = new Color(0.8235294f, 0.8235294f, 0.8235294f, 1.0f);
        COLOR_ARMY_TEXT_SEA_ACTIVE = new Color(0.5294118f, 0.54901963f, 0.5686275f, 1.0f);
        COLOR_INGAME_GOLD = new Color(0.87058824f, 0.85882354f, 0.12941177f, 1.0f);
        COLOR_INGAME_GOLD_HOVER = new Color(0.75686276f, 0.75686276f, 0.0f, 1.0f);
        COLOR_INGAME_GOLD_ACTIVE = new Color(0.6901961f, 0.6901961f, 0.0f, 1.0f);
        COLOR_INGAME_MOVEMENT = new Color(0.25882354f, 0.68235296f, 0.9019608f, 1.0f);
        COLOR_INGAME_MOVEMENT_HOVER = new Color(0.2f, 0.6f, 0.8f, 1.0f);
        COLOR_INGAME_MOVEMENT_ACTIVE = new Color(0.16862746f, 0.5411765f, 0.69803923f, 1.0f);
        COLOR_INGAME_MOVEMENT_ZERO = new Color(0.7490196f, 0.18431373f, 0.14117648f, 1.0f);
        COLOR_INGAME_MOVEMENT_ZERO_HOVER = new Color(0.6431373f, 0.10980392f, 0.08235294f, 1.0f);
        COLOR_INGAME_MOVEMENT_ZERO_ACTIVE = new Color(0.56078434f, 0.06666667f, 0.050980393f, 1.0f);
        COLOR_INGAME_DIPLOMACY_POINTS = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        COLOR_INGAME_DIPLOMACY_POINTS_HOVER = new Color(0.7882353f, 0.7882353f, 0.8f, 1.0f);
        COLOR_INGAME_DIPLOMACY_POINTS_ACTIVE = new Color(0.7529412f, 0.7529412f, 0.7529412f, 1.0f);
        COLOR_BG_GAME_MENU_SHADOW = new Color(0.0f, 0.0f, 0.0f, 0.65f);
        keyboardMessage = "";
        CIV_FLAG_WIDTH = 27;
        CIV_FLAG_HEIGHT = 18;
        FLIP_Y_CIV_FLAG = false;
        FLIP_Y_CIV_FLAG_COUNTER = (byte)(false ? 1 : 0);
        flagEditorMode = FlagEditorMode.PENCIL;
        COLOR_INFO_BOX_GRADIENT = new Color(0.126f, 0.149f, 0.227f, 1.0f);
        dialogType = Dialog.EXIT_GAME;
        iSelectCivilizationPlayerID = 0;
        editorAlliancesNames_GameData = null;
        EDIT_ALLIANCE_NAMES_BUNDLE_ID = 0;
        CREATE_PACKAGE_ALLIANCE_NAMES_GAME_DATA_TAG = null;
        achievement_Data = null;
        SERVICE_RIBBON_WIDTH = 58;
        SERVICE_RIBBON_HEIGHT = 16;
    }

    CFG() {
    }

    protected static final void addCreateScenario_TechnologyLevelsByContinents_Civ() {
        lCreateScenario_TechnologyBContinents.add(new ArrayList());
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("add: ");
        stringBuilder.append(lCreateScenario_TechnologyBContinents.size());
        application.log("AoC", stringBuilder.toString());
    }

    protected static final void addCreateScenario_TechnologyLevelsByContinents_Civ(List<Scenario_GameData_Technology> list) {
        if (list == null) {
            lCreateScenario_TechnologyBContinents.add(new ArrayList());
        } else {
            lCreateScenario_TechnologyBContinents.add(list);
        }
    }

    protected static final void addUndoAssignProvinces(int n, int n2) {
        if (lCreateScenario_UndoAssignProvincesCivID.size() > 499) {
            lCreateScenario_UndoAssignProvincesCivID.remove(0);
        }
        lCreateScenario_UndoAssignProvincesCivID.add(new Undo_AssignProvinceCiv(n, n2));
        menuManager.setCreate_Scenario_Assign_UndoButton(true);
    }

    protected static final void addUndoWastelandProvince(int n) {
        if (lCreateScenario_UndoWastelandProvinces.size() > 99) {
            lCreateScenario_UndoWastelandProvinces.remove(0);
        }
        lCreateScenario_UndoWastelandProvinces.add(n);
        if (menuManager.getInCreateScenario_Available_Provinces()) {
            menuManager.setCreate_Scenario_AvailableProvinces_UndoButton(true);
        } else if (menuManager.getInMapEditor_WastelandMaps_Edit()) {
            menuManager.setMapEditor_WastelandMaps_Edit_UndoButton(true);
        }
    }

    protected static final void buildCreateScenario_TechnologyLevelsByContinents() {
        CFG.initCreateScenario_TechnologyLevelsByContinents_Civ();
        for (int i = 1; i < game.getCivsSize(); ++i) {
            lCreateScenario_TechnologyBContinents.add(new ArrayList());
        }
    }

    protected static final boolean canFormACiv(int n, String string2, boolean bl) {
        if (!CFG.doesNotExists_FormableCiv(string2)) {
            return false;
        }
        if (!game.isAtPeace(n)) {
            return false;
        }
        if (game.getCiv(n).getMoney() < 10000L) {
            return false;
        }
        if (game.getCiv(n).getDiplomacyPoints() < 24) {
            return false;
        }
        if (game.getCiv(n).getCivID() != game.getCiv(n).getPuppetOfCivID()) {
            return false;
        }
        if (bl) {
            CFG.loadFormableCiv_GameData(string2);
        }
        if (!CFG.ownAllProvinces_FormableCiv(n)) {
            if (bl) {
                formableCivs_GameData = null;
            }
            return false;
        }
        if (bl) {
            formableCivs_GameData = null;
        }
        return true;
    }

    protected static final float changeAnimationPos(int n, float f, boolean bl, int n2) {
        block8: {
            float f2;
            int n3;
            block9: {
                n3 = -1;
                switch (n) {
                    default: {
                        break block8;
                    }
                    case 13: {
                        n = -n2;
                        if (!bl) {
                            n3 = 1;
                        }
                        f = n * n3;
                        break block8;
                    }
                    case 6: 
                    case 7: {
                        float f3;
                        f2 = f3 = (float)n2 * 15.0f / 100.0f;
                        if (!bl) break;
                        f2 = f3;
                        break block9;
                    }
                    case 4: 
                    case 5: 
                    case 8: 
                    case 9: {
                        float f4;
                        f2 = f4 = (float)n2 * 10.0f / 100.0f;
                        if (!bl) break;
                        f2 = f4;
                        break block9;
                    }
                    case 2: 
                    case 3: 
                    case 10: 
                    case 11: {
                        float f5;
                        f2 = f5 = (float)n2 * 5.0f / 100.0f;
                        if (!bl) break;
                        f2 = f5;
                        break block9;
                    }
                    case 0: 
                    case 1: 
                    case 12: {
                        float f6;
                        f2 = f6 = (float)n2 * 2.5f / 100.0f;
                        if (!bl) break;
                        f2 = f6;
                        break block9;
                    }
                }
                n3 = 1;
            }
            f -= f2 * (float)n3;
        }
        return f;
    }

    protected static final boolean compareAlphabetic_TwoString(String string2, String string3) {
        for (int i = 0; i < string2.length() && i < string3.length(); ++i) {
            if (string2.charAt(i) < string3.charAt(i)) {
                return false;
            }
            if (string2.charAt(i) == string3.charAt(i)) {
                continue;
            }
            return true;
        }
        return false;
    }

    protected static final void createUnion(int n, int n2) {
        block47: {
            int n3;
            Object object;
            Object object2;
            int n4;
            int n5;
            int n6;
            block49: {
                block50: {
                    block48: {
                        if (n == n2 || n <= 0 || n2 <= 0 || n >= game.getCivsSize() || n2 >= game.getCivsSize() || game.getCivsAtWar(n, n2)) break block47;
                        Gdx.app.log("AoC", "createUnion: 000000");
                        if (!game.getCiv(n).getControlledByPlayer()) break block48;
                        n6 = n;
                        n5 = n2;
                        break block49;
                    }
                    if (game.getCiv(n2).getControlledByPlayer()) break block50;
                    n6 = n;
                    n5 = n2;
                    if (game.getCiv(n).getNumOfProvinces() >= game.getCiv(n2).getNumOfProvinces()) break block49;
                }
                n5 = n;
                n6 = n2;
            }
            Gdx.app.log("AoC", "createUnion: 111111");
            while (true) {
                n = game.getCiv(n5).getNumOfProvinces();
                n4 = 0;
                if (n <= 0) break;
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getCore().addNewCore(n6, Game_Calendar.TURN_ID);
                for (n = 0; n < (object2 = game).getProvince(object2.getCiv(n5).getProvinceID(0)).getPopulationData().getNationalitiesSize(); ++n) {
                    object2 = game;
                    if (object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getPopulationData().getCivID(n) != n5) continue;
                    object2 = game;
                    object2 = object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getPopulationData();
                    object = game;
                    n2 = ((Game)object).getProvince(((Game)object).getCiv(n5).getProvinceID(0)).getPopulationData().getPopulationOfCivID(n6);
                    object = game;
                    object2.setPopulationOfCivID(n6, n2 + ((Game)object).getProvince(((Game)object).getCiv(n5).getProvinceID(0)).getPopulationData().getPopulationOfCivID(n5));
                    object2 = game;
                    object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getPopulationData().setPopulationOfCivID(n5, 0);
                }
                n2 = game.getCiv(n5).getProvinceID(0);
                object2 = game;
                n4 = object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getArmyCivID(n6);
                object2 = game;
                n = object2.getProvince(object2.getCiv(n5).getProvinceID(0)).getArmyCivID(n5);
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getProvinceID(0)).updateArmy(n6, 0);
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getProvinceID(0)).updateArmy(n5, 0);
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getProvinceID(0)).setTrueOwnerOfProvince(n6);
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getProvinceID(0)).setCivID(n6, false);
                game.getProvince(n2).updateArmy(n6, n4 + n);
            }
            Gdx.app.log("AoC", "createUnion: 2222");
            object2 = unionsManager;
            object = new StringBuilder();
            ((StringBuilder)object).append(game.getCiv(n6).getCivTag());
            ((StringBuilder)object).append(";");
            ((StringBuilder)object).append(game.getCiv(n5).getCivTag());
            object2 = object2.getUnionTag(((StringBuilder)object).toString());
            if (object2.length() == 0) {
                object2 = new StringBuilder();
                object2.append(game.getCiv(n6).getCivTag());
                object2.append(";");
                object2.append(game.getCiv(n5).getCivTag());
                object2 = object2.toString();
                game.getCiv(n6).setR((int)((float)game.getCiv(n6).getR() / 2.0f + (float)game.getCiv(n5).getR() / 2.0f));
                game.getCiv(n6).setG((int)((float)game.getCiv(n6).getG() / 2.0f + (float)game.getCiv(n5).getG() / 2.0f));
                game.getCiv(n6).setB((int)((float)game.getCiv(n6).getB() / 2.0f + (float)game.getCiv(n5).getB() / 2.0f));
                game.getCiv(n6).setCivTag((String)object2);
                n = 1;
            } else {
                game.getCiv(n6).setCivTag((String)object2);
                palletManager.loadCivilizationStandardColor(n6);
                n = 0;
            }
            Gdx.app.log("AoC", "createUnion: 3333");
            for (n2 = 1; n2 < game.getCivsSize(); ++n2) {
                if (game.getCiv(n2).getPuppetOfCivID() != n5 || n5 == n2) continue;
                game.getCiv(n2).setPuppetOfCivID(n6);
            }
            if (game.getActiveProvinceID() >= 0) {
                n2 = game.getActiveProvinceID();
                game.setActiveProvinceID(-1);
                game.setActiveProvinceID(n2);
            }
            if (game.getCiv(n5).getAllianceID() > 0) {
                object2 = game;
                object2.getAlliance(object2.getCiv(n5).getAllianceID()).removeCivilization(n5);
                game.getCiv(n5).setAllianceID(0);
            }
            game.buildCivilizationRegions(n6);
            Gdx.app.log("AoC", "createUnion: 444");
            for (n2 = 0; n2 < game.getCiv(n6).getNumOfProvinces(); ++n2) {
                object2 = game;
                object2.getProvince(object2.getCiv(n6).getProvinceID(n2)).setFromCivID(0);
            }
            for (n2 = 0; n2 < game.getCiv(n5).getArmyInAnotherProvinceSize(); ++n2) {
                object2 = game;
                object2 = object2.getProvince(object2.getCiv(n5).getArmyInAnotherProvince(n2));
                object = game;
                n3 = ((Game)object).getProvince(((Game)object).getCiv(n5).getArmyInAnotherProvince(n2)).getArmyCivID(n6);
                object = game;
                object2.updateArmy(n6, n3 + ((Game)object).getProvince(((Game)object).getCiv(n5).getArmyInAnotherProvince(n2)).getArmyCivID(n5));
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getArmyInAnotherProvince(n2)).updateArmy(n5, 0);
            }
            game.getCiv(n6).setNumOfUnits(0);
            game.getCiv(n5).setNumOfUnits(0);
            game.getCiv(n6).buildNumOfUnits();
            Gdx.app.log("AoC", "createUnion: 5555");
            if (game.getPlayerID_ByCivID(n5) >= 0) {
                object2 = game;
                object2.removePlayer(object2.getPlayerID_ByCivID(n5));
                game.getCiv(n5).setControlledByPlayer(false);
                PLAYER_TURNID = game.getPlayerID_ByCivID(n6);
            }
            Gdx.app.log("AoC", "createUnion: 6666");
            for (n2 = 0; n2 < game.getCiv(n5).getMoveUnitsSize(); ++n2) {
                game.getCiv(n6).newMove(game.getCiv(n5).getMoveUnits(n2).getFromProvinceID(), game.getCiv(n5).getMoveUnits(n2).getToProvinceID(), game.getCiv(n5).getMoveUnits(n2).getNumOfUnits(), true);
            }
            for (n2 = 0; n2 < game.getCiv(n5).getMoveUnitsPlunderSize(); ++n2) {
                game.getCiv(n6).newPlunder(game.getCiv(n5).getMoveUnits_Plunder(n2).getFromProvinceID(), game.getCiv(n5).getMoveUnits_Plunder(n2).getNumOfUnits());
            }
            for (n2 = 0; n2 < game.getCiv(n5).getRecruitArmySize(); ++n2) {
                game.getCiv(n6).recruitArmy(game.getCiv(n5).getRecruitArmy(n2).getProvinceID(), game.getCiv(n5).getRecruitArmy(n2).getArmy());
            }
            for (n2 = 0; n2 < game.getCiv(n5).getConstructionsSize(); ++n2) {
                game.getCiv(n6).addNewConstruction(game.getCiv(n5).getConstruction(n2));
            }
            Gdx.app.log("AoC", "createUnion: 7777");
            game.getCiv(n5).clearConstructions();
            game.getCiv(n5).clearMoveUnits();
            game.getCiv(n5).clearMoveUnits_Plunder();
            game.getCiv(n5).clearRegroupArmy();
            game.getCiv(n5).clearRecruitArmy();
            game.getCiv(n6).setMoney(game.getCiv(n6).getMoney() + game.getCiv(n5).getMoney());
            game.getCiv(n5).setMoney(0L);
            gameNewGame.updateFormableCivilizations(n6);
            gameNewGame.updateFormableCivilizations(n5);
            if (game.getCiv(n5).getCapitalProvinceID() >= 0) {
                for (n2 = 0; n2 < (object2 = game).getProvince(object2.getCiv(n5).getCapitalProvinceID()).getCitiesSize(); ++n2) {
                    object2 = game;
                    if (object2.getProvince(object2.getCiv(n5).getCapitalProvinceID()).getCity(n2).getCityLevel() != CFG.getEditorCityLevel(0)) continue;
                    object2 = game;
                    object2.getProvince(object2.getCiv(n5).getCapitalProvinceID()).getCity(n2).setCityLevel(CFG.getEditorCityLevel(1));
                }
                object2 = game;
                object2.getProvince(object2.getCiv(n5).getCapitalProvinceID()).setIsCapital(false);
            }
            Gdx.app.log("AoC", "createUnion: 8888");
            for (n2 = 1; n2 < game.getCivsSize(); ++n2) {
                if (n2 == n5 || n2 == n6 || game.getCiv(n2).getNumOfProvinces() <= 0) continue;
                if (game.getCivsAtWar(n2, n5)) {
                    n3 = game.getWarID(n2, n5);
                    if (n3 < 0 || n3 >= game.getWarsSize()) continue;
                    if (game.getCivsAtWar(n2, n6)) {
                        game.getWar(n3).updateAfterUnion(n6, n5);
                        continue;
                    }
                    game.war_CheckDiplomacy(n2, n6);
                    game.setCivRelation_OfCivB(n2, n6, -100.0f);
                    game.setCivRelation_OfCivB(n6, n2, -100.0f);
                    game.getWar(n3).updateAfterUnion(n6, n5);
                    continue;
                }
                if (game.getCivsAtWar(n2, n6)) continue;
                object2 = game;
                object2.setCivRelation_OfCivB(n6, n2, (object2.getCivRelation_OfCivB(n6, n2) + game.getCivRelation_OfCivB(n5, n2)) / 2.0f);
                object2 = game;
                object2.setCivRelation_OfCivB(n2, n6, (object2.getCivRelation_OfCivB(n2, n6) + game.getCivRelation_OfCivB(n2, n5)) / 2.0f);
            }
            Gdx.app.log("AoC", "createUnion: 9999");
            if (!game.getCiv(n6).getControlledByPlayer()) {
                game.getCiv(n6).buildCivPersonality();
            }
            for (n2 = 0; n2 < game.getCiv(n5).getLoansSize(); ++n2) {
                game.getCiv(n6).addLoan(CFG.game.getCiv((int)n5).getLoan((int)n2).iGoldPerTurn, CFG.game.getCiv((int)n5).getLoan((int)n2).iTurnsLeft);
            }
            game.getCiv(n5).clearLoans();
            for (n2 = game.getCiv(n5).getFestivalsSize() - 1; n2 >= 0; --n2) {
                game.getCiv(n6).addFestival(game.getCiv(n5).getFestival(n2));
                game.getCiv(n5).removeFestival(n2);
            }
            for (n2 = game.getCiv(n5).getAssimilatesSize() - 1; n2 >= 0; --n2) {
                game.getCiv(n6).addAssimilate(game.getCiv(n5).getAssimilate(n2));
                game.getCiv(n5).removeAssimilate(n2);
            }
            for (n2 = game.getCiv(n5).getInvestsSize() - 1; n2 >= 0; --n2) {
                game.getCiv(n6).addInvest(game.getCiv(n5).getInvest(n2));
                game.getCiv(n5).removeInvest(n2);
            }
            if ((game.getPlayer(PLAYER_TURNID).getCivID() == n6 || game.getPlayer(PLAYER_TURNID).getCivID() == n5) && FOG_OF_WAR > 0) {
                for (n2 = 0; n2 < game.getProvincesSize(); ++n2) {
                    game.getProvince(n2).updateDrawArmy();
                }
            }
            Gdx.app.log("AoC", "createUnion: 10");
            try {
                if (CFG.holyRomanEmpire_Manager.holyRomanEmpire.getIsEmperor(n5)) {
                    CFG.holyRomanEmpire_Manager.holyRomanEmpire.setEmperor(n6);
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
            }
            Gdx.app.log("AoC", "createUnion: 11");
            gameAction.buildRank_Score(n6);
            gameAction.buildRank_Score(n5);
            gameAction.buildRank_Positions();
            Gdx.app.log("AoC", "createUnion: 12");
            if (game.getPlayer(PLAYER_TURNID).getCivID() == n6 || game.getPlayer(PLAYER_TURNID).getCivID() == n5) {
                menuManager.updateInGame_TOP_All(game.getPlayer(PLAYER_TURNID).getCivID());
            }
            Gdx.app.log("AoC", "createUnion: 13");
            if (gameAction.getActiveTurnState() == Game_Action.TurnStates.INPUT_ORDERS) {
                CFG.setActiveCivInfo(CFG.getActiveCivInfo());
            }
            Gdx.app.log("AoC", "createUnion: 14");
            if (gameAction.getActiveTurnState() == Game_Action.TurnStates.INPUT_ORDERS) {
                game.getCiv(n6).loadFlag();
            } else {
                unionFlagsToGenerate_Manager.addFlagToLoad(n6);
            }
            Gdx.app.log("AoC", "createUnion: 15");
            if (n != 0) {
                for (n = 0; n < game.getPlayersSize(); ++n) {
                    if (game.getPlayer(n).getCivID() != n6 && game.getPlayer(n).getCivID() != n5) continue;
                    CFG.unionFlagsToGenerate_Manager.lFlags.add(new UnionFlagsToGenerate());
                    n4 = CFG.unionFlagsToGenerate_Manager.lFlags.size() - 1;
                    object2 = game;
                    object2 = object2.getCiv(object2.getPlayer(n).getCivID()).getCivTag().split(";");
                    for (n2 = 0; n2 < ((String[])object2).length; ++n2) {
                        CFG.unionFlagsToGenerate_Manager.lFlags.get((int)n4).lTags.add(object2[n2]);
                    }
                    CFG.unionFlagsToGenerate_Manager.lFlags.get((int)n4).typeOfAction = UnionFlagsToGenerate_TypesOfAction.PLAYER_ID;
                    CFG.unionFlagsToGenerate_Manager.lFlags.get((int)n4).iID = game.getPlayer(n).getCivID();
                }
            } else {
                for (n2 = n4; n2 < game.getPlayersSize(); ++n2) {
                    if (game.getPlayer(n2).getCivID() != n6 && game.getPlayer(n2).getCivID() != n5) continue;
                    game.getPlayer(n2).loadPlayersFlag();
                }
            }
            Gdx.app.log("AoC", "createUnion: 16");
            try {
                if (holyRomanEmpire_Manager.getHRE().getEmperor() == n5) {
                    holyRomanEmpire_Manager.getHRE().addPrince(n6);
                    holyRomanEmpire_Manager.getHRE().setEmperor(n6);
                }
            }
            catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
                // empty catch block
            }
            if ((game.getCiv(n6).getControlledByPlayer() || game.getCiv(n5).getControlledByPlayer()) && CFG.isDesktop() && AoCGame.steamGame != null) {
                AoCGame.steamGame.uploadUnions();
            }
            historyManager.addHistoryLog(new HistoryLog_Union(n6));
            Gdx.app.log("AoC", "createUnion: END");
        }
    }

    protected static final Object deserialize(byte[] arrby) throws IOException, ClassNotFoundException {
        b = new ByteArrayInputStream(arrby);
        o = new ObjectInputStream(b);
        return o.readUnshared();
    }

    protected static final void dialog_False() {
        MenuElement_Hover_v2.resetAnimation();
        int n = 62.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Dialog[dialogType.ordinal()];
        if (n != 9) {
            if (n != 14) {
                return;
            }
            if (TimelapseManager.PAUSE) {
                timelapseManager.pauseUnpause();
            }
            return;
        }
        menuManager.setVisibleInGame_SendMessage(false);
    }

    /*
     * Exception decompiling
     */
    protected static final void dialog_True() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [33[CASE]], but top level block is 2[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected static final void disposeActiveCivFlag() {
        block3: {
            try {
                if (activeCivFlag != null) {
                    activeCivFlag.getTexture().dispose();
                    activeCivFlag = null;
                    activeCivInfo = 0;
                }
                CFG.disposeActiveCivLeader();
            }
            catch (RuntimeException runtimeException) {
                if (!LOGS) break block3;
                CFG.exceptionStack(runtimeException);
            }
        }
    }

    protected static final void disposeActiveCivLeader() {
        block3: {
            try {
                if (activeCivLeader != null) {
                    activeCivLeader.getTexture().dispose();
                    activeCivLeader = null;
                }
            }
            catch (RuntimeException runtimeException) {
                if (!LOGS) break block3;
                CFG.exceptionStack(runtimeException);
            }
        }
    }

    protected static final boolean doesNotExists_FormableCiv(String string2) {
        for (int i = 1; i < game.getCivsSize(); ++i) {
            if (!string2.equals(game.getCiv(i).getCivTag())) continue;
            return false;
        }
        return true;
    }

    protected static final void drawArmyText(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2) {
        block4: {
            try {
                fontArmy.setColor(color2);
                fontArmy.draw((Batch)spriteBatch, string2, (float)n, (float)(-n2));
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (LOGS) {
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
            catch (NullPointerException nullPointerException) {
                if (!LOGS) break block4;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }

    protected static final void drawArmyText_WithShadow(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2) {
        block5: {
            BitmapFont bitmapFont = fontArmy;
            Color color3 = new Color(0.0f, 0.0f, 0.0f, 0.7f);
            bitmapFont.setColor(color3);
            bitmapFont = fontArmy;
            float f = n - 1;
            n2 = -n2;
            try {
                bitmapFont.draw((Batch)spriteBatch, string2, f, (float)(n2 - 1));
                fontArmy.setColor(color2);
                fontArmy.draw((Batch)spriteBatch, string2, (float)n, (float)n2);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (LOGS) {
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
            catch (NullPointerException nullPointerException) {
                if (!LOGS) break block5;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }

    protected static final void drawBG_WithGradient(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        spriteBatch.setColor(new Color(0.0f, 0.01f, 0.012f, 0.45f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(0.0f, 0.01f, 0.012f, 0.32f));
        ImageManager.getImage(Images.patt2).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.patt2).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(0.0f, 0.01f, 0.012f, 0.75f));
        Image image = ImageManager.getImage(Images.gradient);
        int n5 = ImageManager.getImage(Images.gradient).getHeight();
        int n6 = n4 / 4;
        image.draw(spriteBatch, n, n2 - n5, n3, n6);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.gradient).getHeight() + n4 - n6, n3, n4, false, true);
        spriteBatch.setColor(COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1);
        image = ImageManager.getImage(Images.pix255_255_255);
        n4 = n2 + n4 - 1;
        image.draw2(spriteBatch, n, n4 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight() - 1, n3, 1);
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n4 - ImageManager.getImage(Images.pix255_255_255).getHeight() + 1, n3, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorButtons_Bot_Edge_R(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        image.draw2(spriteBatch, n, n2 - 1 - n5, n3, ++n4, true, false);
        ImageManager.getImage(Images.editor_top_line).draw2(spriteBatch, n + n3 - 1, n2 - 2, ImageManager.getImage(Images.editor_top_line).getWidth(), n4, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3 - PADDING, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorButtons_Bot_Edge_R_Reflected(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        image.draw2(spriteBatch, n, n2 - 1 - n5, n3, ++n4, false, false);
        ImageManager.getImage(Images.editor_top_line).draw2(spriteBatch, n - 1, n2 - 2, ImageManager.getImage(Images.editor_top_line).getWidth(), n4, true, true);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n + PADDING, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3 - PADDING, 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorButtons_Top_Edge_R(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        image.draw2(spriteBatch, n, n2 - n5, n3, ++n4, true, true);
        ImageManager.getImage(Images.editor_top_line).draw2(spriteBatch, n + n3 - 1, n2 - ImageManager.getImage(Images.editor_top_line).getHeight(), ImageManager.getImage(Images.editor_top_line).getWidth(), n4, false, true);
    }

    protected static final void drawEditorButtons_Top_Edge_R_Reflected(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        image.draw2(spriteBatch, n, n2 - n5, n3, ++n4, false, true);
        ImageManager.getImage(Images.editor_top_line).draw2(spriteBatch, n - 1, n2 - ImageManager.getImage(Images.editor_top_line).getHeight(), ImageManager.getImage(Images.editor_top_line).getWidth(), n4, true, true);
    }

    protected static final void drawEditorTitle_Bot_Edge_LR(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        int n6 = ImageManager.getImage(Images.editor_top).getWidth();
        int n7 = n4 + 1;
        image.draw2(spriteBatch, n, n2 - n5, n6, n7, false, false);
        ImageManager.getImage(Images.editor_top).draw2(spriteBatch, n + ImageManager.getImage(Images.editor_top).getWidth(), n2 - ImageManager.getImage(Images.editor_top).getHeight(), n3 - ImageManager.getImage(Images.editor_top).getWidth(), n7, true, false);
        spriteBatch.setColor(new Color(0.025f, 0.03f, 0.092f, 0.225f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.line_32_off1).getHeight() + 2, n3, n4 - 2);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 + n4 - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorTitle_Edge_LR(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        Image image = ImageManager.getImage(Images.editor_top);
        int n5 = ImageManager.getImage(Images.editor_top).getHeight();
        int n6 = ImageManager.getImage(Images.editor_top).getWidth();
        int n7 = n4 + 1;
        image.draw2(spriteBatch, n, n2 - n5, n6, n7, false, true);
        ImageManager.getImage(Images.editor_top).draw2(spriteBatch, n + ImageManager.getImage(Images.editor_top).getWidth(), n2 - ImageManager.getImage(Images.editor_top).getHeight(), n3 - ImageManager.getImage(Images.editor_top).getWidth(), n7, true, true);
        spriteBatch.setColor(new Color(0.025f, 0.03f, 0.092f, 0.225f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, n4 - 2);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 + n4 - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorTitle_Edge_R(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        ImageManager.getImage(Images.editor_top).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.editor_top).getHeight(), n3, n4 + 1, true, true);
        spriteBatch.setColor(new Color(0.025f, 0.03f, 0.092f, 0.225f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, n4 - 2);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 + n4 - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawEditorTitle_Edge_R_Reflected(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        ImageManager.getImage(Images.editor_top).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.editor_top).getHeight(), n3, n4 + 1, false, true);
        spriteBatch.setColor(new Color(0.025f, 0.03f, 0.092f, 0.225f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, n4 - 2);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.75f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 + n4 - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawJakowskiGames_RIGHT_BOT(SpriteBatch spriteBatch, int n) {
        fontMain.getData().setScale(1.0f);
        String string2 = CFG.getLukaszJakowskiGames();
        int n2 = GAME_WIDTH;
        int n3 = PADDING;
        CFG.drawText(spriteBatch, string2, n2 - n3 - (int)((float)iJakowskiGamesWidth * 1.0f) + n, GAME_HEIGHT - (int)((float)TEXT_HEIGHT * 1.0f) - n3, new Color(1.0f, 1.0f, 1.0f, 0.5f));
        fontMain.getData().setScale(1.0f);
    }

    protected static final void drawJakowskiGames_RIGHT_BOT(SpriteBatch spriteBatch, int n, float f) {
        f = (1.0f - Math.min(f * 2.0f, 1.0f)) * 0.1f + 1.0f;
        fontMain.getData().setScale(f);
        String string2 = CFG.getLukaszJakowskiGames();
        int n2 = GAME_WIDTH;
        int n3 = PADDING;
        CFG.drawText(spriteBatch, string2, n2 - n3 - (int)((float)iJakowskiGamesWidth * f) + n, GAME_HEIGHT - (int)((float)TEXT_HEIGHT * f) - n3, new Color(1.0f, 1.0f, 1.0f, 0.5f));
        fontMain.getData().setScale(1.0f);
    }

    protected static final void drawLoading(SpriteBatch spriteBatch, int n, int n2, int n3, int n4, float f) {
        int n5;
        Object object;
        block6: {
            if (System.currentTimeMillis() - 2500L > loadingTime) {
                try {
                    object = new StringBuilder();
                    LanguageManager languageManager = langManager;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("L");
                    stringBuilder.append(oR.nextInt(CFG.langManager.iLoading_NumOfTexts));
                    ((StringBuilder)object).append(languageManager.getLoading(stringBuilder.toString()));
                    ((StringBuilder)object).append("..");
                    sLoadingText = ((StringBuilder)object).toString();
                    loadingTime = System.currentTimeMillis();
                    glyphLayout.setText(fontMain, sLoadingText);
                    iLoadingTextWidth = (int)(CFG.glyphLayout.width * LOADING_TEXT_FONT_SCALE);
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    if (!LOGS) break block6;
                    CFG.exceptionStack(illegalArgumentException);
                }
            }
        }
        if (PRESENTS_TIME == 0L) {
            PRESENTS_TIME = System.currentTimeMillis();
        }
        if (System.currentTimeMillis() < PRESENTS_TIME + 3500L) {
            spriteBatch.setColor(Color.BLACK);
            ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, 0, -ImageManager.getImage(Images.line_32_vertical).getHeight(), GAME_WIDTH, GAME_HEIGHT);
            spriteBatch.setColor(Color.WHITE);
            fontMain.getData().setScale(PRESENTS_GAMES_SCALE);
            object = CFG.getLukaszJakowskiGames();
            n5 = GAME_WIDTH / 2;
            float f2 = iJakowskiGamesWidth;
            float f3 = PRESENTS_GAMES_SCALE;
            CFG.drawText(spriteBatch, (String)object, n5 - (int)(f2 * f3 / 2.0f), GAME_HEIGHT / 2 - (int)((float)TEXT_HEIGHT * f3) - PADDING, COLOR_INGAME_DIPLOMACY_POINTS);
            fontMain.getData().setScale(PRESENTS_GAMES_SCALE2);
            CFG.drawText(spriteBatch, "", GAME_WIDTH / 2 - (int)((float)iJakowskiGames_PresentsWidth * PRESENTS_GAMES_SCALE2 / 2.0f), GAME_HEIGHT / 2 + PADDING, COLOR_TEXT_POPULATION_ACTIVE);
            fontMain.getData().setScale(1.0f);
            spriteBatch.setColor(Color.WHITE);
        }
        if (System.currentTimeMillis() < PRESENTS_TIME + 437L) {
            return;
        }
        spriteBatch.setColor(new Color(0.50980395f, 0.13725491f, 0.078431375f, 0.75f));
        object = ImageManager.getImage(Images.pix255_255_255);
        int n6 = ImageManager.getImage(Images.pix255_255_255).getHeight();
        n5 = (int)((float)n3 * f);
        ((Image)object).draw(spriteBatch, n, n2 - n6, n5, n4);
        spriteBatch.setColor(new Color(0.043137256f, 0.05882353f, 0.07450981f, 0.65f));
        object = ImageManager.getImage(Images.pix255_255_255);
        n6 = n + n5;
        ((Image)object).draw(spriteBatch, n6, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3 - n5, n4);
        spriteBatch.setColor(COLOR_LOADING_SPLIT);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n6, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), 1, n4);
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.loading_rect_edge).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.loading_rect_edge).getHeight(), n3 - ImageManager.getImage(Images.loading_rect_edge).getWidth(), n4 - ImageManager.getImage(Images.loading_rect_edge).getHeight());
        object = ImageManager.getImage(Images.loading_rect_edge);
        n6 = n + n3;
        ((Image)object).draw2(spriteBatch, n6 - ImageManager.getImage(Images.loading_rect_edge).getWidth(), n2 - ImageManager.getImage(Images.loading_rect_edge).getHeight(), ImageManager.getImage(Images.loading_rect_edge).getWidth(), n4 - ImageManager.getImage(Images.loading_rect_edge).getHeight(), true);
        object = ImageManager.getImage(Images.loading_rect_edge);
        n5 = n2 + n4;
        ((Image)object).draw2(spriteBatch, n, n5 - ImageManager.getImage(Images.loading_rect_edge).getHeight() * 2, n3 - ImageManager.getImage(Images.loading_rect_edge).getWidth(), ImageManager.getImage(Images.loading_rect_edge).getHeight(), false, true);
        ImageManager.getImage(Images.loading_rect_edge).draw(spriteBatch, n6 - ImageManager.getImage(Images.loading_rect_edge).getWidth(), n5 - ImageManager.getImage(Images.loading_rect_edge).getHeight(), true, true);
        spriteBatch.setColor(new Color(CFG.COLOR_INGAME_GOLD.r, CFG.COLOR_INGAME_GOLD.g, CFG.COLOR_INGAME_GOLD.b, 0.45f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, n, n5 - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), n3, 1);
        fontMain.getData().setScale(LOADING_TEXT_FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, sLoadingText, n3 / 2 + n - iLoadingTextWidth / 2, n2 + (n4 - (int)((float)TEXT_HEIGHT * LOADING_TEXT_FONT_SCALE)) / 2, new Color(0.75686276f, 0.75686276f, 0.75686276f, 1.0f));
        fontMain.getData().setScale(0.8f);
        object = new StringBuilder();
        ((StringBuilder)object).append(sLoading);
        ((StringBuilder)object).append(" ");
        ((StringBuilder)object).append((int)(100.0f * f));
        ((StringBuilder)object).append("%");
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), n, n2 - PADDING - (int)((float)TEXT_HEIGHT * 0.8f), new Color(0.75686276f, 0.75686276f, 0.75686276f, 1.0f));
        fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.35f));
        ImageManager.getImage(Images.gameLogo).draw2(spriteBatch, n6 - ImageManager.getImage(Images.gameLogo).getWidth(), n2 - PADDING - ImageManager.getImage(Images.gameLogo).getHeight() * 2, ImageManager.getImage(Images.gameLogo).getWidth(), ImageManager.getImage(Images.gameLogo).getHeight());
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.gameLogo).draw2(spriteBatch, n6 - ImageManager.getImage(Images.gameLogo).getWidth(), n2 - PADDING - ImageManager.getImage(Images.gameLogo).getHeight() * 2, (int)((float)ImageManager.getImage(Images.gameLogo).getWidth() * f), ImageManager.getImage(Images.gameLogo).getHeight());
    }

    protected static final void drawLogo_Square(SpriteBatch spriteBatch, int n, int n2, int n3) {
        spriteBatch.setColor(Color.BLACK);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n3);
        spriteBatch.setColor(Color.WHITE);
        map.getMapBG().drawMap_LogoSquare(spriteBatch, n, n2, n3, n3);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 1.0f));
        Image image = ImageManager.getImage(Images.gradient);
        int n4 = ImageManager.getImage(Images.gradient).getHeight();
        float f = n3;
        int n5 = (int)(0.15f * f);
        image.draw(spriteBatch, n, n2 - n4, n3, n5);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.gradient).getHeight() + n3 - n5, n3, n5, false, true);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n5, n3, false, false);
        image = ImageManager.getImage(Images.slider_gradient);
        n4 = n + n3;
        image.draw(spriteBatch, n4 - n5, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n5, n3, true, false);
        spriteBatch.setColor(COLOR_FLAG_FRAME);
        image = ImageManager.getImage(Images.pix255_255_255);
        n5 = n + 1;
        int n6 = ImageManager.getImage(Images.pix255_255_255).getHeight();
        n = n3 - 2;
        image.draw(spriteBatch, n5, n2 - n6 + 1, n, 1);
        image = ImageManager.getImage(Images.pix255_255_255);
        image.draw(spriteBatch, n5, (n3 += n2) - ImageManager.getImage(Images.pix255_255_255).getHeight() - 2, n, 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n5, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + 1, 1, n);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n4 - 2, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + 1, 1, n);
        spriteBatch.setColor(Color.WHITE);
        if ((float)ImageManager.getImage(Images.gameLogo).getWidth() > f * 0.5f) {
            ImageManager.getImage(Images.gameLogo).draw(spriteBatch, n4 - PADDING - (int)((float)ImageManager.getImage(Images.gameLogo).getWidth() * 0.5f), n3 - PADDING - ImageManager.getImage(Images.gameLogo).getHeight() - (int)((float)ImageManager.getImage(Images.gameLogo).getHeight() * 0.5f), (int)((float)ImageManager.getImage(Images.gameLogo).getWidth() * 0.5f), (int)((float)ImageManager.getImage(Images.gameLogo).getHeight() * 0.5f));
        } else {
            ImageManager.getImage(Images.gameLogo).draw(spriteBatch, n4 - PADDING - ImageManager.getImage(Images.gameLogo).getWidth(), n3 - PADDING - ImageManager.getImage(Images.gameLogo).getHeight());
        }
    }

    protected static final void drawRect(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2, n3, 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 + n4 - 1, n3, 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 + 1, 1, n4 - 2);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n + n3, n2, 1, n4);
    }

    protected static final void drawRect_InfoBox_Left(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.375f));
        Image image = ImageManager.getImage(Images.slider_gradient);
        int n5 = ImageManager.getImage(Images.slider_gradient).getHeight();
        int n6 = n3 / 2;
        image.draw(spriteBatch, n, n2 - n5, n6, n4, false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.475f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n + n3 - n6, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n6, n4, true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        image = ImageManager.getImage(Images.gradient);
        n5 = ImageManager.getImage(Images.gradient).getHeight();
        n6 = n4 / 5;
        image.draw(spriteBatch, n, n2 - n5, n3, n6);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        image = ImageManager.getImage(Images.gradient);
        n5 = n2 + n4;
        image.draw(spriteBatch, n, n5 - n6 - ImageManager.getImage(Images.gradient).getHeight(), n3, n6, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.475f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n5 - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 + 1 - ImageManager.getImage(Images.pix255_255_255).getHeight(), 1, n4 - 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        CFG.drawRect(spriteBatch, n - 1, n2 - 2, n3 + 1, n4 + 2);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawRect_InfoBox_Left_Title(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.7f));
        Image image = ImageManager.getImage(Images.slider_gradient);
        int n5 = ImageManager.getImage(Images.slider_gradient).getHeight();
        int n6 = n3 / 2;
        image.draw(spriteBatch, n, n2 - n5, n6, n4, false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.375f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n + n3 - n6, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n6, n4, true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        image = ImageManager.getImage(Images.gradient);
        n5 = ImageManager.getImage(Images.gradient).getHeight();
        n6 = n4 / 5;
        image.draw(spriteBatch, n, n2 - n5, n3, n6);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        image = ImageManager.getImage(Images.gradient);
        n4 = n2 + n4;
        image.draw(spriteBatch, n, n4 - n6 - ImageManager.getImage(Images.gradient).getHeight(), n3, n6, false, true);
        spriteBatch.setColor(COLOR_NEW_GAME_EDGE_LINE);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        image = ImageManager.getImage(Images.pix255_255_255);
        n6 = n4 - 1;
        image.draw(spriteBatch, n, n6 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n6 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, false, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.55f);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + 1, n3, 1, true, false);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n4 - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawRect_InfoBox_Right(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.475f));
        Image image = ImageManager.getImage(Images.slider_gradient);
        int n5 = ImageManager.getImage(Images.slider_gradient).getHeight();
        int n6 = n3 / 2;
        image.draw(spriteBatch, n, n2 - n5, n6, n4, false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.375f));
        image = ImageManager.getImage(Images.slider_gradient);
        n5 = n + n3;
        image.draw(spriteBatch, n5 - n6, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n6, n4, true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        image = ImageManager.getImage(Images.gradient);
        int n7 = ImageManager.getImage(Images.gradient).getHeight();
        n6 = n4 / 5;
        image.draw(spriteBatch, n, n2 - n7, n3, n6);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        image = ImageManager.getImage(Images.gradient);
        n7 = n2 + n4;
        image.draw(spriteBatch, n, n7 - n6 - ImageManager.getImage(Images.gradient).getHeight(), n3, n6, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.475f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n7 - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, true, false);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n5 - 1, n2 + 1 - ImageManager.getImage(Images.pix255_255_255).getHeight(), 1, n4 - 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        CFG.drawRect(spriteBatch, n - 1, n2 - 2, n3 + 1, n4 + 2);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawRect_InfoBox_Right_Title(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, n4);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.375f));
        Image image = ImageManager.getImage(Images.slider_gradient);
        int n5 = ImageManager.getImage(Images.slider_gradient).getHeight();
        int n6 = n3 / 2;
        image.draw(spriteBatch, n, n2 - n5, n6, n4, false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.7f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n + n3 - n6, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n6, n4, true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        image = ImageManager.getImage(Images.gradient);
        n5 = ImageManager.getImage(Images.gradient).getHeight();
        n6 = n4 / 5;
        image.draw(spriteBatch, n, n2 - n5, n3, n6);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        image = ImageManager.getImage(Images.gradient);
        n4 = n2 + n4;
        image.draw(spriteBatch, n, n4 - n6 - ImageManager.getImage(Images.gradient).getHeight(), n3, n6, false, true);
        spriteBatch.setColor(COLOR_NEW_GAME_EDGE_LINE);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        image = ImageManager.getImage(Images.pix255_255_255);
        n6 = n4 - 1;
        image.draw(spriteBatch, n, n6 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, n, n6 - ImageManager.getImage(Images.slider_gradient).getHeight(), n3, 1, true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.55f);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + 1, n3, 1, true, false);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n, n4 - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), n3, 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    protected static final void drawRect_NewGameBox(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.new_game_box).getHeight(), n3 - ImageManager.getImage(Images.new_game_box).getWidth(), n4 - ImageManager.getImage(Images.new_game_box).getHeight());
        Image image = ImageManager.getImage(Images.new_game_box);
        int n5 = n + n3;
        image.draw2(spriteBatch, n5 - ImageManager.getImage(Images.new_game_box).getWidth(), n2 - ImageManager.getImage(Images.new_game_box).getHeight(), ImageManager.getImage(Images.new_game_box).getWidth(), n4 - ImageManager.getImage(Images.new_game_box).getHeight(), true);
        image = ImageManager.getImage(Images.new_game_box);
        image.draw2(spriteBatch, n, (n2 += n4) - ImageManager.getImage(Images.new_game_box).getHeight() - ImageManager.getImage(Images.new_game_box).getHeight(), n3 - ImageManager.getImage(Images.new_game_box).getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), false, true);
        ImageManager.getImage(Images.new_game_box).draw(spriteBatch, n5 - ImageManager.getImage(Images.new_game_box).getWidth(), n2 - ImageManager.getImage(Images.new_game_box).getHeight(), true, true);
    }

    protected static final void drawRect_NewGameBox_EDGE(SpriteBatch spriteBatch, int n, int n2, int n3, int n4) {
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, n, n2 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), n3 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), n4 - ImageManager.getImage(Images.new_game_top_edge).getHeight());
        Image image = ImageManager.getImage(Images.new_game_top_edge);
        int n5 = n + n3;
        image.draw2(spriteBatch, n5 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), n2 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), ImageManager.getImage(Images.new_game_top_edge).getWidth(), n4 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), true, false);
        image = ImageManager.getImage(Images.new_game_top_edge);
        image.draw2(spriteBatch, n, (n2 += n4) - ImageManager.getImage(Images.new_game_top_edge).getHeight() * 2, n3 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), ImageManager.getImage(Images.new_game_top_edge).getHeight(), false, true);
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, n5 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), n2 - ImageManager.getImage(Images.new_game_top_edge).getHeight() * 2, ImageManager.getImage(Images.new_game_top_edge).getWidth(), ImageManager.getImage(Images.new_game_top_edge).getHeight(), true, true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void drawText(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2) {
        try {
            fontMain.setColor(color2);
            fontMain.draw((Batch)spriteBatch, string2, (float)n, (float)(-n2));
            return;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }

    protected static final void drawTextBorder(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2) {
        block4: {
            try {
                fontBorder.setColor(color2);
                fontBorder.draw((Batch)spriteBatch, string2, (float)n, (float)(-n2));
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (LOGS) {
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
            catch (NullPointerException nullPointerException) {
                if (!LOGS) break block4;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void drawTextRotated(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2, float f) {
        Throwable throwable2;
        Matrix4 matrix4;
        block7: {
            block6: {
                matrix4 = spriteBatch.getTransformMatrix().cpy();
                try {
                    try {
                        Matrix4 matrix42 = new Matrix4();
                        Vector3 vector3 = new Vector3(0.0f, 0.0f, 1.0f);
                        matrix42.rotate(vector3, f);
                        matrix42.trn(n, -n2, 0.0f);
                        spriteBatch.setTransformMatrix(matrix42);
                        fontMain.setColor(color2);
                        fontMain.draw((Batch)spriteBatch, string2, 0.0f, 0.0f);
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        if (LOGS) {
                            CFG.exceptionStack(indexOutOfBoundsException);
                        }
                    }
                    catch (NullPointerException nullPointerException) {
                        if (!LOGS) break block6;
                        CFG.exceptionStack(nullPointerException);
                    }
                }
                catch (Throwable throwable2) {
                    break block7;
                }
            }
            spriteBatch.setTransformMatrix(matrix4);
            return;
        }
        spriteBatch.setTransformMatrix(matrix4);
        throw throwable2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void drawTextRotatedBorder(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2, float f) {
        Throwable throwable2;
        Matrix4 matrix4;
        block7: {
            block6: {
                matrix4 = spriteBatch.getTransformMatrix().cpy();
                try {
                    try {
                        Matrix4 matrix42 = new Matrix4();
                        Vector3 vector3 = new Vector3(0.0f, 0.0f, 1.0f);
                        matrix42.rotate(vector3, f);
                        matrix42.trn(n, -n2, 0.0f);
                        spriteBatch.setTransformMatrix(matrix42);
                        fontBorder.setColor(color2);
                        fontBorder.draw((Batch)spriteBatch, string2, 0.0f, 0.0f);
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        if (LOGS) {
                            CFG.exceptionStack(indexOutOfBoundsException);
                        }
                    }
                    catch (NullPointerException nullPointerException) {
                        if (!LOGS) break block6;
                        CFG.exceptionStack(nullPointerException);
                    }
                }
                catch (Throwable throwable2) {
                    break block7;
                }
            }
            spriteBatch.setTransformMatrix(matrix4);
            return;
        }
        spriteBatch.setTransformMatrix(matrix4);
        throw throwable2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void drawTextWithShadow(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2) {
        BitmapFont bitmapFont = fontMain;
        Color color3 = new Color(0.0f, 0.0f, 0.0f, 0.7f);
        bitmapFont.setColor(color3);
        bitmapFont = fontMain;
        float f = n - 1;
        n2 = -n2;
        try {
            bitmapFont.draw((Batch)spriteBatch, string2, f, (float)(n2 - 1));
            fontMain.setColor(color2);
            fontMain.draw((Batch)spriteBatch, string2, (float)n, (float)n2);
            return;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void drawTextWithShadowRotated(SpriteBatch spriteBatch, String string2, int n, int n2, Color color2, float f) {
        Throwable throwable2;
        Matrix4 matrix4;
        block7: {
            block6: {
                matrix4 = spriteBatch.getTransformMatrix().cpy();
                try {
                    try {
                        Object object = new Matrix4();
                        Object object2 = new Vector3(0.0f, 0.0f, 1.0f);
                        ((Matrix4)object).rotate((Vector3)object2, f);
                        ((Matrix4)object).trn(n, -n2, 0.0f);
                        spriteBatch.setTransformMatrix((Matrix4)object);
                        object2 = fontMain;
                        object = new Color(0.0f, 0.0f, 0.0f, 0.7f);
                        ((BitmapFont)object2).setColor((Color)object);
                        fontMain.draw((Batch)spriteBatch, string2, -1.0f, -1.0f);
                        fontMain.setColor(color2);
                        fontMain.draw((Batch)spriteBatch, string2, 0.0f, 0.0f);
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        if (LOGS) {
                            CFG.exceptionStack(indexOutOfBoundsException);
                        }
                    }
                    catch (NullPointerException nullPointerException) {
                        if (!LOGS) break block6;
                        CFG.exceptionStack(nullPointerException);
                    }
                }
                catch (Throwable throwable2) {
                    break block7;
                }
            }
            spriteBatch.setTransformMatrix(matrix4);
            return;
        }
        spriteBatch.setTransformMatrix(matrix4);
        throw throwable2;
    }

    protected static final void drawVersion_LEFT_BOT(SpriteBatch spriteBatch, int n) {
        fontMain.getData().setScale(1.0f);
        CFG.drawText(spriteBatch, sVERSION + "" + "BloodyWorld2", PADDING + n, GAME_HEIGHT - PADDING - (int)((float)TEXT_HEIGHT * 1.0f), new Color(1.0f, 1.0f, 1.0f, 0.7f));
        ImageManager.getImage(Images.feather).draw(spriteBatch, PADDING + n, -1, (int)((float)TEXT_HEIGHT * 1.0f), (int)((float)TEXT_HEIGHT * 1.0f));
        CFG.drawText(spriteBatch, "Bloody", PADDING + n + (int)((float)TEXT_HEIGHT * 1.0f) + PADDING - 1, PADDING - 35 + ((int)((float)TEXT_HEIGHT * 1.0f) * 3 + PADDING * 2), Color.RED);
        CFG.drawText(spriteBatch, "               World II", PADDING + n + (int)((float)TEXT_HEIGHT * 1.0f) + PADDING - 1, PADDING - 35 + ((int)((float)TEXT_HEIGHT * 1.0f) * 3 + PADDING * 2), Color.WHITE);
        CFG.drawText(spriteBatch, langManager.get("Version1") + VERSION, PADDING + n, PADDING - 35 + ((int)((float)TEXT_HEIGHT * 1.0f) * 4 + PADDING * 3), new Color(1.0f, 1.0f, 1.0f, 0.7f));
        CFG.drawText(spriteBatch, langManager.get("") + "", PADDING + n, PADDING - 35 + ((int)((float)TEXT_HEIGHT * 1.0f) * 5 + PADDING * 4), new Color(1.0f, 1.0f, 1.0f, 0.7f));
        fontMain.getData().setScale(1.0f);
    }

    protected static final void editorServiceRibbon_Colors_Add() {
        if (editorServiceRibbon_Colors.size() == 0) {
            editorServiceRibbon_Colors.add(new Color(0.9843137f, 0.015686275f, 0.0f, 1.0f));
        } else if (editorServiceRibbon_Colors.size() == 1) {
            editorServiceRibbon_Colors.add(new Color(1.0f, 1.0f, 1.0f, 1.0f));
        } else if (editorServiceRibbon_Colors.size() == 2) {
            editorServiceRibbon_Colors.add(new Color(0.15294118f, 0.3019608f, 0.60784316f, 1.0f));
        } else if (editorServiceRibbon_Colors.size() == 3) {
            editorServiceRibbon_Colors.add(new Color(0.08627451f, 0.14901961f, 0.4509804f, 1.0f));
        } else {
            editorServiceRibbon_Colors.add(CFG.getRandomColor());
        }
    }

    public static void exceptionStack(Throwable throwable) {
        throwable.printStackTrace();
    }

    protected static final String extraRandm_UPDATE_KEY() {
        Random random = new Random();
        String string2 = "";
        for (int i = 0; i < 14; ++i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append((char)(random.nextInt(26) + 97));
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    protected static final String extraRandomTag() {
        Random random = new Random();
        String string2 = "";
        for (int i = 0; i < 8; ++i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append((char)(random.nextInt(26) + 97));
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected static final void formCiv(int var0) {
        block26: {
            if (CFG.canFormACiv(var0, CFG.formableCivs_GameData.getFormableCivTag(), false) == false) return;
            CFG.game.getCiv(var0).clearTagsCanForm();
            CFG.game.getCiv(var0).setCivTag(CFG.formableCivs_GameData.getFormableCivTag());
            CFG.game.getCiv(var0).setCivName(CFG.langManager.getCiv(CFG.game.getCiv(var0).getCivTag()));
            CFG.game.getCiv(var0).loadFlag();
            for (var1_1 = 0; var1_1 < CFG.game.getCiv(var0).getCivRegionsSize(); ++var1_1) {
                CFG.game.getCiv(var0).getCivRegion(var1_1).buildScaleOfText();
            }
            if (CFG.game.getProvince(CFG.formableCivs_GameData.getCapitalProvinceID()).getWasteland() < 0 && !CFG.game.getProvince(CFG.formableCivs_GameData.getCapitalProvinceID()).getSeaProvince() && CFG.formableCivs_GameData.getCapitalProvinceID() != CFG.game.getCiv(var0).getCapitalProvinceID()) {
                if (CFG.game.getCiv(var0).getCapitalProvinceID() >= 0) {
                    for (var1_1 = 0; var1_1 < (var2_2 = CFG.game).getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).getCitiesSize(); ++var1_1) {
                        var2_2 = CFG.game;
                        if (var2_2.getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).getCity(var1_1).getCityLevel() != CFG.getEditorCityLevel(0)) continue;
                        var2_2 = CFG.game;
                        var2_2.getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).getCity(var1_1).setCityLevel(CFG.getEditorCityLevel(1));
                    }
                    var2_2 = CFG.game;
                    var2_2.getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).setIsCapital(false);
                }
                CFG.game.getCiv(var0).setCapitalProvinceID(CFG.formableCivs_GameData.getCapitalProvinceID());
                CFG.game.getProvince(CFG.formableCivs_GameData.getCapitalProvinceID()).setIsCapital(true);
                if (CFG.game.getCiv(var0).getCapitalProvinceID() >= 0) {
                    CFG.game.getCiv(var0).setCoreCapitalProvinceID(CFG.game.getCiv(var0).getCapitalProvinceID());
                    var2_2 = CFG.game;
                    if (var2_2.getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).getCitiesSize() > 0) {
                        var2_2 = CFG.game;
                        var2_2.getProvince(var2_2.getCiv(var0).getCapitalProvinceID()).getCity(0).setCityLevel(CFG.getEditorCityLevel(0));
                    }
                }
            }
            CFG.game.getCiv(var0).updateCivilizationIdeology();
            CFG.game.getCiv(var0).setMoney(CFG.game.getCiv(var0).getMoney() - 10000L);
            CFG.game.getCiv(var0).setDiplomacyPoints(CFG.game.getCiv(var0).getDiplomacyPoints() - 24);
            try {
                var2_2 = Gdx.files;
                var3_12 = new StringBuilder();
                var3_12.append("game/civilizations/");
                var3_12.append(CFG.formableCivs_GameData.getFormableCivTag());
                var2_2 = (Civilization_GameData3)CFG.deserialize(var2_2.internal(var3_12.toString()).readBytes());
                CFG.game.getCiv(var0).setR(var2_2.getR());
                CFG.game.getCiv(var0).setG(var2_2.getG());
                CFG.game.getCiv(var0).setB(var2_2.getB());
            }
            catch (IOException var2_3) {
                ** GOTO lbl148
            }
            catch (ClassNotFoundException var2_4) {
                ** GOTO lbl151
            }
            catch (GdxRuntimeException var2_5) {
                try {
                    var2_2 = Gdx.files;
                    var3_12 = new StringBuilder();
                    var3_12.append("game/civilizations/");
                    var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                    var3_12 = (Civilization_GameData3)CFG.deserialize(var2_2.internal(var3_12.toString()).readBytes());
                    var1_1 = CFG.ideologiesManager.getIdeologyID(CFG.formableCivs_GameData.getFormableCivTag());
                    var2_2 = new Color((float)var3_12.getR() / 255.0f, (float)var3_12.getG() / 255.0f, (float)var3_12.getB() / 255.0f, 0.775f);
                    var3_12 = new Color(CFG.ideologiesManager.getIdeology((int)var1_1).getColor().r, CFG.ideologiesManager.getIdeology((int)var1_1).getColor().g, CFG.ideologiesManager.getIdeology((int)var1_1).getColor().b, 0.225f);
                    var2_2 = CFG.getColorMixed((Color)var2_2, (Color)var3_12);
                    CFG.game.getCiv(var0).setR((int)(var2_2.r * 255.0f));
                    CFG.game.getCiv(var0).setG((int)(var2_2.g * 255.0f));
                    CFG.game.getCiv(var0).setB((int)(var2_2.b * 255.0f));
                }
                catch (GdxRuntimeException var2_6) {
                    try {
                        var2_2 = Gdx.files;
                        var3_12 = new StringBuilder();
                        var3_12.append("game/civilizations/");
                        var3_12.append(CFG.formableCivs_GameData.getFormableCivTag());
                        var2_2 = (Civilization_GameData3)CFG.deserialize(var2_2.local(var3_12.toString()).readBytes());
                        CFG.game.getCiv(var0).setR(var2_2.getR());
                        CFG.game.getCiv(var0).setG(var2_2.getG());
                        CFG.game.getCiv(var0).setB(var2_2.getB());
                    }
                    catch (GdxRuntimeException var2_7) {
                        try {
                            var3_12 = Gdx.files;
                            var2_2 = new StringBuilder();
                            var2_2.append("game/civilizations/");
                            var2_2.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                            var3_12 = (Civilization_GameData3)CFG.deserialize(var3_12.local(var2_2.toString()).readBytes());
                            var1_1 = CFG.ideologiesManager.getIdeologyID(CFG.formableCivs_GameData.getFormableCivTag());
                            var2_2 = new Color((float)var3_12.getR() / 255.0f, (float)var3_12.getG() / 255.0f, (float)var3_12.getB() / 255.0f, 0.775f);
                            var3_12 = new Color(CFG.ideologiesManager.getIdeology((int)var1_1).getColor().r, CFG.ideologiesManager.getIdeology((int)var1_1).getColor().g, CFG.ideologiesManager.getIdeology((int)var1_1).getColor().b, 0.225f);
                            var2_2 = CFG.getColorMixed((Color)var2_2, (Color)var3_12);
                            CFG.game.getCiv(var0).setR((int)(var2_2.r * 255.0f));
                            CFG.game.getCiv(var0).setG((int)(var2_2.g * 255.0f));
                            CFG.game.getCiv(var0).setB((int)(var2_2.b * 255.0f));
                        }
                        catch (GdxRuntimeException var2_8) {
                            var4_13 = CFG.isAndroid();
                            if (!var4_13) ** GOTO lbl118
                            try {
                                var2_2 = Gdx.files;
                                var3_12 = new StringBuilder();
                                var3_12.append("game/civilizations_editor/");
                                var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                var3_12.append("/");
                                var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                var2_2 = (Civilization_GameData3)CFG.deserialize(var2_2.local(var3_12.toString()).readBytes());
                                CFG.game.getCiv(var0).setR(var2_2.getR());
                                CFG.game.getCiv(var0).setG(var2_2.getG());
                                CFG.game.getCiv(var0).setB(var2_2.getB());
                            }
                            catch (GdxRuntimeException var2_9) {
                                try {
                                    block27: {
                                        break block27;
lbl118:
                                        // 1 sources

                                        var2_2 = Gdx.files;
                                        var3_12 = new StringBuilder();
                                        var3_12.append("game/civilizations_editor/");
                                        var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                        var3_12.append("/");
                                        var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                        var2_2 = (Civilization_GameData3)CFG.deserialize(var2_2.internal(var3_12.toString()).readBytes());
                                        CFG.game.getCiv(var0).setR(var2_2.getR());
                                        CFG.game.getCiv(var0).setG(var2_2.getG());
                                        CFG.game.getCiv(var0).setB(var2_2.getB());
                                    }
                                    var2_2 = Gdx.files;
                                    var3_12 = new StringBuilder();
                                    var3_12.append("game/civilizations_editor/");
                                    var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                    var3_12.append("/");
                                    var3_12.append(CFG.ideologiesManager.getRealTag(CFG.formableCivs_GameData.getFormableCivTag()));
                                    var2_2 = (Civilization_GameData3)CFG.deserialize(var2_2.internal(var3_12.toString()).readBytes());
                                    CFG.game.getCiv(var0).setR(var2_2.getR());
                                    CFG.game.getCiv(var0).setG(var2_2.getG());
                                    CFG.game.getCiv(var0).setB(var2_2.getB());
                                }
                                catch (GdxRuntimeException var2_10) {
                                    // empty catch block
                                }
lbl148:
                                // 1 sources

                                if (CFG.LOGS) {
                                    CFG.exceptionStack(var2_3);
                                }
                                break block26;
lbl151:
                                // 1 sources

                                if (CFG.LOGS) {
                                    CFG.exceptionStack(var2_4);
                                }
                            }
                        }
                    }
                }
            }
        }
        if (CFG.game.getCiv(var0).getControlledByPlayer() && CFG.isDesktop() && AoCGame.steamGame != null) {
            AoCGame.steamGame.checkFormableAchievement(var0);
        }
        CFG.gameNewGame.updateFormableCivilizations(var0);
        var1_1 = 0;
        while (var1_1 < CFG.game.getCiv(var0).getNumOfProvinces()) {
            var2_2 = CFG.game;
            var2_2.getProvince(var2_2.getCiv(var0).getProvinceID(var1_1)).setFromCivID(0);
            ++var1_1;
        }
    }

    protected static final Image getActiveCivFlag() {
        Image image;
        Image image2 = image = activeCivFlag;
        if (image == null) {
            image2 = game.getCiv(activeCivInfo).getFlag();
        }
        return image2;
    }

    protected static final int getActiveCivInfo() {
        return activeCivInfo;
    }

    protected static final int getActiveCivInfo_BasedOnActiveProvinceID(int n) {
        if (n >= 0) {
            if (FOG_OF_WAR == 2) {
                if (game.getProvince(n).getCivID() > 0 && CFG.getMetProvince(n)) {
                    return game.getProvince(n).getCivID();
                }
                return game.getPlayer(PLAYER_TURNID).getCivID();
            }
            if (game.getProvince(n).getCivID() > 0) {
                return game.getProvince(n).getCivID();
            }
            return game.getPlayer(PLAYER_TURNID).getCivID();
        }
        return game.getPlayer(PLAYER_TURNID).getCivID();
    }

    protected static final String getAlliances_Random_Names_All_BundleID(Alliances_Names_GameData alliances_Names_GameData, int n) {
        String string2 = "";
        for (int i = 0; i < alliances_Names_GameData.getBundle(n).getWordsSize(); ++i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(alliances_Names_GameData.getBundle(n).getWord(i));
            string2 = i < alliances_Names_GameData.getBundle(n).getWordsSize() - 1 ? ", " : "";
            stringBuilder.append(string2);
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getCityLevelName(int n) {
        if (n == 0) return langManager.get("Capital");
        if (n == 1) return langManager.get("City");
        if (n == 2) return langManager.get("Town");
        if (n == 3) return langManager.get("Village");
        if (n == 0) return langManager.get("Test-City");
        if (n == 5) return langManager.get("Hamlet");
        return langManager.get("Hamlet");
    }

    protected static final int getCityLevel_Population(float f, int n, int n2) {
        float f2 = (float)n2 * 0.2f;
        if ((f = (float)n / f) >= 0.85f + f2) {
            return Images.city2;
        }
        if (f >= 0.55f + f2) {
            return Images.city3;
        }
        if (f >= f2 + 0.325f) {
            return Images.city4;
        }
        return Images.city5;
    }

    protected static final int getCivDifficulty(int n) {
        int n2;
        float f = CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CAN_BECOME_CIVILIZED > 0 ? 15.8f : 5.0f;
        float f2 = (float)game.getCiv(n).getRankPosition() * 65.0f / (float)game.getCivsSize();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int n3 = 0;
        for (n2 = 0; n2 < game.getCiv(n).getNumOfProvinces(); ++n2) {
            Game game;
            for (int i = 0; i < (game = CFG.game).getProvince(game.getCiv(n).getProvinceID(n2)).getNeighboringProvincesSize(); ++i) {
                int n4;
                block4: {
                    game = CFG.game;
                    if (game.getProvince(game.getProvince(game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i)).getCivID() <= 0) continue;
                    for (n4 = 0; n4 < arrayList.size(); ++n4) {
                        int n5 = (Integer)arrayList.get(n4);
                        if (n5 != (game = CFG.game).getProvince(game.getProvince(game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i)).getCivID()) continue;
                        n4 = 1;
                        break block4;
                    }
                    n4 = 0;
                }
                if (n4 != 0) continue;
                game = CFG.game;
                arrayList.add(game.getProvince(game.getProvince(game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i)).getCivID());
            }
        }
        f = f + f2 + (float)arrayList.size();
        for (n2 = n3; n2 < arrayList.size(); ++n2) {
            f += Math.min((float)game.getCiv((Integer)arrayList.get(n2)).getRankScore() / (float)game.getCiv(n).getRankScore(), 1.85f) * 2.68f;
        }
        return Math.min((int)f, 100);
    }

    protected static final Color getColorMixed(Color color2, Color color3) {
        float f = 1.0f - (1.0f - color2.a) * (1.0f - color3.a);
        return new Color(color3.r * color3.a / f + color2.r * color2.a * (1.0f - color3.a) / f, color3.g * color3.a / f + color2.g * color2.a * (1.0f - color3.a) / f, color3.b * color3.a / f + color2.b * color2.a * (1.0f - color3.a) / f, color2.a);
    }

    protected static final float getColorStep(int n, int n2, int n3, int n4) {
        return ((float)n + (float)((n2 - n) * n3) / (float)n4) / 255.0f;
    }

    protected static final Color getColorStep(Color color2, Color color3, int n, int n2, float f) {
        float f2 = color2.r;
        float f3 = color2.r;
        f3 = color3.r;
        f3 = (color3.r - color2.r) * (float)n / (float)n2;
        float f4 = color2.g;
        float f5 = color2.g;
        f5 = color3.g;
        f5 = (color3.g - color2.g) * (float)n / (float)n2;
        float f6 = color2.b;
        float f7 = color2.b;
        f7 = color3.b;
        return new Color(f2 + f3, f4 + f5, f6 + (color3.b - color2.b) * (float)n / (float)n2, f);
    }

    protected static final Color getColorStep_WithAlpha(Color color2, Color color3, int n, int n2) {
        float f = color2.r;
        float f2 = color2.r;
        f2 = color3.r;
        f2 = (color3.r - color2.r) * (float)n / (float)n2;
        float f3 = color2.g;
        float f4 = color2.g;
        f4 = color3.g;
        float f5 = (color3.g - color2.g) * (float)n / (float)n2;
        f4 = color2.b;
        float f6 = color2.b;
        f6 = color3.b;
        float f7 = (color3.b - color2.b) * (float)n / (float)n2;
        f6 = color2.a;
        float f8 = color2.a;
        f8 = color3.a;
        return new Color(f + f2, f3 + f5, f4 + f7, f6 + (color3.a - color2.a) * (float)n / (float)n2);
    }

    protected static Color getColor_CivInfo_InGame_Text(boolean bl, boolean bl2) {
        Color color2 = bl ? COLOR_TEXT_CIV_INFO_ACTIVE : (bl2 ? COLOR_TEXT_CIV_INFO_HOVER : COLOR_TEXT_MODIFIER_NEUTRAL);
        return color2;
    }

    protected static Color getColor_CivInfo_Text(boolean bl, boolean bl2) {
        Color color2 = bl ? COLOR_TEXT_CIV_INFO_ACTIVE : (bl2 ? COLOR_TEXT_CIV_INFO_HOVER : COLOR_TEXT_CIV_INFO);
        return color2;
    }

    protected static final Color getContinentDataColor(String object) {
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/continents/packges_data/");
            stringBuilder.append((String)object);
            object = (Continent_GameData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes());
            object = new Color(((Continent_GameData)object).getR(), ((Continent_GameData)object).getG(), ((Continent_GameData)object).getB(), 0.7f);
            return object;
        }
        catch (IOException | ClassNotFoundException exception) {
            return new Color(1.0f, 1.0f, 1.0f, 0.7f);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getContinentDataName(String charSequence) {
        void var0_2;
        try {
            String string2;
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/continents/packges_data/");
            stringBuilder.append((String)charSequence);
            String string3 = string2 = ((Continent_GameData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes())).getName();
            return var0_2;
        }
        catch (IOException | ClassNotFoundException exception) {
            return var0_2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getCostOfRecruitArmyMoney(int n) {
        int n2 = game.getProvince(n).getCivID();
        n2 = game.getCiv(n2).getCivBuildArmyCost();
        if (game.getProvince(n).getLevelOfArmoury() <= 0) return n2;
        return n2 * 7 / 10;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getCostOfRecruitArmyMoneyAutoplan(int n) {
        int n2 = game.getProvince(n).getCivID();
        n2 = game.getCiv(n2).getCivBuildArmyCost();
        if (game.getProvince(n).getLevelOfArmoury() <= 0) return n2;
        return n2 * 10000 / 10000;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getCostOfRecruitArmyMoney_Instantly(int n) {
        int n2 = game.getProvince(n).getCivID();
        n2 = game.getCiv(n2).getCivBuildArmyCost();
        if (game.getProvince(n).getLevelOfArmoury() <= 0) return n2 * 2;
        return n2 * 20 / 25;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getCreateScenario_TechnologyLevelsByContinents_Continent(int n, int n2) {
        int n3 = 0;
        while (true) {
            try {
                if (n3 >= lCreateScenario_TechnologyBContinents.get(n).size()) return 100;
                if (n2 == lCreateScenario_TechnologyBContinents.get(n).get(n3).getContinentID()) {
                    return lCreateScenario_TechnologyBContinents.get(n).get(n3).getPercentage();
                }
                ++n3;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (!LOGS) return 100;
                CFG.exceptionStack(indexOutOfBoundsException);
                return 100;
            }
        }
    }

    protected static final int getDarker(int n, int n2) {
        return Math.round(Math.max(0, n - n2));
    }

    protected static final Color getDarker(Color color2, int n, float f) {
        float f2 = color2.r;
        float f3 = n;
        return new Color(Math.round(Math.max(0.0f, f2 * 255.0f - f3) / 255.0f), Math.round(Math.max(0.0f, color2.g * 255.0f - f3) / 255.0f), Math.round(Math.max(0.0f, color2.b * 255.0f - f3) / 255.0f), f);
    }

    protected static final String getDifficultyName(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 4) {
                        return langManager.get("Extreme");
                    }
                    return langManager.get("Legendary");
                }
                return langManager.get("Hard");
            }
            return langManager.get("Normal");
        }
        return langManager.get("Beginner");
    }

    protected static final Color getEconomyColor(int n, float f) {
        switch (n / 10) {
            default: {
                return new Color(CFG.COLOR_ECONOMY[10].r, CFG.COLOR_ECONOMY[10].g, CFG.COLOR_ECONOMY[10].b, f);
            }
            case 10: {
                return new Color(CFG.COLOR_ECONOMY[10].r, CFG.COLOR_ECONOMY[10].g, CFG.COLOR_ECONOMY[10].b, f);
            }
            case 9: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[9], arrcolor[10], n % 10, 10, f);
            }
            case 8: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[8], arrcolor[9], n % 10, 10, f);
            }
            case 7: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[7], arrcolor[8], n % 10, 10, f);
            }
            case 6: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[6], arrcolor[7], n % 10, 10, f);
            }
            case 5: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[5], arrcolor[6], n % 10, 10, f);
            }
            case 4: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[4], arrcolor[5], n % 10, 10, f);
            }
            case 3: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[3], arrcolor[4], n % 10, 10, f);
            }
            case 2: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[2], arrcolor[3], n % 10, 10, f);
            }
            case 1: {
                Color[] arrcolor = COLOR_ECONOMY;
                return CFG.getColorStep(arrcolor[1], arrcolor[2], n % 10, 10, f);
            }
            case 0: 
        }
        Color[] arrcolor = COLOR_ECONOMY;
        return CFG.getColorStep(arrcolor[0], arrcolor[1], n % 10, 10, f);
    }

    protected static final int getEditorCityLevel(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n != 4) {
                            if (n != 5) {
                                return Images.city2;
                            }
                            return Images.city5;
                        }
                    } else {
                        return Images.city4;
                    }
                    return Images.city5;
                }
                return Images.city3;
            }
            return Images.city2;
        }
        return Images.city;
    }

    protected static final int getEditorCityLevel_Ref(int n) {
        if (n == Images.city) {
            return 0;
        }
        if (n == Images.city2) {
            return 1;
        }
        if (n == Images.city3) {
            return 2;
        }
        if (n == Images.city4) {
            return 3;
        }
        if (n == Images.city5) {
            return 4;
        }
        if (n == Images.city5) {
            return 5;
        }
        return 2;
    }

    protected static final List<String> getFileNames(String object) {
        Object object2 = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getFileNames: ");
        stringBuilder.append((String)object);
        object2.log("AoC2", stringBuilder.toString());
        object2 = new ArrayList();
        object = Gdx.app.getType() == Application.ApplicationType.Android ? Gdx.files.internal((String)object) : Gdx.files.internal((String)object);
        object = object.list();
        int n = ((FileHandle[])object).length;
        for (int i = 0; i < n; ++i) {
            object2.add(object[i].name());
        }
        return object2;
    }

    protected static final List<String> getFileNames2(String arrfileHandle) {
        int n;
        Object object = Gdx.app;
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("getFileNames: ");
        ((StringBuilder)object2).append((String)arrfileHandle);
        object.log("AoC2", ((StringBuilder)object2).toString());
        object = new ArrayList();
        object2 = Gdx.app.getType();
        Application.ApplicationType applicationType = Application.ApplicationType.Android;
        int n2 = 0;
        if (object2 == applicationType) {
            object2 = Gdx.files.internal((String)arrfileHandle).list();
            int n3 = ((FileHandle[])object2).length;
            for (n = 0; n < n3; ++n) {
                object.add(object2[n].name());
            }
            object2 = new ArrayList();
            arrfileHandle = Gdx.files.local((String)arrfileHandle).list();
            n3 = arrfileHandle.length;
            for (n = n2; n < n3; ++n) {
                object2.add(arrfileHandle[n].name());
            }
            if (object2.size() > object.size()) {
                return object2;
            }
            return object;
        }
        arrfileHandle = Gdx.files.internal((String)arrfileHandle).list();
        n2 = arrfileHandle.length;
        for (n = 0; n < n2; ++n) {
            object.add(arrfileHandle[n].name());
        }
        return object;
    }

    protected static final int getFileNames_Length(String object) {
        object = Gdx.app.getType() == Application.ApplicationType.Android ? Gdx.files.internal((String)object) : Gdx.files.internal((String)object);
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("dirHandle.list()");
        stringBuilder.append(((FileHandle)object).list().length);
        application.log("AoC", stringBuilder.toString());
        return ((FileHandle)object).list().length;
    }

    protected static final String getFogOfWarName(int n) {
        if (n != 0) {
            if (n != 2) {
                return langManager.get("Classic");
            }
            return langManager.get("Discovery");
        }
        return langManager.get("Off");
    }

    protected static final Color getGrowthRateColor(int n, float f) {
        switch (n / 10) {
            default: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                float f2 = arrcolor[arrcolor.length - 1].r;
                arrcolor = COLOR_GROWTH_RATE;
                float f3 = arrcolor[arrcolor.length - 1].g;
                arrcolor = COLOR_GROWTH_RATE;
                return new Color(f2, f3, arrcolor[arrcolor.length - 1].b, f);
            }
            case 10: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                float f4 = arrcolor[arrcolor.length - 1].r;
                arrcolor = COLOR_GROWTH_RATE;
                float f5 = arrcolor[arrcolor.length - 1].g;
                arrcolor = COLOR_GROWTH_RATE;
                return new Color(f4, f5, arrcolor[arrcolor.length - 1].b, f);
            }
            case 9: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[9], arrcolor[10], n % 10, 10, f);
            }
            case 8: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[8], arrcolor[9], n % 10, 10, f);
            }
            case 7: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[7], arrcolor[8], n % 10, 10, f);
            }
            case 6: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[6], arrcolor[7], n % 10, 10, f);
            }
            case 5: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[5], arrcolor[6], n % 10, 10, f);
            }
            case 4: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[4], arrcolor[5], n % 10, 10, f);
            }
            case 3: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[3], arrcolor[4], n % 10, 10, f);
            }
            case 2: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[2], arrcolor[3], n % 10, 10, f);
            }
            case 1: {
                Color[] arrcolor = COLOR_GROWTH_RATE;
                return CFG.getColorStep(arrcolor[1], arrcolor[2], n % 10, 10, f);
            }
            case 0: 
        }
        Color[] arrcolor = COLOR_GROWTH_RATE;
        return CFG.getColorStep(arrcolor[0], arrcolor[1], n % 10, 10, f);
    }

    protected static final int getHappinesImage(int n) {
        n = n > 60 ? Images.happiness : (n > 35 ? Images.happiness1 : Images.happiness2);
        return n;
    }

    protected static boolean getIsInFormableCiv(int n) {
        int n2 = 0;
        while (true) {
            try {
                if (n2 >= formableCivs_GameData.getProvincesSize()) break;
                int n3 = formableCivs_GameData.getProvinceID(n2);
                if (n3 == n) {
                    return true;
                }
                ++n2;
            }
            catch (NullPointerException nullPointerException) {
                if (!LOGS) break;
                CFG.exceptionStack(nullPointerException);
                break;
            }
        }
        return false;
    }

    private static final int getKeyboardMessage_RGB() {
        block7: {
            int n = 0;
            try {
                int n2 = Integer.parseInt(keyboardMessage.substring(3, keyboardMessage.length()));
                if (n2 > 255) {
                    n = 255;
                } else if (n2 >= 0) {
                    n = n2;
                }
                return n;
            }
            catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
                if (LOGS) {
                    CFG.exceptionStack(stringIndexOutOfBoundsException);
                }
            }
            catch (IllegalArgumentException illegalArgumentException) {
                if (!LOGS) break block7;
                CFG.exceptionStack(illegalArgumentException);
            }
        }
        return 0;
    }

    protected static final float getLoadingPadding() {
        if (!CFG.isAndroid() || LANDSCAPE) {
            // empty if block
        }
        return 0.1f;
    }

    protected static String getLukaszJakowski() {
        if (loadedRobotoFont) {
            return "Bloody World II";
        }
        return "Bloody World II";
    }

    protected static String getLukaszJakowskiGames() {
        if (loadedRobotoFont) {
            return "Bloody World II";
        }
        return "Bloody World II";
    }

    protected static boolean getMetCiv(int n) {
        try {
            boolean bl = game.getPlayer(PLAYER_TURNID).getMetCivilization(n);
            return bl;
        }
        catch (NullPointerException nullPointerException) {
            return true;
        }
    }

    protected static boolean getMetCiv_AllPlayers(int n) {
        for (int i = 0; i < game.getPlayersSize(); ++i) {
            Game game = CFG.game;
            if (game.getCiv(game.getPlayer(i).getCivID()).getNumOfProvinces() <= 0 || !CFG.game.getPlayer(i).getMetCivilization(n)) continue;
            return true;
        }
        return false;
    }

    protected static boolean getMetProvince(int n) {
        try {
            boolean bl = game.getPlayer(PLAYER_TURNID).getMetProvince(n);
            return bl;
        }
        catch (NullPointerException nullPointerException) {
            return true;
        }
    }

    protected static final int getMetersToFeet(int n) {
        return (int)((float)n * 3.2808f);
    }

    protected static final String getNumberWithSpaces(String string2) {
        int n = string2.length();
        String string3 = "";
        while (true) {
            int n2 = 0;
            if (n <= 0) break;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" ");
            int n3 = n - 3;
            if (n3 > 0) {
                n2 = n3;
            }
            stringBuilder.append(string2.substring(n2, n));
            stringBuilder.append(string3);
            string3 = stringBuilder.toString();
            n -= 3;
        }
        string2 = string3;
        if (string3.charAt(0) == ' ') {
            string2 = string3.substring(1, string3.length());
        }
        return string2;
    }

    protected static final String getNumber_SHORT(int n) {
        if (n < 1000) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            return stringBuilder.toString();
        }
        if (n < 1000000) {
            CharSequence charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("");
            ((StringBuilder)charSequence).append((float)n / 1000.0f);
            charSequence = ((StringBuilder)charSequence).toString();
            try {
                Object object = Gdx.app;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(((String)charSequence).charAt(((String)charSequence).indexOf(".") + 1));
                object.log("AoC", stringBuilder.toString());
                stringBuilder = new StringBuilder();
                stringBuilder.append("");
                if (((String)charSequence).charAt(((String)charSequence).indexOf(".") + 1) == '0') {
                    charSequence = new StringBuilder();
                    ((StringBuilder)charSequence).append("");
                    ((StringBuilder)charSequence).append(n / 1000);
                    ((StringBuilder)charSequence).append(langManager.get("Value_Thousand"));
                    charSequence = ((StringBuilder)charSequence).toString();
                } else {
                    object = new StringBuilder();
                    ((StringBuilder)object).append(((String)charSequence).substring(0, ((String)charSequence).indexOf(".") + 2));
                    ((StringBuilder)object).append(langManager.get("Value_Thousand"));
                    charSequence = ((StringBuilder)object).toString();
                }
                stringBuilder.append((String)charSequence);
                charSequence = stringBuilder.toString();
                return charSequence;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(n / 1000);
                stringBuilder.append(langManager.get("Value_Thousand"));
                return stringBuilder.toString();
            }
        }
        CharSequence charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append((float)n / 1000000.0f);
        String string2 = charSequence.toString();
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            if (string2.charAt(string2.indexOf(".") + 1) == '0') {
                charSequence = new StringBuilder();
                charSequence.append("");
                charSequence.append(n / 1000);
                charSequence.append(langManager.get("Value_Million"));
                charSequence = charSequence.toString();
            } else {
                charSequence = new StringBuilder();
                charSequence.append(string2.substring(0, string2.indexOf(".") + 2));
                charSequence.append(langManager.get("Value_Million"));
                charSequence = charSequence.toString();
            }
            stringBuilder.append((String)charSequence);
            charSequence = stringBuilder.toString();
            return charSequence;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n / 1000);
            stringBuilder.append(langManager.get("Value_Million"));
            return stringBuilder.toString();
        }
    }

    protected static long getPROVINCE_BORDER_ANIMATION_TIME(String string2) {
        try {
            long l = PROVINCE_BORDER_ANIMATION_TIME.get(string2);
            return l;
        }
        catch (NullPointerException nullPointerException) {
            return 0L;
        }
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getPackageContinentDataName(String charSequence) {
        void var0_2;
        try {
            String string2;
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/continents/packges/");
            stringBuilder.append((String)charSequence);
            String string3 = string2 = ((Package_ContinentsData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes())).getPackageName();
            return var0_2;
        }
        catch (IOException | ClassNotFoundException exception) {
            return var0_2;
        }
    }

    protected static final String getPackageContinentData_AllNames(String string2) {
        int n;
        Serializable serializable;
        Object object;
        try {
            object = Gdx.files;
            serializable = new StringBuilder();
            ((StringBuilder)serializable).append("map/data/continents/packges/");
            ((StringBuilder)serializable).append(string2);
            serializable = (Package_ContinentsData)CFG.deserialize(object.internal(((StringBuilder)serializable).toString()).readBytes());
            n = 0;
            string2 = "";
        }
        catch (IOException | ClassNotFoundException exception) {
            return langManager.get("Error");
        }
        while (true) {
            if (n >= ((Package_ContinentsData)serializable).getContinentsTagsSize()) break;
            object = new StringBuilder();
            ((StringBuilder)object).append(string2);
            ((StringBuilder)object).append(CFG.getContinentDataName(((Package_ContinentsData)serializable).getContinentTag(n)));
            string2 = n < ((Package_ContinentsData)serializable).getContinentsTagsSize() - 1 ? ", " : "";
            ((StringBuilder)object).append(string2);
            string2 = ((StringBuilder)object).toString();
            ++n;
            continue;
            break;
        }
        return string2;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getPackageDiplomacyColorsDataName(String charSequence) {
        void var0_2;
        try {
            String string2;
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/diplomacy_colors/packages/");
            stringBuilder.append((String)charSequence);
            String string3 = string2 = ((DiplomacyColors_GameData2)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes())).getName();
            return var0_2;
        }
        catch (IOException | ClassNotFoundException exception) {
            return var0_2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getPackageRegionDataName(String object) {
        try {
            Object object2 = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/regions/packges/");
            stringBuilder.append((String)object);
            return object2 = ((Package_RegionsData)CFG.deserialize(object2.internal(stringBuilder.toString()).readBytes())).getPackageName();
        }
        catch (IOException | ClassNotFoundException exception) {
            return object;
        }
    }

    protected static final String getPackageRegionsData_AllNames(String string2) {
        int n;
        Serializable serializable;
        Object object;
        try {
            object = Gdx.files;
            serializable = new StringBuilder();
            ((StringBuilder)serializable).append("map/data/regions/packges/");
            ((StringBuilder)serializable).append(string2);
            serializable = (Package_RegionsData)CFG.deserialize(object.internal(((StringBuilder)serializable).toString()).readBytes());
            n = 0;
            string2 = "";
        }
        catch (IOException | ClassNotFoundException exception) {
            return langManager.get("Error");
        }
        while (true) {
            if (n >= ((Package_RegionsData)serializable).getRegionsTagsSize()) break;
            object = new StringBuilder();
            ((StringBuilder)object).append(string2);
            ((StringBuilder)object).append(CFG.getRegionDataName(((Package_RegionsData)serializable).getRegionTag(n)));
            string2 = n < ((Package_RegionsData)serializable).getRegionsTagsSize() - 1 ? ", " : "";
            ((StringBuilder)object).append(string2);
            string2 = ((StringBuilder)object).toString();
            ++n;
            continue;
            break;
        }
        return string2;
    }

    protected static final Color getPactColor(int n, float f) {
        return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.getB(), f), n, 200, f);
    }

    protected static final String getPercentage(float f, float f2, int n) {
        f = f2 = f / f2;
        if (f2 > 100.0f) {
            f = 100.0f;
        }
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(f);
        charSequence = ((StringBuilder)charSequence).toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f);
        return ((String)charSequence).substring(0, Math.min(n, stringBuilder.toString().length()));
    }

    protected static final String getPercentage(int n, int n2, int n3) {
        float f = (float)n / (float)n2 * 100.0f;
        double d = f;
        double d2 = Math.floor(d);
        Double.isNaN(d);
        if (d - d2 == 0.0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append((int)f);
            return stringBuilder.toString();
        }
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(f);
        charSequence = ((StringBuilder)charSequence).toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f);
        return ((String)charSequence).substring(0, Math.min(n3, stringBuilder.toString().length()));
    }

    protected static final String getPercentage_Max100(float f, float f2, int n) {
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(f /= f2);
        charSequence = ((StringBuilder)charSequence).toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f);
        return ((String)charSequence).substring(0, Math.min(n, stringBuilder.toString().length()));
    }

    protected static final String getPercentage_Max100(int n, int n2, int n3) {
        float f;
        float f2 = f = (float)n / (float)n2 * 100.0f;
        if (f > 100.0f) {
            f2 = 100.0f;
        }
        double d = f2;
        double d2 = Math.floor(d);
        Double.isNaN(d);
        if (d - d2 == 0.0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append((int)f2);
            return stringBuilder.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f2);
        String string2 = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f2);
        return string2.substring(0, Math.min(n3, stringBuilder.toString().length()));
    }

    protected static final String getPercentage_Max100_X100(float f, float f2, int n) {
        f = f / f2 * 100.0f;
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(f);
        charSequence = ((StringBuilder)charSequence).toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(f);
        return ((String)charSequence).substring(0, Math.min(n, stringBuilder.toString().length()));
    }

    protected static final Color getPopulationColor(int n, float f) {
        switch (n / 10) {
            default: {
                return new Color(CFG.COLOR_POPULATION[10].r, CFG.COLOR_POPULATION[10].g, CFG.COLOR_POPULATION[10].b, f);
            }
            case 10: {
                return new Color(CFG.COLOR_POPULATION[10].r, CFG.COLOR_POPULATION[10].g, CFG.COLOR_POPULATION[10].b, f);
            }
            case 9: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[9], arrcolor[10], n % 10, 10, f);
            }
            case 8: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[8], arrcolor[9], n % 10, 10, f);
            }
            case 7: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[7], arrcolor[8], n % 10, 10, f);
            }
            case 6: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[6], arrcolor[7], n % 10, 10, f);
            }
            case 5: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[5], arrcolor[6], n % 10, 10, f);
            }
            case 4: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[4], arrcolor[5], n % 10, 10, f);
            }
            case 3: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[3], arrcolor[4], n % 10, 10, f);
            }
            case 2: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[2], arrcolor[3], n % 10, 10, f);
            }
            case 1: {
                Color[] arrcolor = COLOR_POPULATION;
                return CFG.getColorStep(arrcolor[1], arrcolor[2], n % 10, 10, f);
            }
            case 0: 
        }
        Color[] arrcolor = COLOR_POPULATION;
        return CFG.getColorStep(arrcolor[0], arrcolor[1], n % 10, 10, f);
    }

    protected static final Color getProvinceArmyColor_Alliance(int n) {
        return new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), (float)n / (float)MAX_PROVINCE_VALUE * 0.2875f + 0.2875f);
    }

    protected static final Color getProvinceArmyColor_AtWar(int n) {
        return new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), (float)n / (float)MAX_PROVINCE_VALUE * 0.2875f + 0.2875f);
    }

    protected static final Color getProvinceArmyColor_Neutral(int n) {
        return new Color(CFG.COLOR_PROVINCE_ARMY_MAX.r, CFG.COLOR_PROVINCE_ARMY_MAX.g, CFG.COLOR_PROVINCE_ARMY_MAX.b, (float)n / (float)MAX_PROVINCE_VALUE * 0.2875f + 0.2875f);
    }

    protected static final Color getProvinceArmyColor_Own(int n) {
        return new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.getB(), (float)n / (float)MAX_PROVINCE_VALUE * 0.2875f + 0.2875f);
    }

    protected static final Color getProvinceValueColor(int n) {
        Color color2 = new Color(1.0f, 1.0f, 0.8039216f, 0.75f);
        Color color3 = new Color(0.9098039f, 0.09411765f, 0.09411765f, 0.75f);
        int n2 = MAX_PROVINCE_VALUE;
        return CFG.getColorStep(color2, color3, n, n2, (float)n / (float)n2 * 0.075f + 0.67499995f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getRandomAllianceName(int n) {
        int n2;
        int n3;
        int n4;
        Serializable serializable;
        Object object;
        if (n > 100) {
            return "";
        }
        Random random = new Random();
        try {
            object = Gdx.files;
            serializable = new StringBuilder();
            ((StringBuilder)serializable).append("game/alliance_names/");
            ((StringBuilder)serializable).append(lRandomAlliancesNamesPackagesTags.get(random.nextInt(lRandomAlliancesNamesPackagesTags.size())));
            serializable = (Alliances_Names_GameData)CFG.deserialize(object.internal(((StringBuilder)serializable).toString()).readBytes());
            n4 = 0;
            object = "";
            n3 = 0;
        }
        catch (IOException | ClassNotFoundException exception) {
            return "";
        }
        while (true) {
            n2 = n4;
            if (n3 >= ((Alliances_Names_GameData)serializable).getSize()) break;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((String)object);
            stringBuilder.append(((Alliances_Names_GameData)serializable).getBundle(n3).getWord(random.nextInt(((Alliances_Names_GameData)serializable).getBundle(n3).getWordsSize())));
            object = n3 == ((Alliances_Names_GameData)serializable).getSize() - 1 ? "" : " ";
            stringBuilder.append((String)object);
            object = stringBuilder.toString();
            ++n3;
            continue;
            break;
        }
        while (true) {
            if (n2 >= game.getAlliancesSize()) return object;
            if (game.getAlliance(n2).getAllianceName().equals(object)) {
                return CFG.getRandomAllianceName(n + 1);
            }
            ++n2;
            continue;
            break;
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final String getRandomAllianceName(Alliances_Names_GameData alliances_Names_GameData) {
        void var0_3;
        String string2;
        String string3;
        block5: {
            int n;
            Random random;
            try {
                random = new Random();
                n = 0;
                string3 = "";
            }
            catch (IllegalArgumentException illegalArgumentException) {
                string3 = "";
                break block5;
            }
            while (true) {
                string2 = string3;
                try {
                    if (n >= alliances_Names_GameData.getSize()) return string2;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3);
                    stringBuilder.append(alliances_Names_GameData.getBundle(n).getWord(random.nextInt(alliances_Names_GameData.getBundle(n).getWordsSize())));
                    string2 = n < alliances_Names_GameData.getSize() - 1 ? " " : "";
                    stringBuilder.append(string2);
                    string2 = stringBuilder.toString();
                    ++n;
                    string3 = string2;
                    continue;
                }
                catch (IllegalArgumentException illegalArgumentException) {}
                break;
            }
        }
        string2 = string3;
        if (!LOGS) return string2;
        CFG.exceptionStack((Throwable)var0_3);
        return string3;
    }

    protected static Color getRandomColor() {
        return new Color((float)oR.nextInt(256) / 255.0f, (float)oR.nextInt(256) / 255.0f, (float)oR.nextInt(256) / 255.0f, 1.0f);
    }

    protected static Color_GameData getRandomColorGameData() {
        return new Color_GameData((float)oR.nextInt(256) / 255.0f, (float)oR.nextInt(256) / 255.0f, (float)oR.nextInt(256) / 255.0f);
    }

    protected static Point_XY getRandomPointToCenterTheMap() {
        Random random = new Random();
        return new Point_XY(random.nextInt(map.getMapBG().getWidth() / map.getMapBG().getMapScale()), random.nextInt(map.getMapBG().getHeight() / map.getMapBG().getMapScale()));
    }

    protected static final Color getRegionDataColor(String object) {
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/regions/packges_data/");
            stringBuilder.append((String)object);
            object = (Region_GameData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes());
            object = new Color(((Region_GameData)object).getR(), ((Region_GameData)object).getG(), ((Region_GameData)object).getB(), 0.45f);
            return object;
        }
        catch (IOException | ClassNotFoundException exception) {
            return new Color(1.0f, 1.0f, 1.0f, 0.45f);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getRegionDataName(String charSequence) {
        void var0_2;
        try {
            String string2;
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("map/data/regions/packges_data/");
            stringBuilder.append((String)charSequence);
            String string3 = string2 = ((Region_GameData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes())).getName();
            return var0_2;
        }
        catch (IOException | ClassNotFoundException exception) {
            return var0_2;
        }
    }

    protected static final Color getRelationColor(int n, float f) {
        switch (n / 10) {
            default: {
                return new Color(0.0f, 0.0f, 0.0f, ALPHA_DIPLOMACY);
            }
            case 10: {
                return new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), f);
            }
            case 9: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[9].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[9].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[9].getB(), f), n % 10, 10, f);
            }
            case 8: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[8].getB(), f), n % 10, 10, f);
            }
            case 7: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[7].getB(), f), n % 10, 10, f);
            }
            case 6: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[6].getB(), f), n % 10, 10, f);
            }
            case 5: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[5].getB(), f), n % 10, 10, f);
            }
            case 4: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[4].getB(), f), n % 10, 10, f);
            }
            case 3: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[3].getB(), f), n % 10, 10, f);
            }
            case 2: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[2].getB(), f), n % 10, 10, f);
            }
            case 1: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[1].getB(), f), n % 10, 10, f);
            }
            case 0: {
                if (n > 0) {
                    return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[0].getB(), f), n % 10, 10, f);
                }
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getB(), f), -n % 10, 10, f);
            }
            case -1: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[0].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getB(), f), -n % 10, 10, f);
            }
            case -2: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[1].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getB(), f), -n % 10, 10, f);
            }
            case -3: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[2].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getB(), f), -n % 10, 10, f);
            }
            case -4: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[3].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getB(), f), -n % 10, 10, f);
            }
            case -5: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[4].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getB(), f), -n % 10, 10, f);
            }
            case -6: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[5].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getB(), f), -n % 10, 10, f);
            }
            case -7: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[6].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getB(), f), -n % 10, 10, f);
            }
            case -8: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[7].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getB(), f), -n % 10, 10, f);
            }
            case -9: {
                return CFG.getColorStep(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[8].getB(), f), new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[9].getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[9].getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[9].getB(), f), -n % 10, 10, f);
            }
            case -10: 
        }
        return new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), f);
    }

    protected static final String getRescouresPath() {
        if (XXXXHDPI) {
            return "XXXXH/";
        }
        if (XXXHDPI) {
            return "XXXH/";
        }
        if (XXHDPI) {
            return "XXH/";
        }
        if (XHDPI) {
            return "XH/";
        }
        return "H/";
    }

    protected static final Color getTechnologyLevelColor(int n, float f) {
        switch (n / 10) {
            default: {
                return new Color(CFG.COLOR_TECHNOLOGY_LEVEL[10].r, CFG.COLOR_TECHNOLOGY_LEVEL[10].g, CFG.COLOR_TECHNOLOGY_LEVEL[10].b, f);
            }
            case 10: {
                return new Color(CFG.COLOR_TECHNOLOGY_LEVEL[10].r, CFG.COLOR_TECHNOLOGY_LEVEL[10].g, CFG.COLOR_TECHNOLOGY_LEVEL[10].b, f);
            }
            case 9: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[9], arrcolor[10], n % 10, 10, f);
            }
            case 8: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[8], arrcolor[9], n % 10, 10, f);
            }
            case 7: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[7], arrcolor[8], n % 10, 10, f);
            }
            case 6: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[6], arrcolor[7], n % 10, 10, f);
            }
            case 5: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[5], arrcolor[6], n % 10, 10, f);
            }
            case 4: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[4], arrcolor[5], n % 10, 10, f);
            }
            case 3: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[3], arrcolor[4], n % 10, 10, f);
            }
            case 2: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[2], arrcolor[3], n % 10, 10, f);
            }
            case 1: {
                Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
                return CFG.getColorStep(arrcolor[1], arrcolor[2], n % 10, 10, f);
            }
            case 0: 
        }
        Color[] arrcolor = COLOR_TECHNOLOGY_LEVEL;
        return CFG.getColorStep(arrcolor[0], arrcolor[1], n % 10, 10, f);
    }

    protected static final Color getTruceColor(float f) {
        return new Color(1.0f, 1.0f, 1.0f, f);
    }

    protected static final int getUIScale() {
        if (XXXXHDPI) {
            return 4;
        }
        if (XXXHDPI) {
            return 3;
        }
        if (XXHDPI) {
            return 2;
        }
        if (XHDPI) {
            return 1;
        }
        return 0;
    }

    protected static final String getWikiInormationsLink(String string2) {
        try {
            Object object = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/civilizations_informations/");
            stringBuilder.append(string2);
            object = object.internal(stringBuilder.toString()).readString();
            stringBuilder = new StringBuilder();
            stringBuilder.append(WWW_WIKI);
            stringBuilder.append((String)object);
            object = stringBuilder.toString();
            return object;
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            try {
                Files files = Gdx.files;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("game/civilizations_informations/");
                stringBuilder.append(ideologiesManager.getRealTag(string2));
                string2 = files.internal(stringBuilder.toString()).readString();
                stringBuilder = new StringBuilder();
                stringBuilder.append(WWW_WIKI);
                stringBuilder.append(string2);
                string2 = stringBuilder.toString();
                return string2;
            }
            catch (GdxRuntimeException gdxRuntimeException2) {
                return "/";
            }
        }
    }

    protected static final String getWikiInormationsLink_Clear(String string2) {
        try {
            Object object = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/civilizations_informations/");
            stringBuilder.append(string2);
            object = object.internal(stringBuilder.toString()).readString();
            return object;
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            try {
                Files files = Gdx.files;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("game/civilizations_informations/");
                stringBuilder.append(ideologiesManager.getRealTag(string2));
                string2 = files.internal(stringBuilder.toString()).readString();
                return string2;
            }
            catch (GdxRuntimeException gdxRuntimeException2) {
                return langManager.get("NoData");
            }
        }
    }

    protected static final void initCreateScenario_TechnologyLevelsByContinents_Civ() {
        List<List<Scenario_GameData_Technology>> list = lCreateScenario_TechnologyBContinents;
        if (list != null) {
            list.clear();
            lCreateScenario_TechnologyBContinents = null;
        }
        lCreateScenario_TechnologyBContinents = new ArrayList<List<Scenario_GameData_Technology>>();
    }

    protected static final void initEditdiplomacyColors_GameData() {
        diplomacyColors_GameData = new DiplomacyColors_GameData2();
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES = new Color_GameData(0.2f, 0.6f, 1.0f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR = new Color_GameData(0.8f, 0.0f, 0.0f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE = new Color_GameData(0.0f, 0.4f, 1.0f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT = new Color_GameData(1.0f, 1.0f, 0.6f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX = new Color_GameData(0.8f, 0.8f, 0.0f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_VASSAL = new Color_GameData(0.28235295f, 0.47843137f, 0.8627451f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_INDEPENDENCE = new Color_GameData(0.7254902f, 0.28235295f, 0.8627451f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL = new Color_GameData(0.9411765f, 0.9411765f, 0.9411765f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_MILITARY_ACCESS = new Color_GameData(0.9411765f, 0.9411765f, 0.9411765f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_DEFENSIVE_PACT = new Color_GameData(0.9411765f, 0.9411765f, 0.9411765f);
        Color_GameData color_GameData = new Color_GameData(0.92941177f, 0.627451f, 0.5882353f);
        Color_GameData color_GameData2 = new Color_GameData(0.89411765f, 0.5568628f, 0.45490196f);
        Color_GameData color_GameData3 = new Color_GameData(0.85490197f, 0.48235294f, 0.32156864f);
        Color_GameData color_GameData4 = new Color_GameData(0.8039216f, 0.40784314f, 0.20784314f);
        Color_GameData color_GameData5 = new Color_GameData(0.77254903f, 0.3647059f, 0.2f);
        Color_GameData color_GameData6 = new Color_GameData(0.73333335f, 0.3254902f, 0.2f);
        Color_GameData color_GameData7 = new Color_GameData(0.69411767f, 0.28627452f, 0.2f);
        Color_GameData color_GameData8 = new Color_GameData(0.654902f, 0.2509804f, 0.2f);
        Color_GameData color_GameData9 = new Color_GameData(0.62352943f, 0.22352941f, 0.2f);
        Color_GameData color_GameData10 = new Color_GameData(0.6f, 0.2f, 0.2f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE = new Color_GameData[]{color_GameData, color_GameData2, color_GameData3, color_GameData4, color_GameData5, color_GameData6, color_GameData7, color_GameData8, color_GameData9, color_GameData10};
        color_GameData6 = new Color_GameData(0.6f, 0.8f, 0.6f);
        color_GameData10 = new Color_GameData(0.5176471f, 0.7607843f, 0.43137255f);
        color_GameData2 = new Color_GameData(0.40392157f, 0.70980394f, 0.2627451f);
        color_GameData8 = new Color_GameData(0.3019608f, 0.654902f, 0.12156863f);
        color_GameData3 = new Color_GameData(0.20392157f, 0.5921569f, 0.003921569f);
        color_GameData7 = new Color_GameData(0.14901961f, 0.5647059f, 0.0f);
        color_GameData9 = new Color_GameData(0.09411765f, 0.5137255f, 0.0f);
        color_GameData5 = new Color_GameData(0.05490196f, 0.46666667f, 0.0f);
        color_GameData4 = new Color_GameData(0.023529412f, 0.42745098f, 0.0f);
        color_GameData = new Color_GameData(0.0f, 0.4f, 0.0f);
        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE = new Color_GameData[]{color_GameData6, color_GameData10, color_GameData2, color_GameData8, color_GameData3, color_GameData7, color_GameData9, color_GameData5, color_GameData4, color_GameData};
    }

    protected static final boolean isAndroid() {
        boolean bl = Gdx.app.getType() == Application.ApplicationType.Android || Gdx.app.getType() == Application.ApplicationType.iOS;
        return bl;
    }

    protected static final boolean isDesktop() {
        boolean bl = Gdx.app.getType() == Application.ApplicationType.Desktop;
        return bl;
    }

    protected static final boolean isIOS() {
        boolean bl = Gdx.app.getType() == Application.ApplicationType.iOS;
        return bl;
    }

    protected static final boolean isInFormableCivs(String string2) {
        if (formableCivs_GameData.getFormableCivTag() != null && formableCivs_GameData.getFormableCivTag().equals(string2)) {
            return true;
        }
        for (int i = 0; i < formableCivs_GameData.getClaimantsSize(); ++i) {
            if (!string2.equals(formableCivs_GameData.getClaimant(i))) continue;
            return true;
        }
        return false;
    }

    protected static final boolean isInLeaderCivs(String string2) {
        for (int i = 0; i < leader_GameData.getCivsSize(); ++i) {
            if (!string2.equals(leader_GameData.getCiv(i))) continue;
            return true;
        }
        return false;
    }

    protected static final boolean isInTheGame(String string2) {
        for (int i = 1; i < game.getCivsSize(); ++i) {
            if (!string2.equals(game.getCiv(i).getCivTag())) continue;
            return true;
        }
        return false;
    }

    protected static final boolean isInTheGame_Or_IsFormableCiv(String string2) {
        int n;
        for (n = 1; n < game.getCivsSize(); ++n) {
            if (!string2.equals(game.getCiv(n).getCivTag())) continue;
            return true;
        }
        n = 1;
        while (true) {
            int n2 = game.getCivsSize();
            if (n >= n2) break;
            for (int i = 0; i < game.getCiv(n).getTagsCanFormSize(); ++i) {
                if (!string2.equals(game.getCiv(n).getTagsCanForm(i))) continue;
                return true;
            }
            ++n;
        }
        return false;
    }

    protected static final void loadDiplomacyColors_GameData(String string2) {
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/diplomacy_colors/packages/");
            stringBuilder.append(string2);
            diplomacyColors_GameData = (DiplomacyColors_GameData2)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes());
            return;
        }
        catch (IOException | ClassNotFoundException exception) {
            CFG.initEditdiplomacyColors_GameData();
            return;
        }
    }

    protected static final void loadFontArmy() {
        Object object;
        Object object2 = fontArmy;
        if (object2 != null) {
            ((BitmapFont)object2).dispose();
            fontArmy = null;
        }
        object2 = object = langManager.get("fontArmy");
        if (((String)object).equals("fontArmy")) {
            object2 = "rbold.ttf";
        }
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/fonts/");
            stringBuilder.append((String)object2);
            object2 = object = new FreeTypeFontGenerator(files.internal(stringBuilder.toString()));
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            object2 = new FreeTypeFontGenerator(Gdx.files.internal("game/fonts/rbold.ttf"));
        }
        object = new FreeTypeFontGenerator.FreeTypeFontParameter();
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).size = Math.max(CFG.settingsManager.FONT_ARMY_SIZE, 6);
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).color = Color.WHITE;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).minFilter = Texture.TextureFilter.Linear;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).magFilter = Texture.TextureFilter.Linear;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).characters = "0123456789+-.,%?!";
        fontArmy = ((FreeTypeFontGenerator)object2).generateFont((FreeTypeFontGenerator.FreeTypeFontParameter)object);
        ((FreeTypeFontGenerator)object2).dispose();
        glyphLayout.setText(fontArmy, "-+1234567890");
        ARMY_HEIGHT = (int)CFG.glyphLayout.height;
    }

    protected static final void loadFontBorder() {
        Object object;
        Object object2 = fontBorder;
        if (object2 != null) {
            ((BitmapFont)object2).dispose();
            fontBorder = null;
        }
        object2 = object = langManager.get("font2");
        if (((String)object).equals("font2")) {
            object2 = "rbold.ttf";
        }
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/fonts/");
            stringBuilder.append((String)object2);
            object2 = object = new FreeTypeFontGenerator(files.internal(stringBuilder.toString()));
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            object2 = new FreeTypeFontGenerator(Gdx.files.internal("game/fonts/rbold.ttf"));
        }
        object = new FreeTypeFontGenerator.FreeTypeFontParameter();
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).characters = langManager.get("charset");
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).size = CFG.settingsManager.FONT_BORDER_SIZE;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).color = new Color(CFG.settingsManager.civNamesFontColor.getR(), CFG.settingsManager.civNamesFontColor.getG(), CFG.settingsManager.civNamesFontColor.getB(), CFG.settingsManager.civNamesFontColor_ALPHA);
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).minFilter = Texture.TextureFilter.Linear;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).magFilter = Texture.TextureFilter.Linear;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).borderColor = new Color(CFG.settingsManager.civNamesFontColorBorder.getR(), CFG.settingsManager.civNamesFontColorBorder.getG(), CFG.settingsManager.civNamesFontColorBorder.getB(), CFG.settingsManager.civNamesFontColorBorder_ALPHA);
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).borderWidth = CFG.settingsManager.FONT_BORDER_WIDTH_OF_BORDER;
        fontBorder = ((FreeTypeFontGenerator)object2).generateFont((FreeTypeFontGenerator.FreeTypeFontParameter)object);
        ((FreeTypeFontGenerator)object2).dispose();
    }

    protected static final void loadFontMain() {
        Object object;
        Object object2 = fontMain;
        if (object2 != null) {
            ((BitmapFont)object2).dispose();
            fontMain = null;
        }
        object2 = object = langManager.get("font");
        if (((String)object).equals("font")) {
            object2 = "rbold.ttf";
        }
        loadedRobotoFont = ((String)object2).equals("rbold.ttf");
        try {
            Files files = Gdx.files;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("game/fonts/");
            stringBuilder.append((String)object2);
            object2 = object = new FreeTypeFontGenerator(files.internal(stringBuilder.toString()));
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            object2 = new FreeTypeFontGenerator(Gdx.files.internal("game/fonts/rbold.ttf"));
        }
        object = new FreeTypeFontGenerator.FreeTypeFontParameter();
        Gdx.app.log("AoC", langManager.get("charset"));
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).characters = langManager.get("charset");
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).size = Math.max(CFG.settingsManager.FONT_MAIN_SIZE, 6);
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).color = Color.WHITE;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).minFilter = Texture.TextureFilter.Linear;
        ((FreeTypeFontGenerator.FreeTypeFontParameter)object).magFilter = Texture.TextureFilter.Linear;
        fontMain = ((FreeTypeFontGenerator)object2).generateFont((FreeTypeFontGenerator.FreeTypeFontParameter)object);
        ((FreeTypeFontGenerator)object2).dispose();
        glyphLayout.setText(fontMain, "Ay\u04cfdZOP38901ERLj");
        TEXT_HEIGHT = (int)CFG.glyphLayout.height;
        settingsManager.updateCitiesFontScale();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void loadFormableCiv_GameData(String string2) {
        ClassNotFoundException classNotFoundException2;
        block5: {
            try {
                try {
                    Files files = Gdx.files;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(FILE_MAP_PATH);
                    stringBuilder.append(map.getFile_ActiveMap_Path());
                    stringBuilder.append(FILE_MAP_FORMABLE_CIVS_PATH);
                    stringBuilder.append(string2);
                    formableCivs_GameData = (FormableCivs_GameData)CFG.deserialize(files.local(stringBuilder.toString()).readBytes());
                    return;
                }
                catch (GdxRuntimeException gdxRuntimeException) {
                    Files files = Gdx.files;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(FILE_MAP_PATH);
                    stringBuilder.append(map.getFile_ActiveMap_Path());
                    stringBuilder.append(FILE_MAP_FORMABLE_CIVS_PATH);
                    stringBuilder.append(string2);
                    formableCivs_GameData = (FormableCivs_GameData)CFG.deserialize(files.internal(stringBuilder.toString()).readBytes());
                    return;
                }
            }
            catch (IOException iOException) {
            }
            catch (ClassNotFoundException classNotFoundException2) {
                break block5;
            }
            if (!LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
        if (!LOGS) return;
        CFG.exceptionStack(classNotFoundException2);
    }

    protected static final void loadRandomAlliancesNames() {
        block3: {
            lRandomAlliancesNamesPackagesTags = new ArrayList<String>();
            try {
                String string2 = Gdx.files.internal("game/alliance_names/Age_of_Civilizations.json").readString();
                Object object2 = new Json();
                ((Json)object2).setElementType(ConfigAlliancesData.class, "Data_Random_Alliance_Names", Data_Random_Alliance_Names.class);
                new ConfigAlliancesData();
                for (Object object2 : object2.fromJson(ConfigAlliancesData.class, (String)string2).Data_Random_Alliance_Names) {
                    if (!((Data_Random_Alliance_Names)object2).Enabled) continue;
                    lRandomAlliancesNamesPackagesTags.add(((Data_Random_Alliance_Names)object2).Tag);
                }
            }
            catch (GdxRuntimeException gdxRuntimeException) {
                if (!LOGS) break block3;
                CFG.exceptionStack(gdxRuntimeException);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void loadSettings() {
        try {
            settingsManager = (SettingsManager)CFG.deserialize(Gdx.files.local(FILE_SETTINGS).readBytes());
            return;
        }
        catch (ClassNotFoundException classNotFoundException) {
            if (!LOGS) return;
            CFG.exceptionStack(classNotFoundException);
            return;
        }
        catch (IOException iOException) {
            if (!LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            try {
                settingsManager = (SettingsManager)CFG.deserialize(Gdx.files.internal(FILE_SETTINGS).readBytes());
                return;
            }
            catch (GdxRuntimeException | IOException | ClassNotFoundException exception) {
                return;
            }
        }
    }

    protected static final boolean ownAllProvinces_FormableCiv(int n) {
        for (int i = 0; i < formableCivs_GameData.getProvincesSize(); ++i) {
            if (game.getProvince(formableCivs_GameData.getProvinceID(i)).getWasteland() >= 0 || game.getProvince(formableCivs_GameData.getProvinceID(i)).getCivID() == n) continue;
            return false;
        }
        return true;
    }

    protected static final boolean readLocalFiles() {
        int n = 62.$SwitchMap$com$badlogic$gdx$Application$ApplicationType[Gdx.app.getType().ordinal()];
        if (n != 1 && n != 2) {
            if (n != 3) {
                // empty if block
            }
            return false;
        }
        return true;
    }

    protected static final void removeCreateScenario_TechnologyLevelsByContinents_Civ(int n) {
        lCreateScenario_TechnologyBContinents.remove(n);
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("remove: ");
        stringBuilder.append(lCreateScenario_TechnologyBContinents.size());
        application.log("AoC", stringBuilder.toString());
    }

    protected static void removeUndoAssignProvinces() {
        if (lCreateScenario_UndoAssignProvincesCivID.size() > 0) {
            List<Undo_AssignProvinceCiv> list = lCreateScenario_UndoAssignProvincesCivID;
            list.remove(list.size() - 1);
        }
        if (lCreateScenario_UndoAssignProvincesCivID.size() == 0) {
            menuManager.setCreate_Scenario_Assign_UndoButton(false);
        }
    }

    protected static void removeUndoWastelandProvince() {
        if (lCreateScenario_UndoWastelandProvinces.size() > 0) {
            List<Integer> list = lCreateScenario_UndoWastelandProvinces;
            list.remove(list.size() - 1);
        }
        if (lCreateScenario_UndoWastelandProvinces.size() == 0) {
            if (menuManager.getInCreateScenario_Available_Provinces()) {
                menuManager.setCreate_Scenario_AvailableProvinces_UndoButton(false);
            } else if (menuManager.getInMapEditor_WastelandMaps_Edit()) {
                menuManager.setMapEditor_WastelandMaps_Edit_UndoButton(false);
            }
        }
    }

    protected static final void resetManageDiplomacyIDs() {
        MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1 = -1;
        MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = -1;
        MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = -1;
        MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID = 1;
        MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID2 = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void saveSettings() {
        try {
            Gdx.files.local(FILE_SETTINGS).writeBytes(CFG.serialize(settingsManager), false);
            return;
        }
        catch (IOException iOException) {
            if (!LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void saveSettings_ActiveMap() {
        try {
            FileHandle fileHandle = Gdx.files.local(FILE_SETTINGS_LAST_ACTIVE_MAP);
            SaveActiveMap_GameData saveActiveMap_GameData = new SaveActiveMap_GameData();
            saveActiveMap_GameData.iActiveMapID = map.getActiveMapID();
            saveActiveMap_GameData.iActiveMapScale = map.getMapScale(map.getActiveMapID());
            fileHandle.writeBytes(CFG.serialize(saveActiveMap_GameData), false);
            return;
        }
        catch (IOException iOException) {
            if (!LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void saveSettings_LoadingStatus() {
        try {
            FileHandle fileHandle = Gdx.files.local(FILE_SETTINGS_LOADING_STATUS);
            SaveActiveMap_Status_GameData saveActiveMap_Status_GameData = new SaveActiveMap_Status_GameData();
            fileHandle.writeBytes(CFG.serialize(saveActiveMap_Status_GameData), false);
            return;
        }
        catch (IOException iOException) {
            if (!LOGS) return;
            CFG.exceptionStack(iOException);
            return;
        }
    }

    protected static final byte[] serialize(Object object) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        new ObjectOutputStream(byteArrayOutputStream).writeObject(object);
        return byteArrayOutputStream.toByteArray();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected static final void setActiveCivInfo(int var0) {
        try {
            block28: {
                CFG.disposeActiveCivFlag();
                CFG.activeCivInfo = var0;
                var1_1 = CFG.game.getCiv(CFG.activeCivInfo).getCivTag().indexOf(59);
                var2_2 = 0;
                if (var1_1 > 0) {
                    var3_3 = CFG.unionFlagsToGenerate_Manager.lFlags;
                    var4_19 = new UnionFlagsToGenerate();
                    var3_3.add((UnionFlagsToGenerate)var4_19);
                    var1_1 = CFG.unionFlagsToGenerate_Manager.lFlags.size() - 1;
                    var3_3 = CFG.game.getCiv(CFG.activeCivInfo).getCivTag().split(";");
                    for (var0 = var2_2; var0 < var3_3.length; ++var0) {
                        CFG.unionFlagsToGenerate_Manager.lFlags.get((int)var1_1).lTags.add(var3_3[var0]);
                    }
                    CFG.unionFlagsToGenerate_Manager.lFlags.get((int)var1_1).typeOfAction = UnionFlagsToGenerate_TypesOfAction.ACTIVE_CIV_INFO;
                    return;
                }
                try {
                    var3_4 = Gdx.files;
                    var4_20 = new StringBuilder();
                    var4_20.append("game/flagsH/");
                    var4_20.append(CFG.game.getCiv(CFG.activeCivInfo).getCivTag());
                    var4_20.append(".png");
                    var6_24 = new Texture(var3_4.internal(var4_20.toString()));
                    CFG.activeCivFlag = var5_22 = new Image((Texture)var6_24, Texture.TextureFilter.Linear);
                }
                catch (RuntimeException var3_5) {
                    ** GOTO lbl116
                }
                catch (OutOfMemoryError var3_6) {
                    ** GOTO lbl120
                }
                catch (GdxRuntimeException var3_7) {
                    block27: {
                        if (!CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var0).getIdeologyID()).REVOLUTIONARY) break block27;
                        var6_25 = Gdx.files;
                        var5_23 = new StringBuilder();
                        var5_23.append("game/flagsH/rb");
                        var5_23.append((CFG.game.getCiv(var0).getCivID() + CFG.game.getCiv(var0).getCivTag().charAt(0)) % 6);
                        var5_23.append(".png");
                        var4_21 = new Texture(var6_25.internal(var5_23.toString()));
                        CFG.activeCivFlag = var3_8 = new Image(var4_21, Texture.TextureFilter.Nearest);
                        return;
                    }
                    try {
                        var5_22 = Gdx.files;
                        var4_20 = new StringBuilder();
                        var4_20.append("game/flagsH/");
                        var4_20.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                        var4_20.append(".png");
                        var6_24 = new Texture(var5_22.internal(var4_20.toString()));
                        CFG.activeCivFlag = var3_4 = new Image((Texture)var6_24, Texture.TextureFilter.Linear);
                    }
                    catch (GdxRuntimeException var3_9) {
                        var7_26 = CFG.isAndroid();
                        if (!var7_26) ** GOTO lbl86
                        try {
                            var5_22 = Gdx.files;
                            var3_4 = new StringBuilder();
                            var3_4.append("game/civilizations_editor/");
                            var3_4.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                            var3_4.append("/");
                            var3_4.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                            var3_4.append("_FLH.png");
                            var4_20 = new Texture(var5_22.local(var3_4.toString()));
                            CFG.activeCivFlag = var6_24 = new Image((Texture)var4_20, Texture.TextureFilter.Linear);
                        }
                        catch (GdxRuntimeException var3_10) {
                            try {
                                block29: {
                                    break block29;
lbl86:
                                    // 1 sources

                                    var5_22 = Gdx.files;
                                    var4_20 = new StringBuilder();
                                    var4_20.append("game/civilizations_editor/");
                                    var4_20.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                                    var4_20.append("/");
                                    var4_20.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                                    var4_20.append("_FLH.png");
                                    var3_4 = new Texture(var5_22.internal(var4_20.toString()));
                                    CFG.activeCivFlag = var6_24 = new Image((Texture)var3_4, Texture.TextureFilter.Linear);
                                }
                                var4_20 = Gdx.files;
                                var3_4 = new StringBuilder();
                                var3_4.append("game/civilizations_editor/");
                                var3_4.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                                var3_4.append("/");
                                var3_4.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(CFG.activeCivInfo).getCivTag()));
                                var3_4.append("_FLH.png");
                                var5_22 = new Texture(var4_20.internal(var3_4.toString()));
                                CFG.activeCivFlag = var6_24 = new Image((Texture)var5_22, Texture.TextureFilter.Linear);
                            }
                            catch (GdxRuntimeException var3_11) {
                                CFG.activeCivFlag = null;
                                if (!CFG.LOGS) break block28;
                                CFG.exceptionStack(var3_11);
                            }
lbl116:
                            // 1 sources

                            CFG.activeCivFlag = null;
                            if (CFG.LOGS) {
                                CFG.exceptionStack(var3_5);
                            }
                            break block28;
lbl120:
                            // 1 sources

                            CFG.activeCivFlag = null;
                            if (CFG.LOGS) {
                                CFG.exceptionStack(var3_6);
                            }
                        }
                    }
                }
            }
            if (CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData == null) return;
            var0 = CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getImage().length();
            if (var0 <= 0) return;
            try {
                var6_24 = Gdx.files;
                var3_4 = new StringBuilder();
                var3_4.append("game/leadersIMG/");
                var3_4.append(CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getImage());
                var4_20 = new Texture(var6_24.internal(var3_4.toString()));
                CFG.activeCivLeader = var5_22 = new Image((Texture)var4_20, Texture.TextureFilter.Linear);
                return;
            }
            catch (RuntimeException var3_12) {
                ** GOTO lbl163
            }
            catch (OutOfMemoryError var3_13) {
                ** GOTO lbl167
            }
            catch (GdxRuntimeException var3_14) {
                try {
                    var4_20 = Gdx.files;
                    var5_22 = new StringBuilder();
                    var5_22.append("game/leadersIMG/");
                    var5_22.append(CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getImage());
                    var3_15 = new Texture(var4_20.local(var5_22.toString()));
                    CFG.activeCivLeader = var6_24 = new Image(var3_15, Texture.TextureFilter.Linear);
                    return;
                }
                catch (GdxRuntimeException var3_16) {
                    CFG.activeCivLeader = null;
                    if (CFG.LOGS == false) return;
                    CFG.exceptionStack(var3_16);
                    return;
                }
lbl163:
                // 1 sources

                CFG.activeCivLeader = null;
                if (CFG.LOGS == false) return;
                CFG.exceptionStack(var3_12);
                return;
lbl167:
                // 1 sources

                CFG.activeCivLeader = null;
                if (CFG.LOGS == false) return;
                CFG.exceptionStack(var3_13);
                return;
            }
        }
        catch (NullPointerException var3_17) {
            if (CFG.LOGS == false) return;
            CFG.exceptionStack(var3_17);
        }
    }

    protected static final void setActiveCivInfoFlag(Image image) {
        try {
            CFG.disposeActiveCivFlag();
            activeCivFlag = image;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
        }
    }

    protected static final void setCreateScenario_TechnologyLevelsByContinents_Continent(int n, int n2, int n3) {
        for (int i = 0; i < lCreateScenario_TechnologyBContinents.get(n).size(); ++i) {
            if (n2 != lCreateScenario_TechnologyBContinents.get(n).get(i).getContinentID()) continue;
            lCreateScenario_TechnologyBContinents.get(n).get(i).setPercentage(n3);
            return;
        }
        lCreateScenario_TechnologyBContinents.get(n).add(new Scenario_GameData_Technology(n2, n3));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void setDialogType(Dialog var0) {
        CFG.dialogType = var0;
        CFG.menuManager.getDialogMenu().getMenuElement(1).setClickable(true);
        CFG.menuManager.getDialogMenu().getMenuElement(2).setClickable(true);
        var1_3 = 62.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Dialog[CFG.dialogType.ordinal()];
        switch (var1_3) {
            default: {
                break;
            }
            case 55: {
                try {
                    var0 = Gdx.files;
                    var2_4 = new StringBuilder();
                    var2_4.append("map/");
                    var2_4.append(CFG.map.getFile_ActiveMap_Path());
                    var2_4.append("data/");
                    var2_4.append("cities/");
                    var2_4.append(CFG.EDITOR_ACTIVE_GAMEDATA_TAG);
                    var0 = var0.internal(var2_4.toString());
                    ** try [egrp 2[TRYBLOCK] [3, 2 : 349->433)] { 
lbl25:
                    // 1 sources

                    ** GOTO lbl31
lbl26:
                    // 2 sources

                    catch (IOException | ClassNotFoundException var0_2) {
                    }
                }
                catch (IndexOutOfBoundsException var0_1) {
                    CFG.exceptionStack(var0_1);
                }
                break;
lbl31:
                // 1 sources

                CFG.editorCity = (City)CFG.deserialize(var0.readBytes());
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_4 = new StringBuilder();
                var2_4.append(CFG.langManager.get("Remove"));
                var2_4.append(" ");
                var2_4.append(CFG.editorCity.getCityName());
                var2_4.append("?");
                var0.setText(var2_4.toString());
                break;
            }
            case 54: {
                var2_5 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Remove"));
                var0.append(" ");
                var0.append(CFG.game.getCiv(CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV1).getCivName());
                var0.append("?");
                var2_5.setText(var0.toString());
                break;
            }
            case 52: 
            case 53: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_6 = new StringBuilder();
                var2_6.append(CFG.langManager.get("AreYouSure"));
                var2_6.append("? ");
                var2_6.append(CFG.langManager.get("Scale"));
                var2_6.append(" ");
                var2_6.append(CFG.map.getMapScale(CFG.map.getActiveMapID()));
                var2_6.append(" -> ");
                var2_6.append(CFG.langManager.get("Scale"));
                var2_6.append(" ");
                var2_6.append(CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2);
                var2_6.append("?");
                var0.setText(var2_6.toString());
                break;
            }
            case 51: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_7 = new StringBuilder();
                var2_7.append(CFG.langManager.get("Remove"));
                var2_7.append(" ");
                var2_7.append(CFG.game.getCiv(CFG.holyRomanEmpire_Manager.getHRE().getPrince(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID)).getCivName());
                var2_7.append("?");
                var0.setText(var2_7.toString());
                break;
            }
            case 50: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_8 = new StringBuilder();
                var2_8.append(CFG.langManager.get("Remove"));
                var2_8.append(" ");
                var2_8.append(CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 + 1);
                var2_8.append("?");
                var0.setText(var2_8.toString());
                break;
            }
            case 49: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("DeleteSavedGame"));
                break;
            }
            case 48: {
                var2_9 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("AreYouSure"));
                var0.append("?");
                var2_9.setText(var0.toString());
                break;
            }
            case 47: {
                var2_10 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("GenerateSeaRoutes"));
                var0.append("?");
                var2_10.setText(var0.toString());
                break;
            }
            case 46: {
                var2_11 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("GeneratePreDefinedBorders"));
                var0.append("?");
                var2_11.setText(var0.toString());
                break;
            }
            case 45: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_12 = new StringBuilder();
                var2_12.append(CFG.langManager.get("GenerateSuggestedCivilizations"));
                var2_12.append("?");
                var0.setText(var2_12.toString());
                break;
            }
            case 44: {
                var2_13 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("ShuffleCivilizations"));
                var0.append("?");
                var2_13.setText(var0.toString());
                break;
            }
            case 43: {
                var2_14 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("ReleaseAVassal"));
                var0.append("?");
                var2_14.setText(var0.toString());
                break;
            }
            case 42: {
                var2_15 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Open"));
                var0.append(" ");
                var0.append(CFG.GO_TO_LINK);
                var0.append("?");
                var2_15.setText(var0.toString());
                break;
            }
            case 41: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_16 = new StringBuilder();
                var2_16.append(CFG.langManager.get("Open"));
                var2_16.append(" ");
                var2_16.append("https://en.wikipedia.org/wiki/");
                var2_16.append(CFG.EDITOR_ACTIVE_GAMEDATA_TAG);
                var2_16.append("?");
                var0.setText(var2_16.toString());
                break;
            }
            case 40: {
                var2_17 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Open"));
                var0.append(" ");
                var0.append(CFG.getWikiInormationsLink(CFG.EDITOR_ACTIVE_GAMEDATA_TAG));
                var0.append("?");
                var2_17.setText(var0.toString());
                break;
            }
            case 38: 
            case 39: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("AllNotSavedProgressFromLastGameWillBeLostContinue"));
                break;
            }
            case 36: 
            case 37: {
                var2_18 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("SaveTheGame"));
                var0.append("?");
                var2_18.setText(var0.toString());
                break;
            }
            case 35: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_19 = new StringBuilder();
                var2_19.append(CFG.langManager.get("AreYouSure"));
                var2_19.append("?");
                var0.setText(var2_19.toString());
                break;
            }
            case 34: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_20 = new StringBuilder();
                var2_20.append(CFG.langManager.get("AreYouSure"));
                var2_20.append("?");
                var0.setText(var2_20.toString());
                break;
            }
            case 33: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("StartTheTutorial"));
                break;
            }
            case 32: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("SumbitOrders"));
                break;
            }
            case 31: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_21 = new StringBuilder();
                var2_21.append(CFG.langManager.get("Reverse"));
                var2_21.append("?");
                var0.setText(var2_21.toString());
                break;
            }
            case 30: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("NoOrders"));
                break;
            }
            case 27: 
            case 28: 
            case 29: {
                var2_22 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("DeselectAll"));
                var0.append("?");
                var2_22.setText(var0.toString());
                break;
            }
            case 26: {
                var2_23 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("FormX", CFG.langManager.getCiv(CFG.formableCivs_GameData.getFormableCivTag())));
                var0.append("?");
                var2_23.setText(var0.toString());
                break;
            }
            case 25: {
                var2_24 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Surrender"));
                var0.append("? ");
                var0.append(CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getCivName());
                var2_24.setText(var0.toString());
                break;
            }
            case 24: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_25 = new StringBuilder();
                var2_25.append(CFG.langManager.get("SaveEvent"));
                var2_25.append("?");
                var0.setText(var2_25.toString());
                break;
            }
            case 23: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_26 = new StringBuilder();
                var2_26.append(CFG.langManager.get("Back"));
                var2_26.append("?");
                var0.setText(var2_26.toString());
                break;
            }
            case 22: {
                var2_27 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Language"));
                var0.append(": ");
                var0.append(CFG.langManager.get("LANGUAGENAME"));
                var0.append("?");
                var2_27.setText(var0.toString());
                break;
            }
            case 21: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_28 = new StringBuilder();
                var2_28.append(CFG.langManager.get("Remove"));
                var2_28.append("? ");
                var2_28.append(CFG.eventsManager.getEvent(CFG.eventsManager.iCreateEvent_EditEventID));
                var2_28.append("?");
                var0.setText(var2_28.toString());
                break;
            }
            case 20: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_29 = new StringBuilder();
                var2_29.append(CFG.langManager.get("SaveScenario"));
                var2_29.append("?");
                var0.setText(var2_29.toString());
                break;
            }
            case 19: {
                var2_30 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Select"));
                var0.append(" ");
                var0.append(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivName());
                var0.append("?");
                var2_30.setText(var0.toString());
                break;
            }
            case 18: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_31 = new StringBuilder();
                var2_31.append(CFG.langManager.get("Select"));
                var2_31.append(" ");
                var2_31.append(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivName());
                var2_31.append("?");
                var0.setText(var2_31.toString());
                break;
            }
            case 17: {
                var2_32 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Remove"));
                var0.append(" ");
                var0.append(CFG.game.getCiv(CFG.game.getProvince(CFG.iCreateScenario_ActiveProvinceID).getCivID()).getCivName());
                var0.append("?");
                var2_32.setText(var0.toString());
                break;
            }
            case 16: {
                var2_33 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.game.getCiv(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID).getCivName());
                var0.append(". ");
                var0.append(CFG.langManager.get("TakeAll"));
                var0.append("?");
                var2_33.setText(var0.toString());
                break;
            }
            case 15: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_34 = new StringBuilder();
                var2_34.append(CFG.langManager.get("ExitScenarioEditor"));
                var2_34.append("?");
                var0.setText(var2_34.toString());
                break;
            }
            case 14: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_35 = new StringBuilder();
                var2_35.append(CFG.langManager.get("Back"));
                var2_35.append("?");
                var0.setText(var2_35.toString());
                break;
            }
            case 13: {
                var2_36 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("JustOneMoreTurnIPromise"));
                var0.append("?");
                var2_36.setText(var0.toString());
                break;
            }
            case 12: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_37 = new StringBuilder();
                var2_37.append(CFG.langManager.get("ExitToMainMenu"));
                var2_37.append("?");
                var0.setText(var2_37.toString());
                break;
            }
            case 11: {
                var2_38 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("SpectatorMode"));
                var0.append("?");
                var2_38.setText(var0.toString());
                break;
            }
            case 10: {
                var2_39 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Colonize"));
                var0.append("?");
                var2_39.setText(var0.toString());
                break;
            }
            case 9: {
                var2_40 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("AbandonProvince"));
                var0.append("? ");
                var0.append(CFG.game.getProvince(Menu_InGame_Abadon.iProvinceID).getName());
                var2_40.setText(var0.toString());
                break;
            }
            case 8: {
                var2_41 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("Refuse"));
                var0.append("?");
                var2_41.setText(var0.toString());
                break;
            }
            case 7: {
                var2_42 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("AcceptOffer"));
                var0.append("?");
                var2_42.setText(var0.toString());
                break;
            }
            case 6: {
                var2_43 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("SendDemands"));
                var0.append("?");
                var2_43.setText(var0.toString());
                break;
            }
            case 5: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_44 = new StringBuilder();
                var2_44.append(CFG.langManager.get("Back"));
                var2_44.append("? ");
                var2_44.append(CFG.langManager.get("AreYouSure"));
                var0.setText(var2_44.toString());
                break;
            }
            case 4: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_45 = new StringBuilder();
                var2_45.append(CFG.langManager.get("AreYouSure"));
                var2_45.append(" ");
                var2_45.append(CFG.langManager.get("ExitToMainMenu"));
                var2_45.append("?");
                var0.setText(var2_45.toString());
                break;
            }
            case 3: {
                var0 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var2_46 = new StringBuilder();
                var2_46.append(CFG.langManager.get("AreYouSure"));
                var2_46.append(" ");
                var2_46.append(CFG.langManager.get("ExitToMainMenu"));
                var2_46.append("?");
                var0.setText(var2_46.toString());
                break;
            }
            case 2: {
                var2_47 = CFG.menuManager.getDialogMenu().getMenuElement(3);
                var0 = new StringBuilder();
                var0.append(CFG.langManager.get("PlayAs"));
                var0.append(" ");
                var0.append(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivName());
                var0.append("?");
                var2_47.setText(var0.toString());
                break;
            }
            case 1: {
                CFG.menuManager.getDialogMenu().getMenuElement(3).setText(CFG.langManager.get("ExitTheGame"));
                break;
            }
        }
        CFG.menuManager.getDialogMenu().setVisible(true);
    }

    protected static final void setRender_3(boolean bl) {
        renderUpdate_3.update(bl);
    }

    protected static final void showKeyboard() {
        CFG.showKeyboard(menuManager.getActiveMenuElementID());
    }

    protected static final void showKeyboard(int n) {
        CFG.showKeyboard(menuManager.getActiveSliderMenuID(), n);
    }

    protected static final void showKeyboard(int n, int n2) {
        if (Keyboard.colorPickerMode || Keyboard.commandsMode) {
            Keyboard.colorPickerMode = false;
            Keyboard.commandsMode = false;
        }
        CFG.updateKeyboard_Actions();
        if (Keyboard.numbers) {
            Keyboard.numbers = false;
            menuManager.getKeyboard().actionClose();
        }
        menuManager.setKeyboardActiveSliderMenuID(n);
        menuManager.setKeyboardActiveMenuElementID(n2);
        keyboardMessage = menuManager.getActiveMenu().get(menuManager.getKeyboardActiveSliderMenuID()).getMenuElement(menuManager.getKeyboardActiveMenuElementID()).getText();
        menuManager.getKeyboard().setVisible(true);
    }

    protected static final void showKeyboard_ColorPickerRGB(String string2) {
        if (!Keyboard.colorPickerMode) {
            Keyboard.colorPickerMode = true;
            Keyboard.commandsMode = false;
        }
        CFG.updateKeyboard_Actions();
        Keyboard.numbers = true;
        menuManager.getKeyboard().actionClose();
        keyboardMessage = string2;
        menuManager.getKeyboard().setVisible(true);
    }

    protected static final void showKeyboard_Commands() {
        if (!Keyboard.commandsMode) {
            Keyboard.commandsMode = true;
        }
        CFG.updateKeyboard_Actions();
        MenuManager menuManager = CFG.menuManager;
        menuManager.setKeyboardActiveMenuElementID(menuManager.getActiveMenuElementID());
        keyboardMessage = "";
        CFG.menuManager.getKeyboard().setVisible(true);
    }

    protected static final void updateActiveCivInfo_CreateNewGame() {
        int n;
        int n2;
        int n3;
        Object object = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(1);
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(game.getCiv(activeCivInfo).getCivName());
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        object2 = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(0);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(game.getCiv(activeCivInfo).getRankPosition());
        ((MenuElement)object2).setText(((StringBuilder)object).toString());
        menuManager.getCreate_NewGame_Civ_Info().getMenuElement(3).setCurrent(game.getCiv(activeCivInfo).getNumOfProvinces());
        object2 = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4);
        boolean bl = CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData != null && CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getName().length() > 0;
        ((MenuElement)object2).setVisible(bl);
        if (menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).getVisible()) {
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).setText(CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getName());
        }
        if (menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).getVisible()) {
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(3).setHeight(PADDING * 2 + TEXT_HEIGHT);
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).setHeight(PADDING * 2 + TEXT_HEIGHT);
            n3 = menuManager.getCreate_NewGame_Civ_Info().getHeight();
            n2 = TEXT_HEIGHT;
            n2 = Math.min(n3 - (int)((float)n2 + (float)n2 * 0.8f * 2.0f + (float)(PADDING * 2)), menuManager.getCreate_NewGame_Civ_Info().getMenuElement(2).getPosY() * 2);
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(1).setPosY(n2 / 2);
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).setPosY(menuManager.getCreate_NewGame_Civ_Info().getMenuElement(1).getPosY() + TEXT_HEIGHT + PADDING);
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(3).setPosY((int)((float)menuManager.getCreate_NewGame_Civ_Info().getMenuElement(4).getPosY() + (float)TEXT_HEIGHT * 0.8f + (float)PADDING));
        } else {
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(3).setHeight(PADDING * 4 + TEXT_HEIGHT);
            object2 = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(1);
            n = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(2).getPosY();
            n2 = menuManager.getCreate_NewGame_Civ_Info().getMenuElement(2).getHeight() / 2;
            n3 = TEXT_HEIGHT;
            ((MenuElement)object2).setPosY(n + n2 - (int)(((float)n3 + (float)n3 * 0.8f + (float)(PADDING * 2)) / 2.0f));
            menuManager.getCreate_NewGame_Civ_Info().getMenuElement(3).setPosY(menuManager.getCreate_NewGame_Civ_Info().getMenuElement(1).getPosY() + TEXT_HEIGHT + PADDING);
        }
        object = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(1);
        Object object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(game.getCiv(activeCivInfo).countPopulation());
        ((StringBuilder)object3).append(CFG.getNumberWithSpaces(((StringBuilder)object2).toString()));
        ((MenuElement)object).setText(((StringBuilder)object3).toString());
        try {
            object3 = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(3);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            object2 = game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCitiesSize() > 0 ? game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCity(0).getCityName() : game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getName();
            ((StringBuilder)object).append((String)object2);
            ((MenuElement)object3).setText(((StringBuilder)object).toString());
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(3).setText(langManager.get("NoData"));
        }
        n3 = game.getCiv(activeCivInfo).getProvinceID(0);
        n = 1;
        while (true) {
            if (n >= game.getCiv(activeCivInfo).getNumOfProvinces()) break;
            n2 = n3;
            if (game.getProvince(n3).getPopulationData().getPopulation() < game.getProvince(game.getCiv(activeCivInfo).getProvinceID(n)).getPopulationData().getPopulation()) {
                n2 = game.getCiv(activeCivInfo).getProvinceID(n);
            }
            ++n;
            n3 = n2;
            continue;
            break;
        }
        try {
            object = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(5);
            object2 = game.getProvince(n3).getCitiesSize() > 0 ? game.getProvince(n3).getCity(0).getCityName() : game.getProvince(n3).getName();
            ((MenuElement)object).setText((String)object2);
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(5).setCurrent(n3);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(5).setText(langManager.get("NoData"));
        }
        object = new ArrayList();
        object2 = new ArrayList();
        for (n2 = 0; n2 < game.getCiv(activeCivInfo).getNumOfProvinces(); ++n2) {
            for (n3 = 0; n3 < ((Game)(object3 = game)).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n2)).getPopulationData().getNationalitiesSize(); ++n3) {
                block24: {
                    for (n = 0; n < object.size(); ++n) {
                        int n4 = (Integer)object.get(n);
                        if (n4 != ((Game)(object3 = game)).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n2)).getPopulationData().getCivID(n3)) continue;
                        n4 = (Integer)object2.get(n);
                        object3 = game;
                        object2.set(n, n4 + ((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n2)).getPopulationData().getPopulationID(n3));
                        n = 0;
                        break block24;
                    }
                    n = 1;
                }
                if (n == 0) continue;
                object3 = game;
                object.add(((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n2)).getPopulationData().getCivID(n3));
                object3 = game;
                object2.add(((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n2)).getPopulationData().getPopulationID(n3));
            }
        }
        if (object.size() == 0) {
            object.add(activeCivInfo);
            object2.add(1);
        }
        bl = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(6).getIsInView();
        menuManager.getCreate_NewGame_Civ_Info_Stats().setMenuElement(6, new Graph_Circle(menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(6).getPosX(), menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(6).getPosY(), (List)object2, (List)object, null){

            @Override
            protected void buildElementHover() {
                this.menuElementHover = game.getHover_PopulationOfCiv(CFG.getActiveCivInfo());
            }
        });
        menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(6).setIsInView(bl);
        object = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(8);
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append((float)((int)(game.getCiv(activeCivInfo).getTechnologyLevel() * 100.0f)) / 100.0f);
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        object = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(10);
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(game.getCiv(activeCivInfo).countEconomy());
        ((StringBuilder)object2).append(CFG.getNumberWithSpaces(((StringBuilder)object3).toString()));
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        new Random();
        menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(12).setCurrent(CFG.getCivDifficulty(activeCivInfo));
        menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(13).setCurrent(game.getCiv(activeCivInfo).getHappiness());
        menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setCurrent(game.getCiv(activeCivInfo).getIdeologyID());
        if (game.getCiv(activeCivInfo).getIsPartOfHolyRomanEmpire()) {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setCurrent(-1);
            if (holyRomanEmpire_Manager.getHRE().getIsEmperor(activeCivInfo)) {
                menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setText(langManager.get("Emperor"));
            } else if (holyRomanEmpire_Manager.getHRE().getIsElector(activeCivInfo)) {
                menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setText(langManager.get("Elector"));
            } else {
                menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setText(langManager.get("Prince"));
            }
        } else {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14).setCurrent(game.getCiv(activeCivInfo).getIdeologyID());
            object2 = menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(14);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(ideologiesManager.getIdeology(game.getCiv(activeCivInfo).getIdeologyID()).getName());
            ((MenuElement)object2).setText(((StringBuilder)object).toString());
        }
        menuManager.rebuildCreate_NewGame_Civ_Info_Diplomacy();
        if (activeCivLeader != null) {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(0).setVisible(false);
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(2).setVisible(false);
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(4).setVisible(false);
        } else {
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(0).setVisible(true);
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(2).setVisible(true);
            menuManager.getCreate_NewGame_Civ_Info_Stats().getMenuElement(4).setVisible(true);
        }
    }

    protected static final void updateActiveCivInfo_InGame() {
        int n;
        int n2;
        int n3;
        Object object = menuManager.getInGame_CivInfo().getMenuElement(1);
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(game.getCiv(activeCivInfo).getCivName());
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        object = menuManager.getInGame_CivInfo().getMenuElement(0);
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(game.getCiv(activeCivInfo).getRankPosition());
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        menuManager.getInGame_CivInfo().getMenuElement(3).setCurrent(game.getCiv(activeCivInfo).getNumOfProvinces());
        object = menuManager.getInGame_CivInfo().getMenuElement(4);
        boolean bl = CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData != null && CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getName().length() > 0;
        ((MenuElement)object).setVisible(bl);
        if (menuManager.getInGame_CivInfo().getMenuElement(4).getVisible()) {
            menuManager.getInGame_CivInfo().getMenuElement(4).setText(CFG.game.getCiv((int)CFG.activeCivInfo).civGameData.leaderData.getName());
        }
        if (menuManager.getInGame_CivInfo().getMenuElement(4).getVisible()) {
            menuManager.getInGame_CivInfo().getMenuElement(3).setHeight(PADDING * 2 + TEXT_HEIGHT);
            menuManager.getInGame_CivInfo().getMenuElement(4).setHeight(PADDING * 2 + TEXT_HEIGHT);
            n3 = menuManager.getInGame_CivInfo().getHeight();
            n2 = TEXT_HEIGHT;
            n3 = Math.min(n3 - (int)((float)n2 + (float)n2 * 0.8f * 2.0f + (float)(PADDING * 2)), menuManager.getInGame_CivInfo().getMenuElement(2).getPosY() * 2);
            menuManager.getInGame_CivInfo().getMenuElement(1).setPosY(n3 / 2);
            menuManager.getInGame_CivInfo().getMenuElement(4).setPosY(menuManager.getInGame_CivInfo().getMenuElement(1).getPosY() + TEXT_HEIGHT + PADDING);
            menuManager.getInGame_CivInfo().getMenuElement(3).setPosY((int)((float)menuManager.getInGame_CivInfo().getMenuElement(4).getPosY() + (float)TEXT_HEIGHT * 0.8f + (float)PADDING));
        } else {
            menuManager.getInGame_CivInfo().getMenuElement(3).setHeight(PADDING * 4 + TEXT_HEIGHT);
            object = menuManager.getInGame_CivInfo().getMenuElement(1);
            n2 = menuManager.getInGame_CivInfo().getMenuElement(2).getPosY();
            n = menuManager.getInGame_CivInfo().getMenuElement(2).getHeight() / 2;
            n3 = TEXT_HEIGHT;
            ((MenuElement)object).setPosY(n2 + n - (int)(((float)n3 + (float)n3 * 0.8f + (float)(PADDING * 2)) / 2.0f));
            menuManager.getInGame_CivInfo().getMenuElement(3).setPosY(menuManager.getInGame_CivInfo().getMenuElement(1).getPosY() + TEXT_HEIGHT + PADDING);
        }
        Object object3 = menuManager.getInGame_CivInfo_Stats().getMenuElement(1);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(game.getCiv(activeCivInfo).countPopulation());
        ((StringBuilder)object).append(CFG.getNumberWithSpaces(((StringBuilder)object2).toString()));
        ((MenuElement)object3).setText(((StringBuilder)object).toString());
        try {
            if (FOG_OF_WAR == 2) {
                if (game.getPlayer(PLAYER_TURNID).getMetProvince(game.getCiv(activeCivInfo).getCapitalProvinceID())) {
                    object3 = menuManager.getInGame_CivInfo_Stats().getMenuElement(3);
                    object2 = new StringBuilder();
                    ((StringBuilder)object2).append("");
                    object = game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCitiesSize() > 0 ? game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCity(0).getCityName() : game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getName();
                    ((StringBuilder)object2).append((String)object);
                    ((MenuElement)object3).setText(((StringBuilder)object2).toString());
                } else {
                    menuManager.getInGame_CivInfo_Stats().getMenuElement(3).setText(langManager.get("NoData"));
                    menuManager.getInGame_CivInfo_Stats().getMenuElement(3).setCurrent(-1);
                }
            } else {
                object3 = menuManager.getInGame_CivInfo_Stats().getMenuElement(3);
                object2 = new StringBuilder();
                ((StringBuilder)object2).append("");
                object = game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCitiesSize() > 0 ? game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getCity(0).getCityName() : game.getProvince(game.getCiv(activeCivInfo).getCapitalProvinceID()).getName();
                ((StringBuilder)object2).append((String)object);
                ((MenuElement)object3).setText(((StringBuilder)object2).toString());
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(3).setText(langManager.get("NoData"));
            menuManager.getInGame_CivInfo_Stats().getMenuElement(3).setCurrent(-1);
        }
        n2 = game.getCiv(activeCivInfo).getProvinceID(0);
        n = 1;
        while (true) {
            if (n >= game.getCiv(activeCivInfo).getNumOfProvinces()) break;
            n3 = n2;
            if (game.getProvince(n2).getPopulationData().getPopulation() < game.getProvince(game.getCiv(activeCivInfo).getProvinceID(n)).getPopulationData().getPopulation()) {
                n3 = game.getCiv(activeCivInfo).getProvinceID(n);
            }
            ++n;
            n2 = n3;
            continue;
            break;
        }
        try {
            if (FOG_OF_WAR == 2) {
                if (game.getPlayer(PLAYER_TURNID).getMetProvince(n2)) {
                    object2 = menuManager.getInGame_CivInfo_Stats().getMenuElement(5);
                    object = game.getProvince(n2).getCitiesSize() > 0 ? game.getProvince(n2).getCity(0).getCityName() : game.getProvince(n2).getName();
                    ((MenuElement)object2).setText((String)object);
                    menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setCurrent(n2);
                } else {
                    menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setText(langManager.get("NoData"));
                    menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setCurrent(-1);
                }
            } else {
                object2 = menuManager.getInGame_CivInfo_Stats().getMenuElement(5);
                object = game.getProvince(n2).getCitiesSize() > 0 ? game.getProvince(n2).getCity(0).getCityName() : game.getProvince(n2).getName();
                ((MenuElement)object2).setText((String)object);
                menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setCurrent(n2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setText(langManager.get("NoData"));
            menuManager.getInGame_CivInfo_Stats().getMenuElement(5).setCurrent(-1);
        }
        object = new ArrayList();
        object2 = new ArrayList();
        for (n3 = 0; n3 < game.getCiv(activeCivInfo).getNumOfProvinces(); ++n3) {
            for (n2 = 0; n2 < ((Game)(object3 = game)).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n3)).getPopulationData().getNationalitiesSize(); ++n2) {
                block33: {
                    for (n = 0; n < object.size(); ++n) {
                        int n4 = (Integer)object.get(n);
                        if (n4 != ((Game)(object3 = game)).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n3)).getPopulationData().getCivID(n2)) continue;
                        n4 = (Integer)object2.get(n);
                        object3 = game;
                        object2.set(n, n4 + ((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n3)).getPopulationData().getPopulationID(n2));
                        n = 0;
                        break block33;
                    }
                    n = 1;
                }
                if (n == 0) continue;
                object3 = game;
                object.add(((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n3)).getPopulationData().getCivID(n2));
                object3 = game;
                object2.add(((Game)object3).getProvince(((Game)object3).getCiv(activeCivInfo).getProvinceID(n3)).getPopulationData().getPopulationID(n2));
            }
        }
        if (object.size() == 0) {
            object.add(activeCivInfo);
            object2.add(1);
        }
        bl = menuManager.getInGame_CivInfo_Stats().getMenuElement(6).getIsInView();
        menuManager.getInGame_CivInfo_Stats().setMenuElement(6, new Graph_Circle(menuManager.getInGame_CivInfo_Stats().getMenuElement(6).getPosX(), menuManager.getInGame_CivInfo_Stats().getMenuElement(6).getPosY(), (List)object2, (List)object, null){

            @Override
            protected void buildElementHover() {
                this.menuElementHover = game.getHover_PopulationOfCiv(CFG.getActiveCivInfo());
            }
        });
        menuManager.getInGame_CivInfo_Stats().getMenuElement(6).setIsInView(bl);
        object2 = menuManager.getInGame_CivInfo_Stats().getMenuElement(8);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append((float)((int)(game.getCiv(activeCivInfo).getTechnologyLevel() * 100.0f)) / 100.0f);
        ((MenuElement)object2).setText(((StringBuilder)object).toString());
        object2 = menuManager.getInGame_CivInfo_Stats().getMenuElement(10);
        object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(game.getCiv(activeCivInfo).countEconomy());
        ((StringBuilder)object3).append(CFG.getNumberWithSpaces(((StringBuilder)object).toString()));
        ((MenuElement)object2).setText(((StringBuilder)object3).toString());
        menuManager.getInGame_CivInfo_Stats().getMenuElement(11).setCurrent(game.getCiv(activeCivInfo).getHappiness());
        menuManager.getInGame_CivInfo_Stats().getMenuElement(13).setCurrent((int)(game.getCiv(activeCivInfo).getStability() * 100.0f));
        if (game.getCiv(activeCivInfo).getIsPartOfHolyRomanEmpire()) {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(12).setCurrent(-1);
            if (holyRomanEmpire_Manager.getHRE().getIsEmperor(activeCivInfo)) {
                menuManager.getInGame_CivInfo_Stats().getMenuElement(12).setText(langManager.get("Emperor"));
            } else if (holyRomanEmpire_Manager.getHRE().getIsElector(activeCivInfo)) {
                menuManager.getInGame_CivInfo_Stats().getMenuElement(12).setText(langManager.get("Elector"));
            } else {
                menuManager.getInGame_CivInfo_Stats().getMenuElement(12).setText(langManager.get("Prince"));
            }
        } else {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(12).setCurrent(game.getCiv(activeCivInfo).getIdeologyID());
            object2 = menuManager.getInGame_CivInfo_Stats().getMenuElement(12);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(ideologiesManager.getIdeology(game.getCiv(activeCivInfo).getIdeologyID()).getName());
            ((MenuElement)object2).setText(((StringBuilder)object).toString());
        }
        menuManager.rebuildInGame_Civ_Info_Diplomacy();
        object = menuManager;
        bl = game.getPlayer(PLAYER_TURNID).getCivID() == activeCivInfo;
        ((MenuManager)object).setVisible_InGame_CivInfo_Decisions(bl);
        if (menuManager.getVisible_InGame_CivInfo_Stats_Opinions()) {
            menuManager.rebuildInGame_Civ_Info_Opinions();
        }
        if (activeCivLeader != null) {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(0).setVisible(false);
            menuManager.getInGame_CivInfo_Stats().getMenuElement(2).setVisible(false);
            menuManager.getInGame_CivInfo_Stats().getMenuElement(4).setVisible(false);
        } else {
            menuManager.getInGame_CivInfo_Stats().getMenuElement(0).setVisible(true);
            menuManager.getInGame_CivInfo_Stats().getMenuElement(2).setVisible(true);
            menuManager.getInGame_CivInfo_Stats().getMenuElement(4).setVisible(true);
        }
    }

    protected static void updateColorDashed() {
        try {
            Color color2;
            Color color3;
            Color color4;
            COLOR_PROVINCE_DASHED = map.getMapScale().getCurrentScale() > 1.0f ? (map.getMapScale().getCurrentScale() < 4.0f ? (color4 = new Color(CFG.COLOR_PROVINCE_DASHED.r, CFG.COLOR_PROVINCE_DASHED.g, CFG.COLOR_PROVINCE_DASHED.b, 0.65f - map.getMapScale().getCurrentScale() / 4.0f * 0.1f)) : (color3 = new Color(CFG.COLOR_PROVINCE_DASHED.r, CFG.COLOR_PROVINCE_DASHED.g, CFG.COLOR_PROVINCE_DASHED.b, 0.54999995f))) : (color2 = new Color(CFG.COLOR_PROVINCE_DASHED.r, CFG.COLOR_PROVINCE_DASHED.g, CFG.COLOR_PROVINCE_DASHED.b, 0.65f));
        }
        catch (NullPointerException nullPointerException) {
            COLOR_PROVINCE_DASHED = new Color(CFG.COLOR_PROVINCE_DASHED.r, CFG.COLOR_PROVINCE_DASHED.g, CFG.COLOR_PROVINCE_DASHED.b, 0.65f);
        }
    }

    protected static final void updateCreateAVassal_CivInfo() {
        int n;
        int n2;
        Object object = CFG.createVassal_Data.sCivTag;
        int n3 = 0;
        if (object != null) {
            menuManager.getCreateAVassal_Info().getMenuElement(0).setText(langManager.getCiv(CFG.createVassal_Data.sCivTag));
        }
        menuManager.getCreateAVassal_Info().getMenuElement(2).setCurrent(game.getSelectedProvinces().getProvincesSize());
        int n4 = 0;
        for (n2 = 0; n2 < game.getSelectedProvinces().getProvincesSize(); ++n2) {
            object = game;
            n4 += ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n2)).getPopulationData().getPopulation();
        }
        object = menuManager.getCreateAVassal_Stats().getMenuElement(1);
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        Object object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(n4);
        ((StringBuilder)object2).append(CFG.getNumberWithSpaces(((StringBuilder)object3).toString()));
        ((MenuElement)object).setText(((StringBuilder)object2).toString());
        if (CFG.createVassal_Data.iCapitalProvinceID >= 0) {
            object3 = menuManager.getCreateAVassal_Stats().getMenuElement(3);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("");
            object = game.getProvince(CFG.createVassal_Data.iCapitalProvinceID).getCitiesSize() > 0 ? game.getProvince(CFG.createVassal_Data.iCapitalProvinceID).getCity(0).getCityName() : game.getProvince(CFG.createVassal_Data.iCapitalProvinceID).getName();
            ((StringBuilder)object2).append((String)object);
            ((MenuElement)object3).setText(((StringBuilder)object2).toString());
        } else {
            menuManager.getCreateAVassal_Stats().getMenuElement(3).setText("-");
        }
        if (game.getSelectedProvinces().getProvincesSize() > 0) {
            n2 = 1;
            n4 = 0;
            while (true) {
                n = n4;
                if (n2 < game.getSelectedProvinces().getProvincesSize()) {
                    object = game;
                    n = ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n4)).getPopulationData().getPopulation();
                    if (n < ((Game)(object = game)).getProvince(((Game)object).getSelectedProvinces().getProvince(n2)).getPopulationData().getPopulation()) {
                        n4 = n2;
                    }
                    ++n2;
                    continue;
                }
                break;
            }
        } else {
            n = -1;
        }
        if (n >= 0) {
            object3 = menuManager.getCreateAVassal_Stats().getMenuElement(5);
            object = game;
            if (((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n)).getCitiesSize() > 0) {
                object = game;
                object = ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n)).getCity(0).getCityName();
            } else {
                object = game;
                object = ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n)).getName();
            }
            ((MenuElement)object3).setText((String)object);
            menuManager.getCreateAVassal_Stats().getMenuElement(5).setCurrent(game.getSelectedProvinces().getProvince(n));
        } else {
            menuManager.getCreateAVassal_Stats().getMenuElement(5).setText("-");
            menuManager.getCreateAVassal_Stats().getMenuElement(5).setCurrent(-1);
        }
        object3 = new ArrayList<Integer>();
        object = new ArrayList();
        if (game.getSelectedProvinces().getProvincesSize() > 0) {
            for (n2 = 0; n2 < game.getSelectedProvinces().getProvincesSize(); ++n2) {
                for (n4 = 0; n4 < ((Game)(object2 = game)).getProvince(((Game)object2).getSelectedProvinces().getProvince(n2)).getPopulationData().getNationalitiesSize(); ++n4) {
                    block24: {
                        for (n = 0; n < object3.size(); ++n) {
                            int n5 = (Integer)object3.get(n);
                            if (n5 != ((Game)(object2 = game)).getProvince(((Game)object2).getSelectedProvinces().getProvince(n2)).getPopulationData().getCivID(n4)) continue;
                            n5 = (Integer)object.get(n);
                            object2 = game;
                            object.set(n, n5 + ((Game)object2).getProvince(((Game)object2).getSelectedProvinces().getProvince(n2)).getPopulationData().getPopulationID(n4));
                            n = 0;
                            break block24;
                        }
                        n = 1;
                    }
                    if (n == 0) continue;
                    object2 = game;
                    object3.add(((Game)object2).getProvince(((Game)object2).getSelectedProvinces().getProvince(n2)).getPopulationData().getCivID(n4));
                    object2 = game;
                    object.add(((Game)object2).getProvince(((Game)object2).getSelectedProvinces().getProvince(n2)).getPopulationData().getPopulationID(n4));
                }
            }
        } else {
            object3.add(game.getPlayer(PLAYER_TURNID).getCivID());
            object.add(1);
        }
        boolean bl = menuManager.getCreateAVassal_Stats().getMenuElement(6).getIsInView();
        menuManager.getCreateAVassal_Stats().setMenuElement(6, new Graph_Circle(menuManager.getCreateAVassal_Stats().getMenuElement(6).getPosX(), menuManager.getCreateAVassal_Stats().getMenuElement(6).getPosY(), (List)object, (List)object3, null){

            @Override
            protected void buildElementHover() {
                this.menuElementHover = game.getHover_PopulationOfCiv_CreateAVassal();
            }
        });
        menuManager.getCreateAVassal_Stats().getMenuElement(6).setIsInView(bl);
        object3 = menuManager.getCreateAVassal_Stats().getMenuElement(8);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        object2 = game;
        ((StringBuilder)object).append((float)((int)(((Game)object2).getCiv(((Game)object2).getPlayer(PLAYER_TURNID).getCivID()).getTechnologyLevel() * 0.72f * 100.0f)) / 100.0f);
        ((MenuElement)object3).setText(((StringBuilder)object).toString());
        n2 = 0;
        for (n4 = 0; n4 < game.getSelectedProvinces().getProvincesSize(); ++n4) {
            object = game;
            n2 += ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvince(n4)).getEconomy();
        }
        object = menuManager.getCreateAVassal_Stats().getMenuElement(10);
        object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(n2);
        ((StringBuilder)object3).append(CFG.getNumberWithSpaces(((StringBuilder)object2).toString()));
        ((MenuElement)object).setText(((StringBuilder)object3).toString());
        if (game.getSelectedProvinces().getProvincesSize() > 0) {
            float f = 0.0f;
            for (n2 = n3; n2 < game.getSelectedProvinces().getProvincesSize(); ++n2) {
                object = game;
                f += ((Game)object).getProvince(((Game)object).getSelectedProvinces().getProvincesSize()).getHappiness() * 100.0f;
            }
            menuManager.getCreateAVassal_Stats().getMenuElement(11).setCurrent((int)(f / (float)game.getSelectedProvinces().getProvincesSize()));
        } else {
            menuManager.getCreateAVassal_Stats().getMenuElement(11).setCurrent(0);
        }
        if (CFG.createVassal_Data.sCivTag != null) {
            menuManager.getCreateAVassal_Stats().getMenuElement(12).setCurrent(ideologiesManager.getIdeologyID(CFG.createVassal_Data.sCivTag));
            object3 = menuManager.getCreateAVassal_Stats().getMenuElement(12);
            object = ideologiesManager;
            ((MenuElement)object3).setText(((Ideologies_Manager)object).getIdeology(((Ideologies_Manager)object).getIdeologyID(CFG.createVassal_Data.sCivTag)).getName());
        } else {
            object = menuManager.getCreateAVassal_Stats().getMenuElement(12);
            object3 = game;
            ((MenuElement)object).setCurrent(((Game)object3).getCiv(((Game)object3).getPlayer(PLAYER_TURNID).getCivID()).getIdeologyID());
            object2 = menuManager.getCreateAVassal_Stats().getMenuElement(12);
            object3 = ideologiesManager;
            object = game;
            ((MenuElement)object2).setText(((Ideologies_Manager)object3).getIdeology(((Game)object).getCiv(((Game)object).getPlayer(PLAYER_TURNID).getCivID()).getIdeologyID()).getName());
        }
    }

    protected static final void updateCreateScenario_Civilizations() {
        if (game.getActiveProvinceID() >= 0) {
            Game game = CFG.game;
            if (!game.getProvince(game.getActiveProvinceID()).getSeaProvince() && (game = CFG.game).getProvince(game.getActiveProvinceID()).getWasteland() < 0) {
                game = CFG.game;
                if (game.getProvince(game.getActiveProvinceID()).getCivID() > 0) {
                    game = CFG.game;
                    if (game.getProvince(game.getActiveProvinceID()).getIsCapital()) {
                        menuManager.getCreateScenario_Civilizations().getMenuElement(3).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(3).setClickable(false);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(4).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(4).setClickable(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(5).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(5).setClickable(false);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(6).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(6).setClickable(true);
                        menuManager.setVisible_CreateScenario_Civilizations_Suggest(false);
                        menuManager.rebuildCreateScenario_Civilizations_Ideologies();
                    } else {
                        menuManager.getCreateScenario_Civilizations().getMenuElement(3).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(3).setClickable(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(4).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(4).setClickable(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(5).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(5).setClickable(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(6).setVisible(true);
                        menuManager.getCreateScenario_Civilizations().getMenuElement(6).setClickable(true);
                        menuManager.setVisible_CreateScenario_Civilizations_Ideologies(false);
                        menuManager.rebuildCreateScenario_Civilizations_Suggest();
                    }
                } else {
                    menuManager.getCreateScenario_Civilizations().getMenuElement(3).setVisible(true);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(3).setClickable(true);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(4).setVisible(true);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(4).setClickable(false);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(5).setVisible(true);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(5).setClickable(false);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(6).setVisible(true);
                    menuManager.getCreateScenario_Civilizations().getMenuElement(6).setClickable(false);
                    menuManager.setVisible_CreateScenario_Civilizations_Ideologies(false);
                    menuManager.rebuildCreateScenario_Civilizations_Suggest();
                }
            } else {
                menuManager.getCreateScenario_Civilizations().getMenuElement(3).setClickable(false);
                menuManager.getCreateScenario_Civilizations().getMenuElement(4).setClickable(false);
                menuManager.getCreateScenario_Civilizations().getMenuElement(5).setClickable(false);
                menuManager.getCreateScenario_Civilizations().getMenuElement(6).setClickable(false);
                menuManager.setVisible_CreateScenario_Civilizations_Suggest(false);
                menuManager.setVisible_CreateScenario_Civilizations_Ideologies(false);
            }
        } else {
            menuManager.getCreateScenario_Civilizations().getMenuElement(3).setVisible(false);
            menuManager.getCreateScenario_Civilizations().getMenuElement(4).setVisible(false);
            menuManager.getCreateScenario_Civilizations().getMenuElement(5).setVisible(false);
            menuManager.getCreateScenario_Civilizations().getMenuElement(6).setVisible(false);
            menuManager.setVisible_CreateScenario_Civilizations_Suggest(false);
            menuManager.setVisible_CreateScenario_Civilizations_Ideologies(false);
        }
    }

    protected static final void updateKeyboard_Actions() {
        if (Keyboard.colorPickerMode) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    ColorPicker_AoC colorPicker_AoC = menuManager.getColorPicker();
                    int n = Keyboard.activeColor_RGB_ID == 0 ? CFG.getKeyboardMessage_RGB() : (int)(CFG.menuManager.getColorPicker().getActiveColor().r * 255.0f);
                    int n2 = Keyboard.activeColor_RGB_ID == 1 ? CFG.getKeyboardMessage_RGB() : (int)(CFG.menuManager.getColorPicker().getActiveColor().g * 255.0f);
                    int n3 = Keyboard.activeColor_RGB_ID == 2 ? CFG.getKeyboardMessage_RGB() : (int)(CFG.menuManager.getColorPicker().getActiveColor().b * 255.0f);
                    colorPicker_AoC.RGBtoHSV(n, n2, n3);
                    menuManager.getColorPicker().getColorPickerAction().update();
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 3 && (keyboardMessage = keyboardMessage.substring(0, keyboardMessage.length() - 1)).length() == 3) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(keyboardMessage);
                        stringBuilder.append(0);
                        keyboardMessage = stringBuilder.toString();
                    }
                    keyboardSave.action();
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void action(String string2) {
                    try {
                        StringBuilder stringBuilder;
                        if (string2.charAt(0) < '0') return;
                        if (string2.charAt(0) > '9') return;
                        if (keyboardMessage.length() > 2 && keyboardMessage.charAt(3) == '0') {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(keyboardMessage.substring(0, 3));
                            stringBuilder.append(string2);
                            keyboardMessage = stringBuilder.toString();
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(keyboardMessage);
                            stringBuilder.append(string2);
                            keyboardMessage = stringBuilder.toString();
                        }
                        try {
                            if (keyboardMessage.length() > 2 && Integer.parseInt(keyboardMessage.substring(3, keyboardMessage.length())) > 255) {
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(keyboardMessage.substring(0, 3));
                                stringBuilder.append("255");
                                keyboardMessage = stringBuilder.toString();
                            }
                        }
                        catch (IllegalArgumentException illegalArgumentException) {}
                        keyboardSave.action();
                        return;
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(keyboardMessage);
                        stringBuilder.append(string2);
                        keyboardMessage = stringBuilder.toString();
                    }
                }
            };
        } else if (Keyboard.commandsMode) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    Commands.execute(keyboardMessage);
                    keyboardMessage = "";
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "";
                }
            };
            CFG.updateKeyboard_DefaultWrite();
        } else if (Keyboard.changeCivilizationNameMode > 0 && menuManager.getInGameView()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        game.getCiv(Keyboard.changeCivilizationNameMode).setCivName(keyboardMessage);
                        game.setActiveProvinceID(game.getActiveProvinceID());
                        for (int i = 0; i < game.getCiv(Keyboard.changeCivilizationNameMode).getCivRegionsSize(); ++i) {
                            game.getCiv(Keyboard.changeCivilizationNameMode).getCivRegion(i).buildScaleOfText();
                        }
                        if (menuManager.getInGameView()) {
                            CFG.updateActiveCivInfo_InGame();
                        } else if (menuManager.getInCreateNewGame()) {
                            CFG.updateActiveCivInfo_CreateNewGame();
                        }
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "";
                }
            };
            CFG.updateKeyboard_DefaultWrite();
        } else if (Keyboard.changeProvinceNameMode > 0 && menuManager.getInGameView()) {
            keyboardSave = new Keyboard_Action(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void action() {
                    if (keyboardMessage.length() <= 0) return;
                    game.getProvince(Keyboard.changeProvinceNameMode).setName(keyboardMessage);
                    game.setActiveProvinceID(Keyboard.changeProvinceNameMode);
                    try {
                        if (Keyboard.changeCityNameIDToo < 0) return;
                        game.getProvince(Keyboard.changeProvinceNameMode).getCity(Keyboard.changeCityNameIDToo).setCityName(keyboardMessage);
                        return;
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        return;
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "";
                }
            };
            CFG.updateKeyboard_DefaultWrite();
        } else if (menuManager.getInCreateScenario_Civilizations_Select()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Civilizations_SelectList();
                        menuManager.getCreateScenario_Civilizations_SelectAlphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateScenario_Cores_AddCore()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCore_List();
                        menuManager.getCreateScenario_Cores_AddCore_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateScenario_Cores_AddCiv()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Cores_AddCiv_List();
                        menuManager.getCreateScenario_Cores_AddCiv_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInUnions_AddCiv()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildUnions_AddCiv_List();
                        menuManager.getUnions_AddCiv_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateVassal_Select()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateVassal_SelectList();
                        menuManager.getCreateVassal_SelectAlphabet();
                    }
                }
            };
        } else if (menuManager.getInMapEditor_FormableCivs_SelectFormable()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectList();
                        menuManager.getMapEditor_FormableCivs_SelectAlphabet();
                    }
                }
            };
        } else if (menuManager.getInGameCivs()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildGameCivs_SelectList();
                        menuManager.getGameCivs_SelectAlphabet();
                    }
                }
            };
        } else if (menuManager.getInMapEditor_FormableCivs()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs();
                        menuManager.getMapEditor_FormableCivs_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInLeaders()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeaders();
                        menuManager.getLeaders_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInMapEditor_FormableCivs_SelectClaimant()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildMapEditor_FormableCivs_SelectClaimantList();
                        menuManager.getMapEditor_FormableCivs_SelectClaimantAlphabet();
                    }
                }
            };
        } else if (menuManager.getInLeader_Edit_SelectCivs()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildLeader_Edit_SelectCivs_List();
                        menuManager.getLeaders_SelectCivs_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInRandomGame_Civilizations_Select()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildRandomGame_Civilizations_SelectList();
                        menuManager.getRandomGame_Civilizations_SelectAlphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateScenario_Events_SelectCiv()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_SelectCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateScenario_Events_AddCiv()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_AddCiv_Alphabet();
                    }
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    if ((keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "").length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_AddCiv_Alphabet();
                    }
                }
            };
            keyboardWrite = new Keyboard_Action_Write(){

                @Override
                public void action(String string2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(keyboardMessage);
                    stringBuilder.append(string2);
                    keyboardMessage = stringBuilder.toString();
                    if (keyboardMessage.length() > 0) {
                        sSearch = keyboardMessage;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_AddCiv_Alphabet();
                    } else {
                        sSearch = null;
                        menuManager.rebuildCreateScenario_Events_AddCiv_List();
                        menuManager.getCreateScenario_Events_SelectCiv_Alphabet();
                    }
                }
            };
        } else if (menuManager.getInCreateCity()) {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    menuManager.getActiveMenu().get(menuManager.getKeyboardActiveSliderMenuID()).getMenuElement(menuManager.getKeyboardActiveMenuElementID()).setText(keyboardMessage);
                    editorCity.setCityName(keyboardMessage);
                    menuManager.getCreateCity_UpdateSaveButton();
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "";
                    keyboardSave.action();
                    menuManager.getCreateCity_UpdateSaveButton();
                }
            };
            CFG.updateKeyboard_DefaultWrite();
        } else {
            keyboardSave = new Keyboard_Action(){

                @Override
                public void action() {
                    menuManager.getActiveMenu().get(menuManager.getKeyboardActiveSliderMenuID()).getMenuElement(menuManager.getKeyboardActiveMenuElementID()).setText(keyboardMessage);
                }
            };
            keyboardDelete = new Keyboard_Action(){

                @Override
                public void action() {
                    keyboardMessage = keyboardMessage.length() > 1 ? keyboardMessage.substring(0, keyboardMessage.length() - 1) : "";
                }
            };
            CFG.updateKeyboard_DefaultWrite();
        }
    }

    private static final void updateKeyboard_DefaultWrite() {
        keyboardWrite = new Keyboard_Action_Write(){

            @Override
            public void action(String string2) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(keyboardMessage);
                stringBuilder.append(string2);
                keyboardMessage = stringBuilder.toString();
            }
        };
    }

    protected static final void updateMAX_Army() {
        int n;
        int n2 = 0;
        MAX_PROVINCE_VALUE = 0;
        if (FOG_OF_WAR == 0) {
            for (n = n2; n < game.getProvincesSize(); ++n) {
                if (game.getProvince(n).getWasteland() >= 0 || game.getProvinceArmy(n) <= MAX_PROVINCE_VALUE) continue;
                MAX_PROVINCE_VALUE = game.getProvinceArmy(n);
            }
        } else {
            for (n = 0; n < game.getProvincesSize(); ++n) {
                if (game.getProvince(n).getWasteland() >= 0 || !game.getPlayer(PLAYER_TURNID).getFogOfWar(n) || game.getProvinceArmy(n) <= MAX_PROVINCE_VALUE) continue;
                MAX_PROVINCE_VALUE = game.getProvinceArmy(n);
            }
        }
    }

    protected static final void updateMAX_PROVINCE_VALUE() {
        MAX_PROVINCE_VALUE = 1;
        for (int i = 0; i < game.getProvincesSize(); ++i) {
            if (game.getProvince(i).getSeaProvince() || game.getProvince(i).getWasteland() >= 0 || game.getProvinceValue(i) <= MAX_PROVINCE_VALUE) continue;
            MAX_PROVINCE_VALUE = game.getProvinceValue(i);
        }
    }

    protected static final void updateNumOfAvailableProvinces() {
        iNumOfWastelandProvinces = 0;
        iNumOfAvailableProvinces = 0;
        for (int i = 0; i < game.getProvincesSize(); ++i) {
            if (game.getProvince(i).getSeaProvince()) continue;
            if (game.getProvince(i).getWasteland() >= 0) {
                ++iNumOfWastelandProvinces;
                continue;
            }
            ++iNumOfAvailableProvinces;
        }
        Object object = glyphLayout;
        Object object2 = fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(iNumOfAvailableProvinces);
        ((GlyphLayout)object).setText((BitmapFont)object2, stringBuilder.toString());
        iNumOfAvailableProvincesWidth = (int)CFG.glyphLayout.width;
        object2 = glyphLayout;
        object = fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(iNumOfWastelandProvinces);
        ((GlyphLayout)object2).setText((BitmapFont)object, stringBuilder.toString());
        iNumOfWastelandProvincesWidth = (int)CFG.glyphLayout.width;
    }

    protected static final void updateRender(boolean bl) {
        if (bl) {
            renderUpdate_3 = new RenderUpdate(){

                @Override
                public void update(boolean bl) {
                    RENDER3 = bl;
                    RENDER2 = bl;
                    RENDER = bl;
                }
            };
            CFG.setRender_3(true);
        } else {
            renderUpdate_3 = new RenderUpdate(){

                @Override
                public void update(boolean bl) {
                    RENDER3 = false;
                    RENDER2 = false;
                    RENDER = false;
                }
            };
        }
    }

    protected static final void wikiInormationsLink(String object) {
        try {
            Object object2 = Gdx.files;
            CharSequence charSequence = new StringBuilder();
            charSequence.append("game/civilizations_informations/");
            charSequence.append((String)object);
            charSequence = object2.internal(charSequence.toString()).readString();
            object2 = Gdx.net;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(WWW_WIKI);
            stringBuilder.append((String)charSequence);
            object2.openURI(stringBuilder.toString());
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            try {
                Object object3 = Gdx.files;
                CharSequence charSequence = new StringBuilder();
                charSequence.append("game/civilizations_informations/");
                charSequence.append(ideologiesManager.getRealTag((String)object));
                charSequence = object3.internal(charSequence.toString()).readString();
                object = Gdx.net;
                object3 = new StringBuilder();
                ((StringBuilder)object3).append(WWW_WIKI);
                ((StringBuilder)object3).append((String)charSequence);
                object.openURI(((StringBuilder)object3).toString());
            }
            catch (GdxRuntimeException gdxRuntimeException2) {
                toast.setInView(langManager.get("NoData"));
            }
        }
    }

    protected static class ConfigAlliancesData {
        protected String Age_of_Civilizations;
        protected ArrayList Data_Random_Alliance_Names;

        protected ConfigAlliancesData() {
        }
    }

    protected static class ConfigScenarioInfo {
        protected String Age_of_Civilizations;
        protected ArrayList Data_Scenario_Info;

        protected ConfigScenarioInfo() {
        }
    }

    protected static class Data_Random_Alliance_Names {
        protected boolean Enabled;
        protected String Tag;

        protected Data_Random_Alliance_Names() {
        }
    }

    protected static class Data_Scenario_Info {
        protected int Age;
        protected String Author;
        protected int Civs;
        protected int Day;
        protected int Month;
        protected String Name;
        protected String Wiki;
        protected int Year;

        protected Data_Scenario_Info() {
        }
    }

    public static enum FlagEditorMode {
        PENCIL,
        PAINT_BUCKET;

    }

    static interface Keyboard_Action {
        public void action();
    }

    static interface Keyboard_Action_Write {
        public void action(String var1);
    }

    static interface RenderUpdate {
        public void update(boolean var1);
    }

    public static class TopBox {
        protected int iCircleShift;
        protected int iFlagX;
        protected int iFlagY;
        protected int leftExtraViewPadding;

        protected TopBox() {
        }
    }
}

