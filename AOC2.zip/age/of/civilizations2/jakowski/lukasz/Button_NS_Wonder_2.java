/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Wonder;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_NS_Wonder_2
extends Button {
    protected static final float FONTSIZE = 0.7f;
    protected static final float FONTSIZE2 = 0.65f;
    protected static final float TEXT_COST_SCALE = 0.7f;
    protected static final float TEXT_MOVEMENT_COST_SCALE = 0.7f;
    private int iDeathsTEXTWidth;
    protected int iImageID;
    private int iProvinceID = 0;
    protected int iWonderID;
    protected Color oColor;
    protected boolean row = false;
    private String sDeathsTEXT;
    protected Color textColor;

    protected Button_NS_Wonder_2(Color object, int n, int n2, int n3, int n4, int n5) {
        super.init(CFG.game.getProvince((int)n).getWonder((int)n2).sName, 0, n3, n4, n5, (int)((float)CFG.BUTTON_HEIGHT * 3.5f / 5.0f), true, true, false, false);
        this.iProvinceID = n;
        this.oColor = object;
        this.iWonderID = n2;
        object = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(n) ? (CFG.game.getProvince(n).getName().length() > 0 ? CFG.game.getProvince(n).getName() : CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivName()) : CFG.langManager.get("Undiscovered");
        this.sDeathsTEXT = object;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).sName, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Wonder(this.iProvinceID, this.iWonderID, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(this.oColor.r, this.oColor.g, this.oColor.b, 0.1f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, Button_Diplomacy.iDiploWidth, this.getHeight());
        spriteBatch.setColor(new Color(this.oColor.r, this.oColor.g, this.oColor.b, 0.575f));
        ImageManager.getImage(Images.patt_square).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt_square).getHeight() + n2, Button_Diplomacy.iDiploWidth, this.getHeight(), true, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth - CFG.PADDING * 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.35f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - (int)((float)(CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.getWidth() / 2) * CFG.GUI_SCALE) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.getHeight() * CFG.GUI_SCALE / 2.0f) - CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.getHeight() + n2, (int)((float)CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.getWidth() * CFG.GUI_SCALE), (int)((float)CFG.game.getProvince((int)this.iProvinceID).getWonder((int)this.iWonderID).nImage.getHeight() * CFG.GUI_SCALE));
            if (CFG.game.getProvince(this.iProvinceID).getCivID() >= 0 && CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(this.iProvinceID)) {
                CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.CIV_FLAG_WIDTH - CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            } else {
                ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.CIV_FLAG_WIDTH - CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight(), CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            }
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.CIV_FLAG_WIDTH - CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            spriteBatch.setColor(Color.WHITE);
            CFG.fontMain.getData().setScale(0.7f);
            CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(0.65f);
            CFG.drawTextWithShadow(spriteBatch, this.sDeathsTEXT, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
            CFG.fontMain.getData().setScale(1.0f);
            return;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.525f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }

    protected float getImageScale(int n, float f) {
        return (float)CFG.TEXT_HEIGHT * f / (float)ImageManager.getImage(n).getHeight();
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

