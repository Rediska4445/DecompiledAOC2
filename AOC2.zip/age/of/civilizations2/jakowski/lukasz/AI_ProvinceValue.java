/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_ProvinceValue {
    protected int iProvinceID;
    protected float iValue;

    protected AI_ProvinceValue(int n) {
        this.iProvinceID = n;
        this.iValue = 0.0f;
    }

    protected AI_ProvinceValue(int n, int n2) {
        this.iProvinceID = n;
        this.iValue = n2;
    }
}

