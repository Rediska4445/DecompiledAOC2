/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

class Button_Statistics_Color
extends Button_Statistics {
    protected Color oColor;

    protected Button_Statistics_Color(Color color2, String string2, int n, int n2, int n3, int n4, int n5) {
        super(string2, n, n2, n3, n4, n5);
        this.oColor = color2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Rectangle rectangle = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth(), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors(rectangle);
        spriteBatch.setColor(this.oColor);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)this.iTextHeight * 0.7f));
        spriteBatch.setColor(Color.WHITE);
        super.drawText(spriteBatch, CFG.PADDING + 2 + n, n2, bl);
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }
}

