/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_PrepareForWar
extends Button_Build {
    protected static final float FONTSIZE2 = 0.6f;
    protected int iDateWidth;
    protected int iEconomyWidth;
    protected int iFromCivID;
    protected int iFromCivNameWidth;
    protected int iProvinceNameWidth;
    protected Color oColor = Color.WHITE;
    protected String sDate;
    protected String sEconomy;
    protected String sFromCivName;
    protected String sProvinceName;
    protected int warAgainstCivID;

    protected Button_PrepareForWar(String charSequence, int n, int n2, int n3, int n4, int n5, int n6) {
        super((String)charSequence, Images.diplo_war_preparations, 0, 0, n4, n5, n6, true, false, 0, 0.0f);
        this.warAgainstCivID = n2;
        this.iFromCivID = n;
        this.sFromCivName = CFG.game.getCiv(n).getCivName();
        CFG.glyphLayout.setText(CFG.fontMain, this.sFromCivName);
        this.iFromCivNameWidth = (int)(CFG.glyphLayout.width * 0.8f);
        this.sProvinceName = CFG.game.getCiv(n2).getCivName();
        CFG.glyphLayout.setText(CFG.fontMain, this.sProvinceName);
        this.iProvinceNameWidth = (int)(CFG.glyphLayout.width * 0.7f);
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("PreparationTime"));
        ((StringBuilder)charSequence).append(": ");
        this.sDate = ((StringBuilder)charSequence).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sDate);
        this.iDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.sEconomy = CFG.langManager.get("TurnsX", n3);
        CFG.glyphLayout.setText(CFG.fontMain, this.sEconomy);
        this.iEconomyWidth = (int)(CFG.glyphLayout.width * 0.6f);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        CFG.game.getCiv(this.iFromCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 1.0f)) + n, this.getPosY() + this.getHeight() / 2 - CFG.game.getCiv(this.iFromCivID).getFlag().getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 1.0f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 1.0f)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 1.0f)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 1.0f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.flag_rect).getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 1.0f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 1.0f)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 1.0f)));
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sFromCivName, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - this.iFromCivNameWidth - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 1.0f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f) / 2 + n2, this.getColor(bl));
        CFG.game.getCiv(this.warAgainstCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + this.iProvinceNameWidth + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) / 2 - CFG.PADDING / 2 - CFG.game.getCiv(this.warAgainstCivID).getFlag().getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 0.7f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 0.7f)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 0.7f)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + this.iProvinceNameWidth + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) / 2 - CFG.PADDING / 2 - ImageManager.getImage(Images.flag_rect).getHeight() - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 0.7f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect, 0.7f)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect, 0.7f)));
        ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + this.iEconomyWidth + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 - ImageManager.getImage(Images.time).getHeight() + n2, (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time, 0.6f)), (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time, 0.6f)));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sProvinceName, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sEconomy, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, this.oColor);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

