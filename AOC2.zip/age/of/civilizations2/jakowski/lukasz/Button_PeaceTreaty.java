/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.LanguageManager;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_PeaceTreaty
extends Button {
    private static final float TEXT_SCALE_DATE = 0.7f;
    private static final float TEXT_SCALE_WARSCORE = 0.8f;
    private int iDateWidth;
    private String sDate = "";

    protected Button_PeaceTreaty(String object, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super.init((String)object, -1, n2, n3, n4, n5, bl, true, true, bl2, null);
        n = CFG.game.getWar(n).getWarScore_PeaceTreaty();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        if (n == 0) {
            object = CFG.langManager.get("Balanced");
        } else {
            String string2;
            CharSequence charSequence;
            if (n < 0) {
                object = CFG.langManager;
                charSequence = new StringBuilder();
                charSequence.append(Math.abs(n));
                charSequence.append("%");
                string2 = charSequence.toString();
                charSequence = "XInFavorOfAggressors";
            } else {
                object = CFG.langManager;
                charSequence = new StringBuilder();
                charSequence.append(Math.abs(n));
                charSequence.append("%");
                string2 = charSequence.toString();
                charSequence = "XInFavorOfDefenders";
            }
            object = ((LanguageManager)object).get((String)charSequence, string2);
        }
        stringBuilder.append((String)object);
        this.sDate = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sDate);
        this.iDateWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }

    private final float getImageScale(int n) {
        float f = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.7f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.7f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void buildElementHover() {
        Object object;
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        Object object2 = new ArrayList();
        int n = 0;
        int n2 = 0;
        while (true) {
            if (n2 >= CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.size()) break;
            object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.get((int)n2).iCivID);
            object2.add(object);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.get((int)n2).iCivID).getCivName());
            object2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            object2.clear();
            ++n2;
            continue;
            break;
        }
        object = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_truce, 0, 0);
        object2.add(object);
        object = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object2);
        arrayList.add((MenuElement_Hover_v2_Element2)object);
        object2.clear();
        n2 = n;
        while (true) {
            if (n2 >= CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.size()) break;
            object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.get((int)n2).iCivID);
            object2.add(object);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.get((int)n2).iCivID).getCivName());
            object2.add(object);
            object = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            object2.clear();
            ++n2;
            continue;
            break;
        }
        try {
            this.menuElementHover = object2 = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.275f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        if (bl) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.675f));
        } else if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.8f));
        } else {
            spriteBatch.setColor(CFG.COLOR_GRADIENT_DARK_BLUE);
        }
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.2f));
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        if (this.getCheckboxState()) {
            spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_POSITIVE.r, CFG.COLOR_TEXT_MODIFIER_POSITIVE.g, CFG.COLOR_TEXT_MODIFIER_POSITIVE.b, 0.175f));
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.175f));
        }
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.525f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 3);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.gradient).getHeight() - this.getHeight() / 3 + n2, this.getWidth(), this.getHeight() / 3, false, true);
        spriteBatch.setColor(CFG.COLOR_FLAG_FRAME);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.75f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        int n4;
        int n5;
        Image image;
        int n6;
        int n7;
        int n8;
        try {
            n8 = (int)((float)(this.getWidth() / 2) - Math.max((float)this.iDateWidth, (float)this.getTextWidth() * 0.8f) / 2.0f - (float)(CFG.PADDING * 2));
            n7 = 0;
            n6 = 0;
            while (n6 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.size()) {
                image = CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.get((int)n6).iCivID).getFlag();
                n5 = this.getPosX();
                n4 = CFG.CIV_FLAG_WIDTH;
                n3 = n6 + 1;
                image.draw(spriteBatch, n5 + n8 - n4 * n3 - CFG.PADDING * n6 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Aggressors.get((int)n6).iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + n8 - CFG.CIV_FLAG_WIDTH * n3 - CFG.PADDING * n6 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                n6 = n3;
            }
            n3 = (int)((float)(this.getWidth() / 2) + Math.max((float)this.iDateWidth, (float)this.getTextWidth() * 0.8f) / 2.0f + (float)(CFG.PADDING * 2));
            for (n6 = n7; n6 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.size(); ++n6) {
                CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.get((int)n6).iCivID).getFlag().draw(spriteBatch, this.getPosX() + n3 + CFG.CIV_FLAG_WIDTH * n6 + CFG.PADDING * n6 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(CFG.peaceTreatyData.peaceTreatyGameData.lCivsData_Defenders.get((int)n6).iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + n3 + CFG.CIV_FLAG_WIDTH * n6 + CFG.PADDING * n6 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + (this.getWidth() - this.iDateWidth) / 2 + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sText, this.getPosX() + (int)(((float)this.getWidth() - (float)this.getTextWidth() * 0.8f) / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.8f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.475f));
        image = ImageManager.getImage(Images.line_32_off1);
        n7 = this.getPosX();
        n8 = (this.getWidth() - this.iDateWidth) / 2;
        int n9 = CFG.PADDING;
        n4 = this.getPosY();
        n6 = this.getHeight() / 2;
        n5 = CFG.PADDING;
        int n10 = (int)((float)this.iTextHeight * 0.8f);
        int n11 = ImageManager.getImage(Images.line_32_off1).getHeight();
        n3 = this.iDateWidth;
        image.draw(spriteBatch, n7 + n8 - n9 + n, n4 + n6 + n5 + n10 + n2 - n11, CFG.PADDING * 2 + n3, 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.525f));
        image = ImageManager.getImage(Images.line_32_off1);
        n6 = this.getPosX();
        n7 = (this.getWidth() - this.iDateWidth) / 2;
        n11 = CFG.PADDING;
        n8 = this.getPosY();
        n10 = this.getHeight() / 2;
        n5 = CFG.PADDING;
        n3 = (int)((float)this.iTextHeight * 0.8f);
        n9 = ImageManager.getImage(Images.line_32_off1).getHeight();
        n4 = this.iDateWidth;
        image.draw(spriteBatch, n6 + n7 - n11 + n, n8 + n10 + n5 + n3 + 1 + n2 - n9, CFG.PADDING * 2 + n4, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_CIV_NAME_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_CIV_NAME_HOVERED : CFG.COLOR_TEXT_CIV_NAME) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }
}

