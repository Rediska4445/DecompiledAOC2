/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_PeaceTreaty_Demands_Localize
extends Button {
    protected static final float TEXT_SCALE = 0.8f;
    protected int iProvinceID = 0;
    private boolean row = false;

    protected Button_PeaceTreaty_Demands_Localize(int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init("", 0, n2, n3, n4, n5, bl, true, false, false);
        this.iProvinceID = n;
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.8f / (float)n;
    }

    @Override
    protected void actionElement(int n) {
        CFG.game.setActiveProvinceID(this.getCurrent());
        CFG.map.getMapCoordinates().centerToProvinceID(this.getCurrent());
        if (CFG.game.getProvince(this.iProvinceID).getName().length() > 0) {
            CFG.toast.setInView(CFG.game.getProvince(this.iProvinceID).getName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            CFG.toast.setTimeInView(1500);
        }
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("GoTo"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince(this.iProvinceID).getName()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getTrueOwnerOfProvince(), CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("ProvinceValue"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(CFG.peaceTreatyData.drawProvinceOwners.get((int)this.iProvinceID).iProvinceValue);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.victoryPoints, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Continent"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.map.getMapContinents().getName(CFG.game.getProvince(this.iProvinceID).getContinent()), CFG.map.getMapContinents().getColor(CFG.game.getProvince(this.iProvinceID).getContinent())));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.65f));
        } else if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.775f));
        }
        ImageManager.getImage(Images.btn_localization).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.btn_localization).getWidth() * this.getImageScale(ImageManager.getImage(Images.btn_localization).getHeight())) / 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.btn_localization).getHeight() * this.getImageScale(ImageManager.getImage(Images.btn_localization).getHeight())) / 2 + n2 - ImageManager.getImage(Images.btn_localization).getHeight(), (int)((float)ImageManager.getImage(Images.btn_localization).getWidth() * this.getImageScale(ImageManager.getImage(Images.btn_localization).getHeight())), (int)((float)ImageManager.getImage(Images.btn_localization).getHeight() * this.getImageScale(ImageManager.getImage(Images.btn_localization).getHeight())));
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_NUM_OF_PROVINCES) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

