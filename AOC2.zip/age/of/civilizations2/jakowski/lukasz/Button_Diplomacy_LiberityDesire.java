/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Ideology;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Ideology_Vassal;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;
import java.util.List;

class Button_Diplomacy_LiberityDesire
extends Button {
    protected int iCivID = 0;
    private int iImageID = 0;
    private boolean row = false;
    private String sLiberty;
    protected Color textColor;

    protected Button_Diplomacy_LiberityDesire(int n, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n2);
        stringBuilder.append("%");
        super.init(stringBuilder.toString(), n3, n4, n5, n6, n7, bl, true, false, false);
        this.iCivID = n;
        this.textColor = this.getOpinionColor(n2);
        this.sLiberty = CFG.langManager.get("LibertyDesire");
        this.iImageID = Images.diplo_vassal;
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.8f / (float)n;
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            Object object2 = new MenuElement_Hover_v2_Element_Type_Flag(CFG.getActiveCivInfo());
            object.add(object2);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(CFG.langManager.get("LibertyDesire"));
            stringBuilder.append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString());
            object.add(object2);
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(this.getText());
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), this.textColor);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Ideology_Vassal(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID(), CFG.PADDING, 0);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            stringBuilder = new StringBuilder();
            stringBuilder.append(CFG.langManager.get("Lord"));
            stringBuilder.append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString());
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(CFG.game.getCiv(CFG.getActiveCivInfo()).getPuppetOfCivID()).getCivName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getCiv(CFG.getActiveCivInfo()).getPuppetOfCivID(), CFG.PADDING, 0);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Ideology(CFG.game.getCiv(CFG.game.getCiv(CFG.getActiveCivInfo()).getPuppetOfCivID()).getIdeologyID(), CFG.PADDING, 0);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        Object object = CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled();
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = this.getTextWidth();
        double d = n6;
        Double.isNaN(d);
        n6 = (int)(d * 0.6);
        ((Image)object).draw(spriteBatch, n3 + n4 - n5 * 2 - n6 - (int)((float)CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getWidth() * this.getImageScale(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight())) + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight() * this.getImageScale(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight())) / 2 + n2 - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight(), (int)((float)CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getWidth() * this.getImageScale(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight())), (int)((float)CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight() * this.getImageScale(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight())));
        float f = this.getPosX() + n;
        float f2 = CFG.GAME_HEIGHT - this.getPosY() - n2;
        n4 = this.getWidth();
        n3 = CFG.PADDING;
        n5 = this.getTextWidth();
        d = n5;
        Double.isNaN(d);
        n5 = (int)(d * 0.6);
        try {
            object = new Rectangle(f, f2, n4 - n3 * 2 - n5 - (int)((float)CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getWidth() * this.getImageScale(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(CFG.getActiveCivInfo()).getIdeologyID()).getCrownImageScaled().getHeight())) - CFG.PADDING, -this.getHeight());
            spriteBatch.flush();
            ScissorStack.pushScissors((Rectangle)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            Object object2 = ImageManager.getImage(this.iImageID);
            n4 = this.getPosX();
            n5 = this.getWidth();
            n3 = CFG.PADDING;
            d = this.getTextWidth();
            Double.isNaN(d);
            ((Image)object2).draw(spriteBatch, n4 + n5 - n3 * 2 - (int)(d * 0.6) - (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale(ImageManager.getImage(this.iImageID).getHeight())) + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale(ImageManager.getImage(this.iImageID).getHeight())) / 2 + n2 - ImageManager.getImage(this.iImageID).getHeight(), (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale(ImageManager.getImage(this.iImageID).getHeight())), (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale(ImageManager.getImage(this.iImageID).getHeight())));
            f2 = this.getPosX() + n;
            f = CFG.GAME_HEIGHT - this.getPosY() - n2;
            n4 = this.getWidth();
            n3 = CFG.PADDING;
            d = this.getTextWidth();
            Double.isNaN(d);
            object2 = new Rectangle(f2, f, n4 - n3 * 2 - (int)(d * 0.6) - (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale(ImageManager.getImage(this.iImageID).getHeight())) - CFG.PADDING, -this.getHeight());
            spriteBatch.flush();
            ScissorStack.pushScissors((Rectangle)object2);
        }
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawText(spriteBatch, this.sLiberty, this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.getColor(bl));
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + this.getWidth() - (int)((float)this.getTextWidth() * 0.6f) - CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.textColor);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    protected final Color getOpinionColor(int n) {
        Color color2 = n > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (n == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        return color2;
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

