/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_ShowMenu
extends Button {
    protected Button_ShowMenu(int n, int n2, int n3, int n4, boolean bl) {
        super.init("", 0, n, n2, n3, n4, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_top_edge).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_top_edge).getHeight());
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_top_edge).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_top_edge).getHeight(), false, true);
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.65f));
        }
        ImageManager.getImage(Images.btn_show).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_show).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_show).getHeight() / 2 + n2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }
}

