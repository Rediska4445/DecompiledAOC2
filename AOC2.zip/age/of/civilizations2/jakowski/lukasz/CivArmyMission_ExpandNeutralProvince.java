/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces;
import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces_Army;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_RegroupAfterRecruitment;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import java.util.ArrayList;

class CivArmyMission_ExpandNeutralProvince
extends CivArmyMission {
    private int iCivID;
    private int iConquerProvinceID;
    private int iRangeOfRegroup = 3;
    private int iRegroupArmyPlace = -1;

    protected CivArmyMission_ExpandNeutralProvince(int n, int n2) {
        this.toProvinceID = n2;
        this.iConquerProvinceID = n2;
        this.MISSION_ID = -1;
        this.iCivID = n;
        this.MISSION_TYPE = CivArmyMission_Type.EXPAND_NETURAL_PROVINCE;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = 4;
        this.iArmy = 0;
        this.action(n);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    protected boolean action(int var1_1) {
        var2_2 = new ArrayList<Integer>();
        var3_3 = CFG.game.getProvince(this.iConquerProvinceID).getCivID();
        var4_4 = 1;
        if (var3_3 != 0) {
            this.iObsolate = -1;
            return true;
        }
        for (var3_3 = 0; var3_3 < CFG.game.getProvince(this.iConquerProvinceID).getNeighboringProvincesSize(); ++var3_3) {
            if (CFG.game.getProvince(CFG.game.getProvince(this.iConquerProvinceID).getNeighboringProvinces(var3_3)).getCivID() != this.iCivID) continue;
            var2_2.add(CFG.game.getProvince(this.iConquerProvinceID).getNeighboringProvinces(var3_3));
        }
        if (var2_2.size() == 0) {
            this.iObsolate = -1;
            return true;
        }
        if ((long)CFG.game.getProvince(this.iConquerProvinceID).getArmy(0) > (long)CFG.game.getCiv(this.iCivID).getNumOfUnits() + CFG.game.getCiv(this.iCivID).getMoney() / 5L) {
            CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = (CFG.game.getProvince(this.iConquerProvinceID).getArmy(0) + 5 - CFG.game.getCiv(this.iCivID).getNumOfUnits()) * 5;
            ++this.iObsolate;
        }
        var5_5 = new ArrayList<E>();
        for (var3_3 = var2_2.size() - 1; var3_3 >= 0; --var3_3) {
            if (CFG.game.getProvince((Integer)var2_2.get(var3_3)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var2_2.get(var3_3)) <= CFG.game.getProvince(this.iConquerProvinceID).getArmy(0)) continue;
            var5_5.add(var2_2.get(var3_3));
        }
        if (var5_5.size() > 0) {
            var6_6 = CFG.oR.nextInt(var5_5.size());
            var1_1 = 0;
            for (var7_8 = 0; var7_8 < CFG.game.getProvince((Integer)var5_5.get(var6_6)).getNeighboringProvincesSize(); ++var7_8) {
                var3_3 = var1_1;
                if (CFG.game.getProvince(CFG.game.getProvince((Integer)var5_5.get(var6_6)).getNeighboringProvinces(var7_8)).getCivID() == 0) {
                    var3_3 = var1_1 + 1;
                }
                var1_1 = var3_3;
            }
            var3_3 = CFG.game.getProvince((Integer)var5_5.get(var6_6)).getArmyCivID(this.iCivID);
            if (var1_1 > 1) {
                var3_3 = CFG.game.getProvince(this.iConquerProvinceID).getArmy(0) + 5 + CFG.oR.nextInt(5);
            }
            if (CFG.gameAction.moveArmy((Integer)var5_5.get(var6_6), this.iConquerProvinceID, var3_3, this.iCivID, true, false) == false) return false;
            this.iProvinceID = (Integer)var5_5.get(var6_6);
            this.iObsolate = -1;
            return true;
        }
        var5_5.clear();
        var6_7 = 0;
        for (var7_9 = var2_2.size() - 1; var7_9 >= 0; --var7_9) {
            var3_3 = var6_7;
            if (CFG.game.getProvince((Integer)var2_2.get(var7_9)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var2_2.get(var7_9)) > 0) {
                var5_5.add(var2_2.get(var7_9));
                var3_3 = var6_7 + (CFG.game.getProvince((Integer)var2_2.get(var7_9)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var2_2.get(var7_9)));
            }
            var6_7 = var3_3;
        }
        if (CFG.game.getProvince(this.iConquerProvinceID).getArmy(0) + 4 < var6_7) {
            var8_10 = new ArrayList<E>();
            while (var5_5.size() > 0) {
                var6_7 = 0;
                for (var3_3 = var5_5.size() - 1; var3_3 > 0; --var3_3) {
                    var7_9 = var6_7;
                    if (CFG.game.getProvince((Integer)var5_5.get(var6_7)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var5_5.get(var6_7)) < CFG.game.getProvince((Integer)var5_5.get(var3_3)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var5_5.get(var3_3))) {
                        var7_9 = var3_3;
                    }
                    var6_7 = var7_9;
                }
                var8_10.add(var5_5.get(var6_7));
                var5_5.remove(var6_7);
            }
            for (var3_3 = 0; var3_3 < var8_10.size(); ++var3_3) {
                if (CFG.gameAction.moveArmy((Integer)var8_10.get(var3_3), this.iConquerProvinceID, CFG.game.getProvince((Integer)var8_10.get(var3_3)).getArmyCivID(this.iCivID) - CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.haveMission_Army((Integer)var8_10.get(var3_3)), var1_1, true, false)) continue;
                return false;
            }
        }
        if (this.iRegroupArmyPlace < 0) {
            this.iProvinceID = this.iRegroupArmyPlace = ((Integer)var2_2.get(0)).intValue();
            this.iArmy = CFG.game.getProvince(this.iRegroupArmyPlace).getArmyCivID(this.iCivID);
        } else if (CFG.game.getProvince(this.iRegroupArmyPlace).getCivID() != var1_1) {
            this.iProvinceID = this.iRegroupArmyPlace = ((Integer)var2_2.get(0)).intValue();
            this.iArmy = CFG.game.getProvince(this.iRegroupArmyPlace).getArmyCivID(this.iCivID);
        } else {
            if (CFG.game.getProvince(this.iRegroupArmyPlace).getArmyCivID(this.iCivID) > 2) {
                CFG.gameAction.moveArmy(this.iRegroupArmyPlace, this.iConquerProvinceID, CFG.game.getProvince(this.iRegroupArmyPlace).getArmyCivID(this.iCivID), this.iCivID, true, false);
            }
            this.iProvinceID = this.iRegroupArmyPlace;
            this.iArmy = CFG.game.getProvince(this.iRegroupArmyPlace).getArmyCivID(this.iCivID);
        }
        var7_9 = CFG.game.getProvince(this.iConquerProvinceID).getArmy(0) - CFG.game.getCiv(var1_1).isMovingUnitsToProvinceID_Num(this.iConquerProvinceID) - CFG.game.getCiv(var1_1).isRegoupingArmy_ToProvinceID(this.iRegroupArmyPlace);
        if (CFG.game.getCiv(var1_1).getNumOfUnits() <= var7_9) ** GOTO lbl122
        if (var7_9 <= 0) return false;
        var8_10 = CFG.oAI.getAllNeighboringProvincesInRange_WithArmyToRegroup(this.iRegroupArmyPlace, var1_1, this.iRangeOfRegroup, true, false, new ArrayList<AI_NeighProvinces_Army>(), new ArrayList<Integer>(), var7_9);
        var3_3 = 0;
        for (var6_7 = var8_10.size() - 1; var6_7 >= 0; var3_3 += ((AI_NeighProvinces_Army)var8_10.get((int)var6_7)).iArmy, --var6_7) {
        }
        if (var3_3 <= var7_9) {
            if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_RECRUIT) return false;
            var8_10 = CFG.oAI.getAllNeighboringProvincesInRange_Recruit(this.iRegroupArmyPlace, var1_1, 3, true, false, new ArrayList<AI_NeighProvinces>(), new ArrayList<Integer>());
            if (this.iRegroupArmyPlace >= 0 && !CFG.game.getProvince(this.iRegroupArmyPlace).isOccupied() && CFG.game.getProvince(this.iRegroupArmyPlace).getCivID() == var1_1) {
                var8_10.add(new AI_NeighProvinces(this.iRegroupArmyPlace, 1));
            }
            if (var8_10.size() <= 0) return false;
            var10_12 = CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)var8_10.get((int)0)).iProvinceID);
            var6_7 = 0;
            for (var3_3 = var4_4; var3_3 < var8_10.size(); ++var3_3) {
                var4_4 = var10_12;
                if (var10_12 < CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)var8_10.get((int)var3_3)).iProvinceID)) {
                    var4_4 = CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)var8_10.get((int)var3_3)).iProvinceID);
                    var6_7 = var3_3;
                }
                var10_12 = var4_4;
            }
            var4_4 = CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)var8_10.get((int)var6_7)).iProvinceID);
            var11_13 = CFG.game.getCiv(var1_1).getMoney();
            var3_3 = CFG.game.getProvince(((AI_NeighProvinces)var8_10.get((int)var6_7)).iProvinceID).getLevelOfArmoury() > 0 ? 4 : 5;
            var3_3 = Math.min(var7_9, Math.min(var4_4, (int)(var11_13 / (long)var3_3)));
            CFG.game.getCiv(var1_1).recruitArmy_AI(((AI_NeighProvinces)var8_10.get((int)var6_7)).iProvinceID, var3_3);
            var3_3 = CFG.game.getCiv(var1_1).getRecruitArmy_BasedOnProvinceID(((AI_NeighProvinces)var8_10.get((int)var6_7)).iProvinceID);
            if (var3_3 <= 0) return false;
            CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_RegroupAfterRecruitment(var1_1, ((AI_NeighProvinces)var8_10.get((int)var6_7)).iProvinceID, this.iRegroupArmyPlace, var3_3));
            return false;
        }
        var6_7 = var8_10.size();
        var3_3 = var7_9;
        var7_9 = var6_7 - 1;
        while (true) {
            block42: {
                if (var7_9 >= 0) {
                } else {
                    var7_9 = var3_3;
lbl122:
                    // 2 sources

                    var8_10 = var5_5;
                    if (var7_9 <= 0) break;
                    if ((int)(CFG.game.getCiv(var1_1).getMoney() / 5L) > var7_9) {
                        var8_10.clear();
                        for (var3_3 = var2_2.size() - 1; var3_3 >= 0; --var3_3) {
                            if (CFG.gameAction.getRecruitableArmy((Integer)var2_2.get(var3_3), var1_1) <= var7_9) continue;
                            var8_10.add(var2_2.get(var3_3));
                        }
                        if (var8_10.size() != 0) {
                            var3_3 = CFG.oR.nextInt(var8_10.size());
                            CFG.game.getCiv(var1_1).recruitArmy_AI((Integer)var8_10.get(var3_3), var7_9 + 5 + CFG.oR.nextInt(5));
                            return false;
                        }
                        var6_7 = 0;
                        for (var3_3 = var2_2.size() - 1; var3_3 > 0; --var3_3) {
                            var4_4 = var6_7;
                            if (CFG.gameAction.getRecruitableArmy((Integer)var2_2.get(var3_3), var1_1) > CFG.gameAction.getRecruitableArmy((Integer)var2_2.get(var6_7), var1_1)) {
                                var4_4 = var3_3;
                            }
                            var6_7 = var4_4;
                        }
                        CFG.game.getCiv(var1_1).recruitArmy_AI((Integer)var2_2.get(var6_7), var7_9 + 5 + CFG.oR.nextInt(5));
                        break;
                    }
                    this.iRangeOfRegroup = 6;
                    break;
                }
                for (var6_7 = 0; var6_7 < CFG.game.getProvince(((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iProvinceID).getNeighboringProvincesSize(); ++var6_7) {
                    if (this.iConquerProvinceID != CFG.game.getProvince(((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iProvinceID).getNeighboringProvinces(var6_7)) continue;
                    var4_4 = 1;
                    break block42;
                }
                var4_4 = 0;
            }
            var6_7 = var3_3;
            if (var4_4 == 0) {
                var9_11 = new RegroupArmy_Data(var1_1, ((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iProvinceID, this.iRegroupArmyPlace);
                var6_7 = var3_3;
                if (var9_11.getRouteSize() > 0) {
                    if (var9_11.getRouteSize() == 1) {
                        if (CFG.gameAction.moveArmy(((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iProvinceID, this.iRegroupArmyPlace, ((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iArmy, var1_1, true, false) == false) return false;
                        var6_7 = ((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iArmy;
                    } else {
                        if (CFG.gameAction.moveArmy(((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iProvinceID, var9_11.getRoute(0), ((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iArmy, var1_1, true, false) == false) return false;
                        var9_11.setFromProvinceID(var9_11.getRoute(0));
                        var9_11.removeRoute(0);
                        var9_11.setNumOfUnits(((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iArmy);
                        CFG.game.getCiv(var1_1).addRegroupArmy(var9_11);
                        var6_7 = ((AI_NeighProvinces_Army)var8_10.get((int)var7_9)).iArmy;
                    }
                    var6_7 = var3_3 - var6_7;
                }
            }
            if (var6_7 < 0) {
                return false;
            }
            --var7_9;
            var3_3 = var6_7;
        }
        var1_1 = 0;
        while (var1_1 < var2_2.size()) {
            if (!CFG.gameAction.moveArmy((Integer)var2_2.get(var1_1), this.iConquerProvinceID, CFG.game.getProvince((Integer)var2_2.get(var1_1)).getArmyCivID(this.iCivID), this.iCivID, true, false)) {
                return false;
            }
            ++var1_1;
        }
        return false;
    }

    @Override
    protected void onRemove() {
        CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = -1;
    }
}

