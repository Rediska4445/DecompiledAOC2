/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_NeighProvinces_Army {
    protected int iArmy;
    protected int iDistance;
    protected int iProvinceID;

    protected AI_NeighProvinces_Army(int n, int n2, int n3) {
        this.iProvinceID = n;
        this.iDistance = n2;
        this.iArmy = n3;
    }
}

