/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

class Button_New_Game_Players_CivID_LEFT
extends Button_New_Game_Players {
    private int iCivID = 0;

    protected Button_New_Game_Players_CivID_LEFT(int n, String string2, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n2, n3, n4, n5, bl);
        this.iCivID = n;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight());
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), false, true);
        } else {
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight());
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), false, true);
        }
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.215f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 4, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.iCivID < 0) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        } else {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        Rectangle rectangle = new Rectangle(this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 3 + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - (CFG.CIV_FLAG_WIDTH + CFG.PADDING * 4), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors(rectangle);
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 3 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }
}

