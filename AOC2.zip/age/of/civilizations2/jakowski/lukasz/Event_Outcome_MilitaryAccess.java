/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_MilitaryAccess
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID2 = -1;
    protected int iValue = 0;

    Event_Outcome_MilitaryAccess() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl;
        boolean bl2 = bl = false;
        try {
            if (this.getValue() <= 0) return bl2;
            bl2 = bl;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
        if (this.getCivID() < 0) return bl2;
        bl2 = bl;
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl2;
        bl2 = bl;
        if (this.getCivID2() < 0) return bl2;
        bl2 = bl;
        if (this.getCivID2() >= CFG.game.getCivsSize()) return bl2;
        float f = CFG.game.getCivRelation_OfCivB(this.getCivID(), this.getCivID2());
        bl2 = bl;
        if ((int)f == -100) return bl2;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_MILITARY);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID2;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("MilitaryAccess")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ").append(CFG.game.getCiv(this.getCivID2()).getCivName()).append(": ").append(this.getValue()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("MilitaryAccess");
            return var1_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        ArrayList arrayList = new ArrayList();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        ArrayList arrayList3 = arrayList;
        try {
            if (!this.canMakeAction()) return arrayList3;
            arrayList3 = new ArrayList();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList3)).append(CFG.langManager.get("MilitaryAccess")).append(":").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            arrayList3 = new ArrayList(this.getCivID(), CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(" -> ");
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID2()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(this.getCivID2(), CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(arrayList2);
            arrayList.add(arrayList3);
            arrayList2.clear();
            arrayList3 = new ArrayList();
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList3)).append(CFG.langManager.get("Expires")).append(": ").toString());
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            arrayList3 = new ArrayList(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + this.getValue()), CFG.COLOR_TEXT_MODIFIER_NEUTRAL2);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList();
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList3)).append(" [").append(CFG.langManager.get("Turns")).append(": ").append(this.getValue()).append("]").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            arrayList3 = new ArrayList(arrayList2);
            arrayList.add(arrayList3);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    @Override
    protected void outcomeAction() {
        if (this.canMakeAction()) {
            CFG.game.setMilitaryAccess(this.getCivID(), this.getCivID2(), this.getValue());
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID2 = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID2 == n) {
            this.iCivID2 = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID2) return bl2;
        --this.iCivID2;
        return bl;
    }
}

