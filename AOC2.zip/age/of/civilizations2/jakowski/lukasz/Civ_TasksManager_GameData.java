/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Civ_Task;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Civ_TasksManager_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected List<Civ_Task> civTasks = new ArrayList<Civ_Task>();
    protected int iTasksSize = 0;

    Civ_TasksManager_GameData() {
    }

    protected final void addNewTask(Civ_Task civ_Task) {
        for (int i = this.civTasks.size() - 1; i >= 0; --i) {
            int n = 1.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Civ_Task_Type[this.civTasks.get((int)i).taskType.ordinal()];
            if (this.civTasks.get((int)i).iProvinceID != civ_Task.iProvinceID) continue;
            return;
        }
        this.civTasks.add(civ_Task);
        this.iTasksSize = this.civTasks.size();
    }

    protected final void runTasks() {
        for (int i = 0; i < this.iTasksSize; ++i) {
        }
    }
}

