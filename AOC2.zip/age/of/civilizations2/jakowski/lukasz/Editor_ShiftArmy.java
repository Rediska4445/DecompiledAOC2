/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import com.badlogic.gdx.Gdx;

class Editor_ShiftArmy
extends Editor {
    Editor_ShiftArmy() {
    }

    protected static final void saveArmyPosition() {
        CFG.game.saveProvince_Info_GameData_SHIFTXY(CFG.game.getActiveProvinceID());
    }

    @Override
    protected void keyDown(int n) {
        if (CFG.game.getActiveProvinceID() >= 0) {
            if (Gdx.input.isKeyPressed(21)) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setShiftArmyX(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getShiftX() - 1);
            }
            if (Gdx.input.isKeyPressed(22)) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setShiftArmyX(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getShiftX() + 1);
            }
            if (Gdx.input.isKeyPressed(19)) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setShiftArmyY(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getShiftY() - 1);
            }
            if (Gdx.input.isKeyPressed(20)) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setShiftArmyY(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getShiftY() + 1);
            }
            Editor_ShiftArmy.saveArmyPosition();
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SHIFT ARMY: ");
        stringBuilder.append(CFG.game.getActiveProvinceID());
        return stringBuilder.toString();
    }
}

