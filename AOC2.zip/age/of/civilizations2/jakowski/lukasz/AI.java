/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Frontline;
import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces;
import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces_Army;
import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.AI_Style_CityState;
import age.of.civilizations2.jakowski.lukasz.AI_Style_Communism;
import age.of.civilizations2.jakowski.lukasz.AI_Style_Fascism;
import age.of.civilizations2.jakowski.lukasz.AI_Style_Horde;
import age.of.civilizations2.jakowski.lukasz.AI_Style_Rebels;
import age.of.civilizations2.jakowski.lukasz.AI_Style_Tribal;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Message;
import age.of.civilizations2.jakowski.lukasz.MessageBox_GameData;
import age.of.civilizations2.jakowski.lukasz.Message_WeCanSignPeace;
import age.of.civilizations2.jakowski.lukasz.ViewsManager;
import com.badlogic.gdx.Gdx;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class AI {
    protected static int REBUILD_PERSONALITY = 87;
    protected static final int STATUS_QUO_NO_PROGRESS = 49;
    protected static final int STATUS_QUO_TOO_LONG = 299;
    protected static final int STATUS_QUO_TURNS = 39;
    protected static final int STATUS_QUO_TURNS_NO_ONE_ATTACKED = 19;
    protected final int DANGER_EXTRA_AT_WAR;
    protected int MIN_NUM_OF_RIVALS = 1;
    protected int NUM_OF_CIVS_IN_THE_GAME = 0;
    protected int PLAYABLE_PROVINCES = 1;
    protected boolean doneLoadingOrders = false;
    protected Expand expandNeutral;
    protected int iLoadingTurnActionsOfCivID = 0;
    protected int iNeutralProvincesWithSeaAccessSize = 0;
    protected int iNumOfColonizedProvinces = 0;
    private List<AI_Style> lAI_Styles = new ArrayList<AI_Style>();
    protected List<List<AI_Frontline>> lFrontLines = new ArrayList<List<AI_Frontline>>();
    protected List<Integer> lNeutralProvincesWithSeaAccess = new ArrayList<Integer>();
    protected List<Integer> lWastelandProvincesWithSeaAccess = new ArrayList<Integer>();

    protected AI() {
        this.DANGER_EXTRA_AT_WAR = 450;
        this.updateExpand();
        this.lAI_Styles.add(new AI_Style());
        this.lAI_Styles.add(new AI_Style_Communism());
        this.lAI_Styles.add(new AI_Style_Horde());
        this.lAI_Styles.add(new AI_Style_Fascism());
        this.lAI_Styles.add(new AI_Style_CityState());
        this.lAI_Styles.add(new AI_Style_Tribal());
        this.lAI_Styles.add(new AI_Style_Rebels());
        this.build_RebuildPersonality();
    }

    protected final void addNeutralProvincesWithSeaAccess(int n) {
        this.lNeutralProvincesWithSeaAccess.add(n);
    }

    protected final void addWastelandProvincesWithSeaAccess(int n) {
        this.lWastelandProvincesWithSeaAccess.add(n);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void buildAIData() {
        this.resetNeutralProvincesWithSeaAccess();
        this.resetWastelandProvincesWithSeaAccess();
        this.iNumOfColonizedProvinces = 0;
        this.NUM_OF_CIVS_IN_THE_GAME = 0;
        for (var1_1 = 1; var1_1 < CFG.game.getCivsSize(); this.iNumOfColonizedProvinces += CFG.game.getCiv((int)var1_1).civGameData.lColonies_Founded.size(), ++var1_1) {
            CFG.game.getCiv(var1_1).setSeaAccess(0);
            CFG.game.getCiv(var1_1).clearSeaAccess_Provinces();
            CFG.game.getCiv(var1_1).clearSeaAccess_PortProvinces();
            CFG.game.getCiv(var1_1).setBordersWithEnemy(0);
            CFG.game.getCiv(var1_1).setIsAtWar(false);
            CFG.game.getCiv(var1_1).setCanExpandOnContinent(false);
            CFG.game.getCiv(var1_1).setNumOfNeighboringNeutralProvinces(0);
            CFG.game.getCiv((int)var1_1).lArmiesPosition.clear();
            CFG.game.getCiv((int)var1_1).iArmiesPositionSize = 0;
            CFG.game.getCiv((int)var1_1).lBorderWithCivs.clear();
            CFG.game.getCiv((int)var1_1).iBorderWithCivsSize = 0;
            CFG.game.getCiv((int)var1_1).iAveragePopulation = 1;
            CFG.game.getCiv((int)var1_1).lBordersWithNeutralProvincesID.clear();
            CFG.game.getCiv((int)var1_1).lBordersWithWastelandProvincesID.clear();
            CFG.game.getCiv((int)var1_1).civGameData.civPlans.updateObsolateMissions();
            CFG.game.countAvarageDevelopmentLevel_Float(var1_1);
            CFG.game.getCiv((int)var1_1).lProvincesWithHighRevRisk.clear();
            CFG.game.getCiv((int)var1_1).isAtWarWithCivs.clear();
            CFG.game.getCiv((int)var1_1).iNumOf_Forts = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Towers = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Ports = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Farms = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Farms_ProvincesPossibleToBuild = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Workshops = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Libraries = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_Armories = 0;
            CFG.game.getCiv((int)var1_1).iNumOf_SuppliesCamp = 0;
        }
        ViewsManager.updateMaxPopulation();
        ViewsManager.updateMaxEconomy();
        var1_1 = 1;
        while (true) {
            if (var1_1 >= CFG.game.getCivsSize() - 1) break;
            for (var2_2 = var1_1 + 1; var2_2 < CFG.game.getCivsSize(); ++var2_2) {
                if (!CFG.game.getCivsAtWar(var1_1, var2_2)) continue;
                CFG.game.getCiv(var1_1).setIsAtWar(true);
                CFG.game.getCiv(var2_2).setIsAtWar(true);
                CFG.game.getCiv((int)var1_1).isAtWarWithCivs.add(var2_2);
                CFG.game.getCiv((int)var2_2).isAtWarWithCivs.add(var1_1);
            }
            for (var2_2 = 0; var2_2 < CFG.game.getCiv(var1_1).getCivRegionsSize(); ++var2_2) {
                CFG.game.getCiv((int)var1_1).getCivRegion((int)var2_2).iAveragePotential = 0;
            }
            ++var1_1;
        }
        for (var1_1 = 0; var1_1 < CFG.game.getCivsSize(); ++var1_1) {
            if (CFG.game.getCiv(var1_1).getNumOfProvinces() <= 0) continue;
            ++this.NUM_OF_CIVS_IN_THE_GAME;
            if (CFG.game.getCiv(var1_1).isAtWar()) {
                var3_3 = CFG.game.getCiv((int)var1_1).civGameData;
                ++var3_3.iNumOfTurnsAtWar;
                continue;
            }
            var3_3 = CFG.game.getCiv((int)var1_1).civGameData;
            var3_3.iNumOfTurnsAtWar -= 2;
            if (CFG.game.getCiv((int)var1_1).civGameData.iNumOfTurnsAtWar >= 0) continue;
            CFG.game.getCiv((int)var1_1).civGameData.iNumOfTurnsAtWar = 0;
        }
        this.updateMinRivals();
        this.PLAYABLE_PROVINCES = 0;
        block5: for (var1_1 = 0; var1_1 < CFG.game.getProvincesSize(); ++var1_1) {
            if (CFG.game.getProvince(var1_1).getSeaProvince()) continue;
            if (CFG.game.getProvince(var1_1).getWasteland() >= 0) {
                if (!Game_Calendar.getColonizationOfWastelandIsEnabled()) continue;
                for (var2_2 = 0; var2_2 < CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize(); ++var2_2) {
                    if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var2_2)).getLevelOfPort() != -2) {
                        continue;
                    }
                    this.addWastelandProvincesWithSeaAccess(var1_1);
                    continue block5;
                }
                continue;
            }
            this.buildProvinceData(var1_1);
            ++this.PLAYABLE_PROVINCES;
        }
        var1_1 = 1;
        while (true) {
            if (var1_1 >= CFG.game.getCivsSize()) break;
            for (var2_2 = 0; var2_2 < CFG.game.getCiv(var1_1).getCivRegionsSize(); ++var2_2) {
                if (CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvincesSize() <= 0) continue;
                var3_3 = CFG.game.getCiv(var1_1).getCivRegion(var2_2);
                var3_3.iAveragePotential /= CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvincesSize();
            }
            CFG.game.getCiv((int)var1_1).iArmiesPositionSize = CFG.game.getCiv((int)var1_1).lArmiesPosition.size();
            var4_4 = CFG.game.getCiv(var1_1);
            if (CFG.game.getCiv(var1_1).getNumOfProvinces() > 0) {
                var3_3 = CFG.game.getCiv(var1_1);
                var3_3.iAveragePopulation = var2_2 = var3_3.iAveragePopulation / CFG.game.getCiv(var1_1).getNumOfProvinces();
            } else {
                var2_2 = 1;
            }
            var4_4.iAveragePopulation = var2_2;
            for (var2_2 = 0; var2_2 < CFG.game.getCiv(var1_1).getConstructionsSize(); ++var2_2) {
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.FARM) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Farms;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.ARMOURY) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Armories;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.TOWER) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Towers;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.LIBRARY) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Libraries;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.PORT) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Ports;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.NUCLEAR_REACTOR) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_NuclearReactors;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType == ConstructionType.FORT) {
                    var3_3 = CFG.game.getCiv(var1_1);
                    ++var3_3.iNumOf_Forts;
                    continue;
                }
                if (CFG.game.getCiv((int)var1_1).getConstruction((int)var2_2).constructionType != ConstructionType.SUPPLY) continue;
                var3_3 = CFG.game.getCiv(var1_1);
                ++var3_3.iNumOf_SuppliesCamp;
            }
            ++var1_1;
        }
        this.lFrontLines.clear();
        var1_1 = 1;
        while (true) {
            if (var1_1 >= CFG.game.getCivsSize()) break;
            var3_3 = new ArrayList<E>();
            if (CFG.game.getCiv(var1_1).getNumOfProvinces() > 0) {
                block11: for (var2_2 = 0; var2_2 < CFG.game.getCiv(var1_1).getCivRegionsSize(); ++var2_2) {
                    var5_5 = 0;
                    block12: while (true) {
                        if (var5_5 >= CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvincesSize()) continue block11;
                        if (CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getDangerLevel() > 0) {
                            var6_6 = 0;
                            break;
                        }
                        while (true) {
                            ++var5_5;
                            continue block12;
                            break;
                        }
                        break;
                    }
                    while (true) {
                        if (var6_6 >= CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvincesSize()) ** continue;
                        if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID() > 0 && CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID() != var1_1 && !CFG.game.getCivsAreAllied(var1_1, CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID()) && CFG.game.getCiv(var1_1).getPuppetOfCivID() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID() && CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID()).getPuppetOfCivID() != var1_1 && CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID()).getPuppetOfCivID() != CFG.game.getCiv(var1_1).getPuppetOfCivID()) {
                            block42: {
                                var7_7 = true;
                                var8_8 = 0;
                                while (true) {
                                    var9_9 = var7_7;
                                    if (var8_8 >= var3_3.size()) break block42;
                                    if (((AI_Frontline)var3_3.get((int)var8_8)).iRegionID == var2_2 && ((AI_Frontline)var3_3.get((int)var8_8)).iWithCivID == CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID()) break;
                                    ++var8_8;
                                }
                                var9_9 = false;
                                ((AI_Frontline)var3_3.get((int)var8_8)).lProvinces.add(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5));
                                if (CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getBordersWithEnemy()) {
                                    ((AI_Frontline)var3_3.get((int)var8_8)).bordersWithEnemy = true;
                                }
                            }
                            if (var9_9) {
                                var3_3.add(new AI_Frontline(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5), var2_2, CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getNeighboringProvinces(var6_6)).getCivID(), CFG.game.getProvince(CFG.game.getCiv(var1_1).getCivRegion(var2_2).getProvince(var5_5)).getBordersWithEnemy()));
                            }
                        }
                        ++var6_6;
                    }
                }
            }
            this.lFrontLines.add((List<AI_Frontline>)var3_3);
            ++var1_1;
        }
        var1_1 = 1;
        block16: while (true) {
            if (var1_1 >= CFG.game.getCivsSize()) {
                this.iNeutralProvincesWithSeaAccessSize = this.lNeutralProvincesWithSeaAccess.size();
                Gdx.app.log("AI", "--------- TURN: " + Game_Calendar.TURN_ID + " ---------");
                CFG.setRender_3(true);
                return;
            }
            if (CFG.game.getCiv(var1_1).getNumOfProvinces() <= 0) ** GOTO lbl185
            var2_2 = 0;
            while (true) {
                block43: {
                    if (var2_2 < CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize) break block43;
lbl185:
                    // 2 sources

                    ++var1_1;
                    continue block16;
                }
                for (var5_5 = 0; var5_5 < this.lFrontLines.get(var1_1 - 1).size(); ++var5_5) {
                    if (this.lFrontLines.get((int)(var1_1 - 1)).get((int)var5_5).iWithCivID != CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var2_2).onCivID) continue;
                    for (var6_6 = 0; var6_6 < this.lFrontLines.get((int)(var1_1 - 1)).get((int)var5_5).lProvinces.size(); ++var6_6) {
                        CFG.game.getProvince(this.lFrontLines.get((int)(var1_1 - 1)).get((int)var5_5).lProvinces.get(var6_6)).addDangerLevel((int)((0.325f / (float)CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var2_2).iNumOfTurnsLeft + 0.675f) * 450.0f));
                    }
                }
                ++var2_2;
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void buildProvinceData(int var1_1) {
        block56: {
            block57: {
                block55: {
                    block54: {
                        CFG.game.getProvince(var1_1).setBordersWithEnemy(false);
                        CFG.game.getProvince(var1_1).setDangerLevel(0);
                        CFG.game.getProvince(var1_1).setPotential(245);
                        CFG.game.getProvince(var1_1).setNumOfNeighboringNeutralProvinces(0);
                        CFG.game.getProvince((int)var1_1).was = false;
                        CFG.game.getProvince(var1_1).buildRecruitableArmyPoints();
                        if (CFG.game.getProvince(var1_1).getRevolutionaryRisk() > 0.56f) {
                            CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).lProvincesWithHighRevRisk.add(var1_1);
                        }
                        if (CFG.game.getProvince(var1_1).getCivID() <= 0) break block54;
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_Forts += CFG.game.getProvince(var1_1).getLevelOfFort();
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_Towers += CFG.game.getProvince(var1_1).getLevelOfWatchTower();
                        if (CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(var1_1).getTerrainTypeID()) >= 0.0f) {
                            var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                            var2_2.iNumOf_Farms += CFG.game.getProvince(var1_1).getLevelOfFarm();
                            var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                            ++var2_2.iNumOf_Farms_ProvincesPossibleToBuild;
                        }
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_Workshops += CFG.game.getProvince(var1_1).getLevelOfWorkshop();
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_Libraries += CFG.game.getProvince(var1_1).getLevelOfLibrary();
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_Armories += CFG.game.getProvince(var1_1).getLevelOfArmoury();
                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                        var2_2.iNumOf_SuppliesCamp += CFG.game.getProvince(var1_1).getLevelOfSupply();
                        if (CFG.game.getProvince(var1_1).getLevelOfPort() > 0) {
                            var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                            var2_2.iNumOf_Ports += CFG.game.getProvince(var1_1).getLevelOfPort();
                            CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).addSeaAccess_PortProvinces(var1_1);
                        }
                        if (CFG.game.getProvince(var1_1).getLevelOfNuclearReactor() > 0) {
                            var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
                            var2_2.iNumOf_NuclearReactors += CFG.game.getProvince(var1_1).getLevelOfNuclearReactor();
                            CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).addSeaAccess_PortProvinces(var1_1);
                        }
                        if (CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize() > 0) {
                            CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).addSeaAccess_Provinces(var1_1);
                        }
                        break block55;
                    }
                    if (!CFG.game.getProvince(var1_1).getSeaProvince()) break block56;
                    break block57;
                }
                for (var3_8 = 0; var3_8 < CFG.game.getProvince(var1_1).getCivsSize(); ++var3_8) {
                    if (CFG.game.getProvince(var1_1).getArmy(var3_8) <= 0) continue;
                    CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID((int)var3_8)).lArmiesPosition.add(var1_1);
                }
                for (var3_8 = 0; var3_8 < CFG.game.getProvince(var1_1).getNeighboringProvincesSize(); ++var3_8) {
                    if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID() > 0) {
                        CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).addBordersWithCivID(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID());
                        continue;
                    }
                    if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getWasteland() >= 0) {
                        CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).lBordersWithWastelandProvincesID.add(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8));
                        continue;
                    }
                    if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID() != 0) continue;
                    CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).lBordersWithNeutralProvincesID.add(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8));
                }
                break block56;
            }
            for (var3_8 = 1; var3_8 < CFG.game.getProvince(var1_1).getCivsSize(); ++var3_8) {
                if (CFG.game.getProvince(var1_1).getArmy(var3_8) <= 0) continue;
                CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID((int)var3_8)).lArmiesPosition.add(var1_1);
            }
        }
        if (CFG.game.getProvince(var1_1).getWasAttacked() > 0) {
            var2_2 = CFG.game.getProvince(var1_1);
            var4_9 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 45.0f : 10.0f * ((100.0f - (float)(CFG.game.getProvince(var1_1).getArmy(0) * 35) / (float)CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getNumOfUnits()) / 100.0f);
            var2_2.addDangerLevel((int)var4_9);
            CFG.game.getProvince(var1_1).setArmyWasRecruited(0);
            CFG.game.getProvince(var1_1).setWasAttacked(CFG.game.getProvince(var1_1).getWasAttacked() - 1);
        }
        CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getNeighboringProvincesSize());
        CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize());
        CFG.game.getProvince(var1_1).addPotential((int)((float)(CFG.game.getProvince(var1_1).getPopulationData().getPopulation() * 235) / (float)ViewsManager.POPULATION_MAX));
        CFG.game.getProvince(var1_1).addPotential((int)(185.0f * CFG.game.getProvince(var1_1).getGrowthRate_Population_WithFarm()));
        CFG.game.getProvince(var1_1).addPotential((int)((float)(CFG.game.getProvince(var1_1).getEconomy() * 175) / (float)ViewsManager.ECONOMY_MAX));
        CFG.game.getProvince(var1_1).addPotential((int)(115.0f * CFG.game.getProvince(var1_1).getDevelopmentLevel()));
        CFG.game.getProvince(var1_1).addDangerLevel((int)CFG.game.getProvince(var1_1).getRevolutionaryRisk());
        if (CFG.game.getProvince(var1_1).getCivID() != 0) {
            var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID());
            var2_2.iAveragePopulation += CFG.game.getProvince(var1_1).getPopulationData().getPopulation();
            if (CFG.game.getProvince(var1_1).getLevelOfWatchTower() > 0) {
                CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getLevelOfWatchTower() * 4 * CFG.game.getProvince(var1_1).getNeighboringProvincesSize());
            }
            CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getLevelOfPort() * 6 * CFG.game.getProvince(var1_1).getNeighboringProvincesSize());
            CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getLevelOfFort() * 5);
            CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getLevelOfFarm() * 3);
            CFG.game.getProvince(var1_1).addPotential(CFG.game.getProvince(var1_1).getLevelOfWorkshop() * 4);
            if (CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize() > 0) {
                CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).setSeaAccess(CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getSeaAccess() + 1);
            }
            var5_10 = 0;
        } else {
            CFG.game.getProvince(var1_1).addPotential((int)((375.0f + 275.0f * (0.5f + 0.1f * (float)CFG.game.getProvince(var1_1).getNeighboringProvincesSize())) * CFG.game.getProvince(var1_1).getGrowthRate_Population_WithFarm()) + 225);
            for (var3_8 = 0; var3_8 < CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize(); ++var3_8) {
                if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getLevelOfPort() != -2) {
                    continue;
                }
                this.addNeutralProvincesWithSeaAccess(var1_1);
                break;
            }
lbl100:
            // 5 sources

            while (true) {
                var3_8 = 0;
                while (true) {
                    if (var3_8 < CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize()) {
                    } else {
                        block53: {
                            block52: {
                                block51: {
                                    try {
                                        if (CFG.game.getProvince(var1_1).getArmy(0) > 0) {
                                            CFG.game.getProvince(var1_1).setDangerLevel_WithArmy((int)Math.ceil((float)CFG.game.getProvince(var1_1).getDangerLevel() * (1.0f - CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.DANGER_PERC_OF_UNITS * (float)CFG.game.getProvince(var1_1).getArmy(0) / (float)CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getNumOfUnits())));
                                            break block51;
                                        }
                                        CFG.game.getProvince(var1_1).setDangerLevel_WithArmy(CFG.game.getProvince(var1_1).getDangerLevel());
                                    }
                                    catch (IllegalArgumentException var2_3) {
                                        CFG.game.getProvince(var1_1).setDangerLevel_WithArmy(CFG.game.getProvince(var1_1).getDangerLevel());
                                        if (!CFG.LOGS) break block51;
                                        CFG.exceptionStack(var2_3);
                                    }
                                }
                                if (CFG.game.getProvince(var1_1).getLevelOfFort() > 0) {
                                    CFG.game.getProvince(var1_1).setPotential((int)Math.ceil((float)CFG.game.getProvince(var1_1).getPotential() * 0.9566f));
                                }
                                if (CFG.game.getProvince(var1_1).getCivID() > 0) {
                                    try {
                                        var2_2 = CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getCivRegion(CFG.game.getProvince(var1_1).getCivRegionID());
                                        var2_2.iAveragePotential += CFG.game.getProvince(var1_1).getPotential();
                                    }
                                    catch (IndexOutOfBoundsException var2_4) {
                                        if (CFG.LOGS) {
                                            CFG.exceptionStack(var2_4);
                                        }
                                    }
                                    catch (NullPointerException var2_5) {
                                        if (!CFG.LOGS) break block52;
                                        CFG.exceptionStack(var2_5);
                                    }
                                }
                            }
                            try {
                                if (CFG.game.getProvince(var1_1).getCivID() > 0 && CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).getCivRegion((int)CFG.game.getProvince((int)var1_1).getCivRegionID()).isKeyRegion) {
                                    CFG.game.getProvince(var1_1).setDangerLevel((int)((float)CFG.game.getProvince(var1_1).getDangerLevel() * CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.DANGER_EXTRA_KEY_REGION));
                                }
                            }
                            catch (IndexOutOfBoundsException var2_6) {
                                if (CFG.LOGS) {
                                    CFG.exceptionStack(var2_6);
                                }
                            }
                            catch (NullPointerException var2_7) {
                                if (!CFG.LOGS) break block53;
                                CFG.exceptionStack(var2_7);
                            }
                        }
                        if (CFG.game.getProvince(var1_1).getNeighbooringProvinceOfCivWasLost() > 0) {
                            CFG.game.getProvince(var1_1).addDangerLevel((int)((float)CFG.game.getProvince(var1_1).getDangerLevel() * 0.15f * (float)CFG.game.getProvince(var1_1).getNeighbooringProvinceOfCivWasLost()));
                        }
                        if (CFG.game.getProvince(var1_1).getArmyWasRecruited() > 0) {
                            CFG.game.getProvince(var1_1).setArmyWasRecruited(CFG.game.getProvince(var1_1).getArmyWasRecruited() - 1);
                        }
                        if (CFG.game.getProvince(var1_1).getBordersWithEnemy()) {
                            CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).setBordersWithEnemy(CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getBordersWithEnemy() + 1);
                        }
                        if (CFG.game.getProvince(var1_1).getNumOfNeighboringNeutralProvinces() > 0) {
                            CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).setNumOfNeighboringNeutralProvinces(CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getNumOfNeighboringNeutralProvinces() + CFG.game.getProvince(var1_1).getNumOfNeighboringNeutralProvinces());
                        }
                        CFG.game.getProvince(var1_1).setWasConquered((byte)(CFG.game.getProvince(var1_1).getWasConquered() - 1));
                        CFG.game.getProvince(var1_1).setNeighbooringProvinceOfCivWasLost((byte)(CFG.game.getProvince(var1_1).getNeighbooringProvinceOfCivWasLost() - 1));
                        return;
                    }
                    for (var5_10 = 1; var5_10 < CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getCivsSize(); ++var5_10) {
                        if (CFG.game.getCivsAtWar(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getCivID(var5_10))) {
                            var2_2 = CFG.game.getProvince(var1_1);
                            var4_9 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 28.75f : 14.87f;
                            var2_2.addDangerLevel((int)(var4_9 * Math.min(1.0f * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getArmy(var5_10) / Math.max((float)CFG.game.getProvince(var1_1).getArmy(0), 1.0f), 2.0f)));
                            continue;
                        }
                        if (!(CFG.game.getCivRelation_OfCivB(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getCivID(var5_10)) < 0.0f)) continue;
                        var2_2 = CFG.game.getProvince(var1_1);
                        var4_9 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 8.75f : 4.87f;
                        var2_2.addDangerLevel((int)(var4_9 * Math.min(1.0f * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getArmy(var5_10) / Math.max((float)CFG.game.getProvince(var1_1).getArmy(0), 1.0f), 2.0f) * (-CFG.game.getCivRelation_OfCivB(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringSeaProvinces(var3_8)).getCivID(var5_10)) / 100.0f)));
                    }
                    ++var3_8;
                }
                break;
            }
        }
        for (var3_8 = 0; var3_8 < CFG.game.getProvince(var1_1).getNeighboringProvincesSize(); ++var3_8) {
            if (CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID() > 0) {
                if (CFG.game.getProvince(var1_1).getCivID() != CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID() && CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getPuppetOfCivID() != CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()).getPuppetOfCivID()) {
                    if (CFG.game.getCivsAtWar(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID())) {
                        CFG.game.getProvince(var1_1).setBordersWithEnemy(true);
                        var2_2 = CFG.game.getProvince(var1_1);
                        var6_11 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 64 : 24;
                        var7_12 = var6_11;
                        var4_9 = CFG.game.getProvince(var1_1).getWasAttacked() > 0 ? 1.775f : 1.0f;
                        var2_2.addDangerLevel((int)(var4_9 * var7_12 * (float)(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getWasConquered() + 1)));
                    }
                    if (!CFG.game.getCivsAreAllied(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) && CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getPuppetOfCivID() != CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()).getPuppetOfCivID() && CFG.game.getDefensivePact(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) == 0 && CFG.game.getGuarantee(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) == 0 && CFG.game.getCivNonAggressionPact(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) == 0 && CFG.game.getCivTruce(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) < 4) {
                        CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).setCanExpandOnContinent(true);
                        var2_2 = CFG.game.getProvince(var1_1);
                        var6_11 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 14 : 6;
                        var2_2.addDangerLevel(var6_11);
                        var2_2 = CFG.game.getProvince(var1_1);
                        var4_9 = CFG.game.getProvince(var1_1).getIsCapital() != false ? 48.75f : 33.45f;
                        var7_12 = CFG.game.getCivsAtWar(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) != false ? 4.875f * (float)(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getWasConquered() + 1) : Math.max(0.75f, 1.55f - CFG.game.getCivRelation_OfCivB(CFG.game.getProvince(var1_1).getCivID(), CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()) / 25.0f);
                        var2_2.addDangerLevel((int)(var4_9 * var7_12 * (0.625f + Math.min(1.42f, (float)CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getCivID()).getNumOfProvinces() / (float)CFG.game.getCiv(CFG.game.getProvince(var1_1).getCivID()).getNumOfProvinces() / (float)CFG.game.getProvince(var1_1).getNeighboringProvincesSize()))));
                    }
                    CFG.game.getProvince(var1_1).addPotential(-((int)(CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.POTENTIAL_POPULATION * 0.85f * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getPopulationData().getPopulation() / (float)ViewsManager.POPULATION_MAX)));
                    CFG.game.getProvince(var1_1).addPotential(-((int)(CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.POTENTIAL_ECONOMY * 0.85f * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getEconomy() / (float)ViewsManager.ECONOMY_MAX)));
                    CFG.game.getProvince(var1_1).addPotential(-24);
                } else {
                    CFG.game.getProvince(var1_1).addPotential(24);
                    ++var5_10;
                }
            } else {
                CFG.game.getProvince(var1_1).setNumOfNeighboringNeutralProvinces(CFG.game.getProvince(var1_1).getNumOfNeighboringNeutralProvinces() + 1);
                CFG.game.getProvince(var1_1).addPotential((int)(4.0f + 46.0f * CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getGrowthRate_Population()) + 5);
            }
            CFG.game.getProvince(var1_1).addPotential((int)(CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.POTENTIAL_POPULATION * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getPopulationData().getPopulation() / (float)ViewsManager.POPULATION_MAX));
            CFG.game.getProvince(var1_1).addPotential((int)(CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.POTENTIAL_ECONOMY * (float)CFG.game.getProvince(CFG.game.getProvince(var1_1).getNeighboringProvinces(var3_8)).getEconomy() / (float)ViewsManager.ECONOMY_MAX));
        }
        if (var5_10 > 0) {
            CFG.game.getProvince(var1_1).setDangerLevel((int)((float)CFG.game.getProvince(var1_1).getDangerLevel() + CFG.game.getCiv((int)CFG.game.getProvince((int)var1_1).getCivID()).civGameData.civPersonality.DANGER_EXTRA_PER_OWN_PROVINCE * (float)var5_10 * (float)CFG.game.getProvince(var1_1).getDangerLevel()));
        }
        if (CFG.game.getProvince(var1_1).getBordersWithEnemy()) {
            CFG.game.getProvince(var1_1).addDangerLevel(450);
        }
        if (!CFG.game.getProvince(var1_1).getIsCapital()) ** GOTO lbl100
        CFG.game.getProvince(var1_1).addPotential(25);
        if (CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize() <= 0) ** GOTO lbl100
        CFG.game.getProvince(var1_1).addDangerLevel(CFG.game.getProvince(var1_1).getNeighboringSeaProvincesSize() * 25 + 125);
        ** while (true)
    }

    protected final void build_RebuildPersonality() {
        REBUILD_PERSONALITY = CFG.oR.nextInt(20) + 79;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void checkCurrentWars_LookingForPeace() {
        int n = 0;
        while (true) {
            Serializable serializable;
            Serializable serializable2;
            int n2;
            int n3;
            try {
                if (n >= CFG.game.getWarsSize()) return;
                for (n3 = 0; n3 < CFG.game.getWar(n).getDefendersSize(); ++n3) {
                    if (CFG.game.getCiv(CFG.game.getWar(n).getDefenderID(n3).getCivID()).getNumOfProvinces() != 0 || CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getDefenderID((int)n3).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                    for (n2 = 0; n2 < CFG.game.getWar(n).getAggressorsSize(); ++n2) {
                        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getAggressorID((int)n2).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                        serializable2 = CFG.game.getCiv((int)CFG.game.getWar((int)n).getAggressorID((int)n2).getCivID()).getCivilization_Diplomacy_GameData().messageBox;
                        serializable = new Message_WeCanSignPeace(CFG.game.getWar(n).getDefenderID(n3).getCivID());
                        serializable2.addMessage((Message)serializable);
                    }
                }
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
                return;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
                return;
            }
            {
                for (n3 = 0; n3 < CFG.game.getWar(n).getAggressorsSize(); ++n3) {
                    if (CFG.game.getCiv(CFG.game.getWar(n).getAggressorID(n3).getCivID()).getNumOfProvinces() != 0 || CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getAggressorID((int)n3).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                    for (n2 = 0; n2 < CFG.game.getWar(n).getDefendersSize(); ++n2) {
                        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getDefenderID((int)n2).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                        serializable2 = CFG.game.getCiv((int)CFG.game.getWar((int)n).getDefenderID((int)n2).getCivID()).getCivilization_Diplomacy_GameData().messageBox;
                        serializable = new Message_WeCanSignPeace(CFG.game.getWar(n).getAggressorID(n3).getCivID());
                        serializable2.addMessage((Message)serializable);
                    }
                }
            }
            {
                n2 = CFG.game.getWar((int)n).iLastFight_InTunrs;
                n3 = CFG.game.getWar((int)n).wasAnyAttack ? 39 : 19;
                if (n2 > n3 || CFG.game.getWar((int)n).iLastTurn_ConqueredProvince < Game_Calendar.TURN_ID - 49 || CFG.game.getWar(n).getWarTurnID() < Game_Calendar.TURN_ID - (CFG.game.getCivsSize() + 299)) {
                    for (n3 = 0; n3 < CFG.game.getWar(n).getAggressorsSize(); ++n3) {
                        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getAggressorID((int)n3).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                        for (n2 = 0; n2 < CFG.game.getWar(n).getDefendersSize(); ++n2) {
                            if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getWar((int)n).getDefenderID((int)n2).getCivID()).getIdeologyID()).REVOLUTIONARY) continue;
                            serializable = CFG.game.getCiv((int)CFG.game.getWar((int)n).getDefenderID((int)n2).getCivID()).getCivilization_Diplomacy_GameData().messageBox;
                            serializable2 = new Message_WeCanSignPeace(CFG.game.getWar(n).getAggressorID(n3).getCivID());
                            ((MessageBox_GameData)serializable).addMessage((Message)serializable2);
                        }
                    }
                }
                ++n;
                continue;
            }
            break;
        }
    }

    /*
     * Exception decompiling
     */
    protected final boolean expandToNeutralProvinces_Out(int var1_1, boolean var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [27[UNCONDITIONALDOLOOP]], but top level block is 3[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final void expandToNeutralProvinces_Run(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_TYPE != CivArmyMission_Type.EXPAND_NETURAL_PROVINCE || !CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).action(n)) continue;
            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).onRemove();
            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(i);
        }
    }

    protected final int getAIStyle_ByTag(String string2) {
        for (int i = 0; i < this.lAI_Styles.size(); ++i) {
            if (!this.lAI_Styles.get((int)i).TAG.equals(string2)) continue;
            return i;
        }
        return 0;
    }

    protected final AI_Style getAI_Style(int n) {
        try {
            AI_Style aI_Style = this.lAI_Styles.get(n);
            return aI_Style;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (CFG.LOGS) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            return this.lAI_Styles.get(0);
        }
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_Clear(int n, int n2, int n3, boolean bl, boolean bl2, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        n = n3;
        n3 = 0;
        while (n > 0 && (bl2 || arrayList.size() > 0)) {
            int n4;
            arrayList2.clear();
            int n5 = n3 + 1;
            for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                block6: {
                    for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                        if (arrayList2.get(n4) != arrayList.get(n3)) continue;
                        n4 = 0;
                        break block6;
                    }
                    n4 = 1;
                }
                if (n4 == 0) continue;
                arrayList2.add(arrayList.get(n3));
            }
            arrayList.clear();
            for (n3 = arrayList2.size() - 1; n3 >= 0; --n3) {
                for (n4 = 0; n4 < CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvincesSize(); ++n4) {
                    if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n3)).intValue()).getNeighboringProvinces((int)n4)).was) continue;
                    list2.add(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4));
                    CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n3)).intValue()).getNeighboringProvinces((int)n4)).was = true;
                    if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4)).getCivID() != n2 || bl && CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4)).getCivID() != CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4)).getTrueOwnerOfProvince()) continue;
                    list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4), n5));
                    arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n3)).getNeighboringProvinces(n4));
                }
            }
            --n;
            n3 = n5;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_OnlyOwn_Clear(int n, int n2, int n3, boolean bl, boolean bl2, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n4 = 0;
        n = -1;
        while (n3 > 0) {
            int n5;
            int n6;
            arrayList2.clear();
            ++n4;
            for (n6 = arrayList.size() - 1; n6 >= 0; --n6) {
                block8: {
                    for (n5 = arrayList2.size() - 1; n5 >= 0; --n5) {
                        if (arrayList2.get(n5) != arrayList.get(n6)) continue;
                        n5 = 0;
                        break block8;
                    }
                    n5 = 1;
                }
                if (n5 == 0) continue;
                arrayList2.add(arrayList.get(n6));
            }
            arrayList.clear();
            for (n6 = arrayList2.size() - 1; n6 >= 0; --n6) {
                for (n5 = 0; n5 < CFG.game.getProvince((Integer)arrayList2.get(n6)).getNeighboringProvincesSize(); ++n5) {
                    int n7 = n;
                    if (!CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n6)).intValue()).getNeighboringProvinces((int)n5)).was) {
                        list2.add(CFG.game.getProvince((Integer)arrayList2.get(n6)).getNeighboringProvinces(n5));
                        CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n6)).intValue()).getNeighboringProvinces((int)n5)).was = true;
                        if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n6)).getNeighboringProvinces(n5)).getCivID() == n2) {
                            list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n6)).getNeighboringProvinces(n5), n4));
                            n = n4;
                        }
                        arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n6)).getNeighboringProvinces(n5));
                        n7 = n;
                    }
                    n = n7;
                }
            }
            if (n > 0 && n + 4 < n4) break;
            --n3;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_Recruit(int n, int n2, int n3, boolean bl, boolean bl2, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        n = 0;
        while (n3 > 0 && (bl2 || arrayList.size() > 0)) {
            int n4;
            arrayList2.clear();
            int n5 = n + 1;
            for (n = arrayList.size() - 1; n >= 0; --n) {
                block7: {
                    for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                        if (arrayList2.get(n4) != arrayList.get(n)) continue;
                        n4 = 0;
                        break block7;
                    }
                    n4 = 1;
                }
                if (n4 == 0) continue;
                arrayList2.add(arrayList.get(n));
            }
            arrayList.clear();
            for (n = arrayList2.size() - 1; n >= 0; --n) {
                for (n4 = 0; n4 < CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvincesSize(); ++n4) {
                    if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n)).intValue()).getNeighboringProvinces((int)n4)).was) continue;
                    list2.add(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4));
                    CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n)).intValue()).getNeighboringProvinces((int)n4)).was = true;
                    if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4)).getCivID() != n2) continue;
                    if (!CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4)).isOccupied() && CFG.game.getCiv(n2).isRecruitingArmyInProvinceID(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4)) < 0) {
                        list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4), n5));
                    }
                    arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n)).getNeighboringProvinces(n4));
                }
            }
            --n3;
            n = n5;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_RecruitAtWAr(int n, int n2, int n3, boolean bl, boolean bl2, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n4 = 0;
        int n5 = -1;
        int n6 = n3;
        while ((n4 < n6 || list.size() == 0) && arrayList.size() > 0) {
            arrayList2.clear();
            int n7 = n4 + 1;
            for (n = arrayList.size() - 1; n >= 0; --n) {
                block13: {
                    for (n3 = arrayList2.size() - 1; n3 >= 0; --n3) {
                        if (arrayList2.get(n3) != arrayList.get(n)) continue;
                        n3 = 0;
                        break block13;
                    }
                    n3 = 1;
                }
                if (n3 == 0) continue;
                arrayList2.add(arrayList.get(n));
            }
            arrayList.clear();
            n3 = n5;
            n = n6;
            for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                n5 = n3;
                n3 = n;
                n = n5;
                for (int i = 0; i < CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvincesSize(); ++i) {
                    block14: {
                        block15: {
                            n6 = n3;
                            n5 = n;
                            if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was) break block14;
                            list2.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                            CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was = true;
                            if (CFG.game.isAlly(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID())) break block15;
                            n6 = n3;
                            n5 = n;
                            if (CFG.game.getMilitaryAccess(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID()) <= 0) break block14;
                        }
                        n6 = n3;
                        n5 = n;
                        if (!CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).isOccupied()) {
                            n6 = n3;
                            n5 = n;
                            if (n2 == CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID()) {
                                n6 = n3;
                                n5 = n;
                                if (CFG.game.getCiv(n2).isRecruitingArmyInProvinceID(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)) < 0) {
                                    list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i), n7));
                                    n6 = n3;
                                    n5 = n;
                                    if (n < 0) {
                                        n6 = n3 + 4;
                                        n5 = n7;
                                    }
                                }
                            }
                        }
                        arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                    }
                    n3 = n6;
                    n = n5;
                }
                n5 = n;
                n = n3;
                n3 = n5;
            }
            n4 = n7;
            n6 = n;
            n5 = n3;
            if (n3 <= 0) continue;
            n4 = n7;
            n6 = n;
            n5 = n3;
            if (n3 + 8 >= n7) continue;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_Regroup_ForNavalInvasion(int n, int n2, int n3, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n4 = 0;
        int n5 = -1;
        while ((n4 < n3 || list.size() == 0) && arrayList.size() > 0) {
            arrayList2.clear();
            int n6 = n4 + 1;
            for (n = arrayList.size() - 1; n >= 0; --n) {
                block10: {
                    for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                        if (arrayList2.get(n4) != arrayList.get(n)) continue;
                        n4 = 0;
                        break block10;
                    }
                    n4 = 1;
                }
                if (n4 == 0) continue;
                arrayList2.add(arrayList.get(n));
            }
            arrayList.clear();
            n = n5;
            for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                for (int i = 0; i < CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvincesSize(); ++i) {
                    n5 = n;
                    if (!CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was) {
                        list2.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                        CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was = true;
                        n5 = n;
                        if (CFG.game.isAlly(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID())) {
                            n5 = n;
                            if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getArmyCivID(n2) > 0) {
                                list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i), n6));
                                n5 = n;
                                if (n < 0) {
                                    n5 = n6;
                                }
                            }
                            arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                        }
                    }
                    n = n5;
                }
            }
            n4 = n6;
            n5 = n;
            if (n <= 0) continue;
            n4 = n6;
            n5 = n;
            if (n + 2 >= n6) continue;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces_Army> getAllNeighboringProvincesInRange_WithArmyToRegroup(int n, int n2, int n3, boolean bl, boolean bl2, List<AI_NeighProvinces_Army> list, List<Integer> list2, int n4) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n5 = 0;
        n = 0;
        for (int i = n3; i > 0 && (bl2 || arrayList.size() > 0); --i) {
            arrayList2.clear();
            int n6 = n5 + 1;
            for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                block10: {
                    for (n5 = arrayList2.size() - 1; n5 >= 0; --n5) {
                        if (arrayList2.get(n5) != arrayList.get(n3)) continue;
                        n5 = 0;
                        break block10;
                    }
                    n5 = 1;
                }
                if (n5 == 0) continue;
                arrayList2.add(arrayList.get(n3));
            }
            arrayList.clear();
            for (n5 = arrayList2.size() - 1; n5 >= 0; --n5) {
                for (int j = 0; j < CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvincesSize(); ++j) {
                    block11: {
                        block12: {
                            n3 = n;
                            if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n5)).intValue()).getNeighboringProvinces((int)j)).was) break block11;
                            list2.add(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j));
                            CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n5)).intValue()).getNeighboringProvinces((int)j)).was = true;
                            n3 = n;
                            if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)).getCivID() != n2) break block11;
                            if (!bl) break block12;
                            n3 = n;
                            if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)).getCivID() != CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)).getTrueOwnerOfProvince()) break block11;
                        }
                        n3 = n;
                        if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)).getArmyCivID(n2) - CFG.game.getCiv((int)n2).civGameData.civPlans.haveMission_Army(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)) > 0) {
                            int n7 = CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j)).getArmyCivID(n2) - CFG.game.getCiv((int)n2).civGameData.civPlans.haveMission_Army(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j));
                            n3 = n + n7;
                            list.add(new AI_NeighProvinces_Army(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j), n6, n7));
                        }
                        arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(j));
                    }
                    n = n3;
                }
            }
            if (n >= n4) break;
            n5 = n6;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final int getLoadingTurnActionsOfCivID() {
        return this.iLoadingTurnActionsOfCivID;
    }

    protected final boolean prepareForWar_BordersWithEnemy(int n, int n2) {
        if (CFG.game.getProvince(n2).getBordersWithEnemy()) {
            for (int i = 0; i < CFG.game.getProvince(n2).getNeighboringProvincesSize(); ++i) {
                if (!CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID())) continue;
                return true;
            }
        }
        return this.prepareForWar_BordersWithEnemy_Just(n, n2);
    }

    protected final boolean prepareForWar_BordersWithEnemy_Just(int n, int n2) {
        for (int i = 0; i < CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize; ++i) {
            for (int j = 0; j < CFG.game.getProvince(n2).getNeighboringProvincesSize(); ++j) {
                if (CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(j)).getCivID() != CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)i).onCivID) continue;
                return true;
            }
        }
        return false;
    }

    protected final void resetNeutralProvincesWithSeaAccess() {
        this.lNeutralProvincesWithSeaAccess.clear();
        this.iNeutralProvincesWithSeaAccessSize = 0;
    }

    protected final void resetWastelandProvincesWithSeaAccess() {
        this.lWastelandProvincesWithSeaAccess.clear();
    }

    protected final void setLoadingTurnActionsOfCivID(int n) {
        this.iLoadingTurnActionsOfCivID = n;
    }

    /*
     * Exception decompiling
     */
    protected final void turnOrders() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 4[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final void updateExpand() {
        this.expandNeutral = !Game_Calendar.ENABLE_COLONIZATION_NEUTRAL_PROVINCES ? new Expand(){

            @Override
            public boolean expandToNeutralProvinces(int n) {
                return AI.this.expandToNeutralProvinces_Out(n, true);
            }
        } : new Expand(){

            @Override
            public boolean expandToNeutralProvinces(int n) {
                return false;
            }
        };
    }

    protected final void updateMinRivals() {
        this.MIN_NUM_OF_RIVALS = (int)Math.min(3.0, Math.ceil((float)(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME - 1) / 2.0f));
    }

    static interface Expand {
        public boolean expandToNeutralProvinces(int var1);
    }

    class NeutralProvinces {
        protected int iProvinceID;
        protected float iScore;

        protected NeutralProvinces(int n, int n2) {
            this.iProvinceID = n;
            this.buildScore(n2);
        }

        protected final void buildScore(int n) {
            int n2;
            int n3 = 0;
            int n4 = 0;
            int n5 = 0;
            for (n2 = 0; n2 < CFG.game.getProvince(this.iProvinceID).getNeighboringProvincesSize(); ++n2) {
                int n6 = n3;
                int n7 = n4;
                int n8 = n5;
                if (CFG.game.getProvince(CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(n2)).getWasteland() < 0) {
                    if (CFG.game.getProvince(CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(n2)).getCivID() == n) {
                        this.iScore = CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(n2) == CFG.game.getCiv(n).getCapitalProvinceID() ? (this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_CAPITAL) : (this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_OWN_PROVINCE);
                        n7 = n4 + 1;
                        n6 = n3;
                        n8 = n5;
                    } else if (CFG.game.getProvince(CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(n2)).getCivID() == 0) {
                        n6 = n3 + 1;
                        this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_MORE_NEUTRAL;
                        n7 = n4;
                        n8 = n5;
                    } else {
                        n8 = n5 + 1;
                        this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_OTHER_CIV;
                        n7 = n4;
                        n6 = n3;
                    }
                }
                n3 = n6;
                n4 = n7;
                n5 = n8;
            }
            this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_GROWTH_RATE * CFG.game.getProvince(this.iProvinceID).getGrowthRate_Population();
            if (CFG.game.getProvince(this.iProvinceID).getNeighboringSeaProvincesSize() > 0) {
                this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_SEA_ACCESS + CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_SEA_ACCESS_EXTRA * (float)CFG.game.getProvince(this.iProvinceID).getNeighboringSeaProvincesSize();
            }
            float f = this.iScore;
            float f2 = CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_NEIGHBORING_PROVINCES;
            n2 = n4 + n3;
            float f3 = n5 + n2;
            this.iScore = f + f2 * f3;
            this.iScore += (float)((int)(CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_NEIGHBORING_PROVINCES_POTENITAL * (float)n2 / f3));
            if (n3 == 0 && CFG.game.getProvince(this.iProvinceID).getNeighboringProvincesSize() > 0) {
                this.iScore += CFG.game.getCiv((int)n).civGameData.civPersonality.NEUTRAL_EXPAND_LAST_PROVINCE;
            } else if (n4 <= 1) {
                this.iScore *= 0.725f;
            }
        }
    }
}

