/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Message_Type;
import java.io.Serializable;

class Civilization_SentMessages
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iSentInTurnID;
    protected int iToCivID;
    protected Message_Type messageType = Message_Type.GIFT;

    protected Civilization_SentMessages(int n, Message_Type message_Type) {
        this.iToCivID = n;
        this.messageType = message_Type;
        this.iSentInTurnID = Game_Calendar.TURN_ID;
    }
}

