/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Technology
extends Button_Build {
    protected static final float FONTSIZE2 = 0.6f;
    protected int iCivID;
    protected int iDateWidth;
    protected int iEconomyWidth;
    protected int iPointsWidth;
    protected Color oColor = Color.WHITE;
    protected String sDate;
    protected String sEconomy;
    protected String sPoints;
    protected String sProvinceName;

    protected Button_Technology(int n, int n2, int n3, int n4) {
        super(CFG.game.getCiv(n).getCivName(), Images.technology, 0, 0, n2, n3, n4, true, false, 0, 0.0f);
        this.iCivID = n;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("TechnologyLevel"));
        stringBuilder.append(": ");
        this.sDate = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sDate);
        this.iDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((float)((int)(CFG.game.getCiv(n).getTechnologyLevel() * 100.0f)) / 100.0f);
        this.sEconomy = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sEconomy);
        this.iEconomyWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.setMin(CFG.game.getCiv((int)n).civGameData.skills.getPointsLeft(n));
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("PointsLeft"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sPoints, this.oColor));
        stringBuilder = new StringBuilder();
        stringBuilder.append("/");
        stringBuilder.append((int)(CFG.game.getCiv(this.iCivID).getTechnologyLevel() * 100.0f));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.technology, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sEconomy, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_TECHNOLOGY);
        ImageManager.getImage(Images.technology).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + this.iEconomyWidth + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 - ImageManager.getImage(Images.technology).getHeight() + n2, (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology, 0.6f)), (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology, 0.6f)));
        CFG.fontMain.getData().setScale(1.0f);
        ImageManager.getImage(Images.technology).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - ImageManager.getImage(Images.technology).getWidth() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.technology).getHeight() / 2 + n2);
        CFG.drawTextWithShadow(spriteBatch, this.sPoints, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - ImageManager.getImage(Images.technology).getWidth() - this.iPointsWidth + n, this.getPosY() + this.getHeight() / 2 - CFG.TEXT_HEIGHT / 2 + n2, this.oColor);
    }

    @Override
    protected void setMin(int n) {
        Object object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(n);
        this.sPoints = ((StringBuilder)object).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sPoints);
        this.iPointsWidth = (int)CFG.glyphLayout.width;
        object = n > 0 ? CFG.COLOR_TEXT_NUM_OF_PROVINCES : CFG.COLOR_TEXT_MODIFIER_NEUTRAL;
        this.oColor = object;
    }
}

