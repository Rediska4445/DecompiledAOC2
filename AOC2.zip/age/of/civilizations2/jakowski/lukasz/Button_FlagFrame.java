/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_FlagFrame
extends Button {
    protected Button_FlagFrame(int n, int n2, boolean bl) {
        super.init("", 0, n, n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight(), bl, true, false, false, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        this.getFlag().draw(spriteBatch, this.getPosX() + n, this.getPosY() - this.getFlag().getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
        if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.0375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.425f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.top_flag_frame).getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight() + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5, false, true);
            spriteBatch.setColor(Color.WHITE);
        }
        if (bl) {
            ImageManager.getImage(Images.top_flag_frame_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
        } else {
            ImageManager.getImage(Images.top_flag_frame).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
        }
        try {
            Color color2 = new Color((float)CFG.game.getCiv(CFG.getActiveCivInfo()).getR() / 255.0f, (float)CFG.game.getCiv(CFG.getActiveCivInfo()).getG() / 255.0f, (float)CFG.game.getCiv(CFG.getActiveCivInfo()).getB() / 255.0f, 0.725f);
            spriteBatch.setColor(color2);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)CFG.PADDING * 1.25f), ImageManager.getImage(Images.top_flag_frame).getHeight() - 2);
            color2 = new Color(0.0f, 0.0f, 0.0f, 0.45f);
            spriteBatch.setColor(color2);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)CFG.PADDING * 1.25f), 1);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() + n, this.getPosY() + ImageManager.getImage(Images.top_flag_frame).getHeight() - 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)CFG.PADDING * 1.25f), 1);
            spriteBatch.setColor(CFG.COLOR_FLAG_FRAME);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)CFG.PADDING * 1.25f), 1);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() + n, this.getPosY() + ImageManager.getImage(Images.top_flag_frame).getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)CFG.PADDING * 1.25f), 1);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.941f, 1.0f, 0.0f, 1.0f) : (this.getClickable() ? new Color(0.376f, 0.388f, 0.376f, 1.0f) : new Color(0.674f, 0.09f, 0.066f, 0.5f));
        return color2;
    }

    protected Image getFlag() {
        return CFG.getActiveCivFlag();
    }
}

