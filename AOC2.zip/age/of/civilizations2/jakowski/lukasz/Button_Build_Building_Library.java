/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build_Building;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Build_Building_Library
extends Button_Build_Building {
    protected int iProvinceNameWidth;
    protected int iResearchWidth;
    protected String sPerTurn;
    protected String sResearch;

    protected Button_Build_Building_Library(String charSequence, String string2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        super((String)charSequence, string2, n, n2, n3, n4, n5, n6);
        CFG.glyphLayout.setText(CFG.fontMain, this.sProvinceName);
        this.iProvinceNameWidth = (int)(CFG.glyphLayout.width * 0.7f);
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("+");
        ((StringBuilder)charSequence).append(n7);
        this.sResearch = ((StringBuilder)charSequence).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sResearch);
        this.iResearchWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.sPerTurn = CFG.langManager.get("PerTurn");
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        if (this.sCost.length() > 0 && this.sMovementCost.length() > 0) {
            Color color2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            int n9;
            int n10;
            int n11;
            String string2;
            if (this.sCost.length() > 0) {
                ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)) - ImageManager.getImage(Images.top_gold).getHeight() - CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                string2 = this.sCost;
                n11 = this.getPosX();
                n10 = this.getWidth();
                n9 = CFG.PADDING;
                n8 = (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f));
                n7 = CFG.PADDING;
                n6 = this.iCostWidth;
                n5 = this.getPosY();
                n4 = this.getHeight() / 2;
                int n12 = CFG.PADDING / 2;
                n3 = (int)((float)this.getTextHeight() * 0.6f);
                color2 = this.canBuild_MoneyCost ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                CFG.drawTextWithShadow(spriteBatch, string2, n11 + n10 - n9 * 2 - n8 - n7 - n6 + n, n5 + n4 - n12 - n3 + n2, color2);
            }
            if (this.sMovementCost.length() > 0) {
                ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_movement_points).getHeight() + CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                string2 = this.sMovementCost;
                n7 = this.getPosX();
                n6 = this.getWidth();
                n8 = CFG.PADDING;
                n5 = this.iMovementCostWidth;
                n11 = (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f));
                n9 = CFG.PADDING;
                n10 = this.getPosY();
                n4 = this.getHeight() / 2;
                n3 = CFG.PADDING / 2;
                color2 = this.canBuild_Movement ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE;
                CFG.drawTextWithShadow(spriteBatch, string2, n7 + n6 - n8 * 2 - n5 - n11 - n9 + n, n10 + n4 + n3 + n2, color2);
            }
        } else if (this.sMovementCost.length() > 0) {
            ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_movement_points).getHeight() - (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)));
            CFG.fontMain.getData().setScale(0.6f);
            String string3 = this.sMovementCost;
            int n13 = this.getPosX();
            int n14 = this.getWidth();
            int n15 = CFG.PADDING;
            int n16 = this.iMovementCostWidth;
            int n17 = (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f));
            int n18 = CFG.PADDING;
            int n19 = this.getPosY();
            int n20 = this.getHeight() / 2;
            int n21 = (int)((float)this.getTextHeight() * 0.6f) / 2;
            Color color3 = this.canBuild_Movement ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE;
            CFG.drawTextWithShadow(spriteBatch, string3, n13 + n14 - n15 * 2 - n16 - n17 - n18 + n, n19 + n20 - n21 + n2, color3);
        }
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sProvinceName, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        CFG.drawTextWithShadow(spriteBatch, this.sResearch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iProvinceNameWidth + CFG.PADDING + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_RESEARCH);
        ImageManager.getImage(Images.research).draw(spriteBatch, this.getPosX() + CFG.PADDING + CFG.PADDING / 2 + this.iResearchWidth + Button_Diplomacy.iDiploWidth + this.iProvinceNameWidth + CFG.PADDING + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) / 2 - (int)((float)ImageManager.getImage(Images.research).getHeight() * this.getImageScale(Images.research, 0.7f)) / 2 - ImageManager.getImage(Images.research).getHeight() - CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.research).getWidth() * this.getImageScale(Images.research, 0.7f)), (int)((float)ImageManager.getImage(Images.research).getHeight() * this.getImageScale(Images.research, 0.7f)));
        CFG.drawTextWithShadow(spriteBatch, this.sPerTurn, this.getPosX() + CFG.PADDING * 2 + this.iResearchWidth + (int)((float)ImageManager.getImage(Images.research).getWidth() * this.getImageScale(Images.research, 0.7f)) + Button_Diplomacy.iDiploWidth + this.iProvinceNameWidth + CFG.PADDING + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sEconomy, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, this.oColor);
        ImageManager.getImage(Images.technology).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + this.iEconomyWidth + Button_Diplomacy.iDiploWidth + this.iDateWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 - ImageManager.getImage(Images.technology).getHeight() + n2, (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology, 0.6f)), (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology, 0.6f)));
        CFG.fontMain.getData().setScale(1.0f);
    }
}

