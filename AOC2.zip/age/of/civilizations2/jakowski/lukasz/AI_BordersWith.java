/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_BordersWith {
    protected int iNumOfConnections = 0;
    protected int iWithCivID;

    protected AI_BordersWith(int n) {
        this.iWithCivID = n;
        this.iNumOfConnections = 1;
    }

    protected AI_BordersWith(int n, int n2) {
        this.iWithCivID = n;
        this.iNumOfConnections = n2;
    }
}

