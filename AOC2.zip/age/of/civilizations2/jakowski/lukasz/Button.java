/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button
extends MenuElement {
    protected boolean checkbox = false;
    private boolean checkboxState = false;
    protected int iTextHeight;
    protected int iTextPositionX;
    protected int iTextWidth = -1;
    private Checkbox oCheckbox;
    protected String sText = null;
    protected TextPosition textPosition;
    protected TypeOfButton typeOfButton;

    Button() {
    }

    protected Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.25f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.25f));
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button.this.getPosX() + n, Button.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button.this.getWidth() / 4, Button.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button.this.getPosX() + n, Button.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button.this.getWidth(), Button.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button.this.getPosX() + n, Button.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button.this.getHeight() - 1 + n2 - Button.this.getHeight() / 4, Button.this.getWidth(), Button.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected final void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
        if (this.getClickable()) {
            this.drawButtonBG(spriteBatch, n, n2, bl);
        } else {
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.45f);
            this.drawButtonBG(spriteBatch, n, n2, bl);
            spriteBatch.setColor(Color.WHITE);
        }
        this.oCheckbox.drawCheckBox(spriteBatch, n, n2, bl2);
        this.drawText(spriteBatch, n, n2, bl);
    }

    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.textPosition.getTextPosition() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.textPosition.getTextPosition() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        }
    }

    @Override
    protected boolean getCheckboxState() {
        return this.checkboxState;
    }

    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? new Color(0.38f, 0.38f, 0.38f, 1.0f) : new Color(0.49f, 0.49f, 0.49f, 0.5f));
        return color2;
    }

    @Override
    protected String getText() {
        return this.sText;
    }

    @Override
    protected int getTextHeight() {
        return this.iTextHeight;
    }

    @Override
    protected int getTextPos() {
        return this.iTextPositionX;
    }

    @Override
    protected String getTextToDraw() {
        return this.sText;
    }

    @Override
    protected int getTextWidth() {
        return this.iTextWidth;
    }

    protected final void init(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        this.init(string2, n, n2, n3, n4, n5, bl, bl2, bl3, bl4, null);
    }

    protected final void init(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2, boolean bl3, boolean bl4, TypeOfButton typeOfButton) {
        this.typeOfElement = MenuElement.TypeOfElement.BUTTON;
        this.setPosX(n2);
        this.setPosY(n3);
        this.setWidth(n4);
        this.setHeight(n5);
        this.setText(string2);
        this.iTextPositionX = n;
        this.textPosition = n < 0 ? new TextPosition(){

            @Override
            public int getTextPosition() {
                return Button.this.getWidth() / 2 - Button.this.getTextWidth() / 2;
            }
        } : new TextPosition(){

            @Override
            public int getTextPosition() {
                return Button.this.iTextPositionX;
            }
        };
        this.checkbox = bl3;
        this.checkboxState = bl4;
        this.oCheckbox = this.buildCheckbox();
        this.setClickable(bl);
        this.setVisible(bl2);
        this.typeOfButton = typeOfButton;
    }

    protected final void setCheckbox(boolean bl) {
        this.checkbox = bl;
    }

    @Override
    protected final void setCheckboxState(boolean bl) {
        this.checkboxState = bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public void setText(String var1_1) {
        this.sText = var1_1;
        if (var1_1 == null) ** GOTO lbl8
        try {
            CFG.glyphLayout.setText(CFG.fontMain, this.getText());
            this.iTextWidth = (int)CFG.glyphLayout.width;
            this.iTextHeight = (int)CFG.glyphLayout.height;
            return;
lbl8:
            // 1 sources

            this.iTextHeight = 0;
            this.iTextWidth = 0;
            return;
        }
        catch (IllegalArgumentException var1_2) {
            if (CFG.LOGS == false) return;
            CFG.exceptionStack(var1_2);
            return;
        }
        catch (NullPointerException var1_3) {
            if (CFG.LOGS == false) return;
            CFG.exceptionStack(var1_3);
            return;
        }
        catch (IndexOutOfBoundsException var1_4) {
            if (CFG.LOGS == false) return;
            CFG.exceptionStack(var1_4);
        }
    }

    @Override
    protected void setTypeOfButton(TypeOfButton typeOfButton) {
        this.typeOfButton = typeOfButton;
    }

    static interface Checkbox {
        public void drawCheckBox(SpriteBatch var1, int var2, int var3, boolean var4);
    }

    static interface TextPosition {
        public int getTextPosition();
    }

    protected static enum TypeOfButton {
        KEYBOARD,
        KEYBOARD_NUM,
        KEYBOARD_ACTIVE,
        KEYBOARD_SAVE,
        KEYBOARD_OPTIONS;

    }
}

