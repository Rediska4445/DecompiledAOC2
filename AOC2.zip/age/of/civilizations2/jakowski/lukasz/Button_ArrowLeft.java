/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_ArrowLeft
extends Button {
    protected Button_ArrowLeft(int n, int n2, int n3, int n4) {
        super.init("", 0, n, n2, n3, n4, true, true, false, false, null);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.75f));
            ImageManager.getImage(Images.btn_up).draw(spriteBatch, this.getPosX() + ImageManager.getImage(Images.btn_up).getHeight() / 2 + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_up).getWidth() / 2 - ImageManager.getImage(Images.btn_up).getHeight() + n2, ImageManager.getImage(Images.btn_up).getWidth(), ImageManager.getImage(Images.btn_up).getHeight(), 270.0f);
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_up).draw(spriteBatch, this.getPosX() + ImageManager.getImage(Images.btn_up).getHeight() / 2 + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_up).getWidth() / 2 - ImageManager.getImage(Images.btn_up).getHeight() + n2, ImageManager.getImage(Images.btn_up).getWidth(), ImageManager.getImage(Images.btn_up).getHeight(), 270.0f);
        }
    }
}

