/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_RTO_Player;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_RTO_Player_Info
extends Button_RTO_Player {
    protected Button_RTO_Player_Info(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super(n, n2, n3, n4, n5, n6, bl);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() / 2 + n2);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        CFG.drawText(spriteBatch, this.getText(), this.getTextPos() + this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.TEXT_HEIGHT / 2 + n2, CFG.COLOR_TEXT_CIV_NAME);
    }
}

