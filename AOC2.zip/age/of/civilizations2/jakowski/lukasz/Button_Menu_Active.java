/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_Active
extends Button_Menu {
    protected Button_Menu_Active(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            String string2 = this.getTextToDraw();
            int n3 = this.getPosX();
            int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - this.getTextWidth() / 2 : this.getTextPos();
            CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - this.getTextHeight() / 2 + n2, this.getColor(bl));
        } else {
            String string3 = this.getTextToDraw();
            int n5 = this.getPosX();
            int n6 = this.getTextPos() < 0 ? this.getWidth() / 2 - this.getTextWidth() / 2 : this.getTextPos();
            CFG.drawText(spriteBatch, string3, n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - this.getTextHeight() / 2 + n2, this.getColor(bl));
        }
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? (this.getClickable() ? new Color(0.82f, 0.82f, 0.82f, 1.0f) : new Color(0.78f, 0.78f, 0.78f, 0.7f)) : new Color(0.1f, 0.1f, 0.1f, 1.0f);
        return color2;
    }
}

