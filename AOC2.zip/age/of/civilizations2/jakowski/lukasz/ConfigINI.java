/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.GdxRuntimeException;

class ConfigINI {
    protected static boolean fullscreen = true;
    protected static int iHeight = -1;
    protected static int iSamples = -1;
    protected static int iUIScale = -1;
    protected static int iWidth = -1;
    protected static boolean landscape = true;
    protected static boolean vSync;

    ConfigINI() {
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void readConfig() {
        String[] arrstring = Gdx.files.local("config.ini").readString().replace("\n", "").split(";");
        int n = 0;
        while (n < arrstring.length) {
            String[] arrstring2 = arrstring[n].split("=");
            try {
                if (arrstring2[0].equals("FULLSCREEN")) {
                    fullscreen = Boolean.parseBoolean(arrstring2[1]);
                } else if (arrstring2[0].equals("WIDTH")) {
                    iWidth = Integer.parseInt(arrstring2[1]);
                } else if (arrstring2[0].equals("HEIGHT")) {
                    iHeight = Integer.parseInt(arrstring2[1]);
                } else if (arrstring2[0].equals("ANTIALIASING")) {
                    iSamples = Integer.parseInt(arrstring2[1]);
                } else if (arrstring2[0].equals("VSYNC")) {
                    vSync = Boolean.parseBoolean(arrstring2[1]);
                } else if (arrstring2[0].equals("LANDSCAPE")) {
                    landscape = Boolean.parseBoolean(arrstring2[1]);
                } else if (arrstring2[0].equals("UISCALE")) {
                    iUIScale = Integer.parseInt(arrstring2[1]);
                }
                ++n;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                iWidth = -1;
                iHeight = -1;
                fullscreen = true;
                iSamples = -1;
                vSync = false;
                landscape = true;
                iUIScale = -1;
                return;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                iWidth = -1;
                iHeight = -1;
                fullscreen = true;
                iSamples = -1;
                vSync = false;
                landscape = true;
                iUIScale = -1;
                return;
                {
                    catch (GdxRuntimeException gdxRuntimeException) {
                        if (!CFG.LOGS) return;
                        CFG.exceptionStack(gdxRuntimeException);
                        return;
                    }
                }
            }
        }
        return;
    }

    protected static final void saveConfig() {
        FileHandle fileHandle = Gdx.files.local("config.ini");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FULLSCREEN=");
        stringBuilder.append(fullscreen);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), false);
        stringBuilder = new StringBuilder();
        stringBuilder.append("WIDTH=");
        stringBuilder.append(iWidth);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), true);
        stringBuilder = new StringBuilder();
        stringBuilder.append("HEIGHT=");
        stringBuilder.append(iHeight);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), true);
        stringBuilder = new StringBuilder();
        stringBuilder.append("ANTIALIASING=");
        stringBuilder.append(iSamples);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), true);
        stringBuilder = new StringBuilder();
        stringBuilder.append("VSYNC=");
        stringBuilder.append(vSync);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), true);
        stringBuilder = new StringBuilder();
        stringBuilder.append("LANDSCAPE=");
        stringBuilder.append(landscape);
        stringBuilder.append(";\n");
        fileHandle.writeString(stringBuilder.toString(), true);
        stringBuilder = new StringBuilder();
        stringBuilder.append("UISCALE=");
        stringBuilder.append(iUIScale);
        stringBuilder.append(";");
        fileHandle.writeString(stringBuilder.toString(), true);
    }
}

