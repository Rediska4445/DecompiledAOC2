/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Difficulty_Level
extends MenuElement {
    protected static final Color COLOR_BG = new Color(0.05490196f, 0.07450981f, 0.11764706f, 1.0f);
    protected static final Color COLOR_BG_DIFF = new Color(0.039215688f, 0.047058824f, 0.06666667f, 1.0f);
    private float fPercentage = 1.0f;
    protected int iCurrentPosX = 0;
    private long lTime = 0L;

    protected Difficulty_Level(int n, int n2, int n3, int n4, float f) {
        this.setPosX(n);
        this.setPosY(n2);
        this.setWidth(n3);
        this.setHeight(n4);
        this.fPercentage = f;
        this.updateSlider(-1);
        this.lTime = System.currentTimeMillis();
        this.typeOfElement = MenuElement.TypeOfElement.BUTTON;
    }

    @Override
    protected void draw(SpriteBatch spriteBatch, int n, int n2, boolean bl, boolean bl2) {
        if (System.currentTimeMillis() < this.lTime + 425L) {
            this.iCurrentPosX = (int)((float)this.getWidth() * this.fPercentage * ((float)(System.currentTimeMillis() - this.lTime) / 425.0f));
            this.iCurrentPosX = (int)Math.min((float)this.iCurrentPosX, (float)this.getWidth() * this.fPercentage);
            CFG.setRender_3(true);
        } else {
            this.iCurrentPosX = (int)((float)this.getWidth() * this.fPercentage);
        }
        spriteBatch.setColor(COLOR_BG);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(COLOR_BG_DIFF);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - 1 + n2, this.iCurrentPosX, this.getHeight());
        spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.iCurrentPosX + n, this.getPosY() + 2 + n2, 1, this.getHeight() - 4);
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.difficulty_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.difficulty_box).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.difficulty_box).getWidth(), this.getHeight() - ImageManager.getImage(Images.difficulty_box).getHeight());
        ImageManager.getImage(Images.difficulty_box).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.difficulty_box).getWidth() + n, this.getPosY() - ImageManager.getImage(Images.difficulty_box).getHeight() + n2, ImageManager.getImage(Images.difficulty_box).getWidth(), this.getHeight() - ImageManager.getImage(Images.difficulty_box).getHeight(), true);
        ImageManager.getImage(Images.difficulty_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.difficulty_box).getHeight() * 2 + n2, this.getWidth() - ImageManager.getImage(Images.difficulty_box).getWidth(), ImageManager.getImage(Images.difficulty_box).getHeight(), false, true);
        ImageManager.getImage(Images.difficulty_box).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.difficulty_box).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.difficulty_box).getHeight() + n2, true, true);
    }

    @Override
    protected int getCurrent() {
        return (int)(this.fPercentage * 100.0f);
    }

    @Override
    protected void setCurrent(int n) {
        this.fPercentage = (float)n / 100.0f;
        this.lTime = System.currentTimeMillis();
    }
}

