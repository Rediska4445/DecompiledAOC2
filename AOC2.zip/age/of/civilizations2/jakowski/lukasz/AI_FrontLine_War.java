/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Frontline;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game;
import java.util.List;

class AI_FrontLine_War {
    protected int i;
    protected int iFrontArmy = 0;
    protected int iNeighboringProvincesLostScore;

    protected AI_FrontLine_War(int n, int n2) {
        this.i = n2;
        this.iFrontArmy = this.getFrontLineArmy(n);
        this.iNeighboringProvincesLostScore = this.getNeighboringProvincesLostScore(n);
    }

    protected boolean canRecruitArmy_FrontLine(int n) {
        List<List<AI_Frontline>> list = CFG.oAI.lFrontLines;
        int n2 = n - 1;
        for (n = list.get((int)n2).get((int)this.i).lProvinces.size() - 1; n >= 0; --n) {
            if (CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n2).get((int)this.i).lProvinces.get(n)).isOccupied()) continue;
            return true;
        }
        return false;
    }

    protected final int getEnemyRating(int n, int n2) {
        return (int)((float)CFG.game.getCiv(n2).getNumOfUnits() * 1.5f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final int getEnemyRegion_NumOfProvinces(int n) {
        int n2;
        Game game = CFG.game;
        List<List<AI_Frontline>> list = CFG.oAI.lFrontLines;
        int n3 = n - 1;
        try {
            n2 = game.getProvince(list.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvincesSize();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return 1;
        }
        while (n2 >= 0) {
            if (CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n2)).getCivID() == this.getWithCivID(n)) {
                return CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n2)).getRegion_NumOfProvinces();
            }
            --n2;
        }
        return 1;
    }

    protected final int getEnemyRegion_NumOfRegions(int n) {
        try {
            n = CFG.game.getCiv(this.getWithCivID(n)).getCivRegionsSize();
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return 1;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final int getEnemyRegion_Potential(int n) {
        int n2;
        Game game = CFG.game;
        List<List<AI_Frontline>> list = CFG.oAI.lFrontLines;
        int n3 = n - 1;
        try {
            n2 = game.getProvince(list.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvincesSize();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return 1;
        }
        while (n2 >= 0) {
            if (CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n2)).getCivID() == this.getWithCivID(n)) {
                return CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n3).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n2)).getPotentialRegion();
            }
            --n2;
        }
        return 1;
    }

    protected final int getFrontArmy(int n) {
        return CFG.oAI.lFrontLines.get(n - 1).get(this.i).getFrontLineArmy(n);
    }

    protected final int getFrontLineArmy(int n) {
        return CFG.oAI.lFrontLines.get(n - 1).get(this.i).getFrontLineArmy(n);
    }

    protected final int getFrontScore(int n) {
        int n2 = this.iNeighboringProvincesLostScore;
        int n3 = 0;
        if (CFG.game.getCiv(n).getNumOfUnits() < this.getEnemyRating(n, this.getWithCivID(n))) {
            n3 = 20;
        }
        return n2 + 0 + n3;
    }

    protected final int getImportance_OurRegion(int n) {
        try {
            n = CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)(n - 1)).get((int)this.i).lProvinces.get(0)).getPotentialRegion();
            return n;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final int getImportance_Region_NumOfProvinces(int n) {
        int n2;
        List<List<AI_Frontline>> list;
        Game game;
        try {
            game = CFG.game;
            list = CFG.oAI.lFrontLines;
            n2 = n - 1;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        {
            int n3 = game.getProvince(list.get((int)n2).get((int)this.i).lProvinces.get(0)).getNeighboringProvincesSize();
            while (n3 >= 0) {
                if (CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n2).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n3)).getCivID() == this.getWithCivID(n)) {
                    return CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n2).get((int)this.i).lProvinces.get(0)).getNeighboringProvinces(n3)).getRegion_NumOfProvinces();
                }
                --n3;
            }
            return CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n2).get((int)this.i).lProvinces.get(0)).getRegion_NumOfProvinces();
        }
    }

    protected final int getNeighboringProvincesLostScore(int n) {
        List<List<AI_Frontline>> list = CFG.oAI.lFrontLines;
        int n2 = n - 1;
        n = 0;
        for (int i = list.get((int)n2).get((int)this.i).lProvinces.size() - 1; i >= 0; --i) {
            int n3 = n;
            if (CFG.game.getProvince(CFG.oAI.lFrontLines.get((int)n2).get((int)this.i).lProvinces.get(i)).getNeighbooringProvinceOfCivWasLost() > 0) {
                n3 = n + 1;
            }
            n = n3;
        }
        return n;
    }

    protected final int getWithCivID(int n) {
        return CFG.oAI.lFrontLines.get((int)(n - 1)).get((int)this.i).iWithCivID;
    }
}

