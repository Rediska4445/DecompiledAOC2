/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;

class Age {
    protected float AGE_ASSIMILATE_RATE;
    protected int BASE_DIPLOMACY_POINTS;
    protected float BASE_INCOME_PRODUCTION;
    protected float BASE_INCOME_TAXATION = 0.004654f;
    protected float BASE_MILITARY_UPKEEP;
    protected int BASE_MOVEMENT_POINTS = 20;
    protected int COLONIZE_COST_DIPLOMACY_POINTS;
    protected float COLONIZE_COST_GOLD_PERC;
    protected int COLONIZE_COST_MOVEMENT_POINTS;
    protected float COMMERCE_RANGE;
    protected float CONTROL_RANGE;
    protected float DEVELOPMENT_LEVEL_INCREASE = 1.0f;
    protected int DIPLOMACY_ALLIANCE_PROPOSAL_NAGATIVE_DISTANCE;
    protected float DIPLOMACY_RANGE;
    protected float DISEASE_CHANCE;
    protected float EXPENSES_ADMINSTRATION_DISTANCE;
    protected float EXPENSES_ADMINSTRATION_MODIFIER;
    protected float EXPENSES_MILITARY_UPKEEP_MODIFIER;
    protected float FOG_OF_WAR_DISCOVERY_MET_PROVINCES = 1.0f;
    protected int GAME_DAYS_PER_TURN;
    protected float GAME_STARTING_DEVELOPMENT;
    protected float INCOME_MODIFIER;
    protected float INCOME_PRODUCTIONN_PER_DEVELOPMENT_MODIFIER;
    protected float INCOME_PRODUCTION_MODIFIER;
    protected float INCOME_TAXATION_MODIFIER;
    protected float INCOME_TAXATION_PER_TECHNOLOGY_MODIFIER;
    protected int MAX_POPULATION;
    protected float MOVEMENT_POINTS_MODIFIER;
    protected int REBELS_ARMY;
    protected float REVOLUTIONARY_RISK_MODIFIER;
    protected int START_ECONOMY;
    protected int START_POPULATION;
    protected int TECH_COST;
    protected int TECH_MAX;
    protected int TECH_STANDARD;
    protected int WAR_SCORE_RATE;
    private float fEconomyGrowthRate;
    private float fPopulationGrowthRate;
    private int iAgeBeginningYear;
    private int iAgeEndYear;
    private String sName;

    protected Age(String string2, int n, int n2, float f, float f2) {
        this.DIPLOMACY_RANGE = 1.0f;
        this.COMMERCE_RANGE = 1.0f;
        this.CONTROL_RANGE = 1.0f;
        this.INCOME_TAXATION_MODIFIER = 1.0f;
        this.INCOME_MODIFIER = 1.0f;
        this.AGE_ASSIMILATE_RATE = 1.0f;
        this.INCOME_PRODUCTION_MODIFIER = 1.0f;
        this.EXPENSES_ADMINSTRATION_MODIFIER = 1.0f;
        this.EXPENSES_MILITARY_UPKEEP_MODIFIER = 1.0f;
        this.MOVEMENT_POINTS_MODIFIER = 1.0f;
        this.BASE_DIPLOMACY_POINTS = 10;
        this.EXPENSES_ADMINSTRATION_DISTANCE = 3.5f;
        this.DIPLOMACY_ALLIANCE_PROPOSAL_NAGATIVE_DISTANCE = 350;
        this.INCOME_TAXATION_PER_TECHNOLOGY_MODIFIER = 4.1254E-4f;
        this.BASE_MILITARY_UPKEEP = 0.109189f;
        this.GAME_STARTING_DEVELOPMENT = 0.44215f;
        this.GAME_DAYS_PER_TURN = 34;
        this.BASE_INCOME_PRODUCTION = 0.015954f;
        this.INCOME_PRODUCTIONN_PER_DEVELOPMENT_MODIFIER = 0.0015456f;
        this.REVOLUTIONARY_RISK_MODIFIER = 1.0f;
        this.DISEASE_CHANCE = 0.05f;
        this.COLONIZE_COST_MOVEMENT_POINTS = 16;
        this.START_POPULATION = 16;
        this.START_ECONOMY = 16;
        this.MAX_POPULATION = 16;
        this.TECH_STANDARD = 16;
        this.TECH_MAX = 16;
        this.TECH_COST = 16;
        this.COLONIZE_COST_DIPLOMACY_POINTS = 14;
        this.COLONIZE_COST_GOLD_PERC = 0.1675f;
        this.sName = CFG.langManager.get(string2);
        this.iAgeBeginningYear = n;
        this.iAgeEndYear = n2;
        this.fPopulationGrowthRate = f;
        this.fEconomyGrowthRate = f2;
    }

    protected Age(String string2, int n, int n2, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n3, float f9, int n4, float f10, int n5, float f11, float f12, float f13, float f14, int n6, float f15, float f16, float f17, float f18, float f19, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15, int n16, float f20, float f21, float f22, float f23, float f24) {
        this.INCOME_TAXATION_MODIFIER = 1.0f;
        this.INCOME_MODIFIER = 1.0f;
        this.AGE_ASSIMILATE_RATE = 1.0f;
        this.INCOME_PRODUCTION_MODIFIER = 1.0f;
        this.EXPENSES_ADMINSTRATION_MODIFIER = 1.0f;
        this.EXPENSES_MILITARY_UPKEEP_MODIFIER = 1.0f;
        this.MOVEMENT_POINTS_MODIFIER = 1.0f;
        this.BASE_DIPLOMACY_POINTS = 10;
        this.EXPENSES_ADMINSTRATION_DISTANCE = 3.5f;
        this.DIPLOMACY_ALLIANCE_PROPOSAL_NAGATIVE_DISTANCE = 350;
        this.INCOME_TAXATION_PER_TECHNOLOGY_MODIFIER = 4.1254E-4f;
        this.BASE_MILITARY_UPKEEP = 0.109189f;
        this.GAME_STARTING_DEVELOPMENT = 0.44215f;
        this.GAME_DAYS_PER_TURN = 34;
        this.MAX_POPULATION = 34;
        this.TECH_STANDARD = 34;
        this.TECH_MAX = 34;
        this.TECH_COST = 34;
        this.START_POPULATION = 34;
        this.START_ECONOMY = 34;
        this.BASE_INCOME_PRODUCTION = 0.015954f;
        this.INCOME_PRODUCTIONN_PER_DEVELOPMENT_MODIFIER = 0.0015456f;
        this.REVOLUTIONARY_RISK_MODIFIER = 1.0f;
        this.DISEASE_CHANCE = 0.05f;
        this.COLONIZE_COST_MOVEMENT_POINTS = 16;
        this.COLONIZE_COST_DIPLOMACY_POINTS = 14;
        this.COLONIZE_COST_GOLD_PERC = 0.1675f;
        this.sName = CFG.langManager.get(string2);
        this.iAgeBeginningYear = n;
        this.iAgeEndYear = n2;
        this.fPopulationGrowthRate = f;
        this.fEconomyGrowthRate = f2;
        this.FOG_OF_WAR_DISCOVERY_MET_PROVINCES = f3;
        this.DEVELOPMENT_LEVEL_INCREASE = f4;
        this.INCOME_TAXATION_MODIFIER = f5;
        this.INCOME_PRODUCTION_MODIFIER = f6;
        this.EXPENSES_ADMINSTRATION_MODIFIER = f7;
        this.EXPENSES_MILITARY_UPKEEP_MODIFIER = f8;
        this.BASE_MOVEMENT_POINTS = n3;
        this.MOVEMENT_POINTS_MODIFIER = f9;
        this.BASE_DIPLOMACY_POINTS = n4;
        this.EXPENSES_ADMINSTRATION_DISTANCE = f10;
        this.DIPLOMACY_ALLIANCE_PROPOSAL_NAGATIVE_DISTANCE = n5;
        this.BASE_INCOME_TAXATION = f11;
        this.INCOME_TAXATION_PER_TECHNOLOGY_MODIFIER = f12;
        this.BASE_MILITARY_UPKEEP = f13;
        this.GAME_STARTING_DEVELOPMENT = f14;
        this.GAME_DAYS_PER_TURN = n6;
        this.BASE_INCOME_PRODUCTION = f15;
        this.INCOME_PRODUCTIONN_PER_DEVELOPMENT_MODIFIER = f16;
        this.REVOLUTIONARY_RISK_MODIFIER = f17;
        this.COLONIZE_COST_GOLD_PERC = f19;
        this.COLONIZE_COST_MOVEMENT_POINTS = n7;
        this.COLONIZE_COST_DIPLOMACY_POINTS = n8;
        this.REBELS_ARMY = n9;
        this.WAR_SCORE_RATE = n10;
        this.MAX_POPULATION = n11;
        this.START_POPULATION = n12;
        this.TECH_STANDARD = n13;
        this.TECH_MAX = n14;
        this.TECH_COST = n15;
        this.START_ECONOMY = n16;
        this.INCOME_MODIFIER = f20;
        this.AGE_ASSIMILATE_RATE = f21;
        this.DIPLOMACY_RANGE = f22;
        this.COMMERCE_RANGE = f23;
        this.CONTROL_RANGE = f24;
        this.DISEASE_CHANCE = f18;
    }

    protected final int getBeginningYear() {
        return this.iAgeBeginningYear;
    }

    protected final float getEconomyGrowthRate() {
        return this.fEconomyGrowthRate;
    }

    protected final int getEndYear() {
        return this.iAgeEndYear;
    }

    protected final String getName() {
        return this.sName;
    }

    protected final float getPopulationGrowthRate() {
        return this.fPopulationGrowthRate;
    }

    protected final void setEconomyGrowthRate(float f) {
        this.fEconomyGrowthRate = f;
    }

    protected final void setName(String string2) {
        this.sName = CFG.langManager.get(string2);
    }

    protected final void setPopulationGrowthRate(float f) {
        this.fPopulationGrowthRate = f;
    }
}

