/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import java.io.Serializable;

class CivArmyMission
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int MISSION_ID = 0;
    protected CivArmyMission_Type MISSION_TYPE = CivArmyMission_Type.PREAPARE_FOR_WAR;
    protected int TURN_ID = 0;
    protected int iArmy = 0;
    protected int iObsolate = 10;
    protected int iProvinceID;
    protected int toProvinceID;

    CivArmyMission() {
    }

    protected boolean action(int n) {
        return true;
    }

    protected boolean canMakeAction(int n, int n2) {
        return true;
    }

    protected void onRemove() {
    }

    protected boolean prepareData() {
        return true;
    }
}

