/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Diplomacy_Plunder
extends Button_Statistics {
    private static final float FONT_SCALE = 0.7f;
    private int iDiploCostWidth;
    private int iEfficiencyPercWidth;
    private int iEfficiencyWidth;
    private int iIncome;
    private int iIncomeWidth;
    private int iIncomeWidth2;
    private int iPopulation;
    private int iPopulationWidth;
    private String sDiploCost;
    private String sEfficiency;
    private String sEfficiencyPerc;
    private String sIncome;
    private String sPopulation;

    protected Button_Diplomacy_Plunder(String object, int n, int n2, int n3, int n4, int n5) {
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append(CFG.langManager.get("Population"));
        ((StringBuilder)object2).append(": ");
        super(((StringBuilder)object2).toString(), 0, n3, n4, n5, CFG.TEXT_HEIGHT + CFG.PADDING * 4 + CFG.TEXT_HEIGHT + CFG.PADDING);
        this.iPopulation = 0;
        this.iPopulationWidth = 0;
        this.iIncome = 0;
        this.iIncomeWidth = 0;
        this.iIncomeWidth2 = 0;
        this.iDiploCostWidth = 0;
        this.iEfficiencyWidth = 0;
        this.iEfficiencyPercWidth = 0;
        this.sDiploCost = object;
        CFG.glyphLayout.setText(CFG.fontMain, this.sDiploCost);
        this.iDiploCostWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.iPopulation = n;
        Object object3 = CFG.glyphLayout;
        object2 = CFG.fontMain;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iPopulation);
        ((GlyphLayout)object3).setText((BitmapFont)object2, ((StringBuilder)object).toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.7f);
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("ProvinceIncome"));
        ((StringBuilder)object).append(": ");
        this.sIncome = ((StringBuilder)object).toString();
        object3 = CFG.glyphLayout;
        object = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(this.sIncome);
        ((GlyphLayout)object3).setText((BitmapFont)object, ((StringBuilder)object2).toString());
        this.iIncomeWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.iIncome = n2;
        object = CFG.glyphLayout;
        object2 = CFG.fontMain;
        object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(this.iIncome);
        ((GlyphLayout)object).setText((BitmapFont)object2, ((StringBuilder)object3).toString());
        this.iIncomeWidth2 = (int)(CFG.glyphLayout.width * 0.7f);
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Efficiency"));
        ((StringBuilder)object).append(": ");
        this.sEfficiency = ((StringBuilder)object).toString();
        object = CFG.glyphLayout;
        object3 = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(this.sEfficiency);
        ((GlyphLayout)object).setText((BitmapFont)object3, ((StringBuilder)object2).toString());
        this.iEfficiencyWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.setCurrent(0);
    }

    private final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void buildElementHover() {
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.25f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(Color.WHITE);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() * 3 / 5, false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 4 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), true, false);
        super.drawButtonBG(spriteBatch, n, n2, bl);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.45f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - 4, 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - 4, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, this.getColor(bl));
        Object object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iPopulation);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + CFG.PADDING * 2 + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, CFG.COLOR_TEXT_POPULATION);
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + CFG.PADDING * 3 + (int)((float)this.getTextWidth() * 0.7f) + this.iPopulationWidth + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population))) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        CFG.drawTextWithShadow(spriteBatch, this.sIncome, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + CFG.PADDING * 3 + CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, this.getColor(bl));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iIncome);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + CFG.PADDING * 2 + this.iIncomeWidth + n, this.getPosY() + CFG.PADDING * 3 + CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, CFG.COLOR_INGAME_GOLD);
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + CFG.PADDING * 3 + this.iIncomeWidth + this.iIncomeWidth2 + n, this.getPosY() + CFG.PADDING * 3 + CFG.TEXT_HEIGHT + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold))) / 2 - ImageManager.getImage(Images.top_gold).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold)));
        CFG.drawTextWithShadow(spriteBatch, this.sEfficiencyPerc, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iEfficiencyPercWidth + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, CFG.COLOR_TEXT_MODIFIER_NEUTRAL2);
        CFG.drawTextWithShadow(spriteBatch, this.sEfficiency, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iEfficiencyPercWidth - this.iEfficiencyWidth + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, Color.WHITE);
        ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points)) + n, this.getPosY() + CFG.PADDING * 2 + CFG.TEXT_HEIGHT + CFG.PADDING + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points))) / 2 - ImageManager.getImage(Images.top_movement_points).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points)));
        String string2 = this.sDiploCost;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = this.iDiploCostWidth;
        int n7 = (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points));
        int n8 = this.getPosY();
        int n9 = CFG.PADDING;
        int n10 = CFG.TEXT_HEIGHT;
        int n11 = CFG.PADDING;
        int n12 = (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f);
        object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getPlayer((int)CFG.PLAYER_TURNID).getCivID()).getIdeologyID()).COST_OF_PLUNDER ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 - n5 * 3 - n6 - n7 + n, n8 + n9 * 2 + n10 + n11 + n12 + n2, (Color)object);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS);
        return color2;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }

    @Override
    protected void setCurrent(int n) {
        Object object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(n);
        ((StringBuilder)object).append("%");
        this.sEfficiencyPerc = ((StringBuilder)object).toString();
        GlyphLayout glyphLayout = CFG.glyphLayout;
        object = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sEfficiencyPerc);
        glyphLayout.setText((BitmapFont)object, stringBuilder.toString());
        this.iEfficiencyPercWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }
}

