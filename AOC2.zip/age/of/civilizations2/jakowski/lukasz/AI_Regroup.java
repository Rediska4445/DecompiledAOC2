/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_Regroup {
    protected int iArmy;
    protected int iProvinceID;

    protected AI_Regroup(int n, int n2, int n3) {
        this.iProvinceID = n2;
        this.iArmy = n3;
    }
}

