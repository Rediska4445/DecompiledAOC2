/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Alliances_Names_GameData_Bundle
implements Serializable {
    private static final long serialVersionUID = 0L;
    private List<String> sWords = new ArrayList<String>();

    protected Alliances_Names_GameData_Bundle(String string2) {
        this.sWords.add(string2);
    }

    protected final void addWord(String string2) {
        this.sWords.add(string2);
    }

    protected final String getWord(int n) {
        return this.sWords.get(n);
    }

    protected final int getWordsSize() {
        return this.sWords.size();
    }

    protected final void removeWord(int n) {
        this.sWords.remove(n);
    }

    protected final String setWord(int n, String string2) {
        return this.sWords.set(n, string2);
    }
}

