/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Color_GameData;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Civilization_ServiceRibbon_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private List<Color_GameData> lColors = new ArrayList<Color_GameData>();
    private String sSRTAG;

    Civilization_ServiceRibbon_GameData() {
    }

    protected final Color_GameData getColor(int n) {
        return this.lColors.get(n);
    }

    protected final List<Color_GameData> getColors() {
        return this.lColors;
    }

    protected final String getSRTAG() {
        return this.sSRTAG;
    }

    protected final void setSRTAG(String string2) {
        this.sSRTAG = string2;
    }
}

