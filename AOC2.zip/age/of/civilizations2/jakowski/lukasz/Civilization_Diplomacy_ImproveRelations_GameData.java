/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Message_Relations_Increase;
import java.io.Serializable;

class Civilization_Diplomacy_ImproveRelations_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iNumOfTurns = 0;
    protected int iWithCivID = 0;

    protected Civilization_Diplomacy_ImproveRelations_GameData(int n, int n2, int n3) {
        this.iWithCivID = n;
        this.iNumOfTurns = n2;
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Relations_Increase(n3));
    }

    protected final boolean action(int n) {
        boolean bl;
        boolean bl2 = DiplomacyManager.improveRelation(n, this.iWithCivID);
        boolean bl3 = bl = true;
        if (bl2) {
            int n2;
            this.iNumOfTurns = n2 = this.iNumOfTurns - 1;
            bl3 = n2 <= 0 ? bl : false;
        }
        if (CFG.game.getCiv(n).getDiplomacyPoints() >= 5) {
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 5);
        }
        return bl3;
    }
}

