/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_Migrate;
import java.io.Serializable;
import java.util.ArrayList;

class AI_Style_Tribal
extends AI_Style {
    private int MIGRATE_MAX_NUM_OF_PROVINCES = 10;

    protected AI_Style_Tribal() {
        this.TAG = "UNCIVILIZED";
        this.MIGRATE_MAX_NUM_OF_PROVINCES = CFG.oR.nextInt(3) + 3;
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT = 0.02f;
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM = 9;
        this.PERSONALITY_MIN_HAPPINESS_DEFAULT = 80;
        this.PERSONALITY_MIN_HAPPINESS_RANDOM = 18;
        this.PERSONALITY_FORGIVNESS_DEFAULT = 0.5f;
        this.PERSONALITY_FORGIVNESS_RANDOM = 20;
        this.MIN_TURNS_TO_ABANDON_USELESS_PROVINCE = 10;
    }

    private final int migrationTo_Score(int n, int n2) {
        int n3;
        int n4 = (int)(CFG.game.getProvince(n).getGrowthRate_Population_WithFarm() * 100.0f);
        int n5 = 0;
        n4 = n3 = n4 + 0;
        int n6 = n5;
        if (CFG.game.getProvince(n).getCore().getHaveACore(n2)) {
            n4 = n3 + 250;
            n6 = n5;
        }
        while (n6 < CFG.game.getProvince(n).getNeighboringProvincesSize()) {
            n4 = n5 = n4 + (int)(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(n6)).getGrowthRate_Population_WithFarm() * 10.0f);
            if (CFG.game.getProvince(n).getNeighboringProvinces(n6) == CFG.game.getCiv(n2).getCapitalProvinceID()) {
                n4 = n5 + 50;
            }
            n5 = n4;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(n6)).getCivID() > 0) {
                n5 = n4;
                if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(n6)).getCivID() != n2) {
                    n5 = n4 - 200;
                }
            }
            ++n6;
            n4 = n5;
        }
        return n4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void migration_NotConnected(int n) {
        int n2;
        ArrayList<Integer> arrayList;
        ArrayList arrayList2;
        int n3;
        Serializable serializable;
        block17: {
            if (CFG.game.getCiv(n).getCapitalProvinceID() < 0) return;
            serializable = new ArrayList();
            for (n3 = 0; n3 < CFG.game.getCiv(n).getNumOfProvinces(); ++n3) {
                arrayList2 = CFG.game;
                if (!Game.uncivilizedCanMigrate_FromProvince(CFG.game.getCiv(n).getProvinceID(n3), n) || CFG.game.getCiv(n).migratesFromProvinceID(CFG.game.getCiv(n).getProvinceID(n3))) continue;
                serializable.add(CFG.game.getCiv(n).getProvinceID(n3));
            }
            if (serializable.size() <= 0) return;
            arrayList2 = new ArrayList();
            for (n3 = 0; n3 < serializable.size(); ++n3) {
                if (CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivRegionID() == CFG.game.getProvince((Integer)serializable.get(n3)).getCivRegionID()) continue;
                arrayList2.add(serializable.get(n3));
            }
            if (arrayList2.size() <= 0) return;
            arrayList = new ArrayList<Integer>();
            for (n3 = 0; n3 < CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvincesSize(); ++n3) {
                if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n3)).getCivID() != 0) continue;
                arrayList.add(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n3));
            }
            if (arrayList.size() != 0) break block17;
            for (n3 = 0; n3 < CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvincesSize(); ++n3) {
                for (n2 = 0; n2 < CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n3)).getNeighboringProvincesSize(); ++n2) {
                    if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n3)).getNeighboringProvinces(n2)).getCivID() != 0) continue;
                    arrayList.add(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n3)).getNeighboringProvinces(n2));
                }
            }
        }
        if (arrayList.size() <= 0) return;
        ArrayList<Serializable> arrayList3 = new ArrayList<Serializable>();
        int n4 = arrayList2.size() - 1;
        for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
            serializable = new RegroupArmy_Data_Migrate(n, (Integer)arrayList2.get(n4), (Integer)arrayList.get(n3));
            if (((RegroupArmy_Data)serializable).getRouteSize() <= 0) continue;
            arrayList3.add(serializable);
        }
        if (arrayList3.size() <= 0) return;
        n2 = 0;
        for (n3 = arrayList3.size() - 1; n3 > 0; --n3) {
            int n5;
            block19: {
                block18: {
                    if (((RegroupArmy_Data_Migrate)arrayList3.get(n2)).getRouteSize() > ((RegroupArmy_Data_Migrate)arrayList3.get(n3)).getRouteSize()) break block18;
                    n5 = n2;
                    if (((RegroupArmy_Data_Migrate)arrayList3.get(n2)).getRouteSize() != ((RegroupArmy_Data_Migrate)arrayList3.get(n3)).getRouteSize()) break block19;
                    n5 = n2;
                    if (CFG.oR.nextInt(100) >= 50) break block19;
                }
                n5 = n3;
            }
            n2 = n5;
        }
        try {
            CFG.gameAction.migrateToProvince((Integer)arrayList2.get(n4), ((RegroupArmy_Data_Migrate)arrayList3.get(n2)).getRoute(0), n, false);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
        }
    }

    private final void migration_NotConnected_OLD(int n) {
        Object object;
        int n2;
        Object object2 = new ArrayList<Integer>();
        for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
            object = CFG.game;
            if (!Game.uncivilizedCanMigrate_FromProvince(CFG.game.getCiv(n).getProvinceID(n2), n)) continue;
            object2.add(CFG.game.getCiv(n).getProvinceID(n2));
        }
        object = new ArrayList();
        for (n2 = 0; n2 < object2.size(); ++n2) {
            if (((Integer)object2.get(n2)).intValue() == CFG.game.getCiv(n).getCapitalProvinceID()) continue;
            Game game = CFG.game;
            if (Game.provinceBordersWithProvince_LandByLand((Integer)object2.get(n2), CFG.game.getCiv(n).getCapitalProvinceID())) continue;
            object.add(object2.get(n2));
        }
        if (object.size() > 0) {
            for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
                if (CFG.game.getCiv(n).getProvinceID(n2) == CFG.game.getCiv(n).getCapitalProvinceID()) continue;
                for (int i = 0; i < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvincesSize(); ++i) {
                    object2 = CFG.game;
                    if (!Game.provinceBordersWithProvince_LandByLand(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i), CFG.game.getCiv(n).getCapitalProvinceID())) continue;
                    CFG.gameAction.migrateToProvince(CFG.game.getCiv(n).getProvinceID(n2), CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i), n, false);
                }
            }
        }
    }

    @Override
    protected void armyOverBudget_Disband(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_TYPE != CivArmyMission_Type.EXPAND_NETURAL_PROVINCE) continue;
            return;
        }
        super.armyOverBudget_Disband(n);
    }

    @Override
    protected void buildBuildings(int n) {
    }

    @Override
    protected void buildStartingBuildings(int n) {
        block3: {
            try {
                if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(1) * 0.88f) {
                    CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfFarm(1);
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (!CFG.LOGS) break block3;
                CFG.exceptionStack(indexOutOfBoundsException);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final boolean migration(int n) {
        int n3;
        Object object;
        int n2;
        if (this.canCivlize(n)) {
            return false;
        }
        Object object2 = new ArrayList<Integer>();
        for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
            object = CFG.game;
            if (!Game.uncivilizedCanMigrate_FromProvince(CFG.game.getCiv(n).getProvinceID(n2), n)) continue;
            object2.add(CFG.game.getCiv(n).getProvinceID(n2));
        }
        if (object2.size() <= 0) return false;
        ArrayList arrayList = new ArrayList();
        for (n2 = 0; n2 < object2.size(); ++n2) {
            if (((Integer)object2.get(n2)).intValue() == CFG.game.getCiv(n).getCapitalProvinceID()) continue;
            object = CFG.game;
            if (Game.provinceBordersWithProvince_LandByLand((Integer)object2.get(n2), CFG.game.getCiv(n).getCapitalProvinceID())) continue;
            arrayList.add(object2.get(n2));
        }
        if (arrayList.size() <= 0) {
            object2 = CFG.game;
            if (!Game.uncivilizedCanMigrate_FromProvince(CFG.game.getCiv(n).getCapitalProvinceID(), n)) return true;
            object = new ArrayList();
            for (n2 = 0; n2 < CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvincesSize(); ++n2) {
                object2 = CFG.game;
                if (!Game.uncivilizedCanMigrate(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n2), n)) continue;
                object.add(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringProvinces(n2));
            }
            if (object.size() <= 0) return true;
            n3 = 0;
            for (n2 = 1; n2 < object.size(); ++n2) {
                int n4 = n3;
                if (this.migrationTo_Score((Integer)object.get(n3), n) < this.migrationTo_Score((Integer)object.get(n2), n)) {
                    n4 = n2;
                }
                n3 = n4;
            }
        } else {
            n2 = 0;
            while (n2 < CFG.game.getCiv(n).getNumOfProvinces()) {
                if (CFG.game.getCiv(n).getProvinceID(n2) != CFG.game.getCiv(n).getCapitalProvinceID()) {
                    for (int i = 0; i < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvincesSize(); ++i) {
                        object2 = CFG.game;
                        if (!Game.provinceBordersWithProvince_LandByLand(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i), CFG.game.getCiv(n).getCapitalProvinceID())) continue;
                        CFG.gameAction.migrateToProvince(CFG.game.getCiv(n).getProvinceID(n2), CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i), n, false);
                    }
                }
                ++n2;
            }
            return true;
        }
        CFG.gameAction.migrateToProvince(CFG.game.getCiv(n).getCapitalProvinceID(), (Integer)object.get(n3), n, false);
        if (CFG.game.getCiv(n).getNumOfProvinces() <= 1) return true;
        n2 = 0;
        try {
            while (n2 < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(1)).getNeighboringProvincesSize()) {
                if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(1)).getNeighboringProvinces(n2) == CFG.game.getCiv(n).getCapitalProvinceID()) {
                    CFG.gameAction.migrateToProvince(CFG.game.getCiv(n).getProvinceID(1), CFG.game.getCiv(n).getCapitalProvinceID(), n, false);
                    return true;
                }
                ++n2;
            }
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return true;
        }
    }

    @Override
    protected void turnOrders(int n) {
        if (!CFG.game.getCiv(n).isAtWar() && CFG.game.getCiv(n).getCapitalProvinceID() >= 0) {
            if (CFG.oR.nextInt(100) < CFG.game.getCiv((int)n).getCivPersonality().UNCIVILIZED_MIGRATE) {
                if (CFG.game.getCiv(n).getNumOfProvinces() < this.MIGRATE_MAX_NUM_OF_PROVINCES) {
                    this.migration(n);
                } else {
                    this.migration_NotConnected(n);
                    this.migration_NotConnected_OLD(n);
                }
            } else {
                this.migration_NotConnected(n);
                this.migration_NotConnected_OLD(n);
            }
        }
        this.civilize(n);
        this.checkBalanceOfProvinces_Tribal(n);
        super.turnOrders(n);
    }
}

