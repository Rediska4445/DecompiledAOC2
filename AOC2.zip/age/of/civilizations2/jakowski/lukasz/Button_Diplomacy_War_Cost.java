/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy_War;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Diplomacy_War_Cost
extends Button_Diplomacy_War {
    private int iDiploCostWidth = 0;
    private String sDiploCost = "2.4";

    protected Button_Diplomacy_War_Cost(int n, int n2, int n3, int n4, int n5) {
        super(n, n2, n3, n4, n5);
        CFG.glyphLayout.setText(CFG.fontMain, this.sDiploCost);
        this.iDiploCostWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }

    private final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawText(spriteBatch, n, n2, bl);
        CFG.fontMain.getData().setScale(0.7f);
        ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points)) / 2 - ImageManager.getImage(Images.top_diplomacy_points).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points)));
        String string2 = this.sDiploCost;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = this.iDiploCostWidth;
        int n7 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points));
        int n8 = this.getPosY();
        int n9 = this.getHeight() / 2;
        int n10 = (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f);
        Color color2 = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= 20 ? Color.WHITE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 - n5 * 3 - n6 - n7 + n, n8 + n9 - n10 + n2, color2);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

