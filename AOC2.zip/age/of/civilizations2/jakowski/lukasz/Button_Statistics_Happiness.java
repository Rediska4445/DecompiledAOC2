/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

class Button_Statistics_Happiness
extends Button_Statistics {
    protected int iImageID;

    protected Button_Statistics_Happiness(float f, int n, int n2, int n3, int n4, int n5) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        int n6 = (int)f;
        stringBuilder.append(n6);
        stringBuilder.append("%");
        super(stringBuilder.toString(), n, n2, n3, n4, n5);
        this.iImageID = CFG.getHappinesImage(n6);
    }

    private final float getImageScale() {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(this.iImageID).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(this.iImageID).getHeight();
        }
        return f2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Rectangle rectangle = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth(), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors(rectangle);
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(this.iImageID).getHeight() + n2, (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale()));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + CFG.PADDING + (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale()) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }
}

