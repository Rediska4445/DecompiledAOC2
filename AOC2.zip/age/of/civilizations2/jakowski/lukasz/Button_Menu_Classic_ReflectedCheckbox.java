/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Menu_Classic;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_Classic_ReflectedCheckbox
extends Button_Menu_Classic {
    protected Button_Menu_Classic_ReflectedCheckbox(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_Classic_ReflectedCheckbox(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Menu_Classic_ReflectedCheckbox.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.25f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.25f));
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Menu_Classic_ReflectedCheckbox.this.getPosX() + Button_Menu_Classic_ReflectedCheckbox.this.getWidth() - Button_Menu_Classic_ReflectedCheckbox.this.getWidth() / 4 + n, Button_Menu_Classic_ReflectedCheckbox.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_Menu_Classic_ReflectedCheckbox.this.getWidth() / 4, Button_Menu_Classic_ReflectedCheckbox.this.getHeight() - 2, true, false);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }
}

