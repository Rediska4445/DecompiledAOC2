/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Color;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Terrain;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_View_GrowthRate
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.6f;
    protected int iLevelWidth;
    private int iPopulationPercWidth;
    private int iPopulationWidth;
    private int iProvinceID;
    protected boolean isAssimiliate;
    private boolean row;
    protected String sLevel;
    private String sPopulation;
    private String sPopulationPerc;

    protected Button_View_GrowthRate(int n, String object, int n2, int n3, int n4, int n5, boolean bl) {
        boolean bl2 = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        this.iPopulationPercWidth = 0;
        this.isAssimiliate = false;
        this.sLevel = "";
        this.iLevelWidth = 0;
        super.init((String)object, 0, n3, n4, n5, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        if (n % 2 == 0) {
            bl2 = true;
        }
        this.row = bl2;
        this.iProvinceID = n2;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append((int)(CFG.game.getProvince(this.iProvinceID).getGrowthRate_Population_WithFarm_WithTerrain() * 100.0f));
        ((StringBuilder)object).append("%");
        this.sPopulation = ((StringBuilder)object).toString();
        object = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        ((GlyphLayout)object).setText(bitmapFont, stringBuilder.toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation());
        this.sPopulationPerc = CFG.getNumberWithSpaces(((StringBuilder)object).toString());
        CFG.glyphLayout.setText(CFG.fontMain, this.sPopulationPerc);
        this.iPopulationPercWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.isAssimiliate = bl;
        if (CFG.game.getProvince(n2).getLevelOfFarm() > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(CFG.game.getProvince(n2).getLevelOfFarm());
            this.sLevel = ((StringBuilder)object).toString();
            CFG.glyphLayout.setText(CFG.fontMain, this.sLevel);
            this.iLevelWidth = (int)(CFG.glyphLayout.width * 0.6f);
        }
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID()));
        CharSequence charSequence = CFG.game.getProvince(this.iProvinceID).getName().length() > 0 ? CFG.game.getProvince(this.iProvinceID).getName() : CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getCivName();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("GrowthRate"));
        ((StringBuilder)charSequence).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sPopulation, CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population_growth, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        if (BuildingsManager.getFarm_GrowthRateBonus(CFG.game.getProvince(this.iProvinceID).getLevelOfFarm()) > 0.0f) {
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append(CFG.langManager.get("Farm"));
            ((StringBuilder)charSequence).append(": ");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("+");
            ((StringBuilder)charSequence).append((int)(BuildingsManager.getFarm_GrowthRateBonus(CFG.game.getProvince(this.iProvinceID).getLevelOfFarm()) * 100.0f));
            ((StringBuilder)charSequence).append("%");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.b_farm, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        if (CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) > 0.0f) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Color(CFG.terrainTypesManager.getColor(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()), 0, 0));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Terrain(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID(), 0, CFG.PADDING));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append(CFG.terrainTypesManager.getName(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()));
            ((StringBuilder)charSequence).append(": ");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("+");
            ((StringBuilder)charSequence).append((int)(CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) * 100.0f));
            ((StringBuilder)charSequence).append("%");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population_growth, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        } else if (CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) < 0.0f) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Color(CFG.terrainTypesManager.getColor(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()), 0, 0));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Terrain(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID(), 0, CFG.PADDING));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append(CFG.terrainTypesManager.getName(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()));
            ((StringBuilder)charSequence).append(": ");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("");
            ((StringBuilder)charSequence).append((int)(CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) * 100.0f));
            ((StringBuilder)charSequence).append("%");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population_growth, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        } else {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Color(CFG.terrainTypesManager.getColor(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()), 0, 0));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Terrain(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID(), 0, CFG.PADDING));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.terrainTypesManager.getName(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("Population"));
        ((StringBuilder)charSequence).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sPopulationPerc, CFG.COLOR_TEXT_POPULATION));
        if (CFG.game.showTurnChangesInformation(CFG.game.getProvince(this.iProvinceID).getCivID())) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, CFG.PADDING));
            if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population > 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("+");
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append("");
                ((StringBuilder)charSequence).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)charSequence).toString()));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE));
            } else if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population < 0) {
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append("");
                ((StringBuilder)charSequence).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.getNumberWithSpaces(((StringBuilder)charSequence).toString()), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
            } else {
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append("+");
                ((StringBuilder)charSequence).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0));
        } else {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0));
        }
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.isAssimiliate) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfFarm() > 0) {
            ImageManager.getImage(Images.b_farm).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())) - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.b_farm).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_farm).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_farm).getHeight(), (int)((float)ImageManager.getImage(Images.b_farm).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())), (int)((float)ImageManager.getImage(Images.b_farm).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())));
            CFG.fontMain.getData().setScale(0.6f);
            CFG.drawTextWithShadow(spriteBatch, this.sLevel, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())) - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.b_farm).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())) - CFG.PADDING - this.iLevelWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            CFG.fontMain.getData().setScale(1.0f);
        }
        CFG.terrainTypesManager.getIcon(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.terrainTypesManager.getIcon(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        CFG.drawTextWithShadow(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + (int)((float)this.getTextWidth() * 0.65f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, CFG.getGrowthRateColor((int)(CFG.game.getProvince(this.iProvinceID).getGrowthRate_Population_WithFarm() * 100.0f), 1.0f));
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())) / 2 + n2 - ImageManager.getImage(Images.population).getHeight(), (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())));
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawText(spriteBatch, this.sPopulationPerc, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale2(ImageManager.getImage(Images.population).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_POPULATION);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

