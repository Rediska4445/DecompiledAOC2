/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_FlagActionSliderStyle;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_FlagActionSliderStyle_Animated
extends Button_FlagActionSliderStyle {
    protected static final int ANIMATION_T = 750;
    protected static int animationState;
    protected static long lTimeAnimation;

    protected Button_FlagActionSliderStyle_Animated(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_FlagActionSliderStyle_Animated(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    protected static final Color getColorLine() {
        return new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.975f);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (this.getClickable() && !bl && (n3 = animationState++) >= 0) {
            if (n3 == 0) {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_FlagActionSliderStyle_Animated.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_FlagActionSliderStyle_Animated.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    animationState = 0;
                    lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
    }
}

