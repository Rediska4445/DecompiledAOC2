/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;
import java.util.ArrayList;
import java.util.List;

class Event_Conditions_WatchTower
extends Event_Conditions {
    protected int iValue = 0;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Conditions_WatchTower() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_WATCHTOWER);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected String getConditionText() {
        try {
            CharSequence charSequence = new StringBuilder();
            charSequence = ((StringBuilder)charSequence).append(CFG.langManager.get("WatchTower")).append(": ");
            boolean bl = this.getValue() == 0;
            return ((StringBuilder)charSequence).append(bl).toString();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return CFG.langManager.get("WatchTower");
        }
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        block7: {
            int n;
            try {
                if (this.getValue() != 0) break block7;
                n = 0;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                return false;
            }
            while (true) {
                block8: {
                    if (n >= this.getProvinces().size()) return true;
                    if (CFG.game.getProvince(this.getProvinces().get(n)).getLevelOfWatchTower() != 0) break block8;
                    return false;
                }
                ++n;
            }
        }
        int n = 0;
        while (true) {
            if (n >= this.getProvinces().size()) return true;
            int n2 = CFG.game.getProvince(this.getProvinces().get(n)).getLevelOfWatchTower();
            if (n2 > 0) {
                return false;
            }
            ++n;
            continue;
            break;
        }
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }
}

