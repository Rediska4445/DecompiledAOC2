/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Icon
extends Button_Build {
    protected Button_Icon(int n, int n2, int n3) {
        super("", n, 0, 0, n2, n3, Button_Diplomacy.iDiploWidth, true, false, 0, 0.0f);
        this.setHeight(CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }
}

