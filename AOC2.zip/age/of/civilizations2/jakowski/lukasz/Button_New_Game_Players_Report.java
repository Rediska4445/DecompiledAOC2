/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_New_Game_Players_Report
extends Button_New_Game_Players {
    private int iCivID;

    protected Button_New_Game_Players_Report(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super(string2, n2, n3, n4, n5, n6, bl);
        this.iCivID = n;
    }

    protected Button_New_Game_Players_Report(int n, String string2, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n2, n3, n4, n5, bl);
        this.iCivID = n;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.iCivID < 0) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)(((float)this.getTextWidth() * 0.8f + (float)CFG.PADDING + (float)CFG.CIV_FLAG_WIDTH) / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        } else {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)(((float)this.getTextWidth() * 0.8f + (float)CFG.PADDING + (float)CFG.CIV_FLAG_WIDTH) / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)(((float)this.getTextWidth() * 0.8f + (float)CFG.PADDING + (float)CFG.CIV_FLAG_WIDTH) / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)(((float)this.getTextWidth() * 0.8f + (float)CFG.PADDING + (float)CFG.CIV_FLAG_WIDTH) / 2.0f) + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }
}

