/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Civilization_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iB;
    protected int iG;
    protected int iR;

    Civilization_GameData() {
    }
}

