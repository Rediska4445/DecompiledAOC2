/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Workshop;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option_Workshop
extends AI_Build_Option {
    AI_Build_Option_Workshop() {
    }

    @Override
    protected AI_Build getData(int n) {
        return new AI_Build_Workshop(n, this.getMoney(n));
    }

    @Override
    protected float getScore(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_WORKSHOP * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Workshops / Math.max(CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getWorkshop_MaxLevel(), 1)));
    }
}

