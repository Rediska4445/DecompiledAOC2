/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_ProvinceInfo {
    protected int iProvinceID;
    protected int iRecruitable;
    protected float iValue;

    protected AI_ProvinceInfo(int n, int n2, int n3) {
        this.iProvinceID = n;
        this.iValue = n2;
        this.iRecruitable = n3;
    }
}

