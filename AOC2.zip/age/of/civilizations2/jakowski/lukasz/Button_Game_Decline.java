/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_Decline
extends Button_Game {
    protected Button_Game_Decline(int n, int n2, boolean bl) {
        super("", 0, n, n2, bl);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (bl) {
            ImageManager.getImage(Images.btn_x_active).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_x_active).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_x_active).getHeight() / 2 + n2);
        } else {
            if (this.getIsHovered()) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.8f));
            }
            ImageManager.getImage(Images.btn_x).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_x).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_x).getHeight() / 2 + n2);
            spriteBatch.setColor(Color.WHITE);
        }
    }
}

