/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Frontline;
import java.util.ArrayList;
import java.util.List;

class AI_Frontline_AI {
    private int iFrontLinesSize = 0;
    private int iWithCivID = 0;
    private List<AI_Frontline> lFrontLines = new ArrayList<AI_Frontline>();
    private List<Boolean> lFrontLines_OwnFront = new ArrayList<Boolean>();

    protected AI_Frontline_AI(int n, AI_Frontline aI_Frontline, boolean bl) {
        this.iWithCivID = n;
        this.lFrontLines.add(aI_Frontline);
        this.lFrontLines_OwnFront.add(bl);
        this.iFrontLinesSize = this.lFrontLines.size();
    }

    protected final void addFrontLine(AI_Frontline aI_Frontline, boolean bl) {
        this.lFrontLines.add(aI_Frontline);
        this.lFrontLines_OwnFront.add(bl);
        this.iFrontLinesSize = this.lFrontLines.size();
    }

    protected final AI_Frontline getFrontLine(int n) {
        return this.lFrontLines.get(n);
    }

    protected final int getFrontLinesSize() {
        return this.iFrontLinesSize;
    }

    protected final int getWithCivID() {
        return this.iWithCivID;
    }

    protected boolean ownFront(int n) {
        return this.lFrontLines_OwnFront.get(n);
    }
}

