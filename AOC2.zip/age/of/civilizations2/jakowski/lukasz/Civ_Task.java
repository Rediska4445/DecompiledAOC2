/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Civ_Task_Type;
import java.io.Serializable;

class Civ_Task
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iProvinceID;
    protected Civ_Task_Type taskType = Civ_Task_Type.ASSIMILATE_PROVINCE;

    Civ_Task() {
    }

    protected boolean runTask() {
        return true;
    }
}

