/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;
import java.util.ArrayList;
import java.util.List;

class Event_Conditions_Development_Low
extends Event_Conditions {
    protected int iValue = 0;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Conditions_Development_Low() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DEVELOPMENT_LOW);
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("DevelopmentLevel")).append(" < ").append((float)this.getValue() / 100.0f).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("DevelopmentLevel");
            return var1_3;
        }
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected boolean outCondition() {
        int n = 0;
        while (true) {
            int n2;
            try {
                if (n >= this.getProvinces().size()) return true;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                return false;
            }
            float f = CFG.game.getProvince(this.getProvinces().get(n)).getDevelopmentLevel();
            if (f >= (float)(n2 = this.getValue()) / 100.0f) {
                return false;
            }
            ++n;
        }
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }
}

