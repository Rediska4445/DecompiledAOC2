/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_BotBar;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_BotBar_Cores
extends Button_BotBar {
    private int iProvinceID = 0;

    protected Button_BotBar_Cores(String string2, float f, int n, int n2, int n3, boolean bl, boolean bl2) {
        super(string2, f, n, n2, n3, bl, bl2);
        this.iTextPositionX = CFG.PADDING * 2 + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    private final float getImageScale() {
        return (float)CFG.TEXT_HEIGHT / (float)CFG.CIV_FLAG_HEIGHT;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (CFG.game.getProvince(this.iProvinceID).getCore().getCivsSize() == 0) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getTextPos() + this.getTextWidth() + CFG.PADDING + n, this.getPosY() - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + this.getTextWidth() + CFG.PADDING + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
        } else {
            for (int i = 0; i < Math.min(3, CFG.game.getProvince(this.iProvinceID).getCore().getCivsSize()); ++i) {
                CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCore().getCivID(i)).getFlag().draw(spriteBatch, this.getPosX() + this.getTextPos() + this.getTextWidth() + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCore().getCivID(i)).getFlag().getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + this.getTextWidth() + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
            }
        }
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }

    @Override
    protected int getWidth() {
        int n = this.iTextWidth;
        int n2 = CFG.PADDING;
        int n3 = (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale());
        int n4 = CFG.PADDING;
        int n5 = CFG.game.getProvince(this.iProvinceID).getCore().getCivsSize();
        int n6 = 1;
        if (n5 > 1) {
            n6 = Math.min(3, CFG.game.getProvince(this.iProvinceID).getCore().getCivsSize());
        }
        return n + n2 * 2 + 2 + (n3 + n4) * n6 + CFG.PADDING + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    @Override
    protected void setCurrent(int n) {
        this.iProvinceID = n;
    }

    @Override
    public void setText(String string2) {
        block2: {
            this.sText = string2;
            this.setWidth(this.iMinWidth);
            try {
                CFG.glyphLayout.setText(CFG.fontMain, string2);
                this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
                this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            }
            catch (NullPointerException nullPointerException) {
                if (!CFG.LOGS) break block2;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }
}

