/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import java.util.ArrayList;
import java.util.List;

class AI_Build_Invest
extends AI_Build {
    private float fReserve = 10.0f;
    private int iMaxPop = 1;
    private List<Integer> lProvincesToInvest = new ArrayList<Integer>();

    protected AI_Build_Invest(int n, long l) {
        super(n, l);
        this.fReserve = 10.0f - (float)CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_RESRVE_RAND / 100.0f + (float)CFG.oR.nextInt(CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_RESRVE_RAND) / 100.0f;
        int n2 = 0;
        while (true) {
            try {
                if (n2 >= CFG.game.getCiv(n).getNumOfProvinces()) break;
                if (!CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).isOccupied() && CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getProvinceStability() > CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MIN_STABILITY && CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getRevolutionaryRisk() <= CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MAX_REV_RISK && !CFG.game.getCiv(n).isInvestOrganized(CFG.game.getCiv(n).getProvinceID(n2))) {
                    this.lProvincesToInvest.add(CFG.game.getCiv(n).getProvinceID(n2));
                    this.iMaxDangerLevel = Math.max(this.iMaxDangerLevel, CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getDangerLevel());
                    this.iMaxPop = Math.max(this.iMaxPop, CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getPopulationData().getPopulation());
                }
                ++n2;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
                break;
            }
        }
    }

    @Override
    protected boolean build(int n, int n2, boolean bl) {
        int n3;
        int n4 = -1;
        float f = 0.0f;
        for (n3 = this.lProvincesToInvest.size() - 1; n3 >= 0; --n3) {
            float f2;
            if (n4 < 0) {
                n4 = this.lProvincesToInvest.get(n3);
                f2 = this.getProvinceBuildScore(n, n4);
            } else {
                f2 = f;
                if (this.getProvinceBuildScore(n, this.lProvincesToInvest.get(n3)) > f) {
                    n4 = this.lProvincesToInvest.get(n3);
                    f2 = this.getProvinceBuildScore(n, n4);
                }
            }
            f = f2;
        }
        boolean bl2 = bl;
        if (n4 >= 0) {
            int n5 = (int)Math.min(this.getMoney(n), (long)DiplomacyManager.invest_MaxEconomy_Gold(n4, n));
            int n6 = (int)Math.min(Math.floor(CFG.game.getCiv(n).getMovePoints() / 12), (double)(CFG.game.getCiv(n).getNumOfProvinces() / 10));
            n3 = n5;
            if (n2 == 0) {
                n3 = n5;
                if (n6 > 1) {
                    n3 = n5;
                    if (CFG.oR.nextInt(100) < CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_SECOND_INVEST_CHANCE) {
                        n3 = (int)((float)n5 * (1.0f - (float)CFG.oR.nextInt(Math.max(2, CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_SECOND_INVEST_MAX_PERC)) / 100.0f));
                    }
                }
            }
            bl2 = bl;
            if (DiplomacyManager.invest(n4, n, n3)) {
                if (this.getMoney(n) > 10L && 12 <= CFG.game.getCiv(n).getMovePoints()) {
                    n5 = 0;
                    for (n3 = this.lProvincesToInvest.size() - 1; n3 >= 0; --n3) {
                        if (this.lProvincesToInvest.get(n3) == n4) {
                            this.lProvincesToInvest.remove(n3);
                            continue;
                        }
                        ++n5;
                    }
                    if (n5 > 0 && n2 < 10) {
                        return this.build(n, n2 + 1, true);
                    }
                }
                bl2 = true;
            }
        }
        return bl2;
    }

    @Override
    protected long getMoney(int n) {
        if (CFG.game.getCiv(n).getMoney() < AI_Style.getMoney_MinReserve(n)) {
            return 0L;
        }
        return (long)((float)CFG.game.getCiv(n).getMoney() - (float)AI_Style.getMoney_MinReserve(n) * this.fReserve);
    }

    protected float getProvinceBuildScore(int n, int n2) {
        return ((float)CFG.game.getProvince(n2).getPopulationData().getPopulation() / (float)this.iMaxPop * CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_POP_SCORE + CFG.game.getProvince(n2).getDevelopmentLevel() / CFG.game.getCiv(n).getTechnologyLevel() * CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_DEVELOPMENT_SCORE + (10.0f - Math.min(10.0f, (float)CFG.game.getProvince(n2).getPopulationData().getPopulation() / (float)CFG.game.getProvince(n2).getEconomy())) * CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_POP_ECO_DIFFERENCE_SCORE) * (10.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE + CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE * CFG.game.getProvince(n2).getProvinceStability()) * (10.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_DANGER_SCORE * (float)CFG.game.getProvince(n2).getDangerLevel() / (float)this.iMaxDangerLevel) * (10.0f - CFG.game.getProvince(n2).getRevolutionaryRisk());
    }
}

