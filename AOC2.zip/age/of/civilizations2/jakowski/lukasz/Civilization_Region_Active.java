/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.util.ArrayList;
import java.util.List;

class Civilization_Region_Active {
    private int iCivID;
    private List<Integer> lActiveRegions;
    private List<Integer> lRegionStyle;

    protected Civilization_Region_Active(int n, int n2, int n3) {
        this.iCivID = n;
        this.lActiveRegions = new ArrayList<Integer>();
        this.lActiveRegions.add(n2);
        this.lRegionStyle = new ArrayList<Integer>();
        this.lRegionStyle.add(n3);
    }

    protected final void addRegion(int n, int n2) {
        for (int i = 0; i < this.lActiveRegions.size(); ++i) {
            if (this.lActiveRegions.get(i) != n) continue;
            return;
        }
        this.lActiveRegions.add(n);
        this.lRegionStyle.add(n2);
    }

    protected final int getActiveRegionsSize() {
        return this.lActiveRegions.size();
    }

    protected final int getCivID() {
        return this.iCivID;
    }

    protected final int getRegionStyleID(int n) {
        for (int i = 0; i < this.lActiveRegions.size(); ++i) {
            if (this.lActiveRegions.get(i) != n) continue;
            return this.lRegionStyle.get(i);
        }
        return this.lRegionStyle.get(0);
    }

    protected final boolean isActive_RegionID(int n) {
        for (int i = 0; i < this.lActiveRegions.size(); ++i) {
            if (this.lActiveRegions.get(i) != n) continue;
            return true;
        }
        return false;
    }

    protected final void removeRegion(int n) {
        for (int i = 0; i < this.lActiveRegions.size(); ++i) {
            if (this.lActiveRegions.get(i) != n) continue;
            this.lActiveRegions.remove(i);
            this.lRegionStyle.remove(i);
            return;
        }
    }
}

