/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Game_NextTurnUpdate;
import age.of.civilizations2.jakowski.lukasz.Province;
import java.util.ArrayList;

class AI_Style_Rebels
extends AI_Style {
    protected AI_Style_Rebels() {
        this.TAG = "REBELS";
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT = 0.3f;
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM = 20;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final float attackProvince_Score(int n, int n2, int n3) {
        int n4 = 0;
        int n5 = 0;
        for (n2 = 0; n2 < CFG.game.getProvince(n3).getNeighboringProvincesSize(); ++n2) {
            int n6;
            int n7;
            if (CFG.game.getProvince(CFG.game.getProvince(n3).getNeighboringProvinces(n2)).getCivID() == n) {
                n7 = n4 + 1;
                n6 = n5;
            } else {
                n6 = n5;
                n7 = n4;
                if (CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(n3).getNeighboringProvinces(n2)).getCivID())) {
                    n6 = n5 + 1;
                    n7 = n4;
                }
            }
            n5 = n6;
            n4 = n7;
        }
        float f = (float)n4 / (float)(n4 + n5);
        try {
            float f2 = CFG.game.getProvince(n3).getRevolutionaryRisk();
            f += 0.075f * f2;
            return f;
        }
        catch (ArithmeticException arithmeticException) {
            return 0.0f;
        }
    }

    @Override
    protected void buildStartingBuildings(int n) {
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void tryRegroupArmy(int var1_1) {
        var2_2 = new ArrayList<Integer>();
        block0: for (var3_3 = 0; var3_3 < CFG.game.getCiv(var1_1).getNumOfProvinces(); ++var3_3) {
            if (CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getDangerLevel() != 0 || CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getArmy(0) <= 0) continue;
            var4_4 = 0;
            var5_5 = 0;
            while (true) {
                block17: {
                    block16: {
                        var6_6 = var4_4;
                        if (var5_5 >= CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvincesSize()) break block16;
                        if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getCivID() != var1_1 || CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getDangerLevel() <= 0) break block17;
                        var6_6 = 1;
                        CFG.gameAction.moveArmy(CFG.game.getCiv(var1_1).getProvinceID(var3_3), CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5), CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getArmy(0), var1_1, false, true);
                    }
                    if (var6_6 == 0) continue block0;
                    var2_2.add(CFG.game.getCiv(var1_1).getProvinceID(var3_3));
                    continue block0;
                }
                ++var5_5;
            }
        }
        if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE || CFG.oR.nextInt(100) >= 65) return;
        var7_7 = new ArrayList<Integer>();
        var2_2 = new ArrayList<E>();
        for (var3_3 = 0; var3_3 < CFG.game.getCiv(var1_1).getNumOfProvinces(); ++var3_3) {
            block3: for (var5_5 = 0; var5_5 < CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvincesSize(); ++var5_5) {
                if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getCivID() <= 0 || CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getArmy(0) <= 0 || CFG.game.getCiv(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getCivID()).getNumOfProvinces() <= 1 || !CFG.game.getCivsAtWar(var1_1, CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getCivID())) continue;
                var8_8 = 0;
                var4_4 = 0;
                while (true) {
                    block19: {
                        block18: {
                            var6_6 = var8_8;
                            if (var4_4 >= CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getNeighboringProvincesSize()) break block18;
                            if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var4_4)).getCivID() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getCivID() || CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var4_4)).getCivID() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var4_4)).getTrueOwnerOfProvince()) break block19;
                            var6_6 = 0 + 1;
                        }
                        if (var6_6 > 1) continue block3;
                        var7_7.add(CFG.game.getCiv(var1_1).getProvinceID(var3_3));
                        var2_2.add(CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var3_3)).getNeighboringProvinces(var5_5));
                        continue block3;
                    }
                    ++var4_4;
                }
            }
        }
        if (var7_7.size() <= 0) return;
        var3_3 = 0;
        while (var7_7.size() > 0 && CFG.game.getCiv(var1_1).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE && var3_3 < 35) {
            var6_6 = -1;
            var9_9 = 0.0f;
            block6: for (var3_3 = var7_7.size() - 1; var3_3 >= 0; --var3_3) {
                block21: {
                    block20: {
                        if (CFG.game.getCiv(var1_1).isMovingUnitsToProvinceID((Integer)var2_2.get(var3_3))) {
                            var5_5 = var6_6;
                            var10_10 = var9_9;
lbl54:
                            // 6 sources

                            while (true) {
                                var9_9 = var10_10;
                                var6_6 = var5_5;
                                continue block6;
                                break;
                            }
                        }
                        if (var6_6 >= 0) break block20;
                        var5_5 = var3_3;
                        var10_10 = this.attackProvince_Score(var1_1, (Integer)var7_7.get(var3_3), (Integer)var2_2.get(var3_3));
                        ** GOTO lbl54
                    }
                    var11_11 = this.attackProvince_Score(var1_1, (Integer)var7_7.get(var3_3), (Integer)var2_2.get(var3_3));
                    if (!(var9_9 < this.attackProvince_Score(var1_1, (Integer)var7_7.get(var3_3), (Integer)var2_2.get(var3_3)))) break block21;
                    var5_5 = var3_3;
                    var10_10 = var11_11;
                    ** GOTO lbl54
                }
                var10_10 = var9_9;
                var5_5 = var6_6;
                if (var9_9 != var11_11) ** GOTO lbl54
                var10_10 = var9_9;
                var5_5 = var6_6;
                if (CFG.oR.nextInt(100) >= 50) ** GOTO lbl54
                var5_5 = var3_3;
                var10_10 = var11_11;
                ** continue;
            }
            if (var6_6 < 0) return;
            if (CFG.game.getProvince((Integer)var7_7.get(var6_6)).getArmy(0) > 0) {
                CFG.gameAction.moveArmy((Integer)var7_7.get(var6_6), (Integer)var2_2.get(var6_6), CFG.game.getProvince((Integer)var7_7.get(var6_6)).getArmy(0), var1_1, false, true);
            }
            var7_7.remove(var6_6);
            var2_2.remove(var6_6);
            var3_3 = CFG.oR.nextInt(100);
        }
    }

    @Override
    protected void turnOrders(int n) {
        for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            int n2 = (int)(Game_NextTurnUpdate.AVERAGE_MANPOWER_PERTURN * 100.0f);
            if (CFG.game.getCiv(n).getNumOfUnits() >= n2) break;
            if (!((float)CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getArmy(0) < (float)CFG.game.getGameScenarios().getScenario_StartingPopulation() * 0.01f * CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getGrowthRate_Population())) continue;
            Province province = CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i));
            CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getArmy(0);
            float f = Game_NextTurnUpdate.AVERAGE_MANPOWER_PERTURN / 10.0f;
            float f2 = (float)CFG.oR.nextInt(100) / 100.0f;
            n2 = Game_Calendar.CURRENT_AGEID;
            province.updateArmy((int)(f * f2 * (float)(CFG.gameAges.getRebels_Army(n2) + 1)));
        }
        super.turnOrders(n);
    }
}

