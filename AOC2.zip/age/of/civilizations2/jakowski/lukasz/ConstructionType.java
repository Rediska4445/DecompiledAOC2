/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

public enum ConstructionType {
    PORT,
    TOWER,
    FORT,
    FARM,
    LIBRARY,
    ARMOURY,
    WORKSHOP,
    SUPPLY,
    NUCLEAR_REACTOR,
    BUNKER,
    SHAFT;	
    ZAVOD;

}

