/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_View;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_ViewEnd
extends Button_View {
    protected Button_ViewEnd(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        n2 = bl ? Images.top_view_right_h : Images.top_view_right_last;
        ImageManager.getImage(n2).draw2(spriteBatch, this.getPosX() + n, this.getHeight() - ImageManager.getImage(Images.top_view_right_last).getHeight() * 2, this.getWidth(), ImageManager.getImage(Images.top_view_right_last).getHeight(), true);
    }
}

