/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

public final class BuildConfig {
    public static final String APPLICATION_ID = "age.of.civilizations2.jakowski.lukasz";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = true;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 70;
    public static final String VERSION_NAME = "1.2.2.1";
}

