/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_New_Game_Players_Players_RIGHT
extends Button_New_Game_Players {
    protected Button_New_Game_Players_Players_RIGHT(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight(), true, false);
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), true, true);
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.45f);
            ImageManager.getImage(Images.btn_remove).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_remove).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_remove).getHeight() / 2 + n2, true);
        } else if (this.getIsHovered()) {
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight(), true, false);
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), true, true);
            spriteBatch.setColor(1.0f, 1.0f, 1.0f, 0.65f);
            ImageManager.getImage(Images.btn_remove).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_remove).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_remove).getHeight() / 2 + n2, true);
        } else {
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight(), true, false);
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), true, true);
            ImageManager.getImage(Images.btn_remove).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_remove).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_remove).getHeight() / 2 + n2, true);
        }
        spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + 1 + n, this.getPosY() + 2 + n2, 1, this.getHeight() - 6);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }
}

