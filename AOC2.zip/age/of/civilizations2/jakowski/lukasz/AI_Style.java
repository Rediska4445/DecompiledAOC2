/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI;
import age.of.civilizations2.jakowski.lukasz.AI_ArmyUpkeep;
import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Armoury;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Bunker;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Fort;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Invest;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Invest_Development;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Library;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_NuclearReactor;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Port;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Supplies;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Tower;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option_Workshop;
import age.of.civilizations2.jakowski.lukasz.AI_CivsInRange;
import age.of.civilizations2.jakowski.lukasz.AI_Frontline;
import age.of.civilizations2.jakowski.lukasz.AI_Influence;
import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces;
import age.of.civilizations2.jakowski.lukasz.AI_ProvinceInfo;
import age.of.civilizations2.jakowski.lukasz.AI_ProvinceInfo_War;
import age.of.civilizations2.jakowski.lukasz.AI_ProvinceValue;
import age.of.civilizations2.jakowski.lukasz.AI_RegoupArmyData;
import age.of.civilizations2.jakowski.lukasz.AI_ReleaseVassal;
import age.of.civilizations2.jakowski.lukasz.AI_Rival;
import age.of.civilizations2.jakowski.lukasz.AI_Skills;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Administration;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Eco;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Military;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Production;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Research;
import age.of.civilizations2.jakowski.lukasz.AI_Skills_Taxation;
import age.of.civilizations2.jakowski.lukasz.Assimilate_Data;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_ColonizeProvince;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_NavalInvasion;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_RegroupAfterRecruitment;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_RegroupAfterRecruitment_War;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.Civilization;
import age.of.civilizations2.jakowski.lukasz.Civilization_Diplomacy_GameData;
import age.of.civilizations2.jakowski.lukasz.Civilization_SentMessages;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Event_Decision;
import age.of.civilizations2.jakowski.lukasz.Event_GameData;
import age.of.civilizations2.jakowski.lukasz.Game_Action;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Game_Render_Province;
import age.of.civilizations2.jakowski.lukasz.Message_Type;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_AtPeace;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_AtWar;
import age.of.civilizations2.jakowski.lukasz.SkillsManager;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import age.of.civilizations2.jakowski.lukasz.TradeRequest_GameData;
import age.of.civilizations2.jakowski.lukasz.Ultimatum_GameData;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

class AI_Style {
    protected static final int MIN_ARMY_TO_ATTACK = 100;
    protected int MIN_TURNS_TO_ABANDON_USELESS_PROVINCE = 25;
    protected float PERSONALITY_FORGIVNESS_DEFAULT = 1.0f;
    protected int PERSONALITY_FORGIVNESS_RANDOM = 50;
    protected int PERSONALITY_GOODS_RANDOM = 100;
    protected int PERSONALITY_INVESTMENTS_RANDOM = 100;
    protected float PERSONALITY_MIN_AGGRESION_DEFAULT = 0.2475f;
    protected int PERSONALITY_MIN_AGGRESION_RANDOM = 4825;
    protected float PERSONALITY_MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY_DEFAULT = 0.6f;
    protected int PERSONALITY_MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY_RANDOM = 35;
    protected int PERSONALITY_MIN_HAPPINESS_DEFAULT = 69;
    protected int PERSONALITY_MIN_HAPPINESS_RANDOM = 24;
    protected float PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT = 0.05f;
    protected int PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM = 7;
    protected int PERSONALITY_PLUNDER_LOCK = 78;
    protected int PERSONALITY_PLUNDER_MIN = 0;
    protected int PERSONALITY_PLUNDER_RANDOM = 45;
    protected int PERSONALITY_RESEARCH_RANDOM = 100;
    protected int RIVAL_MIN_TURNS = 34;
    protected String TAG = "DEFAULT";
    protected int USE_OF_BUDGET_FOR_SPENDINGS = 35;
    protected int USE_OF_BUDGET_FOR_SPENDINGS_RANDOM = 65;
    protected boolean armyOverBudget = false;

    protected AI_Style() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean diplomacyActions_RivalCiv_IsRival(int n, int n2) {
        int n3 = 0;
        while (n3 < CFG.game.getCiv((int)n).civGameData.civRivalsSize) {
            if (CFG.game.getCiv((int)n).civGameData.civRivals.get((int)n3).iCivID == n2) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    protected static final long getMoney_MinReserve(int n) {
        return (long)Math.max((float)AI_Style.getMoney_MinReserve_LockTreasury(n), (float)CFG.game.getCiv((int)n).iBudget * CFG.game.getCiv((int)n).civGameData.civPersonality.TREASURY_RESERVE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final long getMoney_MinReserve_LockTreasury(int n) {
        if (CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment == null) return CFG.game.getCiv((int)n).civGameData.iLockTreasury;
        return Math.max(CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment.iCost, CFG.game.getCiv((int)n).civGameData.iLockTreasury);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean abandonOrReleaseAsVassalProvinces(int n, List<Integer> list, boolean bl) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        Gdx.app.log("AoC", "abandonOrReleaseAsVassalProvinces -> " + CFG.game.getCiv(n).getCivName());
        Serializable serializable = new ArrayList<AI_ReleaseVassal>();
        for (n6 = list.size() - 1; n6 >= 0; --n6) {
            block1: for (n5 = 0; n5 < CFG.game.getProvince(list.get(n6)).getCore().getCivsSize(); ++n5) {
                if (CFG.game.getCiv(CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5)).getNumOfProvinces() != 0) continue;
                n4 = 1;
                n3 = serializable.size() - 1;
                while (true) {
                    block35: {
                        block34: {
                            n2 = n4;
                            if (n3 < 0) break block34;
                            if (((AI_ReleaseVassal)serializable.get((int)n3)).iCivID != CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5)) break block35;
                            n2 = 0;
                            ((AI_ReleaseVassal)serializable.get(n3)).addProvince(list.get(n6));
                        }
                        if (n2 == 0) continue block1;
                        serializable.add((AI_ReleaseVassal)new AI_ReleaseVassal(CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5), list.get(n6)));
                        continue block1;
                    }
                    --n3;
                }
            }
        }
        if (serializable.size() > 0 && (n5 = this.abandonOrReleaseAsVassalProvinces_ReleaseVassal((List<AI_ReleaseVassal>)((Object)serializable), list, n)) >= 0) {
            n6 = list.size() - 1;
            while (n6 >= 0) {
                if (CFG.game.getCiv(n5).controlsProvince(list.get(n6))) {
                    list.remove(n6);
                }
                --n6;
            }
            return this.abandonOrReleaseAsVassalProvinces(n, list, bl);
        }
        serializable.clear();
        for (n6 = list.size() - 1; n6 >= 0; --n6) {
            block5: for (n5 = 0; n5 < CFG.game.getProvince(list.get(n6)).getNeighboringProvincesSize(); ++n5) {
                if (CFG.game.getProvince(CFG.game.getProvince(list.get(n6)).getNeighboringProvinces(n5)).getCivID() <= 0 || CFG.game.getProvince(CFG.game.getProvince(list.get(n6)).getNeighboringProvinces(n5)).getCivID() == n) continue;
                n4 = 1;
                n3 = serializable.size() - 1;
                while (true) {
                    block37: {
                        block36: {
                            n2 = n4;
                            if (n3 < 0) break block36;
                            if (((AI_ReleaseVassal)serializable.get((int)n3)).iCivID != CFG.game.getProvince(CFG.game.getProvince(list.get(n6)).getNeighboringProvinces(n5)).getCivID()) break block37;
                            n2 = 0;
                            ((AI_ReleaseVassal)serializable.get(n3)).addProvince(list.get(n6));
                        }
                        if (n2 == 0) continue block5;
                        serializable.add(new AI_ReleaseVassal(CFG.game.getProvince(CFG.game.getProvince(list.get(n6)).getNeighboringProvinces(n5)).getCivID(), list.get(n6)));
                        continue block5;
                    }
                    --n3;
                }
            }
            block7: for (n5 = 0; n5 < CFG.game.getProvince(list.get(n6)).getCore().getCivsSize(); ++n5) {
                if (CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5) == n) continue;
                n4 = 1;
                n2 = serializable.size() - 1;
                while (true) {
                    block39: {
                        block38: {
                            n3 = n4;
                            if (n2 < 0) break block38;
                            if (((AI_ReleaseVassal)serializable.get((int)n2)).iCivID != CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5)) break block39;
                            n3 = n4 = 0;
                            if (!((AI_ReleaseVassal)serializable.get(n2)).haveProvince(list.get(n6))) {
                                ((AI_ReleaseVassal)serializable.get(n2)).addProvince(list.get(n6));
                                n3 = n4;
                            }
                        }
                        if (n3 == 0) continue block7;
                        serializable.add(new AI_ReleaseVassal(CFG.game.getProvince(list.get(n6)).getCore().getCivID(n5), list.get(n6)));
                        continue block7;
                    }
                    --n2;
                }
            }
        }
        ArrayList arrayList = new ArrayList();
        for (n6 = serializable.size() - 1; n6 >= 0; --n6) {
            if (!CFG.game.isAlly(n, ((AI_ReleaseVassal)serializable.get((int)n6)).iCivID)) continue;
            arrayList.add(serializable.get(n6));
        }
        for (n6 = arrayList.size() - 1; n6 >= 0; --n6) {
            for (n5 = CFG.game.getCiv(n).getSentMessagesSize() - 1; n5 >= 0; --n5) {
                if (CFG.game.getCiv((int)n).getSentMessage((int)n5).messageType != Message_Type.TRADE_REQUEST_GIVE_PROVINCES || CFG.game.getCiv((int)n).getSentMessage((int)n5).iToCivID != ((AI_ReleaseVassal)arrayList.get((int)n6)).iCivID) continue;
                arrayList.remove(n6);
            }
        }
        while (arrayList.size() > 0) {
            n5 = 0;
            for (n6 = arrayList.size() - 1; n6 > 0; --n6) {
                if (((AI_ReleaseVassal)arrayList.get((int)n5)).lProvinces.size() >= ((AI_ReleaseVassal)arrayList.get((int)n6)).lProvinces.size() && CFG.oR.nextInt(100) >= 96) continue;
                n5 = n6;
            }
            serializable = new TradeRequest_GameData();
            for (n6 = ((AI_ReleaseVassal)arrayList.get((int)n5)).lProvinces.size() - 1; n6 >= 0; --n6) {
                serializable.listLEFT.lProvinces.add(((AI_ReleaseVassal)arrayList.get((int)n5)).lProvinces.get(n6));
            }
            if (!DiplomacyManager.sendTradeRequest(((AI_ReleaseVassal)arrayList.get((int)n5)).iCivID, n, (TradeRequest_GameData)serializable)) break;
            CFG.game.getCiv((int)n).civGameData.lSentMessages.add(new Civilization_SentMessages(((AI_ReleaseVassal)arrayList.get((int)n5)).iCivID, Message_Type.TRADE_REQUEST_GIVE_PROVINCES));
            CFG.game.getCiv((int)((AI_ReleaseVassal)arrayList.get((int)n5)).iCivID).civGameData.lSentMessages.add(new Civilization_SentMessages(n, Message_Type.TRADE_REQUEST_GIVE_PROVINCES));
            block15: for (n6 = serializable.listLEFT.lProvinces.size() - 1; n6 >= 0; --n6) {
                Gdx.app.log("AoC", "abandonOrReleaseAsVassalProvinces -> nTD.listLEFT.lProvinces: " + CFG.game.getProvince(serializable.listLEFT.lProvinces.get(n6)).getName());
                n3 = list.size() - 1;
                while (true) {
                    if (n3 < 0) continue block15;
                    if (list.get(n3).equals(serializable.listLEFT.lProvinces.get(n6))) {
                        list.remove(n3);
                        continue block15;
                    }
                    --n3;
                }
            }
            for (n6 = arrayList.size() - 1; n6 >= 0; --n6) {
                if (n6 == n5) continue;
                for (n3 = ((AI_ReleaseVassal)arrayList.get((int)n5)).lProvinces.size() - 1; n3 >= 0; --n3) {
                    ((AI_ReleaseVassal)arrayList.get(n6)).removeProvinceID(((AI_ReleaseVassal)arrayList.get((int)n5)).lProvinces.get(n3));
                }
            }
            arrayList.remove(n5);
            for (n6 = arrayList.size() - 1; n6 >= 0; --n6) {
                if (((AI_ReleaseVassal)arrayList.get((int)n6)).lProvinces.size() != 0) continue;
                arrayList.remove(n6);
            }
        }
        n6 = list.size() - 1;
        while (n6 >= 0) {
            CFG.gameAction.abadonProvince(list.get(n6), n);
            --n6;
        }
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final int abandonOrReleaseAsVassalProvinces_ReleaseVassal(List<AI_ReleaseVassal> var1_1, List<Integer> var2_2, int var3_3) {
        var4_4 = 0;
        block0: for (var5_5 = var1_1.size() - 1; var5_5 > 0; --var5_5) {
            if (var1_1.get((int)var4_4).lProvinces.size() < var1_1.get((int)var5_5).lProvinces.size()) {
                var6_6 = var5_5;
lbl5:
                // 4 sources

                while (true) {
                    var4_4 = var6_6;
                    continue block0;
                    break;
                }
            }
            var6_6 = var4_4;
            if (var1_1.get((int)var4_4).lProvinces.size() != var1_1.get((int)var5_5).lProvinces.size()) ** GOTO lbl5
            var6_6 = var4_4;
            if (CFG.oR.nextInt(100) >= 50) ** GOTO lbl5
            var6_6 = var5_5;
            ** continue;
        }
        for (var5_5 = var2_2.size() - 1; var5_5 >= 0; --var5_5) {
            CFG.game.getProvince((int)var2_2.get((int)var5_5).intValue()).was = true;
        }
        for (var5_5 = var1_1.get((int)var4_4).lProvinces.size() - 1; var5_5 >= 0; --var5_5) {
            CFG.game.getProvince((int)var1_1.get((int)var4_4).lProvinces.get((int)var5_5).intValue()).was = false;
        }
        for (var6_6 = 0; var6_6 < var1_1.get((int)var4_4).lProvinces.size(); ++var6_6) {
            for (var7_7 = 0; var7_7 < CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringProvincesSize(); ++var7_7) {
                block19: {
                    if (!CFG.game.getProvince((int)CFG.game.getProvince((int)var1_1.get((int)var4_4).lProvinces.get((int)var6_6).intValue()).getNeighboringProvinces((int)var7_7)).was) continue;
                    var8_8 = 1;
                    var9_9 = var1_1.size() - 1;
                    block6: while (true) {
                        block22: {
                            block21: {
                                var5_5 = var8_8;
                                if (var9_9 < 0) break block21;
                                if (!CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringProvinces(var7_7)).getCore().getHaveACore(var1_1.get((int)var9_9).iCivID)) break block22;
                                var5_5 = 0;
                            }
                            block7: for (var9_9 = 0; var9_9 < CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringProvinces(var7_7)).getNeighboringProvincesSize(); ++var9_9) {
                                var10_10 = var1_1.size() - 1;
lbl33:
                                // 2 sources

                                while (true) {
                                    var8_8 = var5_5;
                                    if (var10_10 >= 0) {
                                        if (var10_10 == var4_4 || !var1_1.get(var10_10).haveProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringProvinces(var7_7)).getNeighboringProvinces(var9_9))) break block6;
                                        var8_8 = 0;
                                    }
                                    var5_5 = var8_8;
                                    continue block7;
                                    break;
                                }
                            }
                            break block19;
                        }
                        --var9_9;
                    }
                    --var10_10;
                    ** continue;
                }
                if (var5_5 == 0) continue;
                var1_1.get(var4_4).addProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringProvinces(var7_7));
                CFG.game.getProvince((int)CFG.game.getProvince((int)var1_1.get((int)var4_4).lProvinces.get((int)var6_6).intValue()).getNeighboringProvinces((int)var7_7)).was = false;
            }
            for (var7_7 = 0; var7_7 < CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvincesSize(); ++var7_7) {
                for (var9_9 = 0; var9_9 < CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvincesSize(); ++var9_9) {
                    block20: {
                        if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvinces(var9_9)).getSeaProvince() || !CFG.game.getProvince((int)CFG.game.getProvince((int)CFG.game.getProvince((int)var1_1.get((int)var4_4).lProvinces.get((int)var6_6).intValue()).getNeighboringSeaProvinces((int)var7_7)).getNeighboringProvinces((int)var9_9)).was) continue;
                        var10_10 = 1;
                        var8_8 = var1_1.size() - 1;
                        block11: while (true) {
                            block24: {
                                block23: {
                                    var5_5 = var10_10;
                                    if (var8_8 < 0) break block23;
                                    if (!CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvinces(var9_9)).getCore().getHaveACore(var1_1.get((int)var8_8).iCivID)) break block24;
                                    var5_5 = 0;
                                }
                                block12: for (var8_8 = 0; var8_8 < CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvinces(var9_9)).getNeighboringProvincesSize(); ++var8_8) {
                                    var11_11 = var1_1.size() - 1;
lbl64:
                                    // 2 sources

                                    while (true) {
                                        var10_10 = var5_5;
                                        if (var11_11 >= 0) {
                                            if (var11_11 == var4_4 || !var1_1.get(var11_11).haveProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvinces(var9_9)).getNeighboringProvinces(var8_8))) break block11;
                                            var10_10 = 0;
                                        }
                                        var5_5 = var10_10;
                                        continue block12;
                                        break;
                                    }
                                }
                                break block20;
                            }
                            --var8_8;
                        }
                        --var11_11;
                        ** continue;
                    }
                    if (var5_5 == 0) continue;
                    var1_1.get(var4_4).addProvince(CFG.game.getProvince(CFG.game.getProvince(var1_1.get((int)var4_4).lProvinces.get(var6_6)).getNeighboringSeaProvinces(var7_7)).getNeighboringProvinces(var9_9));
                    CFG.game.getProvince((int)CFG.game.getProvince((int)CFG.game.getProvince((int)var1_1.get((int)var4_4).lProvinces.get((int)var6_6).intValue()).getNeighboringSeaProvinces((int)var7_7)).getNeighboringProvinces((int)var9_9)).was = false;
                }
            }
        }
        this.clearWas(var2_2);
        return CFG.game.releaseAVasssal(CFG.game.getCiv(var1_1.get((int)var4_4).iCivID).getCivTag(), var1_1.get((int)var4_4).lProvinces, -1, var3_3, true);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean alliesAtWar(int n) {
        int n2 = 1;
        while (n2 < CFG.game.getCivsSize()) {
            if (n2 != n && CFG.game.isAlly(n, n2) && CFG.game.getCiv(n2).isAtWar()) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void armyOverBudget_Disband(int var1_1) {
        if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_DISBAND) {
            Gdx.app.log("AoC", "armyOverBudget_Disband -> NO MOVEMENT POITNS");
            return;
        }
        if ((CFG.game.getCiv(var1_1).isAtWar() || CFG.game.getCiv((int)var1_1).civGameData.civPlans.isPreparingForTheWar()) && CFG.game.getCiv((int)var1_1).iBudget > 0 && CFG.game.getCiv(var1_1).getMoney() + (long)(CFG.game.getCiv((int)var1_1).iBudget * 3) > 0L) {
            Gdx.app.log("AoC", "armyOverBudget_Disband -> 000, DONT DISBAND ARMY, WE NEEED IT!!!1");
            return;
        }
        Gdx.app.log("AoC", "armyOverBudget_Disband -> 000");
        var2_2 = new ArrayList<AI_ArmyUpkeep>();
        var3_3 = CFG.game.getCiv((int)var1_1).iBudget;
        var4_4 = this.getMinMilitarySpendings(var1_1);
        var5_5 = (int)(var4_4 * var3_3);
        var3_3 = CFG.game.getCiv((int)var1_1).iBudget;
        var4_4 = this.getMinMilitarySpendings(var1_1);
        var6_6 = (int)Math.abs(var4_4 * var3_3 - (float)CFG.game.getCiv((int)var1_1).iBudget * CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC);
        Gdx.app.log("AoC", "armyOverBudget_Disband -> CFG.game.getCiv(nCivID).iMilitaryUpkeep_Total: " + CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_Total);
        Gdx.app.log("AoC", "armyOverBudget_Disband -> spendingsOnArmy: " + var5_5);
        Gdx.app.log("AoC", "armyOverBudget_Disband -> budgetForArmyisOver: " + var6_6);
        if (CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_Total <= var5_5) return;
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> AA00");
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> CFG.game.getCiv(nCivID).iArmiesPositionSize: " + CFG.game.getCiv((int)var1_1).iArmiesPositionSize);
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> CFG.game.getCiv(nCivID).lArmiesPosition.size(): " + CFG.game.getCiv((int)var1_1).lArmiesPosition.size());
        for (var5_5 = 0; var5_5 < CFG.game.getCiv((int)var1_1).iArmiesPositionSize; ++var5_5) {
            var2_2.add(new AI_ArmyUpkeep(var1_1, CFG.game.getCiv((int)var1_1).lArmiesPosition.get(var5_5)));
        }
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> armyUpkeep.SIZE: " + var2_2.size());
        var7_7 = new ArrayList<E>();
        for (var5_5 = var2_2.size() - 1; var5_5 >= 0; --var5_5) {
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> armyUpkeep.get(i).iCost: " + ((AI_ArmyUpkeep)var2_2.get((int)var5_5)).iCost + ", budgetForArmyisOver: " + var6_6);
            if (((AI_ArmyUpkeep)var2_2.get((int)var5_5)).iCost < var6_6) continue;
            var7_7.add(var2_2.get(var5_5));
        }
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> armiesOver.SIZE: " + var7_7.size());
        if (var7_7.size() > 0) {
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> AA11");
            var8_8 = 0;
            for (var5_5 = 0 + 1; var5_5 < var7_7.size(); ++var5_5) {
                var9_10 = var8_8;
                if (CFG.game.getProvince(((AI_ArmyUpkeep)var7_7.get((int)var8_8)).iProvinceID).getDangerLevel() > CFG.game.getProvince(((AI_ArmyUpkeep)var7_7.get((int)var5_5)).iProvinceID).getDangerLevel()) {
                    var9_10 = var5_5;
                }
                var8_8 = var9_10;
            }
            var4_4 = CFG.game_NextTurnUpdate.getMilitaryUpkeep(((AI_ArmyUpkeep)var7_7.get((int)var8_8)).iProvinceID, 1000, var1_1) / 1000.0f * 1.05f;
            var5_5 = CFG.game.getProvince(((AI_ArmyUpkeep)var7_7.get((int)var8_8)).iProvinceID).getArmyCivID(var1_1);
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> maxDisbandArmy: " + var5_5);
            if (var5_5 > 0) {
                Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> 33333 -> " + (int)Math.min(Math.ceil((float)var6_6 / var4_4), (double)var5_5));
                CFG.gameAction.disbandArmy(((AI_ArmyUpkeep)var7_7.get((int)var8_8)).iProvinceID, (int)Math.min(Math.ceil((float)var6_6 / var4_4), (double)var5_5), var1_1);
                return;
            }
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> 44444");
            return;
        }
        Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND OVER BUDGET -> BB0");
        var7_7.clear();
        for (var5_5 = var2_2.size() - 1; var5_5 >= 0; --var5_5) {
            if (CFG.game.getProvince(((AI_ArmyUpkeep)var2_2.get((int)var5_5)).iProvinceID).getDangerLevel() != 0) continue;
            var7_7.add(var2_2.get(var5_5));
        }
        var5_5 = var6_6;
        if (var7_7.size() <= 0) ** GOTO lbl93
        var8_9 = 0;
        for (var5_5 = var7_7.size() - 1; var5_5 >= 0; var8_9 += ((AI_ArmyUpkeep)var7_7.get((int)var5_5)).iCost, --var5_5) {
        }
        var5_5 = var6_6;
        if (var8_9 < var6_6) ** GOTO lbl93
        while (true) {
            var5_5 = var6_6;
            if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_DISBAND) ** GOTO lbl93
            var5_5 = var6_6;
            if (var7_7.size() <= 0) ** GOTO lbl93
            if (var6_6 <= 0) return;
            var8_9 = 0;
            for (var5_5 = var7_7.size() - 1; var5_5 > 0; --var5_5) {
                var9_11 = var8_9;
                if (((AI_ArmyUpkeep)var7_7.get((int)var8_9)).iCost < ((AI_ArmyUpkeep)var7_7.get((int)var5_5)).iCost) {
                    var9_11 = var5_5;
                }
                var8_9 = var9_11;
            }
            var4_4 = CFG.game_NextTurnUpdate.getMilitaryUpkeep(((AI_ArmyUpkeep)var7_7.get((int)var8_9)).iProvinceID, 1000, var1_1) / 1000.0f;
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND -> 44444");
            CFG.gameAction.disbandArmy(((AI_ArmyUpkeep)var7_7.get((int)var8_9)).iProvinceID, (int)Math.ceil((float)var6_6 / (var4_4 * 1.05f)), var1_1);
            var6_6 -= ((AI_ArmyUpkeep)var7_7.get((int)var8_9)).iCost;
            var7_7.remove(var8_9);
        }
        {
            var4_4 = CFG.game_NextTurnUpdate.getMilitaryUpkeep(((AI_ArmyUpkeep)var2_2.get((int)var8_9)).iProvinceID, 1000, var1_1) / 1000.0f;
            Gdx.app.log("AoC", "armyOverBudget_Disband -> DISBAND -> 55555");
            CFG.gameAction.disbandArmy(((AI_ArmyUpkeep)var2_2.get((int)var8_9)).iProvinceID, (int)Math.ceil((float)var5_5 / (var4_4 * 1.05f)), var1_1);
            var5_5 -= ((AI_ArmyUpkeep)var2_2.get((int)var8_9)).iCost;
            var2_2.remove(var8_9);
lbl93:
            // 5 sources

            if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_DISBAND) return;
            if (var2_2.size() <= 0) return;
            if (var5_5 <= 0) return;
            var8_9 = 0;
            var6_6 = var2_2.size() - 1;
            while (true) {
                if (var6_6 <= 0) continue block7;
                var9_11 = var8_9;
                if (((AI_ArmyUpkeep)var2_2.get((int)var8_9)).iCost < ((AI_ArmyUpkeep)var2_2.get((int)var6_6)).iCost) {
                    var9_11 = var6_6;
                }
                --var6_6;
                var8_9 = var9_11;
            }
        }
    }

    protected final float armyOverBudget_Disband_AtWar(int n) {
        return 0.9f - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(n).getIdeologyID()).getMin_Goods(n) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).MIN_INVESTMENTS;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void assimilateProvinces(int var1_1) {
        try {
            if (CFG.game.getCiv(var1_1).getDiplomacyPoints() < 4) return;
            if (!((float)CFG.game.getCiv(var1_1).getMoney() >= (float)DiplomacyManager.assimilateCost(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(0), 10) * 1.225f)) return;
            var2_2 = new ArrayList<ArrayList<E>>();
            var3_5 = CFG.game.getCiv(var1_1).getCapitalProvinceID() >= 0 ? CFG.game.getCiv(var1_1).getCapitalProvinceID() : CFG.game.getCiv(var1_1).getProvinceID(0);
            for (var4_6 = CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() - 1; var4_6 >= 0; --var4_6) {
                var6_8 = CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6);
                var7_9 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_POPULATION_SCORE;
                var8_10 = Math.min((float)CFG.game.getProvince(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6)).getPopulationData().getPopulation() / (float)CFG.game.getGameScenarios().getScenario_StartingPopulation(), 1.0f);
                var9_11 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_DISTANCE_SCORE;
                var10_12 = CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(var3_5, CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6));
                var11_13 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_LOW_STABILITY_SCORE;
                var5_7 = new ArrayList<E>(var6_8, (1.0f - CFG.game.getProvince(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6)).getProvinceStability()) * var11_13 + (var7_9 * var8_10 + var10_12 * var9_11));
                var2_2.add(var5_7);
            }
            var5_7 = new ArrayList<E>();
            while (var2_2.size() > 0) {
                var6_8 = 0;
                for (var3_5 = 0 + 1; var3_5 < var2_2.size(); ++var3_5) {
                    var4_6 = var6_8;
                    if (((Assimilate_Data)var2_2.get((int)var3_5)).fScore > ((Assimilate_Data)var2_2.get((int)var6_8)).fScore) {
                        var4_6 = var3_5;
                    }
                    var6_8 = var4_6;
                }
                var5_7.add(var2_2.get(var6_8));
                var2_2.remove(var6_8);
            }
            ** GOTO lbl41
        }
        catch (IndexOutOfBoundsException var2_3) {
            CFG.exceptionStack(var2_3);
        }
        return;
        catch (NullPointerException var2_4) {
            CFG.exceptionStack(var2_4);
            return;
        }
        while ((float)CFG.game.getCiv(var1_1).getMoney() >= (float)DiplomacyManager.assimilateCost(((Assimilate_Data)var5_7.get((int)0)).iProvinceID, 10) * 1.225f && DiplomacyManager.addAssimilate(var1_1, ((Assimilate_Data)var5_7.get((int)0)).iProvinceID, (int)Math.min(Math.min((100.0f - CFG.game.getProvince(((Assimilate_Data)var5_7.get((int)0)).iProvinceID).getProvinceStability() * 100.0f) / 1.724f, (float)(CFG.game.getCiv(var1_1).getMoney() / (long)DiplomacyManager.assimilateCost(((Assimilate_Data)var5_7.get((int)0)).iProvinceID, 1))), 40.0f))) {
            var5_7.remove(0);
lbl41:
            // 2 sources

            if (CFG.game.getCiv(var1_1).getDiplomacyPoints() >= 4 && var5_7.size() != 0) continue;
        }
        var5_7.clear();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void assimilateProvincesPlayer(int var1_1) {
        try {
            if (CFG.game.getCiv(var1_1).getDiplomacyPoints() < 4) return;
            if (!((float)CFG.game.getCiv(var1_1).getMoney() >= (float)DiplomacyManager.assimilateCost(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(0), 10) * 1.225f)) return;
            var2_2 = new ArrayList<ArrayList<E>>();
            var3_5 = CFG.game.getCiv(var1_1).getCapitalProvinceID() >= 0 ? CFG.game.getCiv(var1_1).getCapitalProvinceID() : CFG.game.getCiv(var1_1).getProvinceID(0);
            for (var4_6 = CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() - 1; var4_6 >= 0; --var4_6) {
                var6_8 = CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6);
                var7_9 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_POPULATION_SCORE;
                var8_10 = Math.min((float)CFG.game.getProvince(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6)).getPopulationData().getPopulation() / (float)CFG.game.getGameScenarios().getScenario_StartingPopulation(), 1.0f);
                var9_11 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_DISTANCE_SCORE;
                var10_12 = CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(var3_5, CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6));
                var11_13 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.ASSIMILATE_PERC_LOW_STABILITY_SCORE;
                var5_7 = new ArrayList<E>(var6_8, (1.0f - CFG.game.getProvince(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(var4_6)).getProvinceStability()) * var11_13 + (var7_9 * var8_10 + var10_12 * var9_11));
                var2_2.add(var5_7);
            }
            var5_7 = new ArrayList<E>();
            while (var2_2.size() > 0) {
                var6_8 = 0;
                for (var3_5 = 0 + 1; var3_5 < var2_2.size(); ++var3_5) {
                    var4_6 = var6_8;
                    if (((Assimilate_Data)var2_2.get((int)var3_5)).fScore > ((Assimilate_Data)var2_2.get((int)var6_8)).fScore) {
                        var4_6 = var3_5;
                    }
                    var6_8 = var4_6;
                }
                var5_7.add(var2_2.get(var6_8));
                var2_2.remove(var6_8);
            }
            ** GOTO lbl41
        }
        catch (IndexOutOfBoundsException var2_3) {
            CFG.exceptionStack(var2_3);
        }
        return;
        catch (NullPointerException var2_4) {
            CFG.exceptionStack(var2_4);
            return;
        }
        while ((float)CFG.game.getCiv(var1_1).getMoney() >= (float)DiplomacyManager.assimilateCost(((Assimilate_Data)var5_7.get((int)0)).iProvinceID, 10) * 1.225f && DiplomacyManager.addAssimilate(var1_1, ((Assimilate_Data)var5_7.get((int)0)).iProvinceID, (int)Math.min(Math.min((100.0f - CFG.game.getProvince(((Assimilate_Data)var5_7.get((int)0)).iProvinceID).getProvinceStability() * 100.0f) / 1.724f, (float)(CFG.game.getCiv(var1_1).getMoney() / (long)DiplomacyManager.assimilateCost(((Assimilate_Data)var5_7.get((int)0)).iProvinceID, 1))), 100.0f))) {
            var5_7.remove(0);
lbl41:
            // 2 sources

            if (CFG.game.getCiv(var1_1).getDiplomacyPoints() >= 4 && var5_7.size() != 0) continue;
        }
        var5_7.clear();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void buildBuildings(int n) {
        if (this.build_GetMoney(n) > 0L) {
            ArrayList<AI_Build> arrayList = new ArrayList<AI_Build>();
            ArrayList<AI_Build_Option> arrayList2 = new ArrayList<AI_Build_Option>();
            try {
                AI_Build_Option aI_Build_Option;
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(1) && CFG.game.getCiv((int)n).iNumOf_Farms_ProvincesPossibleToBuild * BuildingsManager.getWorkshop_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Farms) {
                    aI_Build_Option = new AI_Build_Option();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getWorkshop_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getWorkshop_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Workshops) {
                    aI_Build_Option = new AI_Build_Option_Workshop();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getLibrary_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getLibrary_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Libraries) {
                    aI_Build_Option = new AI_Build_Option_Library();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getSeaAccess() > 0 && CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getPort_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_Ports) {
                    aI_Build_Option = new AI_Build_Option_Port();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getArmoury_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_Armories) {
                    aI_Build_Option = new AI_Build_Option_Armoury();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getNuclearReactor_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_NuclearReactors) {
                    aI_Build_Option = new AI_Build_Option_NuclearReactor();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getBunker_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_Bunkers) {
                    aI_Build_Option = new AI_Build_Option_Bunker();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getSupply_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_SuppliesCamp) {
                    aI_Build_Option = new AI_Build_Option_Supplies();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getFort_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Forts) {
                    aI_Build_Option = new AI_Build_Option_Fort();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getTower_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getTower_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Towers) {
                    aI_Build_Option = new AI_Build_Option_Tower();
                    arrayList2.add(aI_Build_Option);
                }
                aI_Build_Option = new AI_Build_Option_Invest();
                arrayList2.add(aI_Build_Option);
                if (CFG.game.getCiv((int)n).fAverageDevelopment / CFG.game.getCiv(n).getTechnologyLevel() < 0.9f) {
                    aI_Build_Option = new AI_Build_Option_Invest_Development();
                    arrayList2.add(aI_Build_Option);
                }
                if (arrayList2.size() > 0) {
                    int n2 = 0;
                    for (int i = 0 + 1; i < arrayList2.size(); ++i) {
                        int n3 = n2;
                        if (((AI_Build_Option)arrayList2.get(i)).getScore(n) > ((AI_Build_Option)arrayList2.get(n2)).getScore(n)) {
                            n3 = i;
                        }
                        n2 = n3;
                    }
                    arrayList.add(((AI_Build_Option)arrayList2.get(n2)).getData(n));
                    if (((AI_Build)arrayList.get(0)).build(n, 0, false)) {
                        CFG.game.getCiv(n).buildCivPersonality_Buildings();
                    }
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
            }
            arrayList2.clear();
            arrayList.clear();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void buildBuildings_ForPlayer(int n) {
        if (CFG.game.getCiv(n).getMoney() > 0L) {
            ArrayList<AI_Build> arrayList = new ArrayList<AI_Build>();
            ArrayList<AI_Build_Option> arrayList2 = new ArrayList<AI_Build_Option>();
            try {
                AI_Build_Option aI_Build_Option;
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(1) && CFG.game.getCiv((int)n).iNumOf_Farms_ProvincesPossibleToBuild * BuildingsManager.getWorkshop_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Farms) {
                    aI_Build_Option = new AI_Build_Option();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getWorkshop_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getWorkshop_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Workshops) {
                    aI_Build_Option = new AI_Build_Option_Workshop();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getLibrary_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getLibrary_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Libraries) {
                    aI_Build_Option = new AI_Build_Option_Library();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getSeaAccess() > 0 && CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getPort_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_Ports) {
                    aI_Build_Option = new AI_Build_Option_Port();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getArmoury_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_Armories) {
                    aI_Build_Option = new AI_Build_Option_Armoury();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getSupply_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() > CFG.game.getCiv((int)n).iNumOf_SuppliesCamp) {
                    aI_Build_Option = new AI_Build_Option_Supplies();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getFort_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Forts) {
                    aI_Build_Option = new AI_Build_Option_Fort();
                    arrayList2.add(aI_Build_Option);
                }
                if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getTower_TechLevel(1) && CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getTower_MaxLevel_CanBuild(n) > CFG.game.getCiv((int)n).iNumOf_Towers) {
                    aI_Build_Option = new AI_Build_Option_Tower();
                    arrayList2.add(aI_Build_Option);
                }
                aI_Build_Option = new AI_Build_Option_Invest();
                arrayList2.add(aI_Build_Option);
                if (CFG.game.getCiv((int)n).fAverageDevelopment / CFG.game.getCiv(n).getTechnologyLevel() < 0.9f) {
                    aI_Build_Option = new AI_Build_Option_Invest_Development();
                    arrayList2.add(aI_Build_Option);
                }
                if (arrayList2.size() > 0) {
                    int n2 = 0;
                    for (int i = 0 + 1; i < arrayList2.size(); ++i) {
                        int n3 = n2;
                        if (((AI_Build_Option)arrayList2.get(i)).getScore(n) > ((AI_Build_Option)arrayList2.get(n2)).getScore(n)) {
                            n3 = i;
                        }
                        n2 = n3;
                    }
                    arrayList.add(((AI_Build_Option)arrayList2.get(n2)).getData(n));
                    if (((AI_Build)arrayList.get(0)).build(n, 0, false)) {
                        CFG.game.getCiv(n).buildCivPersonality_Buildings();
                    }
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
            }
            arrayList2.clear();
            arrayList.clear();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void buildStartingBuildings(int n) {
        try {
            if (CFG.game.getCiv(n).getCapitalProvinceID() < 0) return;
            if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getTower_TechLevel(1) * 1.04f) {
                CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfWatchTower(1);
            }
            if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(1) * 0.96f) {
                CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfFort(1);
            }
            if (!(CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getPort_TechLevel(1) * 1.1f)) return;
            this.buildStartingBuildings_Port(n);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void buildStartingBuildings_Port(int var1_1) {
        var2_2 = -1;
        if (CFG.game.getProvince(CFG.game.getCiv(var1_1).getCapitalProvinceID()).getLevelOfPort() < 0) {
            var4_4 = 0;
        } else {
            var3_3 = CFG.game.getCiv(var1_1).getCapitalProvinceID();
            while (true) {
                if (var3_3 < 0) return;
                if (CFG.game.getProvince(var3_3).getLevelOfPort() < 0) return;
                CFG.game.getProvince(var3_3).setLevelOfPort(1);
                return;
            }
        }
        while (true) {
            var3_3 = var2_2;
            if (var4_4 >= CFG.game.getCiv(var1_1).getNumOfProvinces()) ** continue;
            var3_3 = var2_2;
            if (CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var4_4)).getLevelOfPort() == 0) {
                if (var2_2 < 0) {
                    var3_3 = CFG.game.getCiv(var1_1).getProvinceID(var4_4);
                } else {
                    var3_3 = var2_2;
                    if (CFG.game.getProvince(var2_2).getPopulationData().getPopulation() < CFG.game.getProvince(CFG.game.getCiv(var1_1).getProvinceID(var4_4)).getPopulationData().getPopulation()) {
                        var3_3 = CFG.game.getCiv(var1_1).getProvinceID(var4_4);
                    }
                }
            }
            ++var4_4;
            var2_2 = var3_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected long build_GetMoney(int n) {
        if (CFG.game.getCiv(n).getMoney() >= AI_Style.getMoney_MinReserve(n)) return CFG.game.getCiv(n).getMoney() - AI_Style.getMoney_MinReserve(n);
        return 0L;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean canCivlize(int n) {
        if (!(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CIVILIZE_TECH_LEVEL <= CFG.game.getCiv(n).getTechnologyLevel())) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMove(int n) {
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMoveAndRecruit(int n) {
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMoveArmyToProvinceID(int n, int n2) {
        if (CFG.game.getProvince(n).getCivID() == n2) return true;
        if (CFG.game.getCivsAreAllied(n2, CFG.game.getProvince(n).getCivID())) return true;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getPuppetOfCivID() == n2) return true;
        if (CFG.game.getCiv(n2).getPuppetOfCivID() == CFG.game.getProvince(n).getCivID()) return true;
        if (CFG.game.getMilitaryAccess(n2, CFG.game.getProvince(n).getCivID()) <= 0) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canRecruit(int n, int n2) {
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT) return false;
        if (CFG.game.getCiv(n).getMoney() < (long)CFG.getCostOfRecruitArmyMoney(n2)) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void changeTypeOfIdeology(int n) {
        if (CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment == null) return;
        if (CFG.game.getCiv(n).isAtWar()) {
            CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment = null;
            return;
        }
        if (!CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment.action(n)) return;
        CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment = null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void checkBalanceOfProvinces_Tribal(int n) {
        ArrayList<Integer> arrayList;
        try {
            int n2;
            arrayList = new ArrayList<Integer>();
            ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
            int n3 = 0;
            int n4 = 0;
            for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
                n2 = n3;
                int n5 = n4;
                if (!CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).isOccupied()) {
                    if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getBalance_LastTurn() < 0) {
                        if (CFG.game.getCiv(n).getProvinceID(i) != CFG.game.getCiv(n).getCapitalProvinceID()) {
                            arrayList2.add(CFG.game.getCiv(n).getProvinceID(i));
                            n2 = n3 += CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getBalance_LastTurn();
                            n5 = n4;
                            if (CFG.game.getProvince((int)CFG.game.getCiv((int)n).getProvinceID((int)i)).saveProvinceData.iNumOfTurnsWithBalanceOnMinus >= this.MIN_TURNS_TO_ABANDON_USELESS_PROVINCE) {
                                arrayList.add(CFG.game.getCiv(n).getProvinceID(i));
                                n5 = n4;
                                n2 = n3;
                            }
                        } else {
                            n2 = n3 + CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getBalance_LastTurn();
                            n5 = n4;
                        }
                    } else {
                        n5 = n4 + CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getBalance_LastTurn();
                        n2 = n3;
                    }
                }
                n3 = n2;
                n4 = n5;
            }
            if (arrayList2.size() <= 0) return;
            if (!((float)n4 * 0.65f < (float)Math.abs(n3))) return;
            float f = 0.0f;
            for (n2 = arrayList2.size() - 1; n2 >= 0; f += (float)CFG.game.getProvince((Integer)arrayList2.get(n2)).getBalance_LastTurn(), --n2) {
            }
            f /= (float)arrayList2.size();
            arrayList = new ArrayList<Integer>();
            for (n2 = arrayList2.size() - 1; n2 >= 0; --n2) {
                if (!(f * 0.375f > (float)CFG.game.getProvince((Integer)arrayList2.get(n2)).getBalance_LastTurn())) continue;
                arrayList.add((Integer)arrayList2.get(n2));
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        this.abandonOrReleaseAsVassalProvinces(n, arrayList, true);
    }

    protected final void checkPeaceTreaties(int n) {
        if (CFG.game.getCiv(n).isAtWar()) {
            Gdx.app.log("AoC", "checkPeaceTreaties -> " + CFG.game.getCiv(n).getCivName());
            if (CFG.game.getCiv(n).getBordersWithEnemy() == 0) {
                // empty if block
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean civilize(int n) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!this.isUncivilzed(n)) return bl2;
        bl2 = bl;
        if (!this.canCivlize(n)) return bl2;
        if (Game_Calendar.ENABLE_COLONIZATION_NEUTRAL_PROVINCES && this.tryToExpandBeforeCivilize(n) && CFG.oR.nextInt(100) > 2) {
            return bl;
        }
        bl2 = bl;
        if (!DiplomacyManager.civilizeCiv(n)) return bl2;
        return true;
    }

    protected final void clearWas() {
        for (int i = 0; i < CFG.game.getProvincesSize(); ++i) {
            CFG.game.getProvince((int)i).was = false;
        }
    }

    protected final void clearWas(List<Integer> list) {
        for (int i = list.size() - 1; i >= 0; --i) {
            CFG.game.getProvince((int)list.get((int)i).intValue()).was = false;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void colonizeProvinces(int n) {
        int n2;
        if (!Game_Calendar.getColonizationOfWastelandIsEnabled()) {
            if (!Game_Calendar.ENABLE_COLONIZATION_NEUTRAL_PROVINCES) return;
        }
        int n3 = 0;
        for (n2 = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; n2 >= 0; --n2) {
            int n4;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n2).MISSION_TYPE != CivArmyMission_Type.COLONIZE_PROVINCE) continue;
            n3 = n4 = 1;
            if (!CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n2).canMakeAction(n, 0)) continue;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n2).action(n)) {
                CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(n2);
                CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(24), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
                n3 = n4;
                continue;
            }
            n3 = n4;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n2).iObsolate > 0) continue;
            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(n2);
            CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(4), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
            n3 = n4;
        }
        if (n3 != 0) {
            return;
        }
        CFG.game.getCiv((int)n).civGameData.iLockTreasury = 1;
        if (CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID > Game_Calendar.TURN_ID) return;
        if (!Game_Calendar.getCanColonize_TechLevel(n) && CFG.game.getCiv(n).getTechnologyLevel() / Game_Calendar.COLONIZATION_TECH_LEVEL < 1.0f - 0.35f * Math.min((float)CFG.oAI.iNumOfColonizedProvinces / Math.min((float)(Math.min((CFG.game.getCiv(n).getRankPosition() - 1) * 3, 22) + 6), (float)CFG.game.getProvincesSize() * 0.01f), 1.0f)) {
            CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(15), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
            return;
        }
        if (CFG.game.getCiv((int)n).iBudget < 1) {
            CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 5 + CFG.oR.nextInt(10), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
            return;
        }
        if (DiplomacyManager.getColonizeCost_AI(n) / CFG.game.getCiv((int)n).iBudget > 22) {
            CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 8 + CFG.oR.nextInt(12), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
            return;
        }
        if (!((float)CFG.game.getCiv(n).getRankPosition() < Math.max((float)CFG.game.getCivsSize() * 0.35f, 11.0f))) return;
        try {
            if (CFG.game.getCiv(n).isAtWar()) {
                CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID = Math.max(Game_Calendar.TURN_ID + 8 + CFG.oR.nextInt(14), CFG.game.getCiv((int)n).civGameData.iLockColonization_UntilTurnID);
                return;
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        n2 = 0;
        {
            if (Game_Calendar.getColonizationOfWastelandIsEnabled()) {
                n2 = 0 + CFG.oAI.lWastelandProvincesWithSeaAccess.size() + CFG.game.getCiv((int)n).lBordersWithWastelandProvincesID.size();
            }
            n3 = n2;
            if (Game_Calendar.ENABLE_COLONIZATION_NEUTRAL_PROVINCES) {
                n3 = n2 + CFG.oAI.lNeutralProvincesWithSeaAccess.size() + CFG.game.getCiv((int)n).lBordersWithNeutralProvincesID.size();
            }
            if (n3 <= 0) return;
            n2 = 1;
            if (CFG.game.getCiv((int)n).civGameData.lColonies_Founded.size() > 0) {
                n2 = !this.colonizeProvinces_ExtendColony(n) ? 1 : 0;
            }
            if (n2 == 0) return;
            this.colonizeProvinces_FoundNewColony(n);
            return;
        }
    }

    /*
     * Exception decompiling
     */
    protected final boolean colonizeProvinces_ExtendColony(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 4[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final int colonizeProvinces_ExtendColony_Score(int n, int n2) {
        float f;
        float f2 = f = 1.0f;
        if (CFG.game.getProvince(n2).getNeighboringProvincesSize() > 0) {
            int n3 = 0;
            f2 = f;
            for (int i = 0; i < CFG.game.getProvince(n2).getNeighboringProvincesSize(); ++i) {
                f = f2;
                int n4 = n3;
                if (CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID() == n) {
                    n4 = n3 + 1;
                    f = f2 + 0.725f;
                }
                f2 = f;
                n3 = n4;
            }
            f2 += CFG.game.getCiv((int)n).civGameData.civPersonality.COLONIZATION_OWN_PROVINCES * (float)(n3 / Math.max(CFG.game.getProvince(n2).getNeighboringProvincesSize(), 1));
        }
        f = f2 += CFG.game.getCiv((int)n).civGameData.civPersonality.COLONIZATION_DISTANCE * (1.0f - CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(n).getCapitalProvinceID(), n2));
        if (CFG.game.getProvince(n2).getNeighboringSeaProvincesSize() > 0) {
            f = f2 + CFG.game.getCiv((int)n).civGameData.civPersonality.COLONIZATION_SEA;
        }
        return (int)(f + CFG.game.getCiv((int)n).civGameData.civPersonality.COLONIZATION_GROWTH_RATE * CFG.game.getProvince(n2).getGrowthRate_Population());
    }

    protected final void colonizeProvinces_FoundNewColony(int n) {
        int n2;
        ArrayList<AI_ProvinceValue> arrayList;
        block16: {
            boolean bl;
            boolean bl2;
            int n3;
            arrayList = new ArrayList<AI_ProvinceValue>();
            ArrayList<Boolean> arrayList2 = new ArrayList<Boolean>();
            for (n2 = 0; n2 < CFG.map.iNumOfBasins; ++n2) {
                arrayList2.add(false);
            }
            for (n2 = CFG.game.getCiv(n).getSeaAccess_Provinces_Size() - 1; n2 >= 0; --n2) {
                if (CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n2)).isOccupied()) continue;
                for (n3 = 0; n3 < CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n2)).getNeighboringSeaProvincesSize(); ++n3) {
                    arrayList2.set(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n2)).getNeighboringSeaProvinces(n3)).getBasinID(), true);
                }
            }
            block3: for (n2 = CFG.oAI.lNeutralProvincesWithSeaAccess.size() - 1; n2 >= 0; --n2) {
                bl2 = false;
                n3 = 0;
                while (true) {
                    block15: {
                        block14: {
                            bl = bl2;
                            if (n3 >= CFG.game.getProvince(CFG.oAI.lNeutralProvincesWithSeaAccess.get(n2)).getNeighboringSeaProvincesSize()) break block14;
                            if (!((Boolean)arrayList2.get(CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lNeutralProvincesWithSeaAccess.get(n2)).getNeighboringSeaProvinces(n3)).getBasinID())).booleanValue()) break block15;
                            bl = true;
                        }
                        if (!bl) continue block3;
                        arrayList.add(new AI_ProvinceValue(CFG.oAI.lNeutralProvincesWithSeaAccess.get(n2)));
                        continue block3;
                    }
                    ++n3;
                }
            }
            if (arrayList.size() != 0 || !Game_Calendar.getColonizationOfWastelandIsEnabled()) break block16;
            block5: for (n2 = CFG.oAI.lWastelandProvincesWithSeaAccess.size() - 1; n2 >= 0; --n2) {
                bl2 = false;
                n3 = 0;
                while (true) {
                    block18: {
                        block17: {
                            bl = bl2;
                            if (n3 >= CFG.game.getProvince(CFG.oAI.lWastelandProvincesWithSeaAccess.get(n2)).getNeighboringSeaProvincesSize()) break block17;
                            if (!((Boolean)arrayList2.get(CFG.game.getProvince(CFG.game.getProvince(CFG.oAI.lWastelandProvincesWithSeaAccess.get(n2)).getNeighboringSeaProvinces(n3)).getBasinID())).booleanValue()) break block18;
                            bl = true;
                        }
                        if (!bl) continue block5;
                        arrayList.add(new AI_ProvinceValue(CFG.oAI.lWastelandProvincesWithSeaAccess.get(n2)));
                        continue block5;
                    }
                    ++n3;
                }
            }
        }
        if (arrayList.size() > 0 && CFG.game.getProvince(n2 = ((AI_ProvinceValue)arrayList.get((int)CFG.oR.nextInt((int)arrayList.size()))).iProvinceID).getCivID() == 0) {
            CFG.game.getCiv((int)n).civGameData.civPlans.addNewArmyMission(n2, new CivArmyMission_ColonizeProvince(n, n2));
            CFG.game.getCiv((int)n).civGameData.declareWar_CheckNextTurnID = Math.max(CFG.game.getCiv((int)n).civGameData.declareWar_CheckNextTurnID, Game_Calendar.TURN_ID + (int)((float)(CFG.oR.nextInt(25) + 8 + CFG.oR.nextInt(CFG.game.getCivsSize() + 1) / 20) / Game_Calendar.AI_AGGRESSIVNESS));
        }
    }

    protected final void defendFromSeaInvasion(int n) {
        int n2;
        int n3;
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
        for (n3 = CFG.game.getCiv((int)n).isAtWarWithCivs.size() - 1; n3 >= 0; --n3) {
            for (n2 = 0; n2 < CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnitsSize(); ++n2) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnits(n2).getToProvinceID()).getCivID() != n || !CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnits(n2).getFromProvinceID()).getSeaProvince() || CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnits(n2).getToProvinceID()).isOccupied()) continue;
                arrayList.add(CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnits(n2).getToProvinceID());
                arrayList2.add(CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n3)).getMoveUnits(n2).getNumOfUnits());
            }
        }
        while (arrayList.size() > 0) {
            int n4;
            n2 = 0;
            for (n3 = 1; n3 < arrayList.size(); ++n3) {
                n4 = n2;
                if (CFG.game.getProvince((Integer)arrayList.get(n2)).getPotential() < CFG.game.getProvince((Integer)arrayList.get(n3)).getPotential()) {
                    n4 = n3;
                }
                n2 = n4;
            }
            if (CFG.game.getProvince((Integer)arrayList.get(n2)).getArmyCivID(n) < (Integer)arrayList2.get(n2)) {
                n3 = (int)Math.ceil((float)((Integer)arrayList2.get(n2) - CFG.game.getProvince((Integer)arrayList.get(n2)).getArmyCivID(n)) * (1.025f + (float)CFG.oR.nextInt(85) / 1000.0f));
                if (CFG.game.getCiv(n).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT) {
                    if (CFG.game.getCiv(n).getMoney() < (long)(n3 * 5) && CFG.game.getCiv(n).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT + 6) {
                        n4 = (int)((long)(n3 * 5) - CFG.game.getCiv(n).getMoney());
                        if (CFG.game.getCiv(n).getMoney() + (long)n4 > 5L) {
                            DiplomacyManager.takeLoan(n, n4, 5);
                        }
                    }
                    if (CFG.game.getCiv(n).getMoney() <= 5L || CFG.game.getCiv(n).recruitArmy_AI((Integer)arrayList.get(n2), n3)) {
                        // empty if block
                    }
                }
            }
            arrayList.remove(n2);
            arrayList2.remove(n2);
            if (CFG.game.getCiv(n).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE) continue;
        }
    }

    protected void diplomacyActions(int n) {
        if (CFG.game.getCiv(n).getNumOfProvinces() > 0) {
            Gdx.app.log("AoC", "diplomacyActions - > " + CFG.game.getCiv(n).getCivName());
            this.diplomacyActions_BuildCivsInRange(n);
            if (!CFG.game.getCiv(n).isAtWar() && !CFG.game.getCiv((int)n).civGameData.civPlans.isPreparingForTheWar()) {
                this.diplomacyActions_RivalCiv(n);
                this.diplomacyActions_FormCiv(n);
                this.diplomacyActions_CircledVassals(n);
            }
            this.diplomacyActions_FriendCiv(n);
            this.diplomacyActions_FriendCiv_Continuous(n);
            if (!CFG.game.getCiv(n).isAtWar() && !CFG.game.getCiv((int)n).civGameData.civPlans.isPreparingForTheWar()) {
                this.diplomacyActions_DeclareWar(n);
            }
            this.diplomacyActions_Ally(n);
            Gdx.app.log("AoC", "diplomacyActions - > END");
        }
    }

    protected final void diplomacyActions_Ally(int n) {
        if (CFG.game.getCiv((int)n).civGameData.allianceCheck_TurnID <= Game_Calendar.TURN_ID) {
            if (CFG.game.getCiv(n).getNumOfProvinces() < 50 && CFG.game.getCiv(n).getPuppetOfCivID() == n && CFG.game.getCiv(n).getAllianceID() == 0 && CFG.oR.nextInt(100) < 96 && CFG.game.getCiv(n).getFriendlyCivsSize() > 0) {
                int n2 = CFG.oR.nextInt(CFG.game.getCiv(n).getFriendlyCivsSize());
                if (CFG.game.getCiv(CFG.game.getCiv((int)n).getFriendlyCiv((int)n2).iCivID).getAllianceID() == 0) {
                    DiplomacyManager.sendAllianceProposal(CFG.game.getCiv((int)n).getFriendlyCiv((int)n2).iCivID, n);
                    DiplomacyManager.sendUnionProposal(CFG.game.getCiv((int)n).getFriendlyCiv((int)n2).iCivID, n);
                    DiplomacyManager.sendOfferVasalizationProposal(CFG.game.getCiv((int)n).getFriendlyCiv((int)n2).iCivID, n, n2);
                }
            }
            CFG.game.getCiv((int)n).civGameData.allianceCheck_TurnID = Game_Calendar.TURN_ID + 6 + CFG.oR.nextInt(35);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void diplomacyActions_BuildCivsInRange(int n) {
        if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && Game_Calendar.TURN_ID >= CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID) {
            CFG.game.getCiv((int)n).civGameData.civsInRange.clear();
            CFG.game.getCiv((int)n).civGameData.civsInRange = this.diplomacyActions_CivsInRange(n);
            if (CFG.game.getCiv((int)n).civGameData.civsInRange.size() > 0) {
                CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID = CFG.oR.nextInt(45) + 55;
                return;
            }
            CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID = CFG.oR.nextInt(Math.max(75, CFG.game.getCivsSize() / 4)) + 65;
            return;
        }
        CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID = CFG.oR.nextInt(26) + 24;
    }

    protected final void diplomacyActions_CircledVassals(int n) {
        if (CFG.game.getCiv((int)n).civGameData.circledVassals_TurnID <= Game_Calendar.TURN_ID) {
            if (CFG.game.getCiv((int)n).civGameData.iVassalsSize > 0) {
                for (int i = 0; i < CFG.game.getCiv((int)n).civGameData.iVassalsSize; ++i) {
                    if (CFG.oAI.lFrontLines.get(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID - 1).size() != 0 || CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID).getSeaAccess() > 0) continue;
                    if (CFG.game.getCivRelation_OfCivB(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID) > -10.0f) {
                        DiplomacyManager.decreaseRelation(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, 10);
                        DiplomacyManager.decreaseRelation(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, 10);
                        DiplomacyManager.decreaseRelation(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, 10);
                        DiplomacyManager.decreaseRelation(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, 10);
                        DiplomacyManager.decreaseRelation(n, CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, 10);
                    }
                    Ultimatum_GameData ultimatum_GameData = new Ultimatum_GameData();
                    ultimatum_GameData.demandAnexation = true;
                    DiplomacyManager.sendUltimatum(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)i).iCivID, n, ultimatum_GameData, CFG.game.getCiv(n).getNumOfUnits());
                }
            }
            CFG.game.getCiv((int)n).civGameData.circledVassals_TurnID = Game_Calendar.TURN_ID + 30 + CFG.oR.nextInt(25);
        }
    }

    protected final List<AI_CivsInRange> diplomacyActions_CivsInRange(int n) {
        float f;
        int n2;
        ArrayList<AI_CivsInRange> arrayList = new ArrayList<AI_CivsInRange>();
        float f2 = CFG.gameAges.getAge_FogOfWarDiscovery_MetProvinces(Game_Calendar.CURRENT_AGEID);
        for (n2 = 1; n2 < n; ++n2) {
            if (CFG.game.getCiv(n2).getNumOfProvinces() <= 0 || CFG.game.getCiv(n2).getCapitalProvinceID() <= 0 || !((f = CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(n).getCapitalProvinceID(), CFG.game.getCiv(n2).getCapitalProvinceID())) * 0.9f < (f2 * 0.2675f + f2) * CFG.game.getCiv(n).getTechnologyLevel())) continue;
            arrayList.add(new AI_CivsInRange(n2, f));
        }
        for (n2 = n + 1; n2 < CFG.game.getCivsSize(); ++n2) {
            if (CFG.game.getCiv(n2).getNumOfProvinces() <= 0 || CFG.game.getCiv(n2).getCapitalProvinceID() <= 0 || !((f = CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(n).getCapitalProvinceID(), CFG.game.getCiv(n2).getCapitalProvinceID())) * 0.9f < (f2 * 0.2675f + f2) * CFG.game.getCiv(n).getTechnologyLevel())) continue;
            arrayList.add(new AI_CivsInRange(n2, f));
        }
        return arrayList;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void diplomacyActions_DeclareWar(int var1_1) {
        block52: {
            block48: {
                block51: {
                    block50: {
                        block49: {
                            Gdx.app.log("AoC", "diplomacyActions_DeclareWar - > nCivID: " + CFG.game.getCiv(var1_1).getCivName() + ", declareWar_CheckNextTurnID: " + CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID);
                            if (CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID > Game_Calendar.TURN_ID) break block49;
                            if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).CAN_BECOME_CIVILIZED < 0) break block50;
                            CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID = Game_Calendar.TURN_ID + (int)((float)(CFG.oR.nextInt(35) + 12 + CFG.oR.nextInt(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME + 1) / 30) / Game_Calendar.AI_AGGRESSIVNESS);
                        }
                        return;
                    }
                    if (CFG.game.getCiv(var1_1).getPuppetOfCivID() != var1_1) break block51;
                    var2_2 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.AGGRESSION;
lbl11:
                    // 2 sources

                    while (var2_2 * Game_Calendar.AI_AGGRESSIVNESS >= (float)CFG.oR.nextInt(10000) / 100.0f) {
                        var3_3 = new ArrayList<Integer>();
                        if (CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() <= 0) break block48;
                        CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID = Game_Calendar.TURN_ID + 8 + (int)((float)(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() * 2 + CFG.oR.nextInt(14) + CFG.oR.nextInt(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME + 1) / 25) / Game_Calendar.AI_AGGRESSIVNESS);
                        return;
                    }
                    break block52;
                }
                var2_2 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.AGGRESSION / 8.0f;
                ** GOTO lbl11
            }
            if (CFG.game.getCiv((int)var1_1).lProvincesWithLowHappiness.size() > 0) {
                CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID = Game_Calendar.TURN_ID + 8 + (int)((float)(CFG.game.getCiv((int)var1_1).lProvincesWithLowHappiness.size() * 2 + CFG.oR.nextInt(14) + CFG.oR.nextInt(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME + 1) / 25) / Game_Calendar.AI_AGGRESSIVNESS);
                return;
            }
            for (var4_4 = CFG.oAI.lFrontLines.get(var1_1 - 1).size() - 1; var4_4 >= 0; --var4_4) {
                var5_5 = 0;
                for (var6_6 = var3_3.size() - 1; var6_6 >= 0; --var6_6) {
                    if ((Integer)var3_3.get(var6_6) != CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var4_4).iWithCivID) continue;
                    var5_5 = 1;
                }
                if (var5_5 != 0) continue;
                var3_3.add(CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var4_4).iWithCivID);
            }
            for (var4_4 = 0; var4_4 < CFG.game.getCiv(var1_1).getSeaAccess_Provinces_Size(); ++var4_4) {
                for (var6_6 = 0; var6_6 < CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvincesSize(); ++var6_6) {
                    block6: for (var5_5 = 0; var5_5 < CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvincesSize(); ++var5_5) {
                        if (!CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getSeaProvince()) {
                            if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getCivID() > 0) {
                                var7_7 = 0;
                                for (var8_8 = var3_3.size() - 1; var8_8 >= 0; --var8_8) {
                                    if (((Integer)var3_3.get(var8_8)).intValue() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getCivID()) continue;
                                    var7_7 = 1;
                                }
                                if (var7_7 == 0) {
                                    var3_3.add(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getCivID());
                                }
                            }
                            continue block6;
                        }
                        var8_8 = 0;
                        while (true) {
                            if (var8_8 >= CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getNeighboringProvincesSize()) ** continue;
                            if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var8_8)).getCivID() > 0) {
                                var9_9 = false;
                                for (var7_7 = var3_3.size() - 1; var7_7 >= 0; --var7_7) {
                                    if (((Integer)var3_3.get(var7_7)).intValue() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var8_8)).getCivID()) continue;
                                    var9_9 = true;
                                }
                                if (!var9_9) {
                                    var3_3.add(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(var1_1).getSeaAccess_Provinces().get(var4_4)).getNeighboringSeaProvinces(var6_6)).getNeighboringProvinces(var5_5)).getNeighboringProvinces(var8_8)).getCivID());
                                }
                            }
                            ++var8_8;
                        }
                    }
                }
            }
            if ((var3_3.size() == 0 || CFG.oR.nextInt(100) < 6) && CFG.game.getCiv(var1_1).getSeaAccess_PortProvinces_Size() > 0 && CFG.game.getCiv(var1_1).getNumOfProvinces() > 4) {
                for (var4_4 = CFG.game.getCiv((int)var1_1).civGameData.civsInRange.size() - 1; var4_4 >= 0; --var4_4) {
                    var3_3.add(CFG.game.getCiv((int)var1_1).civGameData.civsInRange.get((int)var4_4).iCivID);
                }
            }
            if (var3_3.size() < 0) {
                for (var4_4 = 0; var4_4 < CFG.game.getCiv((int)var1_1).civGameData.civRivalsSize; ++var4_4) {
                    var5_5 = 0;
                    for (var6_6 = var3_3.size() - 1; var6_6 >= 0; --var6_6) {
                        if ((Integer)var3_3.get(var6_6) != CFG.game.getCiv((int)var1_1).civGameData.civRivals.get((int)var4_4).iCivID) continue;
                        var5_5 = 1;
                    }
                    if (var5_5 != 0) continue;
                    var3_3.add(CFG.game.getCiv((int)var1_1).civGameData.civRivals.get((int)var4_4).iCivID);
                }
            }
            block14: for (var4_4 = var3_3.size() - 1; var4_4 >= 0; --var4_4) {
                block58: {
                    block57: {
                        block56: {
                            block55: {
                                block54: {
                                    block53: {
                                        if (CFG.game.getCiv((Integer)var3_3.get(var4_4)).getPuppetOfCivID() != ((Integer)var3_3.get(var4_4)).intValue()) {
                                            var3_3.remove(var4_4);
lbl85:
                                            // 8 sources

                                            continue block14;
                                        }
                                        if (CFG.game.getCiv(var1_1).isFriendlyCiv((Integer)var3_3.get(var4_4)) < 0) break block53;
                                        var3_3.remove(var4_4);
                                        ** GOTO lbl85
                                    }
                                    if (!CFG.game.isAlly(var1_1, (Integer)var3_3.get(var4_4))) break block54;
                                    var3_3.remove(var4_4);
                                    ** GOTO lbl85
                                }
                                if (CFG.game.getGuarantee(var1_1, (Integer)var3_3.get(var4_4)) <= 0 && CFG.game.getGuarantee((Integer)var3_3.get(var4_4), var1_1) <= 0) break block55;
                                var3_3.remove(var4_4);
                                ** GOTO lbl85
                            }
                            if (CFG.game.getCivNonAggressionPact(var1_1, (Integer)var3_3.get(var4_4)) <= 0) break block56;
                            var3_3.remove(var4_4);
                            ** GOTO lbl85
                        }
                        if (CFG.game.getCivTruce(var1_1, (Integer)var3_3.get(var4_4)) <= 0) break block57;
                        var3_3.remove(var4_4);
                        ** GOTO lbl85
                    }
                    var10_10 = CFG.game.getCivRelation_OfCivB(var1_1, (Integer)var3_3.get(var4_4));
                    if (CFG.oAI.NUM_OF_CIVS_IN_THE_GAME >= 10) break block58;
                    var2_2 = 10.0f;
lbl115:
                    // 2 sources

                    while (true) {
                        if (!(var10_10 > var2_2)) ** GOTO lbl85
                        var3_3.remove(var4_4);
                        ** continue;
                        break;
                    }
                }
                var2_2 = Math.max(-50.0f, -50.0f / Game_Calendar.AI_AGGRESSIVNESS);
                ** continue;
            }
            if (var3_3.size() > 0) {
                var4_4 = var6_6 = 0;
                if (CFG.game.getCiv((int)var1_1).civGameData.lColonies_Founded.size() > 0) {
                    var4_4 = var6_6;
                    if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).CAN_BECOME_CIVILIZED < 0) {
                        var11_11 = new ArrayList<E>();
                        for (var4_4 = 0; var4_4 < var3_3.size(); ++var4_4) {
                            if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)((Integer)var3_3.get((int)var4_4)).intValue()).getIdeologyID()).CAN_BECOME_CIVILIZED < 0) continue;
                            var11_11.add((Integer)var3_3.get(var4_4));
                        }
                        var4_4 = var6_6;
                        if (var11_11.size() > 0) {
                            CFG.game.declareWar(var1_1, (Integer)var11_11.get(CFG.oR.nextInt(var11_11.size())), false);
                            var4_4 = 1;
                        }
                    }
                }
                if (var4_4 == 0) {
                    var11_11 = new ArrayList<E>();
                    var2_2 = (float)CFG.oR.nextInt(975) / 1000.0f;
                    var10_10 = (float)CFG.oR.nextInt(1755) / 1000.0f;
                    for (var4_4 = 0; var4_4 < var3_3.size(); ++var4_4) {
                        var11_11.add((Integer)Float.valueOf(this.diplomacyActions_DeclareWar_Score(var1_1, (Integer)var3_3.get(var4_4), 0.125f + var10_10, 0.625f, 1.275f + var2_2)));
                    }
                    var6_6 = 0;
                    for (var4_4 = 1; var4_4 < var3_3.size(); ++var4_4) {
                        var5_5 = var6_6;
                        if (((Float)var11_11.get(var6_6)).floatValue() < ((Float)var11_11.get(var4_4)).floatValue()) {
                            var5_5 = var4_4;
                        }
                        var6_6 = var5_5;
                    }
                    var5_5 = this.diplomacyActions_DeclareWar_Budgets(var1_1, false);
                    if ((float)var5_5 > (float)(var8_8 = this.diplomacyActions_DeclareWar_Budgets((Integer)var3_3.get(var6_6), true)) * 0.695f) {
                        var5_5 = CFG.oR.nextInt(4) + 3;
                        CFG.game.getCiv((int)var1_1).civGameData.civPlans.addNewWarPreparations(var1_1, var1_1, (Integer)var3_3.get(var6_6), var5_5);
                        var11_11 = DiplomacyManager.callToArmsListOfCivs(var1_1, (Integer)var3_3.get(var6_6));
                        for (var4_4 = 0; var4_4 < var11_11.size(); ++var4_4) {
                            DiplomacyManager.sendPrepareForWar((Integer)var11_11.get(var4_4), var1_1, (Integer)var3_3.get(var6_6), var5_5, var1_1);
                        }
                    } else {
                        var12_12 = new ArrayList<Integer>();
                        for (var4_4 = 0; var4_4 < CFG.game.getCiv((Integer)var3_3.get(var6_6)).getHatedCivs_BySize(); ++var4_4) {
                            if (CFG.game.getCiv(var1_1).isHatedCiv(CFG.game.getCiv((Integer)var3_3.get(var6_6)).getHatedCiv_By(var4_4)) || CFG.game.getCiv(CFG.game.getCiv((Integer)var3_3.get(var6_6)).getHatedCiv_By(var4_4)).getNumOfProvinces() <= 0) continue;
                            var12_12.add(CFG.game.getCiv((Integer)var3_3.get(var6_6)).getHatedCiv_By(var4_4));
                        }
                        for (var4_4 = 0; var4_4 < var12_12.size(); ++var4_4) {
                            var5_5 += this.diplomacyActions_DeclareWar_Budgets((Integer)var12_12.get(var4_4), false);
                        }
                        if ((float)var5_5 > (float)var8_8 * 0.605f) {
                            for (var4_4 = 0; var4_4 < var12_12.size(); ++var4_4) {
                                if (var3_3.get(var6_6) == var12_12.get(var4_4)) continue;
                                var11_11 = new TradeRequest_GameData();
                                var11_11.iCivLEFT = var1_1;
                                var11_11.iCivRIGHT = (Integer)var12_12.get(var4_4);
                                var11_11.listRight.iFormCoalitionAgainst = (Integer)var3_3.get(var6_6);
                                var11_11.listLEFT.iGold = CFG.oR.nextInt(50) + 10;
                                DiplomacyManager.sendTradeRequest((Integer)var12_12.get(var4_4), var1_1, var11_11);
                            }
                            var5_5 = CFG.oR.nextInt(4) + 3;
                            CFG.game.getCiv((int)var1_1).civGameData.civPlans.addNewWarPreparations(var1_1, var1_1, (Integer)var3_3.get(var6_6), var5_5);
                            var11_11 = DiplomacyManager.callToArmsListOfCivs(var1_1, (Integer)var3_3.get(var6_6));
                            for (var4_4 = 0; var4_4 < var11_11.size(); ++var4_4) {
                                DiplomacyManager.sendPrepareForWar(var11_11.get(var4_4), var1_1, (Integer)var3_3.get(var6_6), var5_5, var1_1);
                            }
                        } else {
                            DiplomacyManager.sendNonAggressionProposal((Integer)var3_3.get(var6_6), var1_1, 40);
                        }
                    }
                }
                var11_11 = CFG.game.getCiv((int)var1_1).civGameData;
                var1_1 = Game_Calendar.TURN_ID;
                var11_11.declareWar_CheckNextTurnID = (int)((float)(CFG.game.getCiv((Integer)var3_3.get(CFG.oR.nextInt(var3_3.size()))).getNumOfProvinces() + 10 + CFG.oR.nextInt(25) + CFG.oR.nextInt((int)((float)CFG.oAI.NUM_OF_CIVS_IN_THE_GAME * 1.025f) + 1) / 25) / Game_Calendar.AI_AGGRESSIVNESS) + var1_1;
                return;
            }
            CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID = Game_Calendar.TURN_ID + (int)((float)(CFG.oR.nextInt(14) + 10 + CFG.oR.nextInt(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME + 1) / 20) / Game_Calendar.AI_AGGRESSIVNESS);
            return;
        }
        CFG.game.getCiv((int)var1_1).civGameData.declareWar_CheckNextTurnID = Game_Calendar.TURN_ID + (int)((float)(CFG.oR.nextInt(14) + 8 + CFG.oR.nextInt(CFG.oAI.NUM_OF_CIVS_IN_THE_GAME + 1) / 30) / Game_Calendar.AI_AGGRESSIVNESS);
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final int diplomacyActions_DeclareWar_Budgets(int var1_1, boolean var2_2) {
        var4_4 = var3_3 = CFG.game.getCiv((int)var1_1).iBudget;
        if (CFG.game.getCiv(var1_1).getPuppetOfCivID() != var1_1) {
            var4_4 = var3_3 + CFG.game.getCiv((int)CFG.game.getCiv((int)var1_1).getPuppetOfCivID()).iBudget;
        }
        for (var3_3 = 0; var3_3 < CFG.game.getCiv((int)var1_1).civGameData.iVassalsSize; ++var3_3) {
            var4_4 += CFG.game.getCiv((int)CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_3).iCivID).iBudget;
        }
        var3_3 = var4_4;
        if (CFG.game.getCiv(var1_1).getAllianceID() > 0) {
            var5_5 = 0;
            while (true) {
                var3_3 = var4_4;
                if (var5_5 >= CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilizationsSize()) break;
                var3_3 = var4_4;
                if (var1_1 != CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var5_5)) {
                    var3_3 = var4_4;
                    if (var1_1 != CFG.game.getCiv(CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var5_5)).getPuppetOfCivID()) {
                        var3_3 = var4_4;
                        if (CFG.game.getCiv(var1_1).getPuppetOfCivID() != CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var5_5)) {
                            var3_3 = var4_4 + CFG.game.getCiv((int)CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var5_5)).iBudget;
                        }
                    }
                }
                ++var5_5;
                var4_4 = var3_3;
            }
        }
        var5_5 = var3_3;
        if (var2_2 == false) return var5_5;
        block16: for (var6_6 = 1; var6_6 < var1_1; ++var6_6) {
            block25: {
                block26: {
                    var4_4 = var3_3;
                    if (CFG.game.getDefensivePact(var1_1, var6_6) <= 0) break block25;
                    var5_5 = var3_3;
                    var4_4 = var3_3;
                    if (CFG.game.getCiv(var6_6).getNumOfProvinces() <= 0) break block26;
                    var4_4 = var3_3;
                    var5_5 = var3_3 + CFG.game.getCiv((int)var6_6).iBudget;
                }
lbl37:
                // 4 sources

                while (true) {
                    var3_3 = var5_5;
                    continue block16;
                    break;
                }
            }
            var5_5 = var3_3;
            var4_4 = var3_3;
            if (CFG.game.getGuarantee(var6_6, var1_1) <= 0) ** GOTO lbl37
            var5_5 = var3_3;
            var4_4 = var3_3;
            if (CFG.game.getCiv(var6_6).getNumOfProvinces() <= 0) ** GOTO lbl37
            var4_4 = var3_3;
            var5_5 = var3_3 + CFG.game.getCiv((int)var6_6).iBudget;
            ** continue;
        }
        var6_6 = var1_1;
        block18: while (true) {
            block27: {
                var4_4 = var3_3;
                var5_5 = var3_3;
                if (var6_6 >= CFG.game.getCivsSize()) return var5_5;
                var4_4 = var3_3;
                if (CFG.game.getDefensivePact(var1_1, var6_6) <= 0) break;
                var5_5 = var3_3;
                var4_4 = var3_3;
                if (CFG.game.getCiv(var6_6).getNumOfProvinces() <= 0) break block27;
                var4_4 = var3_3;
                var5_5 = var3_3 + CFG.game.getCiv((int)var6_6).iBudget;
            }
lbl70:
            // 4 sources

            while (true) {
                ++var6_6;
                var3_3 = var5_5;
                continue block18;
                break;
            }
            break;
        }
        var5_5 = var3_3;
        var4_4 = var3_3;
        try {
            if (CFG.game.getGuarantee(var1_1, var6_6) <= 0) ** GOTO lbl70
            var5_5 = var3_3;
            var4_4 = var3_3;
        }
        catch (IndexOutOfBoundsException var7_7) {
            return var4_4;
        }
        if (CFG.game.getCiv(var6_6).getNumOfProvinces() <= 0) ** GOTO lbl70
        var4_4 = var3_3;
        var5_5 = CFG.game.getCiv((int)var6_6).iBudget;
        var5_5 = var3_3 + var5_5;
        ** continue;
    }

    protected final float diplomacyActions_DeclareWar_Score(int n, int n2, float f, float f2, float f3) {
        return (1.0f - Math.min((float)CFG.game.getCiv((int)n2).iBudget / (float)CFG.game.getCiv((int)n).iBudget, 0.95f)) * f + (CFG.game.getCiv((int)n2).civGameData.civAggresionLevel / 4.0f + 1.0f) * f3 * (1.0f - Math.min(CFG.game.getCivRelation_OfCivB(n, n2) + 100.0f, 200.0f) / 200.0f);
    }

    protected final void diplomacyActions_FormCiv(int n) {
        if (Game_Calendar.TURN_ID >= CFG.game.getCiv((int)n).civGameData.checkFormCiv_TurnID) {
            if (CFG.game.getCiv(n).getTagsCanFormSize() > 0) {
                for (int i = 0; i < CFG.game.getCiv(n).getTagsCanFormSize(); ++i) {
                    if (!CFG.canFormACiv(n, CFG.game.getCiv(n).getTagsCanForm(i), true)) continue;
                    CFG.loadFormableCiv_GameData(CFG.game.getCiv(n).getTagsCanForm(i));
                    CFG.formCiv(n);
                }
                CFG.game.getCiv((int)n).civGameData.checkFormCiv_TurnID = Game_Calendar.TURN_ID + 6 + CFG.oR.nextInt(50);
            }
            CFG.game.getCiv((int)n).civGameData.checkFormCiv_TurnID = Game_Calendar.TURN_ID + 2;
        }
    }

    protected final void diplomacyActions_FriendCiv(int n) {
        this.diplomacyActions_InfluencedCiv_Update(n);
        if (Game_Calendar.TURN_ID >= CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID) {
            int n2 = Math.min(CFG.oAI.MIN_NUM_OF_RIVALS, CFG.game.getCiv(n).getNumOfProvinces()) - CFG.game.getCiv((int)n).civGameData.civsInfluencedSize;
            if (n2 > 0) {
                if (CFG.gameAction.getUpdateCivsDiplomacyPoints(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()) <= 3) {
                    CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
                } else if (CFG.game.getCiv((int)n).civGameData.civsInRange.size() > 0) {
                    int n3;
                    ArrayList<AI_CivsInRange> arrayList = new ArrayList<AI_CivsInRange>();
                    for (n3 = CFG.game.getCiv((int)n).civGameData.civsInRange.size() - 1; n3 >= 0; --n3) {
                        arrayList.add(CFG.game.getCiv((int)n).civGameData.civsInRange.get(n3));
                    }
                    Object object = Gdx.app;
                    Serializable serializable = new StringBuilder();
                    ((StringBuilder)serializable).append("diplomacyActions_FriendCiv -> ");
                    ((StringBuilder)serializable).append(CFG.game.getCiv(n).getCivName());
                    ((StringBuilder)serializable).append(", possibleCivs.size: ");
                    ((StringBuilder)serializable).append(arrayList.size());
                    object.log("AoC", ((StringBuilder)serializable).toString());
                    for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                        if (AI_Style.diplomacyActions_RivalCiv_IsRival(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID)) {
                            arrayList.remove(n3);
                            continue;
                        }
                        if (this.diplomacyActions_IsInfluenced(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID)) {
                            arrayList.remove(n3);
                            continue;
                        }
                        if (this.diplomacyActions_IsInfluenced(((AI_CivsInRange)arrayList.get((int)n3)).iCivID, n) && CFG.oR.nextInt(100) < 88) {
                            arrayList.remove(n3);
                            continue;
                        }
                        if (!(CFG.game.getCivRelation_OfCivB(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID) > 55.0f) && !(CFG.game.getCivRelation_OfCivB(((AI_CivsInRange)arrayList.get((int)n3)).iCivID, n) > 55.0f)) continue;
                        arrayList.remove(n3);
                    }
                    if (arrayList.size() > 0) {
                        int n4;
                        ArrayList<Float> arrayList2 = new ArrayList<Float>();
                        serializable = new ArrayList();
                        float f = (float)CFG.oR.nextInt(475) / 1000.0f;
                        float f2 = (float)CFG.oR.nextInt(325) / 1000.0f;
                        float f3 = (float)CFG.game.getCiv(n).getRankPosition() / (float)CFG.game.getCivsSize();
                        float f4 = (float)CFG.oR.nextInt(65) / 1000.0f;
                        n3 = (int)((float)CFG.game.getCiv((int)n).iBudget * ((float)CFG.oR.nextInt(725) / 100.0f + 0.625f));
                        int n5 = arrayList.size();
                        for (n4 = 0; n4 < n5; ++n4) {
                            arrayList2.add(Float.valueOf(this.diplomacyActions_FriendlyCiv_Score(n3, n, (AI_CivsInRange)arrayList.get(n4), f + 1.85f, f2 + 0.625f)));
                            serializable.add(n4);
                        }
                        f = CFG.gameAges.getAge_FogOfWarDiscovery_MetProvinces(Game_Calendar.CURRENT_AGEID);
                        for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                            arrayList2.set(n3, Float.valueOf((float)CFG.oR.nextInt(45) / 100.0f + ((Float)arrayList2.get(n3)).floatValue() * (1.0f - ((AI_CivsInRange)arrayList.get((int)n3)).fRange * (f3 * 0.1475f + 0.2825f + f4) / ((0.2675f * f + f) * CFG.game.getCiv(n).getTechnologyLevel()) + Math.min(CFG.game.getCivRelation_OfCivB(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID), 0.0f) / 100.0f * 0.115f)));
                        }
                        object = new ArrayList();
                        while (serializable.size() > 0 && object.size() < n2) {
                            n5 = 0;
                            for (n3 = serializable.size() - 1; n3 > 0; --n3) {
                                n4 = n5;
                                if (((Float)arrayList2.get((Integer)serializable.get(n3))).floatValue() > ((Float)arrayList2.get((Integer)serializable.get(n5))).floatValue()) {
                                    n4 = n3;
                                }
                                n5 = n4;
                            }
                            object.add(serializable.get(n5));
                            serializable.remove(n5);
                        }
                        n4 = Math.min(CFG.oR.nextInt(2) + 1, n2);
                        n5 = n2;
                        for (n3 = 0; n3 < arrayList.size() && n3 < n4; ++n3) {
                            CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().addImproveRelations(n, ((AI_CivsInRange)arrayList.get((int)((Integer)object.get((int)n3)).intValue())).iCivID, CFG.oR.nextInt(35) + 4);
                            CFG.game.getCiv((int)n).civGameData.civsInfluenced.add(new AI_Influence(((AI_CivsInRange)arrayList.get((int)((Integer)object.get((int)n3)).intValue())).iCivID, CFG.oR.nextInt(40) + 32, Game_Calendar.TURN_ID + this.RIVAL_MIN_TURNS * 3 / 4 + CFG.oR.nextInt(40)));
                            --n5;
                        }
                        CFG.game.getCiv((int)n).civGameData.civsInfluencedSize = CFG.game.getCiv((int)n).civGameData.civsInfluenced.size();
                        if (n5 <= 0) {
                            CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
                        } else if (arrayList.size() - n4 > Math.min(CFG.oAI.MIN_NUM_OF_RIVALS, CFG.game.getCiv(n).getNumOfProvinces()) - CFG.game.getCiv((int)n).civGameData.civsInfluencedSize) {
                            CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 5 + CFG.oR.nextInt(12);
                        }
                    } else {
                        CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
                    }
                    CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
                } else {
                    CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
                }
            } else {
                CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + 12 + CFG.oR.nextInt(24);
            }
        }
    }

    protected final void diplomacyActions_FriendCiv_Continuous(int n) {
        int n2;
        Object object;
        int n3;
        if (CFG.game.getCiv(n).getDiplomacyPoints() < 70 && (n3 = CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().getImproveRelationsSize()) > 0 && CFG.gameAction.getUpdateCivsDiplomacyPoints(n) - n3 * 3 < 4) {
            CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().removeImproveRelations(n, 0);
        }
        n3 = 0;
        while (n3 < CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().getImproveRelationsSize()) {
            object = CFG.game.getCiv(n).getCivilization_Diplomacy_GameData();
            n2 = object.getImproveRelation((int)n3).iWithCivID;
            if (!this.diplomacyActions_IsInfluenced(n, n2)) {
                ((Civilization_Diplomacy_GameData)object).removeImproveRelations_WithCivID(n, n2);
                continue;
            }
            ++n3;
        }
        while (true) {
            block7: {
                for (n3 = 0; n3 < CFG.game.getCiv((int)n).civsInfluencedSize; ++n3) {
                    if (CFG.game.getCiv(n).getDiplomacyPoints() < 70) {
                        n2 = CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().getImproveRelationsSize();
                        if (CFG.gameAction.getUpdateCivsDiplomacyPoints(n) - n2 * 3 < 4) break;
                    }
                    n2 = CFG.game.getCiv((int)n).civsInfluenced.get((int)n3).iCivID;
                    object = CFG.game.getCiv(n).getCivilization_Diplomacy_GameData();
                    if (!((Civilization_Diplomacy_GameData)object).isEmassyClosed(n2) && (int)CFG.game.getCivRelation_OfCivB(n, n2) != -100) {
                        if (object.isImprovingRelation(n2)) continue;
                        CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().addImproveRelations(n, n2, 25);
                        continue;
                    }
                    break block7;
                }
                return;
            }
            object = CFG.game.getCiv((int)n).civsInfluenced;
            object.remove(n3);
            CFG.game.getCiv((int)n).civsInfluencedSize = n3 = object.size();
        }
    }

    protected final float diplomacyActions_FriendlyCiv_Score(int n, int n2, AI_CivsInRange aI_CivsInRange, float f, float f2) {
        float f3 = f * (float)Math.min(n, CFG.game.getCiv((int)aI_CivsInRange.iCivID).iBudget) / (float)Math.max(n, CFG.game.getCiv((int)aI_CivsInRange.iCivID).iBudget);
        float f4 = f2 * (float)Math.min(CFG.game.getCiv(n2).getNumOfProvinces(), CFG.game.getCiv(aI_CivsInRange.iCivID).getNumOfProvinces()) / (float)Math.max(CFG.game.getCiv(n2).getNumOfProvinces(), CFG.game.getCiv(aI_CivsInRange.iCivID).getNumOfProvinces());
        boolean bl = this.isRivalOfMyRival(n2, aI_CivsInRange.iCivID);
        f2 = 1.0f;
        f = bl ? 1.0625f : 1.0f;
        if (CFG.game.getCivRelation_OfCivB(n2, aI_CivsInRange.iCivID) > 40.0f) {
            f2 = 0.625f;
        }
        return f3 + f4 * f * f2;
    }

    protected final void diplomacyActions_InfluencedCiv_Update(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civsInfluencedSize - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civsInfluenced.get((int)i).iUntilTurnID > Game_Calendar.TURN_ID) continue;
            CFG.game.getCiv((int)n).civGameData.civsInfluenced.remove(i);
            CFG.game.getCiv((int)n).civGameData.civsInfluencedSize = CFG.game.getCiv((int)n).civGameData.civsInfluenced.size();
            CFG.game.getCiv((int)n).civGameData.holdLookingForFriends_UntilTurnID = Game_Calendar.TURN_ID + CFG.oR.nextInt(2);
        }
    }

    protected final boolean diplomacyActions_IsInfluenced(int n, int n2) {
        for (int i = 0; i < CFG.game.getCiv((int)n).civGameData.civsInfluencedSize; ++i) {
            if (CFG.game.getCiv((int)n).civGameData.civsInfluenced.get((int)i).iCivID != n2) continue;
            return true;
        }
        return false;
    }

    protected final void diplomacyActions_RivalCiv(int n) {
        this.diplomacyActions_RivalCiv_Update(n);
        if (Game_Calendar.TURN_ID >= CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID) {
            int n2 = Math.min(CFG.oAI.MIN_NUM_OF_RIVALS, CFG.game.getCiv(n).getNumOfProvinces()) - CFG.game.getCiv((int)n).civGameData.civRivalsSize;
            if (n2 > 0) {
                if (CFG.game.getCiv((int)n).civGameData.civsInRange.size() > 0) {
                    int n3;
                    ArrayList<AI_CivsInRange> arrayList = new ArrayList<AI_CivsInRange>();
                    for (n3 = CFG.game.getCiv((int)n).civGameData.civsInRange.size() - 1; n3 >= 0; --n3) {
                        arrayList.add(CFG.game.getCiv((int)n).civGameData.civsInRange.get(n3));
                    }
                    Object object = Gdx.app;
                    Serializable serializable = new StringBuilder();
                    ((StringBuilder)serializable).append("diplomacyActions_RivalCiv -> ");
                    ((StringBuilder)serializable).append(CFG.game.getCiv(n).getCivName());
                    ((StringBuilder)serializable).append(", possibleCivs.size: ");
                    ((StringBuilder)serializable).append(arrayList.size());
                    object.log("AoC", ((StringBuilder)serializable).toString());
                    for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                        if (AI_Style.diplomacyActions_RivalCiv_IsRival(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID)) {
                            arrayList.remove(n3);
                            continue;
                        }
                        if (!this.diplomacyActions_IsInfluenced(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID)) continue;
                        arrayList.remove(n3);
                    }
                    if (arrayList.size() > 0) {
                        int n4;
                        float f;
                        float f2;
                        ArrayList<Float> arrayList2 = new ArrayList<Float>();
                        serializable = new ArrayList();
                        float f3 = (float)CFG.oR.nextInt(475) / 1000.0f;
                        float f4 = (float)CFG.oR.nextInt(525) / 1000.0f;
                        float f5 = (float)CFG.game.getCiv(n).getRankPosition() / (float)CFG.game.getCivsSize() * 0.1475f + 0.2825f + (float)CFG.oR.nextInt(65) / 1000.0f;
                        if (CFG.game.getCiv(n).getNumOfProvinces() >= 5 && CFG.game.getCiv((int)n).iLeague <= 6) {
                            f2 = CFG.game.getCiv((int)n).iBudget;
                            f = 0.775f;
                            n3 = CFG.oR.nextInt(625);
                        } else {
                            f2 = CFG.game.getCiv((int)n).iBudget;
                            f = 0.925f;
                            n3 = CFG.oR.nextInt(15);
                        }
                        int n5 = (int)(f2 * ((float)n3 / 100.0f + f));
                        n3 = arrayList.size();
                        f = f5;
                        for (n4 = 0; n4 < n3; ++n4) {
                            arrayList2.add(Float.valueOf(this.diplomacyActions_RivalCiv_Score(n5, n, (AI_CivsInRange)arrayList.get(n4), f3 + 1.85f, f4 + 0.625f)));
                            serializable.add(n4);
                        }
                        f2 = CFG.gameAges.getAge_FogOfWarDiscovery_MetProvinces(Game_Calendar.CURRENT_AGEID);
                        for (n3 = arrayList.size() - 1; n3 >= 0; --n3) {
                            arrayList2.set(n3, Float.valueOf(((Float)arrayList2.get(n3)).floatValue() * ((-f + ((float)CFG.oR.nextInt(350) / 100.0f + 0.25f) * CFG.game.getCiv((int)((AI_CivsInRange)arrayList.get((int)n3)).iCivID).civGameData.civAggresionLevel) * ((AI_CivsInRange)arrayList.get((int)n3)).fRange / ((0.2675f * f2 + f2) * CFG.game.getCiv(n).getTechnologyLevel()) + 1.0f + Math.min(CFG.game.getCivRelation_OfCivB(n, ((AI_CivsInRange)arrayList.get((int)n3)).iCivID), 0.0f) / 100.0f * 0.115f)));
                        }
                        object = new ArrayList();
                        while (serializable.size() > 0 && object.size() < n2) {
                            n4 = 0;
                            for (n3 = serializable.size() - 1; n3 > 0; --n3) {
                                n5 = n4;
                                if (((Float)arrayList2.get((Integer)serializable.get(n3))).floatValue() > ((Float)arrayList2.get((Integer)serializable.get(n4))).floatValue()) {
                                    n5 = n3;
                                }
                                n4 = n5;
                            }
                            object.add(serializable.get(n4));
                            serializable.remove(n4);
                        }
                        n5 = Math.min(CFG.oR.nextInt(2) + 1, n2);
                        n3 = n2;
                        for (n4 = 0; n4 < arrayList.size() && n4 < n5; ++n4) {
                            n2 = CFG.oR.nextInt(35) + 15;
                            DiplomacyManager.decreaseRelation(n, ((AI_CivsInRange)arrayList.get((int)((Integer)object.get((int)n4)).intValue())).iCivID, n2);
                            CFG.game.getCiv((int)n).civGameData.civRivals.add(new AI_Rival(((AI_CivsInRange)arrayList.get((int)((Integer)object.get((int)n4)).intValue())).iCivID, Game_Calendar.TURN_ID + n2 * 2 + CFG.oR.nextInt(20)));
                            --n3;
                        }
                        CFG.game.getCiv((int)n).civGameData.civRivalsSize = CFG.game.getCiv((int)n).civGameData.civRivals.size();
                        if (n3 <= 0) {
                            CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = Game_Calendar.TURN_ID + (int)((float)this.RIVAL_MIN_TURNS / 10.0f + (float)CFG.oR.nextInt(45) / Game_Calendar.AI_AGGRESSIVNESS);
                        } else if (arrayList.size() - n5 > Math.min(CFG.oAI.MIN_NUM_OF_RIVALS, CFG.game.getCiv(n).getNumOfProvinces()) - CFG.game.getCiv((int)n).civGameData.civRivalsSize) {
                            CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = Game_Calendar.TURN_ID + 5 + (int)((float)CFG.oR.nextInt(12) / Game_Calendar.AI_AGGRESSIVNESS);
                        }
                    } else {
                        CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = Game_Calendar.TURN_ID + (int)(((float)this.RIVAL_MIN_TURNS / 10.0f + (float)CFG.oR.nextInt(60)) / Game_Calendar.AI_AGGRESSIVNESS);
                    }
                } else {
                    CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID + 1;
                }
            } else {
                CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = CFG.game.getCiv((int)n).civGameData.nextBuildCivsInRange_TurnID + 5 + CFG.oR.nextInt(25);
            }
        }
    }

    protected final float diplomacyActions_RivalCiv_Score(int n, int n2, AI_CivsInRange aI_CivsInRange, float f, float f2) {
        return f * (float)Math.min(n, CFG.game.getCiv((int)aI_CivsInRange.iCivID).iBudget) / (float)Math.max(n, CFG.game.getCiv((int)aI_CivsInRange.iCivID).iBudget) + f2 * (float)Math.min(CFG.game.getCiv(n2).getNumOfProvinces(), CFG.game.getCiv(aI_CivsInRange.iCivID).getNumOfProvinces()) / (float)Math.max(CFG.game.getCiv(n2).getNumOfProvinces(), CFG.game.getCiv(aI_CivsInRange.iCivID).getNumOfProvinces());
    }

    protected final void diplomacyActions_RivalCiv_Update(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civRivalsSize - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civRivals.get((int)i).iUntilTurnID > Game_Calendar.TURN_ID) continue;
            CFG.game.getCiv((int)n).civGameData.civRivals.remove(i);
            CFG.game.getCiv((int)n).civGameData.civRivalsSize = CFG.game.getCiv((int)n).civGameData.civRivals.size();
            CFG.game.getCiv((int)n).civGameData.holdLookingForEnemy_UntilTurnID = Game_Calendar.TURN_ID + CFG.oR.nextInt(2);
        }
    }

    protected final boolean doHaveAVisionInProvince(int n, int n2) {
        if (CFG.FOG_OF_WAR == 0) {
            return true;
        }
        if (CFG.game.getProvince(n).getLevelOfFort() == 0) {
            for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
                if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getLevelOfWatchTower() <= 0 || !CFG.game.isAlly(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID(), n2)) continue;
                return true;
            }
        }
        return false;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_RegroupAtWar(int n, int n2, int n3, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n4 = 0;
        n = -1;
        while ((n4 < n3 || list.size() == 0) && arrayList.size() > 0) {
            int n5;
            int n6;
            arrayList2.clear();
            ++n4;
            for (n6 = arrayList.size() - 1; n6 >= 0; --n6) {
                block13: {
                    for (n5 = arrayList2.size() - 1; n5 >= 0; --n5) {
                        if (arrayList2.get(n5) != arrayList.get(n6)) continue;
                        n5 = 0;
                        break block13;
                    }
                    n5 = 1;
                }
                if (n5 == 0) continue;
                arrayList2.add(arrayList.get(n6));
            }
            arrayList.clear();
            for (n5 = arrayList2.size() - 1; n5 >= 0; --n5) {
                for (int i = 0; i < CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvincesSize(); ++i) {
                    if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n5)).intValue()).getNeighboringProvinces((int)i)).was) continue;
                    list2.add(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i));
                    CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n5)).intValue()).getNeighboringProvinces((int)i)).was = true;
                    if (!CFG.game.isAlly(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i)).getCivID()) && CFG.game.getMilitaryAccess(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i)).getCivID()) <= 0) continue;
                    if (CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i)).getBordersWithEnemy()) {
                        boolean bl;
                        block14: {
                            for (n6 = 0; n6 < CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i)).getNeighboringProvincesSize(); ++n6) {
                                if (!CFG.game.getCivsAtWar(n2, CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i)).getNeighboringProvinces(n6)).getCivID())) continue;
                                bl = true;
                                break block14;
                            }
                            bl = false;
                        }
                        n6 = n;
                        if (bl) {
                            list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i), n4));
                            n6 = n;
                            if (n < 0) {
                                n6 = n4;
                            }
                        }
                    } else {
                        n6 = n;
                        if (this.moveAtWar_BordersWithEnemyCheck(n2, CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i))) {
                            list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i), n4));
                            n6 = n;
                            if (n < 0) {
                                n6 = n4;
                            }
                        }
                    }
                    arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n5)).getNeighboringProvinces(i));
                    n = n6;
                }
            }
            if (n <= 0 || n + 2 >= n4) continue;
            break;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final List<AI_NeighProvinces> getAllNeighboringProvincesInRange_RegroupPrepareForWAr(int n, int n2, int n3, List<AI_NeighProvinces> list, List<Integer> list2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(n);
        list2.add(n);
        CFG.game.getProvince((int)n).was = true;
        ArrayList arrayList2 = new ArrayList();
        int n4 = 0;
        int n5 = -1;
        while ((n4 < n3 || list.size() == 0) && arrayList.size() > 0) {
            arrayList2.clear();
            int n6 = n4 + 1;
            for (n = arrayList.size() - 1; n >= 0; --n) {
                block11: {
                    for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                        if (arrayList2.get(n4) != arrayList.get(n)) continue;
                        n4 = 0;
                        break block11;
                    }
                    n4 = 1;
                }
                if (n4 == 0) continue;
                arrayList2.add(arrayList.get(n));
            }
            arrayList.clear();
            n = n5;
            for (n4 = arrayList2.size() - 1; n4 >= 0; --n4) {
                for (int i = 0; i < CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvincesSize(); ++i) {
                    block12: {
                        block13: {
                            n5 = n;
                            if (CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was) break block12;
                            list2.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                            CFG.game.getProvince((int)CFG.game.getProvince((int)((Integer)arrayList2.get((int)n4)).intValue()).getNeighboringProvinces((int)i)).was = true;
                            if (CFG.game.isAlly(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID())) break block13;
                            n5 = n;
                            if (CFG.game.getMilitaryAccess(n2, CFG.game.getProvince(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i)).getCivID()) <= 0) break block12;
                        }
                        n5 = n;
                        if (CFG.oAI.prepareForWar_BordersWithEnemy(n2, CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i))) {
                            list.add(new AI_NeighProvinces(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i), n6));
                            n5 = n;
                            if (n < 0) {
                                n5 = n6;
                            }
                        }
                        arrayList.add(CFG.game.getProvince((Integer)arrayList2.get(n4)).getNeighboringProvinces(i));
                    }
                    n = n5;
                }
            }
            n4 = n6;
            n5 = n;
            if (n <= 0) continue;
            n4 = n6;
            n5 = n;
            if (n + 2 >= n6) continue;
        }
        for (n = list2.size() - 1; n >= 0; --n) {
            CFG.game.getProvince((int)list2.get((int)n).intValue()).was = false;
        }
        arrayList.clear();
        list2.clear();
        return list;
    }

    protected final int getEnemyArmyInNeighbooringProvinces_ArmyOnlyAtWar(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n4 = n3;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() > 0) {
                for (n4 = 0; n4 < CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivsSize(); ++n4) {
                    int n5 = n3;
                    if (CFG.game.getCivsAtWar(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID(n4), n2)) {
                        n5 = n3 + CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getArmyCivID(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID(n4));
                    }
                    n3 = n5;
                }
                n4 = n3;
            }
            n3 = n4;
        }
        return n3;
    }

    protected final int getEnemyArmyInNeighbooringProvinces_Total(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n4 = n3;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() > 0) {
                int n5 = 0;
                while (true) {
                    n4 = n3;
                    if (n5 >= CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivsSize()) break;
                    if (CFG.game.getCivsAtWar(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID(n5), n2)) {
                        n4 = n3 + CFG.game.getProvinceArmy(CFG.game.getProvince(n).getNeighboringProvinces(i));
                        break;
                    }
                    ++n5;
                }
            }
            n3 = n4;
        }
        return n3;
    }

    protected final int getEnemyArmyInNeighbooringSeaProvinces_Total(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringSeaProvincesSize(); ++i) {
            for (int j = 1; j < CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringSeaProvinces(i)).getCivsSize(); ++j) {
                int n4 = n3;
                if (CFG.game.getCivsAtWar(CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringSeaProvinces(i)).getCivID(j), n2)) {
                    n4 = n3 + CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringSeaProvinces(i)).getArmy(j);
                }
                n3 = n4;
            }
        }
        return n3;
    }

    protected final int getEnemyArmy_ExtraMovedArmy(int n) {
        int n2 = 0;
        for (int i = 0; i < CFG.game.getProvince(n).getCivsSize(); ++i) {
            for (int j = 0; j < CFG.game.getCiv(CFG.game.getProvince(n).getCivID(i)).getMoveUnitsSize(); ++j) {
                int n3 = n2;
                if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID(i)).getMoveUnits(j).getFromProvinceID() == n) {
                    n3 = n2 + CFG.game.getCiv(CFG.game.getProvince(n).getCivID(i)).getMoveUnits(j).getNumOfUnits();
                }
                n2 = n3;
            }
        }
        return n2;
    }

    protected float getMinMilitarySpendings(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.MIN_MILITARY_SPENDINGS;
    }

    protected final int getMovingArmyToProvinceID(int n, int n2) {
        int n3;
        int n4;
        int n5;
        int n6 = 0;
        int n7 = 0;
        for (n5 = 0; n5 < CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size(); ++n5) {
            n4 = n7;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n5).toProvinceID == n2) {
                n4 = n7 + CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n5).iArmy;
            }
            n7 = n4;
        }
        n5 = 0;
        while (true) {
            n3 = n7;
            if (n5 >= CFG.game.getCiv(n).getRegroupArmySize()) break;
            n4 = n7;
            if (CFG.game.getCiv(n).getRegroupArmy(n5).getToProvinceID() == n2) {
                n4 = n7 + CFG.game.getCiv(n).getRegroupArmy(n5).getNumOfUnits();
            }
            ++n5;
            n7 = n4;
        }
        for (n4 = n6; n4 < CFG.game.getCiv(n).getMoveUnitsSize(); ++n4) {
            n7 = n3;
            if (CFG.game.getCiv(n).getMoveUnits(n4).getToProvinceID() == n2) {
                n7 = n3 + CFG.game.getCiv(n).getMoveUnits(n4).getNumOfUnits();
            }
            n3 = n7;
        }
        return n3;
    }

    protected final int getPotential_BasedOnNeighboringProvs(int n, int n2) {
        int n3 = CFG.game.getProvince(n).getPotential();
        int n4 = 1;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n5 = n3;
            int n6 = n4;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() != n2) {
                n5 = n3 + CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getPotentialModified(n2);
                n6 = n4 + 1;
            }
            n3 = n5;
            n4 = n6;
        }
        return n3 / n4;
    }

    protected final int getPotential_BasedOnNeighboringProvs(int n, int n2, int n3) {
        int n4 = CFG.game.getProvince(n).getPotential();
        int n5 = 1;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n6 = n4;
            int n7 = n5;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() == n3) {
                n6 = n4 + CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getPotentialModified(n2);
                n7 = n5 + 1;
            }
            n4 = n6;
            n5 = n7;
        }
        return n4 / n5;
    }

    protected final int getPotential_BasedOnNeighboringProvs(int n, int n2, List<Integer> list) {
        int n3 = CFG.game.getProvince(n).getPotential();
        int n4 = list.size();
        int n5 = 1;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n6 = n3;
            n3 = n5;
            n5 = n6;
            for (int j = 0; j < n4; ++j) {
                int n7 = n5;
                n6 = n3;
                if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() == list.get(j).intValue()) {
                    n7 = n5 + CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getPotentialModified(n2);
                    n6 = n3 + 1;
                }
                n5 = n7;
                n3 = n6;
            }
            n6 = n5;
            n5 = n3;
            n3 = n6;
        }
        return n3 / n5;
    }

    protected final int getPrepareForWar_TurnsLeft(int n, int n2) {
        for (int i = 0; i < CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize; ++i) {
            if (CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)i).onCivID != n2) continue;
            return CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)i).iNumOfTurnsLeft;
        }
        return -1;
    }

    protected final int getPrepareForWar_TurnsLeft_BasedOnNeighboors(int n, int n2) {
        int n3 = 8;
        for (int i = 0; i < CFG.game.getProvince(n2).getNeighboringProvincesSize(); ++i) {
            int n4 = n3;
            if (CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID() > 0) {
                n4 = n3;
                if (CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID() != n) {
                    for (int j = 0; j < CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize; ++j) {
                        n4 = n3;
                        if (CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)j).onCivID == CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID()) {
                            n4 = Math.max(CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)j).iNumOfTurnsLeft, n3);
                        }
                        n3 = n4;
                    }
                    n4 = n3;
                }
            }
            n3 = n4;
        }
        return n3;
    }

    protected final int getRecruitableArmy(int n, int n2) {
        return Math.min(CFG.gameAction.getRecruitableArmy(n, n2), (int)(CFG.game.getCiv(n2).getMoney() / (long)CFG.getCostOfRecruitArmyMoney(n)));
    }

    protected final int getRegroupArmy_NumOfUnits(int n, int n2) {
        int n3 = CFG.game.getProvince(n2).getArmyCivID(n);
        for (int i = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; i >= 0; --i) {
            int n4 = n3;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).iProvinceID == n2) {
                n4 = n3 - CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).iArmy;
            }
            n3 = n4;
        }
        return n3;
    }

    protected final float getValue_PositionOfArmy(int n, List<AI_ProvinceInfo> list, int n2, int n3, float f, float f2, int n4, int n5, int n6, float f3) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_POTENTIAL * (list.get((int)n2).iValue / f) + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_DANGER * ((float)CFG.game.getProvince(list.get((int)n2).iProvinceID).getDangerLevel_WithArmy() / (float)n4) * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_NUM_OF_UNITS + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_NUM_OF_UNITS * (1.0f - (float)(CFG.game.getProvince(list.get((int)n2).iProvinceID).getArmy(0) + n3) / ((float)n5 + (float)n6 * CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_NUM_OF_UNITS_RECRUITMENT))) * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_REGION_NUM_OF_PROVINCES + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_REGION_NUM_OF_PROVINCES * (float)CFG.game.getProvince(list.get((int)n2).iProvinceID).getRegion_NumOfProvinces() / f3 - CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_REGION_POTENTIAL + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_REGION_POTENTIAL * (float)CFG.game.getProvince(list.get((int)n2).iProvinceID).getPotentialRegion() / f2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void happinessCrisis(int n) {
        Object object;
        block13: {
            try {
                int n2;
                if (CFG.game.getCiv((int)n).lProvincesWithLowHappiness.size() <= 0) return;
                if (CFG.game.getCiv(n).getMovePoints() < 8) return;
                if (!((float)CFG.game.getCiv(n).getMoney() >= (float)DiplomacyManager.festivalCost(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(0)) * 1.0f)) return;
                ArrayList<Object> arrayList = new ArrayList<Object>();
                if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0) {
                    CFG.game.getCiv(n).getCapitalProvinceID();
                } else {
                    CFG.game.getCiv(n).getProvinceID(0);
                }
                for (n2 = CFG.game.getCiv((int)n).lProvincesWithLowHappiness.size() - 1; n2 >= 0; --n2) {
                    if (CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2)).getHappiness() < Game_Action.RISE_REVOLT_RISK_HAPPINESS) {
                        object = new Assimilate_Data(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2), (float)CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2)).getPopulationData().getPopulation() * (6.0f - CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2)).getHappiness() / 4.0f));
                        arrayList.add(object);
                        continue;
                    }
                    object = new Assimilate_Data(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2), (float)CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2)).getPopulationData().getPopulation() * (6.0f - CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2)).getHappiness()));
                    arrayList.add(object);
                }
                object = new ArrayList();
                while (arrayList.size() > 0) {
                    int n3 = 0;
                    for (n2 = 1; n2 < arrayList.size(); ++n2) {
                        int n4 = n3;
                        if (((Assimilate_Data)arrayList.get((int)n2)).fScore > ((Assimilate_Data)arrayList.get((int)n3)).fScore) {
                            n4 = n2;
                        }
                        n3 = n4;
                    }
                    object.add(arrayList.get(n3));
                    arrayList.remove(n3);
                }
                break block13;
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
                return;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            return;
        }
        while (CFG.game.getCiv(n).getMovePoints() >= 8 && object.size() != 0 && DiplomacyManager.addFestival(n, ((Assimilate_Data)object.get((int)0)).iProvinceID)) {
            object.remove(0);
        }
        object.clear();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void hostFestivals(int n, int n2) {
        ArrayList arrayList;
        int n3;
        if (CFG.game.getCiv(n).getMovePoints() < 8) return;
        if (!((float)CFG.game.getCiv(n).getMoney() >= (float)DiplomacyManager.festivalCost(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(0)) * 1.05f)) return;
        ArrayList arrayList2 = new ArrayList();
        int n4 = CFG.game.getCiv(n).getCapitalProvinceID() >= 0 ? CFG.game.getCiv(n).getCapitalProvinceID() : CFG.game.getCiv(n).getProvinceID(0);
        for (n3 = CFG.game.getCiv((int)n).lProvincesWithLowHappiness.size() - 1; n3 >= 0; --n3) {
            arrayList = new ArrayList(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n3), (CFG.game.getCiv((int)n).civGameData.civPersonality.ASSIMILATE_PERC_POPULATION_SCORE * Math.min((float)CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n3)).getPopulationData().getPopulation() / (float)CFG.game.getGameScenarios().getScenario_StartingPopulation(), 1.0f) + CFG.game.getCiv((int)n).civGameData.civPersonality.ASSIMILATE_PERC_DISTANCE_SCORE * CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(n4, CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n3))) * CFG.game.getProvince(CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n3)).getProvinceStability());
            arrayList2.add(arrayList);
        }
        arrayList = new ArrayList();
        while (true) {
            n4 = n2;
            if (arrayList2.size() <= 0) break;
            n3 = 0;
            for (n4 = 1; n4 < arrayList2.size(); ++n4) {
                int n5 = n3;
                if (((Assimilate_Data)arrayList2.get((int)n4)).fScore > ((Assimilate_Data)arrayList2.get((int)n3)).fScore) {
                    n5 = n4;
                }
                n3 = n5;
            }
            arrayList.add(arrayList2.get(n3));
            arrayList2.remove(n3);
        }
        while (CFG.game.getCiv(n).getMovePoints() >= 8 && arrayList.size() != 0 && (float)CFG.game.getCiv(n).getMoney() >= (float)DiplomacyManager.festivalCost(((Assimilate_Data)arrayList.get((int)0)).iProvinceID) * 1.125f && DiplomacyManager.addFestival(n, ((Assimilate_Data)arrayList.get((int)0)).iProvinceID)) {
            arrayList.remove(0);
            if (n4 <= 0) {
                return;
            }
            --n4;
        }
        try {
            arrayList.clear();
            return;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
        }
    }

    protected final boolean isRivalOfMyRival(int n, int n2) {
        for (int i = 0; i < CFG.game.getCiv((int)n).civGameData.civRivalsSize; ++i) {
            if (!AI_Style.diplomacyActions_RivalCiv_IsRival(CFG.game.getCiv((int)n).civGameData.civRivals.get((int)i).iCivID, n2)) continue;
            return true;
        }
        return false;
    }

    protected final boolean isUncivilzed(int n) {
        boolean bl = CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CAN_BECOME_CIVILIZED >= 0;
        return bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void manageBudget(int var1_1) {
        block41: {
            block42: {
                block35: {
                    block40: {
                        block39: {
                            block38: {
                                block37: {
                                    block36: {
                                        block23: {
                                            block33: {
                                                block34: {
                                                    block27: {
                                                        block32: {
                                                            block31: {
                                                                block30: {
                                                                    block29: {
                                                                        block28: {
                                                                            block25: {
                                                                                block26: {
                                                                                    block24: {
                                                                                        CFG.game.getCiv(var1_1).setSpendings_Goods(Math.max(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) + 0.01f, CFG.game.getCiv(var1_1).getSpendings_Goods()));
                                                                                        CFG.game.getCiv(var1_1).setSpendings_Investments(Math.max(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + 0.01f, CFG.game.getCiv(var1_1).getSpendings_Investments()));
                                                                                        var2_2 = CFG.game.getCiv(var1_1).isAtWar();
                                                                                        var3_3 = 0.275f;
                                                                                        var4_4 = 0;
                                                                                        var5_5 = 0.3f;
                                                                                        var6_6 = 1.0f;
                                                                                        if (var2_2 || CFG.game.getCiv((int)var1_1).civGameData.civPlans.isPreparingForTheWar()) break block23;
                                                                                        if (CFG.game.getCiv(var1_1).getMoney() >= AI_Style.getMoney_MinReserve_LockTreasury(var1_1)) break block24;
                                                                                        if (CFG.game.getCiv(var1_1).getMoney() > 0L) {
                                                                                            var3_3 = 0.275f + (float)CFG.game.getCiv(var1_1).getMoney() / (float)AI_Style.getMoney_MinReserve_LockTreasury(var1_1) * 0.225f;
                                                                                        }
                                                                                        break block25;
                                                                                    }
                                                                                    if (CFG.game.getCiv(var1_1).getMoney() >= AI_Style.getMoney_MinReserve(var1_1)) break block26;
                                                                                    if (CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f > 0.0f) {
                                                                                        var3_3 = CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f + 1.0f;
                                                                                        CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TREASURY_RESERVE = Math.max(2.25f, CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TREASURY_RESERVE - 0.75f);
                                                                                    } else {
                                                                                        var3_3 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TREASURY_RESERVE_MODIFIER + (1.0f - CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TREASURY_RESERVE_MODIFIER) * (float)CFG.game.getCiv(var1_1).getMoney() / ((float)CFG.game.getCiv((int)var1_1).iBudget * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TREASURY_RESERVE);
                                                                                    }
                                                                                    ** GOTO lbl24
                                                                                }
                                                                                if (CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f > 0.0f) {
                                                                                    var3_3 = CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f + 1.0f;
lbl24:
                                                                                    // 3 sources

                                                                                    var7_7 = var3_3;
                                                                                } else {
                                                                                    var7_7 = 1.0f;
                                                                                }
                                                                                var3_3 = var7_7;
                                                                                if (CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() > 0) {
                                                                                    var4_4 = DiplomacyManager.assimilateCost(CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.get(0), 25);
                                                                                    var8_9 = CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size();
                                                                                    var3_3 = Math.min(var7_7, (float)CFG.game.getCiv(var1_1).getMoney() * 0.9f / (float)(var4_4 * var8_9) + 0.1f);
                                                                                }
                                                                            }
                                                                            if (CFG.game.getCiv(var1_1).getHappiness() - CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV >= 0) break block27;
                                                                            if (CFG.game.getCiv(var1_1).getHappiness() >= 20) break block28;
                                                                            var7_7 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f;
                                                                            var5_5 = 16.0f;
                                                                            break block29;
                                                                        }
                                                                        if (CFG.game.getCiv(var1_1).getHappiness() >= 40) break block30;
                                                                        var7_7 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f;
                                                                        var5_5 = 4.0f;
                                                                    }
                                                                    var7_7 /= var5_5;
                                                                    break block31;
                                                                }
                                                                if (CFG.game.getCiv(var1_1).getHappiness() >= 55) break block32;
                                                                var7_7 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f / 2.0f;
                                                            }
                                                            var5_5 = var7_7;
                                                            var7_7 = 0.0f;
                                                            break block33;
                                                        }
                                                        var7_7 = 0.3f * ((float)CFG.game.getCiv(var1_1).getHappiness() / (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV);
                                                        break block34;
                                                    }
                                                    var7_7 = var5_5;
                                                    if (CFG.game.getCiv(var1_1).getHappiness() > 80) {
                                                        var7_7 = var5_5;
                                                        if ((float)CFG.game.getCiv(var1_1).getHappiness() > CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_PROVINCE_HAPPINESS_RUN_FESTIVAL * 115.0f) {
                                                            var7_7 = 0.3f + (float)CFG.oR.nextInt(1450) / 1000.0f;
                                                        }
                                                    }
                                                }
                                                var5_5 = 0.7f;
                                            }
                                            CFG.game.getCiv(var1_1).setTaxationLevel((CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION * var5_5 + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION * var7_7) * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TAXATION_LEVEL);
                                            this.updateMilitarySpendings(var1_1);
                                            var7_7 = 0.97f - CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS;
                                            if (!(var7_7 > 0.0f)) {
                                                CFG.game.getCiv(var1_1).setSpendings_Research(0.0f);
                                                return;
                                            }
                                            if (CFG.game.getCiv(var1_1).getMoney() < 0L) {
                                                var3_3 = var7_7 * ((float)CFG.oR.nextInt(46) / 100.0f + 0.04f);
                                                var7_7 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET;
                                                CFG.game.getCiv(var1_1).setSpendings_Goods(Math.max(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET / var7_7 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var3_3), CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)));
                                                CFG.game.getCiv(var1_1).setSpendings_Investments(Math.max(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET / var7_7 * (var3_3 * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS), CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS));
                                                CFG.game.getCiv(var1_1).setSpendings_Research(0.0f);
                                                return;
                                            }
                                            if (CFG.game.getCiv((int)var1_1).fAverageDevelopment / CFG.game.getCiv(var1_1).getTechnologyLevel() < CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY) {
                                                var6_6 = 1.0f + (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY - CFG.game.getCiv((int)var1_1).fAverageDevelopment / CFG.game.getCiv(var1_1).getTechnologyLevel()) / CFG.game.getCiv(var1_1).getTechnologyLevel();
                                            }
                                            var5_5 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET * var6_6 + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET;
                                            CFG.game.getCiv(var1_1).setSpendings_Goods(Math.max(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET / var5_5 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var7_7) * var3_3, CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)));
                                            CFG.game.getCiv(var1_1).setSpendings_Investments(Math.max(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET * var6_6 / var5_5 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var7_7) * var3_3, CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS));
                                            CFG.game.getCiv(var1_1).setSpendings_Research(CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET / var5_5 * (var7_7 * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS) * var3_3);
                                            return;
                                        }
                                        if (CFG.game.getCiv((int)var1_1).isAtWarWithCivs.size() > 0) {
                                            for (var8_10 = CFG.game.getCiv((int)var1_1).isAtWarWithCivs.size() - 1; var8_10 >= 0; --var8_10) {
                                                var4_4 = (int)((float)var4_4 + Math.max(1.0f, (float)CFG.game.getCiv((int)CFG.game.getCiv((int)var1_1).isAtWarWithCivs.get((int)var8_10).intValue()).iBudget * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR_MODIFIER));
                                            }
                                            CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR = Math.max(Math.min(2.0f, (float)var4_4 / (float)CFG.game.getCiv((int)var1_1).iBudget), CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS);
                                        } else {
                                            CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS;
                                        }
                                        if (CFG.game.getCiv(var1_1).getHappiness() - CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV >= 0) break block35;
                                        if (CFG.game.getCiv(var1_1).getHappiness() >= 20) break block36;
                                        var7_8 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f;
                                        var3_3 = 16.0f;
                                        break block37;
                                    }
                                    if (CFG.game.getCiv(var1_1).getHappiness() >= 40) break block38;
                                    var7_8 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f;
                                    var3_3 = 4.0f;
                                }
                                var3_3 = var7_8 / var3_3;
                                break block39;
                            }
                            if (CFG.game.getCiv(var1_1).getHappiness() >= 55) break block40;
                            var3_3 = (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV / 100.0f / 2.0f;
                        }
                        var5_5 = 0.0f;
                        var7_8 = var3_3;
                        break block41;
                    }
                    var3_3 = 0.3f * ((float)CFG.game.getCiv(var1_1).getHappiness() / (float)CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_FOR_CIV);
                    break block42;
                }
                var3_3 = var5_5;
                if (CFG.game.getCiv(var1_1).getHappiness() > 80) {
                    var3_3 = var5_5;
                    if ((float)CFG.game.getCiv(var1_1).getHappiness() > CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_PROVINCE_HAPPINESS_RUN_FESTIVAL * 115.0f) {
                        var3_3 = 0.3f + (float)CFG.oR.nextInt(1450) / 1000.0f;
                    }
                }
            }
            var7_8 = 0.7f;
            var5_5 = var3_3;
        }
        CFG.game.getCiv(var1_1).setTaxationLevel((CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION * var7_8 + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION * var5_5) * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.TAXATION_LEVEL);
        this.updateMilitarySpendings(var1_1);
        var7_8 = 0.97f - CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS;
        if (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR > CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC) {
            var3_3 = 0.275f - (1.0f - CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC / Math.min(1.0f, CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_WAR)) * 0.375f;
        } else {
            for (var8_10 = CFG.game.getCiv((int)var1_1).isAtWarWithCivs.size() - 1; var8_10 >= 0; --var8_10) {
            }
            var3_3 = 0.25f;
        }
        if (CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f > 0.0f) {
            var3_3 = CFG.game_NextTurnUpdate.getInflationPerc(var1_1) * 100.0f + 1.0f;
        }
        if (!(var7_8 > 0.0f)) {
            CFG.game.getCiv(var1_1).setSpendings_Research(0.0f);
            return;
        }
        if (CFG.game.getCiv(var1_1).getMoney() < 0L) {
            var3_3 = var7_8 * ((float)CFG.oR.nextInt(46) / 100.0f + 0.04f);
            var7_8 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET;
            CFG.game.getCiv(var1_1).setSpendings_Goods(Math.max(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET / var7_8 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var3_3), CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)));
            CFG.game.getCiv(var1_1).setSpendings_Investments(Math.max(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET / var7_8 * (var3_3 * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS), CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS));
            CFG.game.getCiv(var1_1).setSpendings_Research(0.0f);
            return;
        }
        if (CFG.game.getCiv((int)var1_1).fAverageDevelopment / CFG.game.getCiv(var1_1).getTechnologyLevel() < CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_DIFFERENCE_IN_DEVELOPMENT_TO_TECHNOLOGY) {
            var6_6 = 1.0f - CFG.game.getCiv((int)var1_1).fAverageDevelopment / CFG.game.getCiv(var1_1).getTechnologyLevel();
        }
        var5_5 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET + (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET) * var6_6 + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET;
        CFG.game.getCiv(var1_1).setSpendings_Goods(Math.max(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.GOODS_EXTRA_PERC_OF_BUDGET / var5_5 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var7_8) * var3_3, CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)));
        CFG.game.getCiv(var1_1).setSpendings_Investments(Math.max((CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET + (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS + CFG.game.getCiv((int)var1_1).civGameData.civPersonality.INVESTMENTS_EXTRA_PERC_OF_BUDGET) * var6_6) / var5_5 * (CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS * var7_8) * var3_3, CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS));
        CFG.game.getCiv(var1_1).setSpendings_Research(CFG.game.getCiv((int)var1_1).civGameData.civPersonality.RESEARCH_PERC_OF_BUDGET / var5_5 * (var7_8 * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.USE_OF_BUDGET_FOR_SPENDINGS) * var3_3);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void manageVassalsTribute(int var1_1) {
        var2_2 = 0;
        while (true) {
            if (var2_2 >= CFG.game.getCiv((int)var1_1).civGameData.lVassals.size()) return;
            var3_3 = CFG.game.getCiv((int)var1_1).civGameData.lVassals.get(var2_2);
            var4_5 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.VASSALS_TRIBUTE_PERC;
            var5_6 = CFG.game.getCivRelation_OfCivB(var1_1, CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var2_2).iCivID);
            var6_7 = 0.0f;
            if (!(var5_6 > 0.0f)) ** GOTO lbl12
            var6_7 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.VASSALS_TRIBUTE_PERC * CFG.game.getCiv((int)var1_1).civGameData.civPersonality.VASSALS_TRIBUTE_PERC_FRIENDLY * CFG.game.getCivRelation_OfCivB(var1_1, CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var2_2).iCivID) / 100.0f;
lbl12:
            // 2 sources

            var3_3.setTribute((int)(25.0f * (var4_5 - var6_7 + (float)CFG.oR.nextInt((int)(CFG.game.getCiv((int)var1_1).civGameData.civPersonality.VASSALS_TRIBUTE_PERC_RAND * 100.0f)) / 100.0f)));
            ++var2_2;
            continue;
            break;
        }
        catch (IndexOutOfBoundsException var3_4) {
            CFG.exceptionStack(var3_4);
        }
    }

    /*
     * Exception decompiling
     */
    protected final void moveAtWar(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[TRYBLOCK]], but top level block is 114[FORLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    protected final void moveAtWarPlayer(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[TRYBLOCK]], but top level block is 114[FORLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void moveAtWar_AtSea(int n) {
        block34: {
            if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE) return;
            Gdx.app.log("AoC", "moveAtWar -> BY SEA");
            int n2 = this.moveAtWar_AtSea_RunMissions(n);
            Gdx.app.log("AoC", "moveAtWar -> BY SEA -> numOfCurrentInvasions: " + n2);
            if (Game_Calendar.TURN_ID <= CFG.game.getCiv((int)n).civGameData.iNextPossibleNavalInvastionTurnID) {
                return;
            }
            if (CFG.game.getCiv(n).getBordersWithEnemy() != 0 || n2 <= 0) {
                // empty if block
            }
            if ((float)n2 >= Math.max(1.0f, (float)CFG.game.getCiv(n).getNumOfProvinces() / 4.0f)) return;
            n2 = CFG.game.getCiv(n).getBordersWithEnemy();
            int n3 = CFG.DIFFICULTY;
            if (n3 - 4 == 0 || n3 == 0) {
                n2 = 0;
            }
            if (n2 == 0) {
                Gdx.app.log("AoC", "moveAtWar -> BY SEA -> NO NEIGHBORING ENEMIES, LOOK FOR SEA PROVINCES");
                boolean bl = BuildingsManager.canBuildPort(CFG.game.getCiv(n).getProvinceID(0));
                if (CFG.game.getCiv(n).getSeaAccess_PortProvinces_Size() == 0 && !bl) {
                    Gdx.app.log("AoC", "moveAtWar -> BY SEA -> CANT GO TO THE SEA..");
                    return;
                }
                if (CFG.game.getCiv(n).getSeaAccess() > 0) {
                    ArrayList<Integer> arrayList = new ArrayList<Integer>();
                    for (n2 = CFG.game.getCiv((int)n).isAtWarWithCivs.size() - 1; n2 >= 0; --n2) {
                        if (CFG.game.getCiv(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n2)).getSeaAccess() <= 0) continue;
                        arrayList.add(CFG.game.getCiv((int)n).isAtWarWithCivs.get(n2));
                    }
                    if (arrayList.size() > 0) {
                        float f;
                        float f2;
                        float f3;
                        ArrayList<Boolean> arrayList2 = new ArrayList<Boolean>();
                        ArrayList arrayList3 = new ArrayList();
                        ArrayList arrayList4 = new ArrayList();
                        for (n2 = 0; n2 < CFG.map.iNumOfBasins; ++n2) {
                            arrayList2.add(false);
                            arrayList3.add(new ArrayList());
                            arrayList4.add(new ArrayList());
                        }
                        if (!bl) {
                            for (n2 = CFG.game.getCiv(n).getSeaAccess_PortProvinces_Size() - 1; n2 >= 0; --n2) {
                                for (n3 = 0; n3 < CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_PortProvinces().get(n2)).getNeighboringSeaProvincesSize(); ++n3) {
                                    arrayList2.set(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_PortProvinces().get(n2)).getNeighboringSeaProvinces(n3)).getBasinID(), true);
                                }
                            }
                        } else {
                            for (n2 = CFG.game.getCiv(n).getSeaAccess_Provinces_Size() - 1; n2 >= 0; --n2) {
                                for (n3 = 0; n3 < CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n2)).getNeighboringSeaProvincesSize(); ++n3) {
                                    arrayList2.set(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n2)).getNeighboringSeaProvinces(n3)).getBasinID(), true);
                                }
                            }
                        }
                        int n4 = 0;
                        int n5 = 0;
                        n2 = arrayList.size() - 1;
                        block6: while (true) {
                            if (n2 < 0) {
                                Gdx.app.log("AoC", "moveAtWar -> BY SEA -> possibleMoveTo_OwnProvinces: " + n4);
                                Gdx.app.log("AoC", "moveAtWar -> BY SEA -> possibleMoveTo: " + n5);
                                if (n5 + n4 == 0) return;
                                n2 = -1;
                                f3 = -1.0f;
                                if (n5 > 0 || n4 > 0) {
                                    break;
                                }
                                break block34;
                            }
                            n3 = CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces_Size() - 1;
                            while (true) {
                                if (n3 >= 0) {
                                } else {
                                    --n2;
                                    continue block6;
                                }
                                for (int i = 0; i < CFG.game.getProvince(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvincesSize(); ++i) {
                                    int n6 = n5;
                                    int n7 = n4;
                                    if (((Boolean)arrayList2.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvinces(i)).getBasinID())).booleanValue()) {
                                        if (CFG.game.getProvince(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3)).getTrueOwnerOfProvince() == n) {
                                            ((List)arrayList3.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvinces(i)).getBasinID())).add(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3));
                                            n7 = n4 + 1;
                                            n6 = n5;
                                        } else {
                                            ((List)arrayList4.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvinces(i)).getBasinID())).add(CFG.game.getCiv((Integer)arrayList.get(n2)).getSeaAccess_Provinces().get(n3));
                                            n6 = n5 + 1;
                                            n7 = n4;
                                        }
                                    }
                                    n5 = n6;
                                    n4 = n7;
                                }
                                --n3;
                            }
                            break;
                        }
                        for (n3 = arrayList3.size() - 1; n3 >= 0; --n3) {
                            for (n4 = ((List)arrayList3.get(n3)).size() - 1; n4 >= 0; --n4) {
                                f2 = this.moveAtWar_AtSea_ToProvinceID_Score(n, (Integer)((List)arrayList3.get(n3)).get(n4), true);
                                f = f3;
                                if (f2 > f3) {
                                    n2 = (Integer)((List)arrayList3.get(n3)).get(n4);
                                    f = f2;
                                }
                                f3 = f;
                            }
                        }
                        n3 = arrayList4.size() - 1;
                        n4 = n2;
                        for (n2 = n3; n2 >= 0; --n2) {
                            for (n3 = ((List)arrayList4.get(n2)).size() - 1; n3 >= 0; --n3) {
                                f2 = this.moveAtWar_AtSea_ToProvinceID_Score(n, (Integer)((List)arrayList4.get(n2)).get(n3), false);
                                f = f3;
                                if (f2 > f3) {
                                    n4 = (Integer)((List)arrayList4.get(n2)).get(n3);
                                    f = f2;
                                }
                                f3 = f;
                            }
                        }
                        if (n4 >= 0) {
                            if (!CFG.game.isAlly(n, CFG.game.getProvince(n4).getCivID()) && CFG.game.getCiv(n).getRankPosition() > CFG.game.getCiv(CFG.game.getProvince(n4).getCivID()).getRankPosition() && CFG.oR.nextInt(100) < 0) {
                                CFG.game.getCiv((int)n).civGameData.iNextPossibleNavalInvastionTurnID = Game_Calendar.TURN_ID + 1;
                                return;
                            }
                            this.moveAtWar_AtSea_ToProvinceID(n, n4);
                        } else {
                            Gdx.app.log("AoC", "moveAtWar -> BY SEA -> iBestProvinceID_MoveTo: " + n4);
                        }
                    }
                }
            }
        }
        Gdx.app.log("AoC", "moveAtWar -> BY SEA -> MP: " + CFG.game.getCiv(n).getMovePoints());
        Gdx.app.log("AoC", "moveAtWar -> BY SEA END");
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final float moveAtWar_AtSea_FromProvinceID_Score(int n, int n2, int n3, boolean bl, int n4) {
        float f;
        float f2 = CFG.game.getProvince(n2).getPotential();
        int n5 = CFG.game.getProvince(n2).getArmyCivID(n);
        int n6 = CFG.game.getProvince(n2).isOccupied() ? 0 : n4;
        float f3 = (n6 + n5) / Math.max(1, CFG.game.getCiv(n).getNumOfUnits() + n4);
        if (CFG.game.getProvince(n2).getLevelOfPort() > 0) {
            f = 1.5f;
            return f * (f2 * (f3 * 0.625f + 0.375f)) * (1.0f - CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(n2, n3) / 2.0f);
        }
        f = 1.0f;
        return f * (f2 * (f3 * 0.625f + 0.375f)) * (1.0f - CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(n2, n3) / 2.0f);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final int moveAtWar_AtSea_RunMissions(int n) {
        int n2 = 0;
        int n3 = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1;
        while (n3 >= 0) {
            int n4 = n2;
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n3).MISSION_TYPE == CivArmyMission_Type.NAVAL_INVASION) {
                n4 = n2;
                if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n3).canMakeAction(n, 0)) {
                    if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n3).action(n)) {
                        CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(n3);
                        n4 = n2;
                    } else if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n3).iObsolate <= 0) {
                        CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(n3);
                        n4 = n2;
                    } else {
                        n4 = n2 + 1;
                    }
                }
            }
            --n3;
            n2 = n4;
        }
        return n2;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    protected final void moveAtWar_AtSea_ToProvinceID(int n, int n2) {
        int n3;
        block27: {
            int n4;
            float f;
            int n5;
            Gdx.app.log("AoC", "moveAtWar -> BY SEA -> iBestProvinceID_MoveTo: " + n2 + ", NAME: " + CFG.game.getProvince(n2).getName());
            ArrayList<Boolean> arrayList = new ArrayList<Boolean>();
            for (n5 = 0; n5 < CFG.map.iNumOfBasins; ++n5) {
                arrayList.add(false);
            }
            for (n5 = 0; n5 < CFG.game.getProvince(n2).getNeighboringSeaProvincesSize(); ++n5) {
                arrayList.set(CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringSeaProvinces(n5)).getBasinID(), true);
            }
            n5 = -1;
            float f2 = -1.0f;
            Civilization civilization = CFG.game.getCiv(n);
            long l = civilization.getCivBuildArmyCost();
            if (civilization.getMoney() > l && CFG.game.getCiv((int)n).iBudget > 0) {
                civilization = CFG.game.getCiv(n);
                l = civilization.getCivBuildArmyCost();
                f = (float)(civilization.getMoney() / l) * 0.8f;
            } else {
                f = 0.0f;
            }
            int n6 = (int)f;
            int n7 = CFG.game.getCiv(n).getSeaAccess_Provinces_Size() - 1;
            block2: while (true) {
                if (n7 < 0) {
                    if (n5 < 0) {
                        Gdx.app.log("AoC", "moveAtWar -> BY SEA -> iBestProvinceID_MoveFrom: " + n5);
                        return;
                    }
                    Gdx.app.log("AoC", "moveAtWar -> BY SEA -> iBestProvinceID_MoveFrom: " + n5 + ", NAME: " + CFG.game.getProvince(n5).getName() + " PORT: " + CFG.game.getProvince(n5).getLevelOfPort());
                    n3 = n5;
                    if (CFG.game.getProvince(n5).getLevelOfPort() <= 0) {
                        break;
                    }
                    break block27;
                }
                n4 = 0;
                while (true) {
                    block29: {
                        block28: {
                            f = f2;
                            n3 = n5;
                            if (n4 >= CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n7)).getNeighboringSeaProvincesSize()) break block28;
                            if (!((Boolean)arrayList.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n7)).getNeighboringSeaProvinces(n4)).getBasinID())).booleanValue()) break block29;
                            f = f2;
                            n3 = n5;
                            if (!CFG.game.getCiv(n).getCivRegion(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n7)).getCivRegionID()).checkRegionBordersWithEnemy(n)) {
                                float f3 = this.moveAtWar_AtSea_FromProvinceID_Score(n, CFG.game.getCiv(n).getSeaAccess_Provinces().get(n7), n2, false, n6);
                                f = f2;
                                n3 = n5;
                                if (f3 > f2) {
                                    n3 = CFG.game.getCiv(n).getSeaAccess_Provinces().get(n7);
                                    f = f3;
                                }
                            }
                        }
                        --n7;
                        f2 = f;
                        n5 = n3;
                        continue block2;
                    }
                    ++n4;
                }
                break;
            }
            Gdx.app.log("AoC", "moveAtWar -> BY SEA -> TRY FIND NEIGHBORING PROVINCE WITH PORT");
            n6 = 0;
            n3 = 0;
            while (true) {
                block31: {
                    block30: {
                        n7 = n5;
                        n4 = n6;
                        if (n3 >= CFG.game.getProvince(n5).getNeighboringProvincesSize()) break block30;
                        if (CFG.game.getProvince(CFG.game.getProvince(n5).getNeighboringProvinces(n3)).getCivID() != n || CFG.game.getProvince(CFG.game.getProvince(n5).getNeighboringProvinces(n3)).getLevelOfPort() <= 0) break block31;
                        n7 = CFG.game.getProvince(n5).getNeighboringProvinces(n3);
                        n4 = 1;
                        Gdx.app.log("AoC", "moveAtWar -> BY SEA -> UPDATE 00: iBestProvinceID_MoveFrom: " + n7 + ", NAME: " + CFG.game.getProvince(n7).getName() + " PORT: " + CFG.game.getProvince(n7).getLevelOfPort());
                    }
                    n3 = n7;
                    if (n4 == 0) {
                        break;
                    }
                    break block27;
                }
                ++n3;
            }
            n5 = 0;
            block5: while (true) {
                n3 = n7;
                if (n5 >= CFG.game.getProvince(n7).getNeighboringProvincesSize()) break;
                n4 = n5;
                n3 = n7;
                boolean bl = true;
                while (true) {
                    block33: {
                        block32: {
                            if (!bl || (bl = false)) continue;
                            if (CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getCivID() != n) break block32;
                            n4 = n5;
                            n3 = n7;
                            if (CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getLevelOfPort() <= 0) break block32;
                            n6 = 0;
                            n4 = n5;
                            n3 = n7;
                            if (n6 >= CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getNeighboringProvincesSize()) break block32;
                            if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getNeighboringProvinces(n6)).getCivID() != n || CFG.game.getProvince(CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getNeighboringProvinces(n6)).getLevelOfPort() <= 0) break block33;
                            n3 = CFG.game.getProvince(CFG.game.getProvince(n7).getNeighboringProvinces(n5)).getNeighboringProvinces(n6);
                            n4 = CFG.game.getProvince(n3).getNeighboringProvincesSize();
                            Gdx.app.log("AoC", "moveAtWar -> BY SEA -> UPDATE 00: iBestProvinceID_MoveFrom: " + n3 + ", NAME: " + CFG.game.getProvince(n3).getName() + " PORT: " + CFG.game.getProvince(n3).getLevelOfPort());
                        }
                        n5 = n4 + 1;
                        n7 = n3;
                        continue block5;
                    }
                    ++n6;
                }
                break;
            }
        }
        CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_NavalInvasion(n, n3, n2));
        CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1).action(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final float moveAtWar_AtSea_ToProvinceID_Score(int n, int n2, boolean bl) {
        float f = 0.725f;
        float f2 = CFG.game.getProvince(n2).getPotential();
        float f3 = (float)(CFG.game.getProvince(n2).getPotentialRegion() * CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getCivRegion(CFG.game.getProvince(n2).getCivRegionID()).getProvincesSize()) / (float)CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces();
        float f4 = bl ? 1.625f : (CFG.game.getProvince(n2).isOccupied() ? 0.725f : 1.0f);
        if (!CFG.game.getProvince(n2).getIsCapital()) {
            f = 1.0f;
            return f4 * (f3 + f2) * f * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.WAR_ATTACK_NAVAL_DISTANCE * CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game_NextTurnUpdate.getAdministration_Capital(n), n2));
        }
        if (CFG.game.getProvince(n2).getCivID() != n) {
            return f4 * (f3 + f2) * f * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.WAR_ATTACK_NAVAL_DISTANCE * CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game_NextTurnUpdate.getAdministration_Capital(n), n2));
        }
        f = 1.45f;
        return f4 * (f3 + f2) * f * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.WAR_ATTACK_NAVAL_DISTANCE * CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game_NextTurnUpdate.getAdministration_Capital(n), n2));
    }

    protected final float moveAtWar_AttackTo_Score(int n, int n2) {
        return CFG.game.getProvince(n2).getPotentialModified_WAR_MoveTo(n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean moveAtWar_BordersWithEnemyCheck(int n, int n2) {
        int n3 = 0;
        while (n3 < CFG.game.getProvince(n2).getNeighboringProvincesSize()) {
            if (CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(n3)).getCivID())) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    protected final int moveAtWar_NumOfNotCoveredNeighEnemyProvinces(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(n2).getNeighboringProvincesSize(); ++i) {
            int n4 = n3;
            if (CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(n2).getNeighboringProvinces(i)).getCivID())) {
                n4 = n3;
                if (!CFG.game.getCiv(n).isMovingUnitsToProvinceID(CFG.game.getProvince(n2).getNeighboringProvinces(i))) {
                    n4 = n3 + 1;
                }
            }
            n3 = n4;
        }
        return n3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void moveAtWar_Recruit(int var1_1, List<AI_ProvinceInfo_War> var2_2, List<Integer> var3_3, boolean var4_4) {
        block39: {
            if (CFG.game.getCiv(var1_1).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_RECRUIT) {
                Gdx.app.log("AoC", "RECRUIT NO MOVEMNETS POINTS 0000");
                return;
            }
            if (var3_3.size() * CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE > CFG.game.getCiv(var1_1).getMovePoints()) {
                var5_5 = CFG.game.getCiv(var1_1);
                var6_6 = var5_5.getCivBuildArmyCost();
                if (Math.max((float)(var5_5.getMoney() / var6_6) / (float)CFG.game.getCiv(var1_1).getNumOfUnits(), 0.001f) < 1.0f && CFG.oR.nextInt(100) < 85) {
                    Gdx.app.log("AoC", "RECRUIT, IT IS NOT WORTH TO RECRUIT IN THIS TURN");
                    return;
                }
            }
            var8_7 = CFG.game.getCiv((int)var1_1).iBudget;
            var9_8 = var4_4 != false ? CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_NOT_BORDERING_WITH_ENEMY : (CFG.game.getCiv(var1_1).getBordersWithEnemy() == 0 && (var11_9 = CFG.DIFFICULTY) - 4 != 0 && var11_9 != 0 ? CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_NOT_BORDERING_WITH_ENEMY : CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_RECRUIT_AT_WAR);
            var10_10 = (int)((var9_8 - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).MIN_INVESTMENTS) * var8_7 - (float)CFG.game.getCiv((int)var1_1).iBudget * CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC);
            if (var10_10 < 0) {
                Gdx.app.log("AoC", "RECRUIT, nUpkeepLeft: " + var10_10);
                return;
            }
            if (var4_4 || CFG.game.getCiv(var1_1).getCapitalProvinceID() < 0 || CFG.game.getProvince(CFG.game.getCiv(var1_1).getCapitalProvinceID()).getCivID() != var1_1 || CFG.game.getProvince(CFG.game.getCiv(var1_1).getCapitalProvinceID()).getNeighboringSeaProvincesSize() <= 0 || CFG.game.getCiv(var1_1).getBordersWithEnemy() != 0) ** GOTO lbl28
            var12_11 = 0;
            var11_9 = var2_2.size() - 1;
            while (true) {
                block41: {
                    block40: {
                        var13_12 = var12_11;
                        if (var11_9 < 0) break block40;
                        if (((AI_ProvinceInfo_War)var2_2.get((int)var11_9)).iProvinceID != CFG.game.getCiv(var1_1).getCapitalProvinceID()) break block41;
                        var13_12 = 1;
                    }
                    if (var13_12 == 0) {
                        var2_2.add((AI_NeighProvinces)new AI_ProvinceInfo_War(CFG.game.getCiv(var1_1).getCapitalProvinceID(), this.getPotential_BasedOnNeighboringProvs(CFG.game.getCiv(var1_1).getCapitalProvinceID(), var1_1), true));
                    }
lbl28:
                    // 4 sources

                    var14_13 = (int)((float)var10_10 / (CFG.game_NextTurnUpdate.getMilitaryUpkeep_WithoutDefensivePosition(((AI_ProvinceInfo_War)var2_2.get((int)0)).iProvinceID, 1000, var1_1) / 1000.0f));
                    var13_12 = CFG.game.getCiv(var1_1).getMovePoints();
                    var11_9 = var3_3.size() > 0 ? CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE * var3_3.size() : CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE;
                    var13_12 = Math.max(1, Math.min((var13_12 - var11_9) / CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_RECRUIT, CFG.game.getCiv(var1_1).getNumOfProvinces()));
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> " + CFG.game.getCiv(var1_1).getCivName());
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> iNumOfMaxRecruitments: " + var13_12);
                    var11_9 = var13_12;
                    if (var3_3.size() > 1) {
                        var11_9 = var13_12;
                        if (var13_12 > 1) {
                            var3_3 = CFG.game.getCiv(var1_1);
                            var6_6 = var3_3.getCivBuildArmyCost();
                            var11_9 = var13_12;
                            if (Math.min(var3_3.getMoney() / var6_6, (long)var14_13) <= (long)((AI_ProvinceInfo_War)var2_2.get(0)).getRecruitableArmy(var1_1)) {
                                var3_3 = CFG.game.getCiv(var1_1);
                                var6_6 = var3_3.getCivBuildArmyCost();
                                var11_9 = var13_12;
                                if ((float)Math.min(var3_3.getMoney() / var6_6, (long)var14_13) < (float)CFG.game.getCiv(var1_1).getNumOfUnits() * 0.35f) {
                                    var11_9 = var13_12;
                                    if (CFG.oR.nextInt(100) < 95) {
                                        var11_9 = 1;
                                    }
                                }
                            }
                        }
                    }
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> iNumOfMaxRecruitments: " + var11_9);
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> numOfUnitsToRecruit_MAX: " + var14_13);
                    var3_3 = new ArrayList<E>();
                    var9_8 = 0.0f;
                    for (var13_12 = 0; var13_12 < var11_9 && var13_12 < var2_2.size(); var9_8 += ((AI_ProvinceInfo_War)var2_2.get((int)var13_12)).iValue, ++var13_12) {
                        var3_3.add(var2_2.get(var13_12));
                    }
                    break;
                }
                --var11_9;
            }
            var15_14 = (int)CFG.game.getCiv(var1_1).getMoney();
            var13_12 = 0;
            var10_10 = 0;
            block2: while (true) {
                if (var10_10 >= var3_3.size()) {
                    if (var13_12 == 0) return;
                    var2_2 = CFG.game.getCiv(var1_1);
                    var6_6 = var2_2.getCivBuildArmyCost();
                    if (var2_2.getMoney() >= var6_6) return;
                    CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ArmyFullyRecruitedLastTurn = true;
                    return;
                }
                var11_9 = CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(var1_1).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(var1_1).getCivBuildArmyCost();
                var8_7 = Math.min(var14_13, var15_14 / var11_9);
                var12_11 = (int)(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iValue * var8_7 / var9_8);
                var2_2 = Gdx.app;
                var16_15 = new StringBuilder().append("moveAtWar_Recruit -> RECRUIT MAX: ");
                var5_5 = CFG.game.getCiv(var1_1);
                var6_6 = var5_5.getCivBuildArmyCost();
                var2_2.log("AoC", var16_15.append(var5_5.getMoney() / var6_6).toString());
                Gdx.app.log("AoC", "moveAtWar_Recruit -> tArmyToRecruit_PRE: " + var12_11);
                var11_9 = 0;
                if (((AI_ProvinceInfo_War)var3_3.get(var10_10)).getRecruitableArmy(var1_1) < var12_11) {
                    var11_9 = 1;
                }
                if (CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getCivID() != var1_1 || var11_9 != 0) {
                    var2_2 = CFG.oAI.getAllNeighboringProvincesInRange_RecruitAtWAr(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var1_1, Math.max(10, CFG.game.getCiv(var1_1).getNumOfProvinces() / 8), true, false, new ArrayList<AI_NeighProvinces>(), new ArrayList<Integer>());
                    if (var2_2.size() > 0) {
                        Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000");
                        if (var11_9 != 0 || CFG.oR.nextInt(100) < 100) {
                            var12_11 = 0;
                            var17_16 = CFG.gameAction.getRecruitableArmy(var2_2.get((int)0).iProvinceID);
                            for (var11_9 = 1; var11_9 < var2_2.size(); ++var11_9) {
                                var18_17 = var17_16;
                                if (var17_16 < CFG.gameAction.getRecruitableArmy(var2_2.get((int)var11_9).iProvinceID)) {
                                    var12_11 = var11_9;
                                    var18_17 = CFG.gameAction.getRecruitableArmy(var2_2.get((int)var11_9).iProvinceID);
                                }
                                var17_16 = var18_17;
                            }
                        } else {
                            var12_11 = CFG.oR.nextInt(var2_2.size());
                        }
                        if ((float)CFG.gameAction.getRecruitableArmy(var2_2.get((int)var12_11).iProvinceID, var1_1) < (float)((AI_ProvinceInfo_War)var3_3.get(var10_10)).getRecruitableArmy(var1_1) * 1.2f) {
                            Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000A -> ARMY CAN'T BE RECRUITED FROM NEIGH PROVINCES -> SEND BY SEA!");
                            var11_9 = CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(var1_1).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(var1_1).getCivBuildArmyCost();
                            var8_7 = Math.min(var14_13, Math.min(var14_13, var15_14 / var11_9));
                            var12_11 = (int)(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iValue * var8_7 / var9_8);
                            Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000A -> TO RECR ARMY: " + var12_11 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var1_1));
                            var11_9 = var13_12;
                            if (CFG.game.getCiv(var1_1).recruitArmy_AI(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var12_11)) {
                                var11_9 = 1;
                            }
                        } else {
                            var11_9 = CFG.game.getProvince(var2_2.get((int)var12_11).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(var1_1).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(var1_1).getCivBuildArmyCost();
                            var8_7 = Math.min(var14_13, Math.min(var14_13, var15_14 / var11_9));
                            var11_9 = (int)(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iValue * var8_7 / var9_8);
                            Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 0000B -> TO RECR ARMY: " + var11_9 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(var2_2.get((int)var12_11).iProvinceID, var1_1));
                            if (CFG.game.getCiv(var1_1).recruitArmy_AI(var2_2.get((int)var12_11).iProvinceID, var11_9)) {
                                var13_12 = 1;
                            }
                            var17_16 = CFG.game.getCiv(var1_1).getRecruitArmy_BasedOnProvinceID(var2_2.get((int)var12_11).iProvinceID);
                            var11_9 = var13_12;
                            if (var17_16 > 0) {
                                CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_RegroupAfterRecruitment_War(var1_1, var2_2.get((int)var12_11).iProvinceID, ((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var17_16));
                                var11_9 = var13_12;
                            }
                        }
                    } else {
                        Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000 -> ARMY CAN'T BE RECRUITED FROM NEIGH PROVINCES -> SEND BY SEA!");
                        var11_9 = var13_12;
                        if (!var4_4) {
                            break;
                        }
                    }
                } else {
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 1111 -> PROV: " + ((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID + " -> " + CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getName());
                    var11_9 = CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(var1_1).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(var1_1).getCivBuildArmyCost();
                    var8_7 = Math.min(var14_13, Math.min(var14_13, var15_14 / var11_9));
                    var12_11 = (int)(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iValue * var8_7 / var9_8);
                    Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 1111 -> TO RECR ARMY: " + var12_11 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var1_1));
                    var11_9 = var13_12;
                    if (CFG.game.getCiv(var1_1).recruitArmy_AI(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID, var12_11)) {
                        var11_9 = 1;
                    }
                }
lbl136:
                // 8 sources

                while (true) {
                    ++var10_10;
                    var13_12 = var11_9;
                    continue block2;
                    break;
                }
                break;
            }
            var17_16 = 1;
            var11_9 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.size() - 1;
            while (true) {
                block43: {
                    block42: {
                        var12_11 = var17_16;
                        if (var11_9 < 0) break block42;
                        if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.get((int)var11_9).MISSION_TYPE != CivArmyMission_Type.NAVAL_INVASION || CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.get((int)var11_9).toProvinceID != ((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID) break block43;
                        var12_11 = 0;
                    }
                    var11_9 = var13_12;
                    if (var12_11 == 0) ** GOTO lbl136
                    var12_11 = var11_9 = ((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID;
                    if (CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringSeaProvincesSize() == 0) {
                        break;
                    }
                    break block39;
                }
                --var11_9;
            }
            var17_16 = 0;
            while (true) {
                block44: {
                    block45: {
                        var12_11 = var11_9;
                        if (var17_16 >= CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringSeaProvincesSize()) break;
                        var12_11 = var11_9;
                        if (CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringProvinces(var17_16)).getLevelOfPort() < 0) break block44;
                        if (CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringProvinces(var17_16)).getCivID() == var1_1) break block45;
                        var12_11 = var11_9;
                        if (!CFG.game.getCivsAtWar(var1_1, CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringProvinces(var17_16)).getCivID())) break block44;
                    }
                    var12_11 = CFG.game.getProvince(((AI_ProvinceInfo_War)var3_3.get((int)var10_10)).iProvinceID).getNeighboringProvinces(var17_16);
                }
                ++var17_16;
                var11_9 = var12_11;
            }
        }
        this.moveAtWar_AtSea_ToProvinceID(var1_1, var12_11);
        var11_9 = var13_12;
        ** while (true)
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void moveAtWar_RecruitPlayer(int n, List<AI_ProvinceInfo_War> object, List<Integer> arrayList, boolean bl) {
        int n2;
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT) {
            Gdx.app.log("AoC", "RECRUIT NO MOVEMNETS POINTS 0000");
            return;
        }
        if (arrayList.size() * CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE > CFG.game.getCiv(n).getMovePoints() && Math.max((float)(CFG.game.getCiv(n).getMoney() / 5L) / (float)CFG.game.getCiv(n).getNumOfUnits(), 0.0f) < 0.0f && CFG.oR.nextInt(100) < 85) {
            Gdx.app.log("AoC", "RECRUIT, IT IS NOT WORTH TO RECRUIT IN THIS TURN");
            return;
        }
        float f = CFG.game.getCiv((int)n).iBudget;
        float f2 = bl || CFG.game.getCiv(n).getBordersWithEnemy() == 0 ? CFG.game.getCiv((int)n).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_NOT_BORDERING_WITH_ENEMY : CFG.game.getCiv((int)n).civGameData.civPersonality.MIN_MILITARY_SPENDINGS_RECRUIT_AT_WAR;
        int n3 = (int)(f * (f2 - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(n).getIdeologyID()).getMin_Goods(n) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).MIN_INVESTMENTS) - (float)CFG.game.getCiv((int)n).iBudget * CFG.game.getCiv((int)n).iMilitaryUpkeep_PERC);
        if (n3 < 0) {
            object = Gdx.app;
            arrayList = new StringBuilder();
            ((StringBuilder)((Object)arrayList)).append("RECRUIT, nUpkeepLeft: ");
            ((StringBuilder)((Object)arrayList)).append(n3);
            object.log("AoC", ((StringBuilder)((Object)arrayList)).toString());
            return;
        }
        if (!bl && CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() == n && CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringSeaProvincesSize() > 0) {
            block32: {
                for (n2 = object.size() - 1; n2 >= 0; --n2) {
                    if (((AI_ProvinceInfo_War)object.get((int)n2)).iProvinceID != CFG.game.getCiv(n).getCapitalProvinceID()) continue;
                    n2 = 1;
                    break block32;
                }
                n2 = 0;
            }
            if (n2 == 0) {
                object.add(new AI_ProvinceInfo_War(CFG.game.getCiv(n).getCapitalProvinceID(), this.getPotential_BasedOnNeighboringProvs(CFG.game.getCiv(n).getCapitalProvinceID(), n), true));
            }
        }
        int n4 = (int)((float)n3 / (CFG.game_NextTurnUpdate.getMilitaryUpkeep_WithoutDefensivePosition(((AI_ProvinceInfo_War)object.get((int)0)).iProvinceID, 1000, n) / 1000.0f));
        n3 = CFG.game.getCiv(n).getMovePoints();
        n2 = arrayList.size() > 0 ? CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE * arrayList.size() : CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE;
        n3 = Math.max(1, Math.min((n3 - n2) / CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT, CFG.game.getCiv(n).getNumOfProvinces()));
        Object object2 = Gdx.app;
        Object object3 = new StringBuilder();
        ((StringBuilder)object3).append("moveAtWar_Recruit -> ");
        ((StringBuilder)object3).append(CFG.game.getCiv(n).getCivName());
        object2.log("AoC", ((StringBuilder)object3).toString());
        object3 = Gdx.app;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("moveAtWar_Recruit -> iNumOfMaxRecruitments: ");
        ((StringBuilder)object2).append(n3);
        object3.log("AoC", ((StringBuilder)object2).toString());
        n2 = n3;
        if (arrayList.size() > 1) {
            n2 = n3;
            if (n3 > 1) {
                long l = CFG.game.getCiv(n).getMoney() / 5L;
                long l2 = n4;
                n2 = n3;
                if (Math.min(l, l2) <= (long)((AI_ProvinceInfo_War)object.get(0)).getRecruitableArmyAutoplan(n)) {
                    n2 = n3;
                    if ((float)Math.min(CFG.game.getCiv(n).getMoney() / 5L, l2) < (float)CFG.game.getCiv(n).getNumOfUnits() * 0.35f) {
                        n2 = n3;
                        if (CFG.oR.nextInt(100) < 95) {
                            n2 = 1;
                        }
                    }
                }
            }
        }
        object2 = Gdx.app;
        arrayList = new StringBuilder();
        ((StringBuilder)((Object)arrayList)).append("moveAtWar_Recruit -> iNumOfMaxRecruitments: ");
        ((StringBuilder)((Object)arrayList)).append(n2);
        object2.log("AoC", ((StringBuilder)((Object)arrayList)).toString());
        arrayList = Gdx.app;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("moveAtWar_Recruit -> numOfUnitsToRecruit_MAX: ");
        ((StringBuilder)object2).append(n4);
        arrayList.log("AoC", ((StringBuilder)object2).toString());
        arrayList = new ArrayList();
        f2 = 0.0f;
        for (n3 = 0; n3 < n2 && n3 < object.size(); f2 += ((AI_ProvinceInfo_War)object.get((int)n3)).iValue, ++n3) {
            arrayList.add(object.get(n3));
        }
        n3 = (int)CFG.game.getCiv(n).getMoney();
        int n5 = 0;
        int n6 = 0;
        n2 = n4;
        n4 = n5;
        while (true) {
            block37: {
                int n7;
                block41: {
                    int n8;
                    int n9;
                    block33: {
                        block40: {
                            block34: {
                                block38: {
                                    int n10;
                                    block39: {
                                        block36: {
                                            block35: {
                                                if (n4 >= arrayList.size()) break block34;
                                                n7 = CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID).getLevelOfArmoury();
                                                n5 = 4;
                                                n7 = n7 > 0 ? 4 : 5;
                                                n7 = (int)((float)Math.min(n2, n3 / n7) * ((AI_ProvinceInfo_War)arrayList.get((int)n4)).iValue / f2);
                                                object = Gdx.app;
                                                object2 = new StringBuilder();
                                                ((StringBuilder)object2).append("moveAtWar_Recruit -> RECRUIT MAX: ");
                                                ((StringBuilder)object2).append(CFG.game.getCiv(n).getMoney() / 5L);
                                                object.log("AoC", ((StringBuilder)object2).toString());
                                                object2 = Gdx.app;
                                                object = new StringBuilder();
                                                ((StringBuilder)object).append("moveAtWar_Recruit -> tArmyToRecruit_PRE: ");
                                                ((StringBuilder)object).append(n7);
                                                object2.log("AoC", ((StringBuilder)object).toString());
                                                n7 = ((AI_ProvinceInfo_War)arrayList.get(n4)).getRecruitableArmyAutoplan(n) < n7 ? 1 : 0;
                                                if (CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID).isOccupied() || CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID).getCivID() != n || n7 != 0) break block35;
                                                object = Gdx.app;
                                                object2 = new StringBuilder();
                                                ((StringBuilder)object2).append("moveAtWar_Recruit -> RECRUIT MODE 1111 -> PROV: ");
                                                ((StringBuilder)object2).append(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID);
                                                ((StringBuilder)object2).append(" -> ");
                                                ((StringBuilder)object2).append(CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID).getName());
                                                object.log("AoC", ((StringBuilder)object2).toString());
                                                if (CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID).getLevelOfArmoury() <= 0) {
                                                    n5 = 5;
                                                }
                                                n5 = (int)((float)Math.min(n2, Math.min(n2, n3 / n5)) * ((AI_ProvinceInfo_War)arrayList.get((int)n4)).iValue / f2);
                                                object = Gdx.app;
                                                object2 = new StringBuilder();
                                                ((StringBuilder)object2).append("moveAtWar_Recruit -> RECRUIT MODE 1111 -> TO RECR ARMY: ");
                                                ((StringBuilder)object2).append(n5);
                                                ((StringBuilder)object2).append(", RECRITABLE MAX: ");
                                                ((StringBuilder)object2).append(CFG.gameAction.getRecruitableArmyAutoplan(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID, n));
                                                object.log("AoC", ((StringBuilder)object2).toString());
                                                if (CFG.game.getCiv(n).recruitArmyAutoplan_AI(((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID, n5)) break block36;
                                                n5 = n6;
                                                break block37;
                                            }
                                            object3 = CFG.oAI;
                                            int n11 = ((AI_ProvinceInfo_War)arrayList.get((int)n4)).iProvinceID;
                                            n9 = Math.max(10, CFG.game.getCiv(n).getNumOfProvinces() / 8);
                                            object2 = new ArrayList<AI_NeighProvinces>();
                                            object = new ArrayList<Integer>();
                                            n8 = n4;
                                            n10 = n3;
                                            if ((object = ((AI)object3).getAllNeighboringProvincesInRange_RecruitAtWAr(n11, n, n9, true, false, (List<AI_NeighProvinces>)object2, (List<Integer>)object)).size() <= 0) break block38;
                                            Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000");
                                            if (n7 == 0 && CFG.oR.nextInt(100) >= 90) {
                                                n7 = CFG.oR.nextInt(object.size());
                                            } else {
                                                n11 = CFG.gameAction.getRecruitableArmyAutoplan(((AI_NeighProvinces)object.get((int)0)).iProvinceID);
                                                n9 = 0;
                                                for (n7 = 1; n7 < object.size(); ++n7) {
                                                    int n12 = n11;
                                                    if (n11 < CFG.gameAction.getRecruitableArmyAutoplan(((AI_NeighProvinces)object.get((int)n7)).iProvinceID)) {
                                                        n12 = CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)object.get((int)n7)).iProvinceID);
                                                        n9 = n7;
                                                    }
                                                    n11 = n12;
                                                }
                                                n7 = n9;
                                            }
                                            if (!((float)CFG.gameAction.getRecruitableArmyAutoplan(((AI_NeighProvinces)object.get((int)n7)).iProvinceID, n) < (float)((AI_ProvinceInfo_War)arrayList.get(n8)).getRecruitableArmyAutoplan(n) * 1.2f)) break block39;
                                            Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000A -> ARMY CAN'T BE RECRUITED FROM NEIGH PROVINCES -> SEND BY SEA!");
                                            if (CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getLevelOfArmoury() <= 0) {
                                                n5 = 5;
                                            }
                                            n7 = n10 / n5;
                                            n5 = n2;
                                            n7 = (int)((float)Math.min(n5, Math.min(n5, n7)) * ((AI_ProvinceInfo_War)arrayList.get((int)n8)).iValue / f2);
                                            object = Gdx.app;
                                            object2 = new StringBuilder();
                                            ((StringBuilder)object2).append("moveAtWar_Recruit -> RECRUIT MODE 000A -> TO RECR ARMY: ");
                                            ((StringBuilder)object2).append(n7);
                                            ((StringBuilder)object2).append(", RECRITABLE MAX: ");
                                            ((StringBuilder)object2).append(CFG.gameAction.getRecruitableArmyAutoplan(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID, n));
                                            object.log("AoC", ((StringBuilder)object2).toString());
                                            n5 = n6;
                                            if (!CFG.game.getCiv(n).recruitArmyAutoplan_AI(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID, n7)) break block37;
                                        }
                                        n5 = 1;
                                        break block37;
                                    }
                                    n9 = n2;
                                    if (CFG.game.getProvince(((AI_NeighProvinces)object.get((int)n7)).iProvinceID).getLevelOfArmoury() <= 0) {
                                        n5 = 5;
                                    }
                                    n5 = (int)((float)Math.min(n9, Math.min(n9, n10 / n5)) * ((AI_ProvinceInfo_War)arrayList.get((int)n8)).iValue / f2);
                                    object2 = Gdx.app;
                                    object3 = new StringBuilder();
                                    ((StringBuilder)object3).append("moveAtWar_Recruit -> RECRUIT MODE 0000B -> TO RECR ARMY: ");
                                    ((StringBuilder)object3).append(n5);
                                    ((StringBuilder)object3).append(", RECRITABLE MAX: ");
                                    ((StringBuilder)object3).append(CFG.gameAction.getRecruitableArmyAutoplan(((AI_NeighProvinces)object.get((int)n7)).iProvinceID, n));
                                    object2.log("AoC", ((StringBuilder)object3).toString());
                                    if (CFG.game.getCiv(n).recruitArmyAutoplan_AI(((AI_NeighProvinces)object.get((int)n7)).iProvinceID, n5)) {
                                        n6 = 1;
                                    }
                                    n9 = CFG.game.getCiv(n).getRecruitArmy_BasedOnProvinceID(((AI_NeighProvinces)object.get((int)n7)).iProvinceID);
                                    n5 = n6;
                                    if (n9 > 0) {
                                        CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_RegroupAfterRecruitment_War(n, ((AI_NeighProvinces)object.get((int)n7)).iProvinceID, ((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID, n9));
                                        n5 = n6;
                                    }
                                    break block37;
                                }
                                Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 000 -> ARMY CAN'T BE RECRUITED FROM NEIGH PROVINCES -> SEND BY SEA!");
                                n5 = n6;
                                if (bl) break block37;
                                break block40;
                            }
                            if (n6 != 0 && CFG.game.getCiv(n).getMoney() < 25L) {
                                CFG.game.getCiv((int)n).civGameData.moveAtWar_ArmyFullyRecruitedLastTurn = true;
                            }
                            return;
                        }
                        for (n5 = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; n5 >= 0; --n5) {
                            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n5).MISSION_TYPE != CivArmyMission_Type.NAVAL_INVASION || CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n5).toProvinceID != ((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID) continue;
                            n7 = 0;
                            break block33;
                        }
                        n7 = 1;
                    }
                    n5 = n6;
                    if (n7 == 0) break block37;
                    n7 = n5 = ((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID;
                    if (CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringSeaProvincesSize() != 0) break block41;
                    for (n7 = 0; n7 < CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringSeaProvincesSize(); ++n7) {
                        block42: {
                            block43: {
                                n9 = n5;
                                if (CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringProvinces(n7)).getLevelOfPort() < 0) break block42;
                                if (CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringProvinces(n7)).getCivID() == n) break block43;
                                n9 = n5;
                                if (!CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringProvinces(n7)).getCivID())) break block42;
                            }
                            n9 = CFG.game.getProvince(((AI_ProvinceInfo_War)arrayList.get((int)n8)).iProvinceID).getNeighboringProvinces(n7);
                        }
                        n5 = n9;
                    }
                    n7 = n5;
                }
                this.moveAtWar_AtSea_ToProvinceID(n, n7);
                n5 = n6;
            }
            ++n4;
            n6 = n5;
        }
    }

    /*
     * Exception decompiling
     */
    protected final void moveAtWar_Regroup(int var1_1, List<AI_ProvinceInfo_War> var2_2, List<Integer> var3_5) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 17[FORLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean plunderProvince(int n, int n2) {
        if (CFG.game.getProvince(n2).isOccupied() && (float)CFG.game.getProvince(n2).getArmyCivID(n) < (float)CFG.game.getCiv(n).getNumOfUnits() * 0.025f && CFG.game.getCiv((int)n).civGameData.iPlunder_LastTurnID <= Game_Calendar.TURN_ID && (float)this.getRegroupArmy_NumOfUnits(n, n2) / DiplomacyManager.plunderEfficiency_RequiredMAX(n, n2) > 0.45f && CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_PLUNDER <= CFG.game.getCiv(n).getMovePoints()) {
            if (CFG.game.getCiv((int)n).civGameData.civPersonality.PLUNDER_CHANCE > (float)CFG.oR.nextInt(1000) / 1000.0f) {
                CFG.game.getCiv((int)n).civGameData.iPlunder_LastTurnID = CFG.oR.nextInt(25) < this.PERSONALITY_PLUNDER_LOCK ? Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(4) : Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(4);
            }
            return true;
        }
        return false;
    }

    protected final boolean plunderProvincePlayer(int n, int n2) {
        if (CFG.game.getProvince(n2).isOccupied() && (float)CFG.game.getProvince(n2).getArmyCivID(n) < (float)CFG.game.getCiv(n).getNumOfUnits() * 0.0f && CFG.game.getCiv((int)n).civGameData.iPlunder_LastTurnID <= Game_Calendar.TURN_ID && (float)this.getRegroupArmy_NumOfUnits(n, n2) / DiplomacyManager.plunderEfficiency_RequiredMAX(n, n2) > 0.0f && CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_PLUNDER <= CFG.game.getCiv(n).getMovePoints()) {
            if (CFG.game.getCiv((int)n).civGameData.civPersonality.PLUNDER_CHANCE > (float)CFG.oR.nextInt(1000) / 1000.0f) {
                CFG.game.getCiv((int)n).civGameData.iPlunder_LastTurnID = CFG.oR.nextInt(25) < this.PERSONALITY_PLUNDER_LOCK ? Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(4) : Game_Calendar.TURN_ID + 2 + CFG.oR.nextInt(4);
            }
            return true;
        }
        return false;
    }

    protected final void prepareArmyForRevolution(int n) {
    }

    protected final void prepareForWar(int n, float f) {
        if (CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize > 0) {
            int n2;
            int n3;
            List<Object> list;
            int n4;
            ArrayList<Object> arrayList = new ArrayList<Object>();
            block0: for (n4 = 0; n4 < (list = CFG.oAI.lFrontLines).get(n3 = n - 1).size(); ++n4) {
                for (n2 = 0; n2 < CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize; ++n2) {
                    if (CFG.oAI.lFrontLines.get((int)n3).get((int)n4).iWithCivID != CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)n2).onCivID) continue;
                    arrayList.add(n4);
                    continue block0;
                }
            }
            if (arrayList.size() > 0) {
                int n5;
                int n6;
                list = new ArrayList<List<AI_Frontline>>();
                ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
                for (n4 = 0; n4 < CFG.game.getCiv((int)n).civGameData.civPlans.iWarPreparationsSize; ++n4) {
                    arrayList2.add(CFG.game.getCiv((int)n).civGameData.civPlans.warPreparations.get((int)n4).onCivID);
                }
                for (n4 = 0; n4 < arrayList.size(); ++n4) {
                    n6 = CFG.oAI.lFrontLines.get((int)n3).get((int)((Integer)arrayList.get((int)n4)).intValue()).lProvinces.size();
                    for (n2 = 0; n2 < n6; ++n2) {
                        block20: {
                            for (n5 = 0; n5 < list.size(); ++n5) {
                                if (((AI_ProvinceInfo)list.get((int)n5)).iProvinceID != CFG.oAI.lFrontLines.get((int)n3).get((int)((Integer)arrayList.get((int)n4)).intValue()).lProvinces.get(n2)) continue;
                                n5 = 1;
                                break block20;
                            }
                            n5 = 0;
                        }
                        if (n5 != 0) continue;
                        list.add((List<AI_Frontline>)((Object)new AI_ProvinceInfo(CFG.oAI.lFrontLines.get((int)n3).get((int)((Integer)arrayList.get((int)n4)).intValue()).lProvinces.get(n2), this.getPotential_BasedOnNeighboringProvs((int)CFG.oAI.lFrontLines.get((int)n3).get((int)((Integer)arrayList.get((int)n4)).intValue()).lProvinces.get(n2), n, arrayList2), CFG.gameAction.getRecruitableArmy(CFG.oAI.lFrontLines.get((int)n3).get((int)((Integer)arrayList.get((int)n4)).intValue()).lProvinces.get(n2)))));
                    }
                }
                arrayList2.clear();
                if (list.size() > 0) {
                    arrayList = new ArrayList();
                    int n7 = list.size();
                    float f2 = 1.0f;
                    n2 = 1;
                    n4 = 1;
                    n3 = 0;
                    for (n6 = 0; n6 < n7; ++n6) {
                        f = f2;
                        if (((AI_ProvinceInfo)list.get((int)n6)).iValue > f2) {
                            f = ((AI_ProvinceInfo)list.get((int)n6)).iValue;
                        }
                        n5 = n2;
                        if (CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n6)).iProvinceID).getDangerLevel() > n2) {
                            n5 = CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n6)).iProvinceID).getDangerLevel();
                        }
                        int n8 = n3 + this.getMovingArmyToProvinceID(n, ((AI_ProvinceInfo)list.get((int)n6)).iProvinceID);
                        arrayList.add(n8);
                        n3 = n4;
                        if (CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n6)).iProvinceID).getArmy(0) + n8 > n4) {
                            n3 = CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n6)).iProvinceID).getArmy(0) + n8;
                        }
                        f2 = f;
                        n2 = n5;
                        n4 = n3;
                        n3 = n8;
                    }
                    n3 = list.size();
                    for (n5 = 0; n5 < n3; ++n5) {
                        ((AI_ProvinceInfo)list.get((int)n5)).iValue = CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_POTENTIAL * (((AI_ProvinceInfo)list.get((int)n5)).iValue / f2) + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_DANGER * ((float)CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n5)).iProvinceID).getDangerLevel() / (float)n2) * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_NUM_OF_UNITS + CFG.game.getCiv((int)n).civGameData.civPersonality.VALUABLE_NUM_OF_UNITS * (1.0f - (float)(CFG.game.getProvince(((AI_ProvinceInfo)list.get((int)n5)).iProvinceID).getArmy(0) + (Integer)arrayList.get(n5)) / (float)n4));
                    }
                    arrayList = new ArrayList();
                    while (list.size() > 0) {
                        n3 = list.size();
                        n2 = 0;
                        for (n4 = 1; n4 < n3; ++n4) {
                            n5 = n2;
                            if (((AI_ProvinceInfo)list.get((int)n2)).iValue < ((AI_ProvinceInfo)list.get((int)n4)).iValue) {
                                n5 = n4;
                            }
                            n2 = n5;
                        }
                        arrayList.add(list.get(n2));
                        list.remove(n2);
                    }
                    list = new ArrayList<List<AI_Frontline>>();
                    for (n4 = 0; n4 < CFG.game.getCiv((int)n).iArmiesPositionSize; ++n4) {
                        if (CFG.game.getCiv((int)n).civGameData.civPlans.haveMission(CFG.game.getCiv((int)n).lArmiesPosition.get(n4))) continue;
                        list.add((List<AI_Frontline>)((Object)CFG.game.getCiv((int)n).lArmiesPosition.get(n4)));
                    }
                    list = CFG.oAI.getAllNeighboringProvincesInRange_Recruit(((AI_ProvinceInfo)arrayList.get((int)0)).iProvinceID, n, 3, true, false, new ArrayList<AI_NeighProvinces>(), new ArrayList<Integer>());
                    if (list.size() > 0) {
                        n2 = CFG.oR.nextInt(list.size());
                        CFG.game.getCiv(n).recruitArmyAutoplan_AI(((AI_NeighProvinces)list.get((int)n2)).iProvinceID, CFG.gameAction.getRecruitableArmy(((AI_NeighProvinces)list.get((int)n2)).iProvinceID));
                        n4 = CFG.game.getCiv(n).getRecruitArmy_BasedOnProvinceID(((AI_NeighProvinces)list.get((int)n2)).iProvinceID);
                        if (n4 > 0) {
                            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_RegroupAfterRecruitment(n, ((AI_NeighProvinces)list.get((int)n2)).iProvinceID, ((AI_ProvinceInfo)arrayList.get((int)0)).iProvinceID, n4));
                        }
                    }
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void prepareForWar2(int var1_1) {
        block97: {
            block98: {
                block96: {
                    block95: {
                        block90: {
                            block87: {
                                Gdx.app.log("AoC", "moveAtWar -> " + CFG.game.getCiv(var1_1).getCivName());
                                if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize == 0) {
                                    return;
                                }
                                var2_2 = new ArrayList();
                                new ArrayList<E>();
                                block45: for (var3_5 = CFG.oAI.lFrontLines.get(var1_1 - 1).size() - 1; var3_5 >= 0; --var3_5) {
                                    var4_6 = 0;
                                    while (true) {
                                        block83: {
                                            if (var4_6 >= CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize) continue block45;
                                            if (CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var3_5).iWithCivID != CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var4_6).onCivID) break block83;
                                            block47: for (var5_7 = CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var3_5).lProvinces.size() - 1; var5_7 >= 0; --var5_7) {
                                                var6_8 = 1;
                                                var7_9 = var2_2.size() - 1;
                                                while (true) {
                                                    block84: {
                                                        var8_10 = var6_8;
                                                        if (var7_9 >= 0) {
                                                            if (((AI_ProvinceInfo_War)var2_2.get((int)var7_9)).iProvinceID != CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var3_5).lProvinces.get(var5_7)) break block84;
                                                            var8_10 = 0;
                                                        }
                                                        if (var8_10 == 0) continue block47;
                                                        var9_11 = new AI_ProvinceInfo_War(CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var3_5).lProvinces.get(var5_7), this.getPotential_BasedOnNeighboringProvs(CFG.oAI.lFrontLines.get((int)(var1_1 - 1)).get((int)var3_5).lProvinces.get(var5_7), var1_1), true);
                                                        var2_2.add(var9_11);
                                                        continue block47;
                                                    }
                                                    --var7_9;
                                                }
                                            }
                                        }
                                        ++var4_6;
                                    }
                                }
                                var3_5 = 0;
                                while (true) {
                                    if (var3_5 >= CFG.game.getCiv((int)var1_1).civGameData.iVassalsSize) break;
                                    block50: for (var4_6 = CFG.oAI.lFrontLines.get(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1).size() - 1; var4_6 >= 0; --var4_6) {
                                        var5_7 = 0;
                                        while (true) {
                                            block85: {
                                                if (var5_7 >= CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize) continue block50;
                                                if (CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1)).get((int)var4_6).iWithCivID != CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var5_7).onCivID) break block85;
                                                block52: for (var7_9 = CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1)).get((int)var4_6).lProvinces.size() - 1; var7_9 >= 0; --var7_9) {
                                                    var10_12 = 1;
                                                    var6_8 = var2_2.size() - 1;
                                                    while (true) {
                                                        block86: {
                                                            var8_10 = var10_12;
                                                            if (var6_8 >= 0) {
                                                                if (((AI_ProvinceInfo_War)var2_2.get((int)var6_8)).iProvinceID != CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1)).get((int)var4_6).lProvinces.get(var7_9)) break block86;
                                                                var8_10 = 0;
                                                            }
                                                            if (var8_10 == 0) continue block52;
                                                            var9_11 = new AI_ProvinceInfo_War(CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1)).get((int)var4_6).lProvinces.get(var7_9), this.getPotential_BasedOnNeighboringProvs(CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID - 1)).get((int)var4_6).lProvinces.get(var7_9), CFG.game.getCiv((int)var1_1).civGameData.lVassals.get((int)var3_5).iCivID), false);
                                                            var2_2.add(var9_11);
                                                            continue block52;
                                                        }
                                                        --var6_8;
                                                    }
                                                }
                                            }
                                            ++var5_7;
                                        }
                                    }
                                    ++var3_5;
                                }
                                if (CFG.game.getCiv(var1_1).getPuppetOfCivID() == var1_1) break block87;
                                block54: for (var3_5 = CFG.oAI.lFrontLines.get(CFG.game.getCiv(var1_1).getPuppetOfCivID() - 1).size() - 1; var3_5 >= 0; --var3_5) {
                                    var4_6 = 0;
                                    while (true) {
                                        block88: {
                                            if (var4_6 >= CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize) continue block54;
                                            if (CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).getPuppetOfCivID() - 1)).get((int)var3_5).iWithCivID != CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var4_6).onCivID) break block88;
                                            block56: for (var5_7 = CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).getPuppetOfCivID() - 1)).get((int)var3_5).lProvinces.size() - 1; var5_7 >= 0; --var5_7) {
                                                var6_8 = 1;
                                                var8_10 = var2_2.size() - 1;
                                                while (true) {
                                                    block89: {
                                                        var7_9 = var6_8;
                                                        if (var8_10 >= 0) {
                                                            if (((AI_ProvinceInfo_War)var2_2.get((int)var8_10)).iProvinceID != CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).getPuppetOfCivID() - 1)).get((int)var3_5).lProvinces.get(var5_7)) break block89;
                                                            var7_9 = 0;
                                                        }
                                                        if (var7_9 == 0) continue block56;
                                                        var9_11 = new AI_ProvinceInfo_War(CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).getPuppetOfCivID() - 1)).get((int)var3_5).lProvinces.get(var5_7), this.getPotential_BasedOnNeighboringProvs(CFG.oAI.lFrontLines.get((int)(CFG.game.getCiv((int)var1_1).getPuppetOfCivID() - 1)).get((int)var3_5).lProvinces.get(var5_7), CFG.game.getCiv(var1_1).getPuppetOfCivID()), false);
                                                        var2_2.add(var9_11);
                                                        continue block56;
                                                    }
                                                    --var8_10;
                                                }
                                            }
                                        }
                                        ++var4_6;
                                    }
                                }
                            }
                            if (CFG.game.getCiv(var1_1).getAllianceID() <= 0) break block90;
                            var3_5 = 0;
                            while (true) {
                                block91: {
                                    if (var3_5 >= CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilizationsSize()) break;
                                    if (CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var3_5) == var1_1) break block91;
                                    block59: for (var4_6 = CFG.oAI.lFrontLines.get(CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var3_5) - 1).size() - 1; var4_6 >= 0; --var4_6) {
                                        var5_7 = 0;
                                        while (true) {
                                            block92: {
                                                if (var5_7 >= CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize) continue block59;
                                                if (CFG.oAI.lFrontLines.get((int)(CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var3_5) - 1)).get((int)var4_6).iWithCivID != CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var5_7).onCivID) break block92;
                                                block61: for (var7_9 = CFG.oAI.lFrontLines.get((int)(CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var3_5) - 1)).get((int)var4_6).lProvinces.size() - 1; var7_9 >= 0; --var7_9) {
                                                    var10_12 = 1;
                                                    var6_8 = var2_2.size() - 1;
                                                    while (true) {
                                                        block93: {
                                                            var8_10 = var10_12;
                                                            if (var6_8 >= 0) {
                                                                if (((AI_ProvinceInfo_War)var2_2.get((int)var6_8)).iProvinceID != CFG.oAI.lFrontLines.get((int)(CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var3_5) - 1)).get((int)var4_6).lProvinces.get(var7_9)) break block93;
                                                                var8_10 = 0;
                                                            }
                                                            if (var8_10 == 0) continue block61;
                                                            var9_11 = new AI_ProvinceInfo_War(CFG.oAI.lFrontLines.get((int)(CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var3_5) - 1)).get((int)var4_6).lProvinces.get(var7_9), this.getPotential_BasedOnNeighboringProvs(CFG.oAI.lFrontLines.get((int)(CFG.game.getAlliance((int)CFG.game.getCiv((int)var1_1).getAllianceID()).getCivilization((int)var3_5) - 1)).get((int)var4_6).lProvinces.get(var7_9), CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getCivilization(var3_5)), false);
                                                            var2_2.add(var9_11);
                                                            continue block61;
                                                        }
                                                        --var6_8;
                                                    }
                                                }
                                            }
                                            ++var5_7;
                                        }
                                    }
                                }
                                ++var3_5;
                            }
                        }
                        var9_11 = Gdx.app;
                        var11_13 = new StringBuilder();
                        var9_11.log("AoC", var11_13.append("prepareForWar2 -> tempFrontProvinces.size: ").append(var2_2.size()).toString());
                        if (var2_2.size() <= 0) ** GOTO lbl261
                        var4_6 = 1;
                        var12_14 = 1.0f;
                        var11_13 = new ArrayList();
                        var3_5 = 1;
                        var13_15 = 1.0f;
                        var14_16 = 1.0f;
                        var9_11 = new ArrayList();
                        var7_9 = 0;
                        for (var5_7 = var2_2.size() - 1; var5_7 >= 0; --var5_7) {
                            var15_17 = var12_14;
                            if (((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iValue > var12_14) {
                                var15_17 = ((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iValue;
                            }
                            var8_10 = var4_6;
                            if (CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getDangerLevel_WithArmy() > var4_6) {
                                var8_10 = CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getDangerLevel_WithArmy();
                            }
                            var16_18 = var13_15;
                            if ((float)CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getRegion_NumOfProvinces() > var13_15) {
                                var16_18 = CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getRegion_NumOfProvinces();
                            }
                            var17_19 = var14_16;
                            if ((float)CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getPotentialRegion() > var14_16) {
                                var17_19 = CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getPotentialRegion();
                            }
                            var11_13.add(var7_9 += this.getMovingArmyToProvinceID(var1_1, ((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID));
                            var4_6 = var3_5;
                            if (CFG.game.getProvinceArmy(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID) + var7_9 > var3_5) {
                                var4_6 = CFG.game.getProvinceArmy(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID) + var7_9;
                            }
                            var3_5 = var4_6;
                            var4_6 = var8_10;
                            var12_14 = var15_17;
                            var13_15 = var16_18;
                            var14_16 = var17_19;
                            continue;
                        }
                        ** try [egrp 29[TRYBLOCK] [62, 63 : 2513->2523)] { 
lbl185:
                        // 2 sources

                        for (var5_7 = var2_2.size() - 1; var5_7 >= 0; --var5_7) {
                            var18_20 = (AI_ProvinceInfo_War)var2_2.get(var5_7);
                            var19_21 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_POTENTIAL;
                            var15_17 = ((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iValue / var12_14;
                            var16_18 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_DANGER;
                            var20_22 = (float)CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getDangerLevel_WithArmy() / (float)var4_6;
                            var21_23 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_NUM_OF_UNITS;
                            var22_24 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_NUM_OF_UNITS;
                            var7_9 = CFG.game.getProvinceArmy(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID);
                            var17_19 = (float)((Integer)var11_13.get(var5_7) + var7_9) / (float)var3_5;
                            var23_25 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_REGION_NUM_OF_PROVINCES;
                            var24_26 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_REGION_NUM_OF_PROVINCES;
                            var24_26 = (float)CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getRegion_NumOfProvinces() * var24_26 / var13_15;
                            var25_27 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_REGION_POTENTIAL;
                            var26_28 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.WAR_REGION_POTENTIAL;
                            var18_20.iValue = (float)CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var5_7)).iProvinceID).getPotentialRegion() * var26_28 / var14_16 + (var24_26 + (1.0f - var23_25) - var25_27) + (var19_21 * var15_17 + var20_22 * var16_18 + ((1.0f - var17_19) * var22_24 + (1.0f - var21_23)));
                            continue;
                        }
                        var11_13 = new ArrayList();
                        var5_7 = 0;
                        while (true) {
                            if (var2_2.size() <= 0) break;
                            var7_9 = 0;
                            var8_10 = var2_2.size();
                            block66: for (var3_5 = 1; var3_5 < var8_10; ++var3_5) {
                                block94: {
                                    if (!(((AI_ProvinceInfo_War)var2_2.get((int)var7_9)).iValue < ((AI_ProvinceInfo_War)var2_2.get((int)var3_5)).iValue)) break block94;
                                    var4_6 = var3_5;
lbl216:
                                    // 4 sources

                                    while (true) {
                                        var7_9 = var4_6;
                                        continue block66;
                                        break;
                                    }
                                }
                                var4_6 = var7_9;
                                if (((AI_ProvinceInfo_War)var2_2.get((int)var7_9)).iValue != ((AI_ProvinceInfo_War)var2_2.get((int)var3_5)).iValue) ** GOTO lbl216
                                var4_6 = var7_9;
                                if (CFG.oR.nextInt(100) >= 50) ** GOTO lbl216
                                var4_6 = var3_5;
                                ** continue;
                            }
                            if (CFG.game.getProvince(((AI_ProvinceInfo_War)var2_2.get((int)var7_9)).iProvinceID).getArmyCivID(var1_1) > 0) {
                                var9_11.add(var5_7);
                            }
                            var11_13.add(var2_2.get(var7_9));
                            var2_2.remove(var7_9);
                            ++var5_7;
                            continue;
                            break;
                        }
                        this.prepareForWar_Regroup(var1_1, (List<AI_ProvinceInfo_War>)var11_13, (List<Integer>)var9_11);
                        var18_20 = Gdx.app;
                        var2_2 = new StringBuilder();
                        var18_20.log("AoC", var2_2.append("prepareForWar2 -> BEFORE RECRUIT MP: ").append((float)CFG.game.getCiv(var1_1).getMovePoints() / 10.0f).toString());
                        var2_2 = CFG.game.getCiv(var1_1);
                        var27_29 = var2_2.getCivBuildArmyCost();
                        if (var2_2.getMoney() <= var27_29 || CFG.game.getCiv((int)var1_1).iBudget <= 0) ** GOTO lbl261
                        if (!((float)var9_11.size() * 1.75f * (float)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE <= (float)(CFG.game.getCiv(var1_1).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_RECRUIT))) break block95;
                        var3_5 = 1;
lbl248:
                        // 2 sources

                        while (true) {
                            if (var3_5 != 0) ** GOTO lbl-1000
                            var2_2 = CFG.game.getCiv(var1_1);
                            var27_29 = var2_2.getCivBuildArmyCost();
                            var13_15 = var2_2.getMoney() / var27_29;
                            if (CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ProvincesLostAndConquered_LastTurn >= 0) break block96;
                            var14_16 = 0.16f + 0.03f * (float)CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ProvincesLostAndConquered_LastTurn;
lbl256:
                            // 3 sources

                            while (var14_16 * var13_15 > (float)CFG.game.getCiv(var1_1).getNumOfUnits() || CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ProvincesLostAndConquered_LastTurn < -3 || CFG.game.getCiv(var1_1).getNumOfProvinces() < 3) lbl-1000:
                            // 2 sources

                            {
                                Gdx.app.log("AoC", "prepareForWar2 -> BEFORE RECRUIT 000: true");
                                this.prepareForWar_Recruit(var1_1, (List<AI_ProvinceInfo_War>)var11_13, (List<Integer>)var9_11, false);
lbl259:
                                // 2 sources

                                while (true) {
                                    CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ArmyFullyRecruitedLastTurn = false;
lbl261:
                                    // 3 sources

                                    this.moveAtWar_AtSea(var1_1);
                                    break;
                                }
                            }
                            break block97;
lbl-1000:
                            // 3 sources

                            {
                                while (true) {
                                    Gdx.app.log("AoC", "prepareForWar2 -> END, movementPoints:" + (float)CFG.game.getCiv(var1_1).getMovePoints() / 10.0f);
                                    return;
                                }
                                break;
                            }
                            break;
                        }
                    }
                    var3_5 = 0;
                    ** while (true)
                }
                if (!CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ArmyFullyRecruitedLastTurn) break block98;
                var14_16 = 0.6f;
                ** GOTO lbl256
            }
            var14_16 = 0.75f;
            ** GOTO lbl256
        }
        try {
            Gdx.app.log("AoC", "prepareForWar2 -> BEFORE RECRUIT 000: false");
            ** continue;
        }
lbl282:
        // 42 sources

        catch (IndexOutOfBoundsException var2_3) {
            Gdx.app.log("AoC", "prepareForWar2 -> ERRRORR");
            CFG.exceptionStack(var2_3);
            ** GOTO lbl-1000
        }
lbl286:
        // 42 sources

        catch (ArithmeticException var2_4) {
            Gdx.app.log("AoC", "prepareForWar2 -> ERRRORR");
            CFG.exceptionStack(var2_4);
            ** continue;
        }
    }

    protected final void prepareForWar_MoveReadyArmies(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_TYPE != CivArmyMission_Type.PREAPARE_FOR_WAR) continue;
            int n2 = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_ID < 0 ? 0 : this.getPrepareForWar_TurnsLeft(n, CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_ID);
            if (n2 < 0) {
                CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(i);
                continue;
            }
            if (!CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).canMakeAction(n, n2) || !CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).action(n)) continue;
            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(i);
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    protected final void prepareForWar_Recruit(int n, List<AI_ProvinceInfo_War> list, List<Integer> object, boolean bl) {
        float f;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        long l;
        Object object2;
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT) {
            Gdx.app.log("AoC", "RECRUIT NO MOVEMNETS POINTS 0000");
            return;
        }
        if (object.size() * CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE > CFG.game.getCiv(n).getMovePoints()) {
            object2 = CFG.game.getCiv(n);
            l = ((Civilization)object2).getCivBuildArmyCost();
            if (Math.max((float)(((Civilization)object2).getMoney() / l) / (float)CFG.game.getCiv(n).getNumOfUnits(), 0.001f) < 0.048f && CFG.oR.nextInt(100) < 85) {
                Gdx.app.log("AoC", "RECRUIT, IT IS NOT WORTH TO RECRUIT IN THIS TURN");
                return;
            }
        }
        if ((n6 = (int)((float)CFG.game.getCiv((int)n).iBudget * (0.8f - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(n).getIdeologyID()).getMin_Goods(n) - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).MIN_INVESTMENTS) - (float)CFG.game.getCiv((int)n).iBudget * CFG.game.getCiv((int)n).iMilitaryUpkeep_PERC)) < 0) {
            Gdx.app.log("AoC", "RECRUIT, nUpkeepLeft: " + n6);
            return;
        }
        boolean bl2 = true;
        while (true) {
            block31: {
                block29: {
                    block30: {
                        if (!bl2 || (bl2 = false)) continue;
                        if (bl || CFG.game.getCiv(n).getCapitalProvinceID() < 0 || CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() != n || CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getNeighboringSeaProvincesSize() <= 0) break block29;
                        n5 = 0;
                        n4 = list.size() - 1;
                        n3 = n5;
                        if (n4 < 0) break block30;
                        if (((AI_ProvinceInfo_War)list.get((int)n4)).iProvinceID != CFG.game.getCiv(n).getCapitalProvinceID()) break block31;
                        n3 = 1;
                    }
                    if (n3 == 0) {
                        list.add((AI_NeighProvinces)((Object)new AI_ProvinceInfo_War(CFG.game.getCiv(n).getCapitalProvinceID(), this.getPotential_BasedOnNeighboringProvs(CFG.game.getCiv(n).getCapitalProvinceID(), n), true)));
                    }
                }
                n2 = (int)((float)n6 / (CFG.game_NextTurnUpdate.getMilitaryUpkeep_WithoutDefensivePosition(((AI_ProvinceInfo_War)list.get((int)0)).iProvinceID, 1000, n) / 1000.0f));
                n4 = CFG.game.getCiv(n).getMovePoints();
                n3 = object.size() > 0 ? CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE * object.size() : CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE;
                n4 = Math.max(1, Math.min((n4 - n3) / CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT, CFG.game.getCiv(n).getNumOfProvinces()));
                Gdx.app.log("AoC", "prepareForWar_Recruit -> " + CFG.game.getCiv(n).getCivName());
                Gdx.app.log("AoC", "prepareForWar_Recruit -> iNumOfMaxRecruitments: " + n4);
                n3 = n4;
                if (object.size() > 1) {
                    n3 = n4;
                    if (n4 > 1) {
                        object = CFG.game.getCiv(n);
                        l = ((Civilization)object).getCivBuildArmyCost();
                        n3 = n4;
                        if (Math.min(((Civilization)object).getMoney() / 5L, (long)n2) <= (long)((AI_ProvinceInfo_War)((Object)list.get(0))).getRecruitableArmy(n)) {
                            object = CFG.game.getCiv(n);
                            l = ((Civilization)object).getCivBuildArmyCost();
                            n3 = n4;
                            if ((float)Math.min(((Civilization)object).getMoney() / l, (long)n2) < (float)CFG.game.getCiv(n).getNumOfUnits() * 0.35f) {
                                n3 = n4;
                                if (CFG.oR.nextInt(100) < 95) {
                                    n3 = 1;
                                }
                            }
                        }
                    }
                }
                Gdx.app.log("AoC", "prepareForWar_Recruit -> iNumOfMaxRecruitments: " + n3);
                Gdx.app.log("AoC", "prepareForWar_Recruit -> numOfUnitsToRecruit_MAX: " + n2);
                object = new ArrayList();
                f = 0.0f;
                for (n4 = 0; n4 < n3 && n4 < list.size(); f += ((AI_ProvinceInfo_War)list.get((int)n4)).iValue, ++n4) {
                    object.add(list.get(n4));
                }
                break;
            }
            --n4;
        }
        int n7 = (int)CFG.game.getCiv(n).getMoney();
        n4 = 0;
        n6 = 0;
        while (true) {
            if (n6 >= object.size()) {
                if (n4 == 0) return;
                if (CFG.game.getCiv(n).getMoney() >= 25L) return;
                CFG.game.getCiv((int)n).civGameData.moveAtWar_ArmyFullyRecruitedLastTurn = true;
                return;
            }
            n3 = CFG.game.getProvince(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(n).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(n).getCivBuildArmyCost();
            float f2 = Math.min(n2, n7 / n3);
            n3 = (int)(((AI_ProvinceInfo_War)object.get((int)n6)).iValue * f2 / f);
            Application application = Gdx.app;
            object2 = new StringBuilder().append("prepareForWar_Recruit -> RECRUIT MAX: ");
            list = CFG.game.getCiv(n);
            l = ((Civilization)((Object)list)).getCivBuildArmyCost();
            application.log("AoC", ((StringBuilder)object2).append(((Civilization)((Object)list)).getMoney() / l).toString());
            Gdx.app.log("AoC", "prepareForWar_Recruit -> tArmyToRecruit_PRE: " + n3);
            n5 = 0;
            if (((AI_ProvinceInfo_War)object.get(n6)).getRecruitableArmy(n) < n3) {
                n5 = 1;
            }
            if (CFG.game.getProvince(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID).getCivID() != n || n5 != 0) {
                list = CFG.oAI.getAllNeighboringProvincesInRange_RecruitAtWAr(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n, Math.max(10, CFG.game.getCiv(n).getNumOfProvinces() / 8), true, false, new ArrayList<AI_NeighProvinces>(), new ArrayList<Integer>());
                n3 = n4;
                if (list.size() > 0) {
                    int n8;
                    Gdx.app.log("AoC", "prepareForWar_Recruit -> RECRUIT MODE 000");
                    if (n5 != 0 || CFG.oR.nextInt(100) < 90) {
                        n5 = 0;
                        int n9 = CFG.gameAction.getRecruitableArmy(list.get((int)0).iProvinceID);
                        for (n3 = 1; n3 < list.size(); ++n3) {
                            n8 = n9;
                            if (n9 < CFG.gameAction.getRecruitableArmy(list.get((int)n3).iProvinceID)) {
                                n5 = n3;
                                n8 = CFG.gameAction.getRecruitableArmy(list.get((int)n3).iProvinceID);
                            }
                            n9 = n8;
                        }
                    } else {
                        n5 = CFG.oR.nextInt(list.size());
                    }
                    if ((float)CFG.gameAction.getRecruitableArmy(list.get((int)n5).iProvinceID, n) < (float)((AI_ProvinceInfo_War)object.get(n6)).getRecruitableArmy(n) * 1.2f) {
                        Gdx.app.log("AoC", "prepareForWar_Recruit -> RECRUIT MODE 000A -> ARMY CAN'T BE RECRUITED FROM NEIGH PROVINCES -> SEND BY SEA!");
                        n3 = CFG.game.getProvince(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(n).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(n).getCivBuildArmyCost();
                        f2 = Math.min(n2, Math.min(n2, n7 / n3));
                        n5 = (int)(((AI_ProvinceInfo_War)object.get((int)n6)).iValue * f2 / f);
                        Gdx.app.log("AoC", "prepareForWar_Recruit -> RECRUIT MODE 000A -> TO RECR ARMY: " + n5 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n));
                        n3 = n4;
                        if (CFG.game.getCiv(n).recruitArmy_AI(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n5)) {
                            n3 = 1;
                        }
                    } else {
                        n3 = CFG.game.getProvince(list.get((int)n5).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(n).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(n).getCivBuildArmyCost();
                        f2 = Math.min(n2, Math.min(n2, n7 / n3));
                        n3 = (int)(((AI_ProvinceInfo_War)object.get((int)n6)).iValue * f2 / f);
                        Gdx.app.log("AoC", "prepareForWar_Recruit -> RECRUIT MODE 0000B -> TO RECR ARMY: " + n3 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(list.get((int)n5).iProvinceID, n));
                        if (CFG.game.getCiv(n).recruitArmy_AI(list.get((int)n5).iProvinceID, n3)) {
                            n4 = 1;
                        }
                        n8 = CFG.game.getCiv(n).getRecruitArmy_BasedOnProvinceID(list.get((int)n5).iProvinceID);
                        n3 = n4;
                        if (n8 > 0) {
                            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.add(new CivArmyMission_RegroupAfterRecruitment(n, list.get((int)n5).iProvinceID, ((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n8));
                            n3 = n4;
                        }
                    }
                }
            } else {
                Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 1111 -> PROV: " + ((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID + " -> " + CFG.game.getProvince(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID).getName());
                n3 = CFG.game.getProvince(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID).getLevelOfArmoury() > 0 ? CFG.game.getCiv(n).getCivBuildArmyCost() * 5 / 4 : CFG.game.getCiv(n).getCivBuildArmyCost();
                f2 = Math.min(n2, Math.min(n2, n7 / n3));
                n5 = (int)(((AI_ProvinceInfo_War)object.get((int)n6)).iValue * f2 / f);
                Gdx.app.log("AoC", "moveAtWar_Recruit -> RECRUIT MODE 1111 -> TO RECR ARMY: " + n5 + ", RECRITABLE MAX: " + CFG.gameAction.getRecruitableArmy(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n));
                n3 = n4;
                if (CFG.game.getCiv(n).recruitArmy_AI(((AI_ProvinceInfo_War)object.get((int)n6)).iProvinceID, n5)) {
                    n3 = 1;
                }
            }
            ++n6;
            n4 = n3;
        }
    }

    /*
     * Exception decompiling
     */
    protected final void prepareForWar_Regroup(int var1_1, List<AI_ProvinceInfo_War> var2_2, List<Integer> var3_5) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:532)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:61)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:475)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    protected final void recruitMilitary_MinSpendings(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 16[WHILELOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final void regroupArmyAfterRecruitment(int n) {
        for (int i = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; i >= 0; --i) {
            if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)i).MISSION_TYPE != CivArmyMission_Type.REGRUOP_AFTER_RECRUIT || !CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).canMakeAction(n, 0) || !CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(i).action(n)) continue;
            CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(i);
        }
    }

    /*
     * Exception decompiling
     */
    protected final void regroupArmy_AtPeace(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 17[FORLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean regroupArmy_AtPeace_AtSea(int n, AI_RegoupArmyData aI_RegoupArmyData) {
        int n2;
        int n3;
        Object object = new ArrayList<AI_ProvinceInfo>();
        for (n3 = 0; n3 < CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvincesSize(); ++n3) {
            if (CFG.game.getProvince(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3)).getCivID() != n) continue;
            object.add(new AI_ProvinceInfo(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3), this.getPotential_BasedOnNeighboringProvs(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3), n), 1));
        }
        ArrayList<Integer> arrayList = Gdx.app;
        Serializable serializable = new StringBuilder();
        ((StringBuilder)serializable).append("regroupArmy_AtPeace_AtSea -> ");
        ((StringBuilder)serializable).append(CFG.game.getCiv(n).getCivName());
        ((StringBuilder)serializable).append(", Province: ");
        ((StringBuilder)serializable).append(aI_RegoupArmyData.iProvinceID);
        ((StringBuilder)serializable).append(", NAME: ");
        ((StringBuilder)serializable).append(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getName());
        ((StringBuilder)serializable).append(", nArmy: ");
        ((StringBuilder)serializable).append(aI_RegoupArmyData.iArmy);
        ((StringBuilder)serializable).append(", possibleMoveTo.size: ");
        ((StringBuilder)serializable).append(object.size());
        Object object2 = ((StringBuilder)serializable).toString();
        serializable = "AoC";
        arrayList.log("AoC", (String)object2);
        if (object.size() > 0) {
            int n4;
            int n5;
            arrayList = new ArrayList();
            int n6 = object.size();
            float f = 1.0f;
            int n7 = 0;
            n3 = 1;
            int n8 = 1;
            float f2 = 1.0f;
            float f3 = 1.0f;
            for (n5 = 0; n5 < n6; ++n5) {
                float f4 = f2;
                if (((AI_ProvinceInfo)object.get((int)n5)).iValue > f2) {
                    f4 = ((AI_ProvinceInfo)object.get((int)n5)).iValue;
                }
                n4 = n8;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getDangerLevel_WithArmy() > n8) {
                    n4 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getDangerLevel_WithArmy();
                }
                f2 = f;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getRegion_NumOfProvinces() > f) {
                    f2 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getRegion_NumOfProvinces();
                }
                float f5 = f3;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getPotentialRegion() > f3) {
                    f5 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getPotentialRegion();
                }
                arrayList.add(n7 += this.getMovingArmyToProvinceID(n, ((AI_ProvinceInfo)object.get((int)n5)).iProvinceID));
                n8 = n3;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getArmy(0) + n7 > n3) {
                    n8 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getArmy(0) + n7;
                }
                f = f2;
                n3 = n8;
                n8 = n4;
                f2 = f4;
                f3 = f5;
            }
            n4 = object.size();
            for (n5 = 0; n5 < n4; ++n5) {
                ((AI_ProvinceInfo)object.get((int)n5)).iValue = this.getValue_PositionOfArmy(n, (List<AI_ProvinceInfo>)object, n5, (Integer)arrayList.get(n5), f2, f3, n8, n3, aI_RegoupArmyData.iArmy, aI_RegoupArmyData.iArmy);
            }
            object2 = new ArrayList();
            while (object.size() > 0) {
                n5 = object.size();
                n4 = 0;
                for (n3 = 1; n3 < n5; ++n3) {
                    n8 = n4;
                    if (((AI_ProvinceInfo)object.get((int)n4)).iValue < ((AI_ProvinceInfo)object.get((int)n3)).iValue) {
                        n8 = n3;
                    }
                    n4 = n8;
                }
                object2.add(object.get(n4));
                object.remove(n4);
            }
            f3 = Math.max((float)aI_RegoupArmyData.iArmy / (float)CFG.game.getCiv(n).getNumOfUnits(), 0.01f);
            if (CFG.game.getCiv((int)n).civGameData.civPersonality.REGROUP_AT_PEACE_DISBAND_IF_LESS_THAN_PERC > f3) {
                n3 = 1;
            } else {
                n3 = Math.max(1, Math.min((CFG.game.getCiv(n).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE) / (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE * 2), CFG.oR.nextInt(3) + 1));
                n3 = f3 > 0.54f ? Math.min(n3, 4) : (f3 > 0.34f ? Math.min(n3, 3) : (f3 > 0.14f ? Math.min(n3, 2) : Math.min(n3, 1)));
            }
            arrayList = Gdx.app;
            object = new StringBuilder();
            ((StringBuilder)object).append("regroupArmy_AtPeace_AtSea -> 000 -> iNumOfMaxMovements: ");
            ((StringBuilder)object).append(n3);
            arrayList.log((String)((Object)serializable), ((StringBuilder)object).toString());
            arrayList = new ArrayList<Integer>();
            f3 = 0.0f;
            for (n8 = 0; n8 < n3 && n8 < object2.size(); ++n8) {
                arrayList.add((Integer)object2.get(n8));
                f3 += ((AI_ProvinceInfo)object2.get((int)n8)).iValue;
            }
            object = Gdx.app;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("regroupArmy_AtPeace_AtSea -> 000 -> tRecruitArmiesForProvinces.size: ");
            ((StringBuilder)object2).append(arrayList.size());
            object.log((String)((Object)serializable), ((StringBuilder)object2).toString());
            for (n3 = 0; n3 < arrayList.size(); ++n3) {
                n8 = (int)Math.ceil((float)aI_RegoupArmyData.iArmy * ((AI_ProvinceInfo)arrayList.get((int)n3)).iValue / f3);
                object2 = Gdx.app;
                object = new StringBuilder();
                ((StringBuilder)object).append("regroupArmy_AtPeace_AtSea -> 000 -> nArmy.iArmy: ");
                ((StringBuilder)object).append(aI_RegoupArmyData.iArmy);
                ((StringBuilder)object).append(", tArmyToRecruit_PRE: ");
                ((StringBuilder)object).append(n8);
                object2.log((String)((Object)serializable), ((StringBuilder)object).toString());
                if (n8 <= 0) break;
                object = new RegroupArmy_Data_AtPeace(n, aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)arrayList.get((int)n3)).iProvinceID);
                if (((RegroupArmy_Data)object).getRouteSize() <= 0) continue;
                if (((RegroupArmy_Data)object).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)arrayList.get((int)n3)).iProvinceID, n8, n, true, false);
                    continue;
                }
                if (!CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)object).getRoute(0), n8, n, true, false)) continue;
                ((RegroupArmy_Data)object).setFromProvinceID(((RegroupArmy_Data)object).getRoute(0));
                ((RegroupArmy_Data)object).removeRoute(0);
                ((RegroupArmy_Data)object).setNumOfUnits(n8);
                CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)object);
            }
            return true;
        }
        serializable = "AoC";
        block7: for (n3 = CFG.game.getCiv(n).getSeaAccess_Provinces_Size() - 1; n3 >= 0; --n3) {
            for (n2 = 0; n2 < CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvincesSize(); ++n2) {
                if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvinces(n2)).getBasinID() != CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getBasinID()) continue;
                object.add((AI_ProvinceInfo)new AI_ProvinceInfo(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3), this.getPotential_BasedOnNeighboringProvs(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3), n), 1));
                continue block7;
            }
        }
        arrayList = Gdx.app;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("regroupArmy_AtPeace_AtSea ->  111, possibleMoveTo.size: ");
        ((StringBuilder)object2).append(object.size());
        arrayList.log((String)((Object)serializable), ((StringBuilder)object2).toString());
        if (object.size() > 0) {
            int n9;
            int n10;
            serializable = new ArrayList();
            int n11 = object.size();
            float f = 1.0f;
            int n12 = 0;
            n2 = 1;
            n3 = 1;
            float f6 = 1.0f;
            float f7 = 1.0f;
            for (n10 = 0; n10 < n11; ++n10) {
                float f8 = f6;
                if (((AI_ProvinceInfo)object.get((int)n10)).iValue > f6) {
                    f8 = ((AI_ProvinceInfo)object.get((int)n10)).iValue;
                }
                n9 = n3;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getDangerLevel_WithArmy() > n3) {
                    n9 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getDangerLevel_WithArmy();
                }
                f6 = f;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getRegion_NumOfProvinces() > f) {
                    f6 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getRegion_NumOfProvinces();
                }
                float f9 = f7;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getPotentialRegion() > f7) {
                    f9 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getPotentialRegion();
                }
                serializable.add(n12 += this.getMovingArmyToProvinceID(n, ((AI_ProvinceInfo)object.get((int)n10)).iProvinceID));
                n3 = n2;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getArmy(0) + n12 > n2) {
                    n3 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getArmy(0) + n12;
                }
                f = f6;
                n2 = n3;
                n3 = n9;
                f6 = f8;
                f7 = f9;
            }
            n10 = object.size();
            for (n9 = 0; n9 < n10; ++n9) {
                ((AI_ProvinceInfo)object.get((int)n9)).iValue = this.getValue_PositionOfArmy(n, (List<AI_ProvinceInfo>)object, n9, (Integer)serializable.get(n9), f6, f7, n3, n2, aI_RegoupArmyData.iArmy, aI_RegoupArmyData.iArmy);
            }
            serializable = new ArrayList<Integer>();
            if (object.size() > 0) {
                n9 = object.size();
                n10 = 0;
                for (n3 = 1; n3 < n9; ++n3) {
                    n2 = n10;
                    if (((AI_ProvinceInfo)object.get((int)n10)).iValue < ((AI_ProvinceInfo)object.get((int)n3)).iValue) {
                        n2 = n3;
                    }
                    n10 = n2;
                }
                serializable.add((Integer)object.get(n10));
                object.remove(n10);
            }
            if (((RegroupArmy_Data)((Object)(arrayList = new RegroupArmy_Data_AtPeace(n, aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)serializable.get((int)0)).iProvinceID)))).getRouteSize() > 0) {
                if (((RegroupArmy_Data)((Object)arrayList)).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)serializable.get((int)0)).iProvinceID, aI_RegoupArmyData.iArmy, n, true, false);
                } else if (CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)((Object)arrayList)).getRoute(0), aI_RegoupArmyData.iArmy, n, true, false)) {
                    ((RegroupArmy_Data)((Object)arrayList)).setFromProvinceID(((RegroupArmy_Data)((Object)arrayList)).getRoute(0));
                    ((RegroupArmy_Data)((Object)arrayList)).removeRoute(0);
                    ((RegroupArmy_Data)((Object)arrayList)).setNumOfUnits(aI_RegoupArmyData.iArmy);
                    CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)((Object)arrayList));
                }
            }
            return true;
        }
        if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() == n) {
            serializable = new RegroupArmy_Data_AtPeace(n, aI_RegoupArmyData.iProvinceID, CFG.game.getCiv(n).getCapitalProvinceID());
            if (((RegroupArmy_Data)serializable).getRouteSize() > 0) {
                if (((RegroupArmy_Data)serializable).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, CFG.game.getCiv(n).getCapitalProvinceID(), aI_RegoupArmyData.iArmy, n, true, false);
                } else if (CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)serializable).getRoute(0), aI_RegoupArmyData.iArmy, n, true, false)) {
                    ((RegroupArmy_Data)serializable).setFromProvinceID(((RegroupArmy_Data)serializable).getRoute(0));
                    ((RegroupArmy_Data)serializable).removeRoute(0);
                    ((RegroupArmy_Data)serializable).setNumOfUnits(aI_RegoupArmyData.iArmy);
                    CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)serializable);
                }
            } else {
                CFG.gameAction.disbandArmy(aI_RegoupArmyData.iProvinceID, aI_RegoupArmyData.iArmy, n);
            }
        } else {
            CFG.gameAction.disbandArmy(aI_RegoupArmyData.iProvinceID, aI_RegoupArmyData.iArmy, n);
        }
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean regroupArmy_AtPeace_InAnotherTerritory(int var1_1, AI_RegoupArmyData var2_2) {
        block30: {
            block32: {
                var3_5 = Math.max((float)var2_2.iArmy / (float)CFG.game.getCiv(var1_1).getNumOfUnits(), 0.01f);
                var4_6 = CFG.oAI;
                var5_7 = var2_2.iProvinceID;
                var6_8 = CFG.game.getCiv((int)var1_1).civGameData.civPersonality.REGROUP_AT_PEACE_MAX_PROVINCES;
                var7_9 = CFG.game.getCiv(var1_1).getNumOfProvinces() / 15;
                var8_10 = new ArrayList<E>();
                var9_11 = new ArrayList();
                var9_11 = var4_6.getAllNeighboringProvincesInRange_OnlyOwn_Clear(var5_7, var1_1, var7_9 + var6_8, false, false, (List<AI_NeighProvinces>)var8_10, (List<Integer>)var9_11);
                var8_10 = Gdx.app;
                var4_6 = new List<CivArmyMission>();
                var4_6.append("regroupArmy_AtPeace_InAnotherTerritory - > listOfPossibleProvinces.size: ");
                var4_6.append(var9_11.size());
                var8_10.log("AoC", var4_6.toString());
                if (var9_11.size() <= 0) break block30;
                var5_7 = CFG.game.getCiv(var1_1).getMovePoints() / CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).COST_OF_MOVE;
                if (!(var3_5 > 0.275f)) ** GOTO lbl23
                var6_8 = Math.min(var5_7, 2);
                break block32;
lbl23:
                // 1 sources

                var6_8 = Math.min(var5_7, 1);
            }
            Gdx.app.log("AoC", "regroupArmy_AtPeace_InAnotherTerritory -> 000");
            Gdx.app.log("AoC", "regroupArmy_AtPeace_InAnotherTerritory -> 1111");
            var8_10 = new ArrayList<E>();
            var4_6 = new List<CivArmyMission>();
            for (var5_7 = var9_11.size() - 1; var5_7 >= 0; --var5_7) {
                var4_6.add((CivArmyMission)Integer.valueOf(var5_7));
                continue;
            }
            while (true) {
                if (var4_6.size() <= 0) break;
                var10_12 = 0;
                for (var5_7 = var4_6.size() - 1; var5_7 > 0; --var5_7) {
                    var7_9 = var10_12;
                    if (CFG.game.getProvince(((AI_NeighProvinces)var9_11.get((int)((Integer)var4_6.get((int)var10_12)).intValue())).iProvinceID).getPotential() < CFG.game.getProvince(((AI_NeighProvinces)var9_11.get((int)((Integer)var4_6.get((int)var5_7)).intValue())).iProvinceID).getPotential()) {
                        var7_9 = var5_7;
                    }
                    var10_12 = var7_9;
                    continue;
                }
                var8_10.add(var4_6.get(var10_12));
                var4_6.remove(var10_12);
                continue;
                break;
            }
            var10_12 = 0;
            for (var5_7 = 0; var5_7 < var6_8; ++var5_7) {
                if (var5_7 >= var8_10.size()) break;
                var10_12 += CFG.game.getProvince(((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var5_7)).intValue())).iProvinceID).getPotential();
                continue;
            }
            var4_6 = Gdx.app;
            var11_13 = new StringBuilder();
            var11_13.append("regroupArmy_AtPeace_InAnotherTerritory -> 222, nNumOfPossibleMovements: ");
            var11_13.append(var6_8);
            var4_6.log("AoC", var11_13.toString());
            var5_7 = -1;
            for (var7_9 = 0; var7_9 < var6_8; ++var7_9) {
                block31: {
                    if (var7_9 >= var8_10.size() || var2_2.iArmy <= 0) break;
                    var4_6 = new List<CivArmyMission>(var1_1, var2_2.iProvinceID, ((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var7_9)).intValue())).iProvinceID);
                    if (var4_6.getRouteSize() <= 0) break block31;
                    if (var7_9 == var6_8) ** GOTO lbl-1000
                    if (var7_9 != var8_10.size() - 1) {
                        var12_14 = (int)Math.ceil((float)var2_2.iArmy * ((float)CFG.game.getProvince(((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var7_9)).intValue())).iProvinceID).getPotential() / (float)var10_12));
                    } else lbl-1000:
                    // 2 sources

                    {
                        var12_14 = var2_2.iArmy;
                    }
                    var2_2.iArmy -= var12_14;
                    if (var12_14 <= 0) break;
                    var11_13 = CFG.gameAction;
                    var13_15 = var2_2.iProvinceID;
                    var14_16 = var4_6.getRoute(0);
                    if (!var11_13.moveArmy(var13_15, var14_16, var12_14, var1_1, true, false)) continue;
                    if (var4_6.getRouteSize() > 1) {
                        var15_17 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions;
                        var11_13 = new CivArmyMission_RegroupAfterRecruitment(var1_1, var4_6.getRoute(0), ((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var7_9)).intValue())).iProvinceID, var12_14);
                        var15_17.add(var11_13);
                    }
                    var5_7 = var7_9;
                    continue;
                }
                if (var5_7 < 0) continue;
                var11_13 = new RegroupArmy_Data_AtPeace(var1_1, var2_2.iProvinceID, ((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var5_7)).intValue())).iProvinceID);
                if (var11_13.getRouteSize() <= 0 || !CFG.gameAction.moveArmy(var2_2.iProvinceID, var11_13.getRoute(0), var2_2.iArmy, var1_1, true, false)) continue;
                if (var11_13.getRouteSize() <= 1) return true;
                var4_6 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions;
                var15_17 = new CivArmyMission_RegroupAfterRecruitment(var1_1, var11_13.getRoute(0), ((AI_NeighProvinces)var9_11.get((int)((Integer)var8_10.get((int)var5_7)).intValue())).iProvinceID, var2_2.iArmy);
                var4_6.add((CivArmyMission)var15_17);
                return true;
            }
            if (var5_7 < 0) return false;
            return true;
        }
        try {
            if (CFG.game.getCiv(var1_1).getCapitalProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getCiv(var1_1).getCapitalProvinceID()).getCivID() == var1_1) {
                var9_11 = new RegroupArmy_Data_AtPeace(var1_1, var2_2.iProvinceID, CFG.game.getCiv(var1_1).getCapitalProvinceID());
                if (var9_11.getRouteSize() > 0) {
                    if (var9_11.getRouteSize() == 1) {
                        CFG.gameAction.moveArmy(var2_2.iProvinceID, CFG.game.getCiv(var1_1).getCapitalProvinceID(), var2_2.iArmy, var1_1, true, false);
                        return false;
                    } else {
                        if (!CFG.gameAction.moveArmy(var2_2.iProvinceID, var9_11.getRoute(0), var2_2.iArmy, var1_1, true, false)) return false;
                        var9_11.setFromProvinceID(var9_11.getRoute(0));
                        var9_11.removeRoute(0);
                        var9_11.setNumOfUnits(var2_2.iArmy);
                        CFG.game.getCiv(var1_1).addRegroupArmy((RegroupArmy_Data)var9_11);
                    }
                    return false;
                } else {
                    CFG.gameAction.disbandArmy(var2_2.iProvinceID, var2_2.iArmy, var1_1);
                }
                return false;
            } else {
                CFG.gameAction.disbandArmy(var2_2.iProvinceID, var2_2.iArmy, var1_1);
            }
            return false;
        }
        catch (StackOverflowError var2_3) {
            CFG.exceptionStack(var2_3);
            return false;
        }
        catch (IndexOutOfBoundsException var2_4) {
            CFG.exceptionStack(var2_4);
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    protected final boolean regroupArmy_AtPeace_InOwnTerritory_WithoutDanger(int var1_1, AI_RegoupArmyData var2_2, boolean var3_11) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 1[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean regroupArmy_AtWar_AtSea(int n, AI_RegoupArmyData aI_RegoupArmyData) {
        int n2;
        int n3;
        Object object = new ArrayList<AI_ProvinceInfo>();
        for (n3 = 0; n3 < CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvincesSize(); ++n3) {
            if (CFG.game.getProvince(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3)).getCivID() != n && !CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3)).getCivID())) continue;
            object.add(new AI_ProvinceInfo(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3), this.getPotential_BasedOnNeighboringProvs(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getNeighboringProvinces(n3), n), 1));
        }
        ArrayList<Integer> arrayList = Gdx.app;
        Serializable serializable = new StringBuilder();
        ((StringBuilder)serializable).append("regroupArmy_AtWar_AtSea -> ");
        ((StringBuilder)serializable).append(CFG.game.getCiv(n).getCivName());
        ((StringBuilder)serializable).append(", Province: ");
        ((StringBuilder)serializable).append(aI_RegoupArmyData.iProvinceID);
        ((StringBuilder)serializable).append(", NAME: ");
        ((StringBuilder)serializable).append(CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getName());
        ((StringBuilder)serializable).append(", nArmy: ");
        ((StringBuilder)serializable).append(aI_RegoupArmyData.iArmy);
        ((StringBuilder)serializable).append(", possibleMoveTo.size: ");
        ((StringBuilder)serializable).append(object.size());
        Object object2 = ((StringBuilder)serializable).toString();
        serializable = "AoC";
        arrayList.log("AoC", (String)object2);
        if (object.size() > 0) {
            int n4;
            int n5;
            arrayList = new ArrayList();
            int n6 = object.size();
            float f = 1.0f;
            int n7 = 0;
            n3 = 1;
            int n8 = 1;
            float f2 = 1.0f;
            float f3 = 1.0f;
            for (n5 = 0; n5 < n6; ++n5) {
                float f4 = f2;
                if (((AI_ProvinceInfo)object.get((int)n5)).iValue > f2) {
                    f4 = ((AI_ProvinceInfo)object.get((int)n5)).iValue;
                }
                n4 = n8;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getDangerLevel_WithArmy() > n8) {
                    n4 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getDangerLevel_WithArmy();
                }
                f2 = f;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getRegion_NumOfProvinces() > f) {
                    f2 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getRegion_NumOfProvinces();
                }
                float f5 = f3;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getPotentialRegion() > f3) {
                    f5 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getPotentialRegion();
                }
                arrayList.add(n7 += this.getMovingArmyToProvinceID(n, ((AI_ProvinceInfo)object.get((int)n5)).iProvinceID));
                n8 = n3;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getArmy(0) + n7 > n3) {
                    n8 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n5)).iProvinceID).getArmy(0) + n7;
                }
                f = f2;
                n3 = n8;
                n8 = n4;
                f2 = f4;
                f3 = f5;
            }
            n4 = object.size();
            for (n5 = 0; n5 < n4; ++n5) {
                ((AI_ProvinceInfo)object.get((int)n5)).iValue = this.getValue_PositionOfArmy(n, (List<AI_ProvinceInfo>)object, n5, (Integer)arrayList.get(n5), f2, f3, n8, n3, aI_RegoupArmyData.iArmy, aI_RegoupArmyData.iArmy);
            }
            object2 = new ArrayList();
            while (object.size() > 0) {
                n5 = object.size();
                n8 = 0;
                for (n3 = 1; n3 < n5; ++n3) {
                    n4 = n8;
                    if (((AI_ProvinceInfo)object.get((int)n8)).iValue < ((AI_ProvinceInfo)object.get((int)n3)).iValue) {
                        n4 = n3;
                    }
                    n8 = n4;
                }
                object2.add(object.get(n8));
                object.remove(n8);
            }
            f3 = Math.max((float)aI_RegoupArmyData.iArmy / (float)CFG.game.getCiv(n).getNumOfUnits(), 0.01f);
            if (CFG.game.getCiv((int)n).civGameData.civPersonality.REGROUP_AT_PEACE_DISBAND_IF_LESS_THAN_PERC > f3) {
                n3 = 1;
            } else {
                n3 = Math.max(1, Math.min((CFG.game.getCiv(n).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE) / (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE * 2), CFG.oR.nextInt(3) + 1));
                n3 = f3 > 0.34f ? Math.min(n3, 4) : (f3 > 0.24f ? Math.min(n3, 3) : (f3 > 0.1f ? Math.min(n3, 2) : Math.min(n3, 1)));
            }
            object = Gdx.app;
            arrayList = new StringBuilder();
            ((StringBuilder)((Object)arrayList)).append("regroupArmy_AtWar_AtSea -> 000 -> iNumOfMaxMovements: ");
            ((StringBuilder)((Object)arrayList)).append(n3);
            object.log((String)((Object)serializable), ((StringBuilder)((Object)arrayList)).toString());
            arrayList = new ArrayList<Integer>();
            f3 = 0.0f;
            for (n8 = 0; n8 < n3 && n8 < object2.size(); ++n8) {
                arrayList.add((Integer)object2.get(n8));
                f3 += ((AI_ProvinceInfo)object2.get((int)n8)).iValue;
            }
            object = Gdx.app;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("regroupArmy_AtWar_AtSea -> 000 -> tRecruitArmiesForProvinces.size: ");
            ((StringBuilder)object2).append(arrayList.size());
            object.log((String)((Object)serializable), ((StringBuilder)object2).toString());
            for (n3 = 0; n3 < arrayList.size(); ++n3) {
                n8 = (int)Math.ceil((float)aI_RegoupArmyData.iArmy * ((AI_ProvinceInfo)arrayList.get((int)n3)).iValue / f3);
                object = Gdx.app;
                object2 = new StringBuilder();
                ((StringBuilder)object2).append("regroupArmy_AtWar_AtSea -> 000 -> nArmy.iArmy: ");
                ((StringBuilder)object2).append(aI_RegoupArmyData.iArmy);
                ((StringBuilder)object2).append(", tArmyToRecruit_PRE: ");
                ((StringBuilder)object2).append(n8);
                object.log((String)((Object)serializable), ((StringBuilder)object2).toString());
                if (n8 <= 0) break;
                object = new RegroupArmy_Data_AtWar(n, aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)arrayList.get((int)n3)).iProvinceID);
                if (((RegroupArmy_Data)object).getRouteSize() <= 0) continue;
                if (((RegroupArmy_Data)object).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)arrayList.get((int)n3)).iProvinceID, n8, n, true, false);
                    continue;
                }
                if (!CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)object).getRoute(0), n8, n, true, false)) continue;
                ((RegroupArmy_Data)object).setFromProvinceID(((RegroupArmy_Data)object).getRoute(0));
                ((RegroupArmy_Data)object).removeRoute(0);
                ((RegroupArmy_Data)object).setNumOfUnits(n8);
                CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)object);
            }
            return true;
        }
        serializable = "AoC";
        block7: for (n3 = CFG.game.getCiv(n).getSeaAccess_Provinces_Size() - 1; n3 >= 0; --n3) {
            for (n2 = 0; n2 < CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvincesSize(); ++n2) {
                if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3)).getNeighboringSeaProvinces(n2)).getBasinID() != CFG.game.getProvince(aI_RegoupArmyData.iProvinceID).getBasinID()) continue;
                object.add((AI_ProvinceInfo)new AI_ProvinceInfo(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3), this.getPotential_BasedOnNeighboringProvs(CFG.game.getCiv(n).getSeaAccess_Provinces().get(n3), n), 1));
                continue block7;
            }
        }
        arrayList = Gdx.app;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("regroupArmy_AtWar_AtSea ->  111, possibleMoveTo.size: ");
        ((StringBuilder)object2).append(object.size());
        arrayList.log((String)((Object)serializable), ((StringBuilder)object2).toString());
        if (object.size() > 0) {
            int n9;
            int n10;
            serializable = new ArrayList();
            int n11 = object.size();
            float f = 1.0f;
            int n12 = 0;
            n2 = 1;
            n3 = 1;
            float f6 = 1.0f;
            float f7 = 1.0f;
            for (n10 = 0; n10 < n11; ++n10) {
                float f8 = f6;
                if (((AI_ProvinceInfo)object.get((int)n10)).iValue > f6) {
                    f8 = ((AI_ProvinceInfo)object.get((int)n10)).iValue;
                }
                n9 = n3;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getDangerLevel_WithArmy() > n3) {
                    n9 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getDangerLevel_WithArmy();
                }
                f6 = f;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getRegion_NumOfProvinces() > f) {
                    f6 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getRegion_NumOfProvinces();
                }
                float f9 = f7;
                if ((float)CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getPotentialRegion() > f7) {
                    f9 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getPotentialRegion();
                }
                serializable.add(n12 += this.getMovingArmyToProvinceID(n, ((AI_ProvinceInfo)object.get((int)n10)).iProvinceID));
                n3 = n2;
                if (CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getArmy(0) + n12 > n2) {
                    n3 = CFG.game.getProvince(((AI_ProvinceInfo)object.get((int)n10)).iProvinceID).getArmy(0) + n12;
                }
                f = f6;
                n2 = n3;
                n3 = n9;
                f6 = f8;
                f7 = f9;
            }
            n10 = object.size();
            for (n9 = 0; n9 < n10; ++n9) {
                ((AI_ProvinceInfo)object.get((int)n9)).iValue = this.getValue_PositionOfArmy(n, (List<AI_ProvinceInfo>)object, n9, (Integer)serializable.get(n9), f6, f7, n3, n2, aI_RegoupArmyData.iArmy, aI_RegoupArmyData.iArmy);
            }
            serializable = new ArrayList<Integer>();
            if (object.size() > 0) {
                n9 = object.size();
                n10 = 0;
                for (n3 = 1; n3 < n9; ++n3) {
                    n2 = n10;
                    if (((AI_ProvinceInfo)object.get((int)n10)).iValue < ((AI_ProvinceInfo)object.get((int)n3)).iValue) {
                        n2 = n3;
                    }
                    n10 = n2;
                }
                serializable.add((Integer)object.get(n10));
                object.remove(n10);
            }
            if (((RegroupArmy_Data)((Object)(arrayList = new RegroupArmy_Data_AtWar(n, aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)serializable.get((int)0)).iProvinceID)))).getRouteSize() > 0) {
                if (((RegroupArmy_Data)((Object)arrayList)).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((AI_ProvinceInfo)serializable.get((int)0)).iProvinceID, aI_RegoupArmyData.iArmy, n, true, false);
                } else if (CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)((Object)arrayList)).getRoute(0), aI_RegoupArmyData.iArmy, n, true, false)) {
                    ((RegroupArmy_Data)((Object)arrayList)).setFromProvinceID(((RegroupArmy_Data)((Object)arrayList)).getRoute(0));
                    ((RegroupArmy_Data)((Object)arrayList)).removeRoute(0);
                    ((RegroupArmy_Data)((Object)arrayList)).setNumOfUnits(aI_RegoupArmyData.iArmy);
                    CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)((Object)arrayList));
                }
            }
            return true;
        }
        if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() == n) {
            serializable = new RegroupArmy_Data_AtWar(n, aI_RegoupArmyData.iProvinceID, CFG.game.getCiv(n).getCapitalProvinceID());
            if (((RegroupArmy_Data)serializable).getRouteSize() > 0) {
                if (((RegroupArmy_Data)serializable).getRouteSize() == 1) {
                    CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, CFG.game.getCiv(n).getCapitalProvinceID(), aI_RegoupArmyData.iArmy, n, true, false);
                } else if (CFG.gameAction.moveArmy(aI_RegoupArmyData.iProvinceID, ((RegroupArmy_Data)serializable).getRoute(0), aI_RegoupArmyData.iArmy, n, true, false)) {
                    ((RegroupArmy_Data)serializable).setFromProvinceID(((RegroupArmy_Data)serializable).getRoute(0));
                    ((RegroupArmy_Data)serializable).removeRoute(0);
                    ((RegroupArmy_Data)serializable).setNumOfUnits(aI_RegoupArmyData.iArmy);
                    CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)serializable);
                }
            } else {
                CFG.gameAction.disbandArmy(aI_RegoupArmyData.iProvinceID, aI_RegoupArmyData.iArmy, n);
            }
        } else {
            CFG.gameAction.disbandArmy(aI_RegoupArmyData.iProvinceID, aI_RegoupArmyData.iArmy, n);
        }
        return true;
    }

    /*
     * Exception decompiling
     */
    protected final boolean regroupArmy_AtWar_WithoutDanger(int var1_1, AI_RegoupArmyData var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 40[FORLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    protected final boolean regroupArmy_PrepareForWar_WithoutDanger(int var1_1, AI_RegoupArmyData var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [1[TRYBLOCK]], but top level block is 40[UNCONDITIONALDOLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final void relocateLostCapital(int n) {
        block10: {
            if (!(CFG.game.getCiv(n).getCapitalProvinceID() == CFG.game.getCiv(n).getCoreCapitalProvinceID() || CFG.game.getCiv(n).getCoreCapitalProvinceID() < 0 || CFG.game.getProvince(CFG.game.getCiv(n).getCoreCapitalProvinceID()).getCivID() != n || CFG.game.getProvince(CFG.game.getCiv(n).getCoreCapitalProvinceID()).isOccupied() || CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() != n)) {
                if ((float)CFG.game.getCiv(n).getMoney() > (float)CFG.gameAction.moveCapital_Cost(n) * 4.76124f) {
                    CFG.gameAction.moveCapital(n, CFG.game.getCiv(n).getCoreCapitalProvinceID());
                }
                break block10;
            }
            if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && (CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID() == n || CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).isOccupied() && CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getCivID()))) break block10;
            int n2 = CFG.game.getCiv(n).getProvinceID(0);
            int n3 = this.relocateLostCapital_ProvinceScore(n, CFG.game.getCiv(n).getProvinceID(0));
            int n4 = 1;
            while (true) {
                int n5;
                block11: {
                    if (n4 >= CFG.game.getCiv(n).getNumOfProvinces()) break;
                    int n6 = this.relocateLostCapital_ProvinceScore(n, CFG.game.getCiv(n).getProvinceID(n4));
                    n5 = n3;
                    if (n3 >= n6) break block11;
                    n2 = CFG.game.getCiv(n).getProvinceID(n4);
                    n5 = n6;
                }
                ++n4;
                n3 = n5;
            }
            try {
                if (!CFG.game.getProvince(n2).isOccupied()) {
                    CFG.gameAction.moveCapital(n, n2);
                }
            }
            catch (NullPointerException nullPointerException) {
                CFG.exceptionStack(nullPointerException);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                CFG.exceptionStack(indexOutOfBoundsException);
            }
        }
    }

    protected final int relocateLostCapital_ProvinceScore(int n, int n2) {
        n = CFG.game.getProvince(n2).isOccupied() ? -1 : (int)((float)CFG.game.getProvince(n).getPopulationData().getPopulationOfCivID(n) + (float)CFG.game.getProvince(n).getPopulationData().getPopulation() / 15.0f + (float)CFG.game.getProvince(n).getEconomy() / 6.0f);
        return n;
    }

    protected final void respondToEvents(int n) {
        CFG.game.getCiv(n).runNextEvent();
    }

    /*
     * Exception decompiling
     */
    protected final void respondToMessages(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:406)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:481)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean tryToExpandBeforeCivilize(int n) {
        if (CFG.game.getCiv(n).getBordersWithEnemy() > 0) {
            return false;
        }
        if (CFG.game.getCiv(n).getMoney() + (long)CFG.game.getCiv((int)n).iBudget > -1000L && CFG.game.getCiv(n).getNumOfNeighboringNeutralProvinces() > 0) {
            int n2;
            for (n2 = CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.size() - 1; n2 >= 0; --n2) {
                if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get((int)n2).MISSION_TYPE != CivArmyMission_Type.EXPAND_NETURAL_PROVINCE) continue;
                if (CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n2).action(n)) {
                    CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.get(n2).onRemove();
                    CFG.game.getCiv((int)n).civGameData.civPlans.lArmiesMissions.remove(n2);
                    continue;
                }
                return true;
            }
            if (CFG.game.getCiv(n).getNumOfProvinces() < n % 2 + 6) {
                n2 = -1;
                for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
                    for (int j = 0; j < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getNeighboringProvincesSize(); ++j) {
                        int n3 = n2;
                        if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getNeighboringProvinces(j)).getCivID() == 0) {
                            n3 = n2 < 0 ? CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getNeighboringProvinces(j)).getArmy(0) : Math.min(n2, CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getNeighboringProvinces(j)).getArmy(0));
                        }
                        n2 = n3;
                    }
                }
                if (n2 < 0) {
                    return false;
                }
                if ((n2 = (int)((long)n2 - ((long)CFG.game.getCiv(n).getNumOfUnits() + Math.max(CFG.game.getCiv(n).getMoney(), 0L) / 5L))) <= 0) {
                    CFG.oAI.expandToNeutralProvinces_Out(n, false);
                    return true;
                }
                if ((int)Math.ceil((float)n2 / (float)(CFG.game.getCiv((int)n).iBudget / 5)) < 50) {
                    CFG.oAI.expandToNeutralProvinces_Out(n, false);
                    return true;
                }
            }
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected void turnOrders(int var1_1) {
        block76: {
            Gdx.app.log(this.TAG, "BEGIN, " + CFG.game.getCiv(var1_1).getCivName());
            this.armyOverBudget = false;
            this.relocateLostCapital(var1_1);
            this.changeTypeOfIdeology(var1_1);
            this.checkPeaceTreaties(var1_1);
            if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize > 0) {
                CFG.game.getCiv((int)var1_1).civGameData.civPlans.checkWarPreparations(var1_1);
            }
            try {
                if (CFG.game.getCiv(var1_1).isAtWar()) {
                    this.defendFromSeaInvasion(var1_1);
                    this.moveAtWar(var1_1);
                    this.armyOverBudget = true;
                }
                if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.isPreparingForTheWar()) {
                    this.prepareForWar2(var1_1);
                }
            }
            catch (IndexOutOfBoundsException var3_3) {
                CFG.exceptionStack(var3_3);
            }
            catch (NullPointerException var3_4) {
                CFG.exceptionStack(var3_4);
            }
            catch (ArithmeticException var3_5) {
                CFG.exceptionStack(var3_5);
            }
            CFG.oAI.expandNeutral.expandToNeutralProvinces(var1_1);
            Gdx.app.log("AoC", "MILITARY UPKEEP CHECK: " + (0.96f - CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC - CFG.game.getCiv(var1_1).getSpendings_Goods() - CFG.game.getCiv(var1_1).getSpendings_Investments()));
            if (this.getMinMilitarySpendings(var1_1) + 0.025f < CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC) {
                Gdx.app.log("AoC", "MILITARY UPKEEP CHECK: we need to disband");
                this.armyOverBudget_Disband(var1_1);
                this.armyOverBudget = true;
            }
            if (CFG.game.getCiv(var1_1).getHappiness() < CFG.game.getCiv((int)var1_1).civGameData.civPersonality.MIN_HAPPINESS_CRISIS) {
                this.happinessCrisis(var1_1);
            } else if (!CFG.game.getCiv(var1_1).isAtWar()) {
                if (CFG.game.getCiv((int)var1_1).lProvincesWithLowHappiness.size() > 0 && CFG.game.getCiv(var1_1).getTaxationLevel() <= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION && CFG.game.getCiv(var1_1).getSpendings_Goods() >= CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)) {
                    this.hostFestivals(var1_1, CFG.game.getCiv(var1_1).getNumOfProvinces());
                }
            } else if (CFG.game.getCiv((int)var1_1).lProvincesWithLowHappiness.size() > 0 && CFG.game.getCiv(var1_1).getTaxationLevel() <= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)var1_1).getIdeologyID()).ACCEPTABLE_TAXATION && CFG.game.getCiv(var1_1).getSpendings_Goods() >= CFG.ideologiesManager.getIdeology(CFG.game.getCiv(var1_1).getIdeologyID()).getMin_Goods(var1_1)) {
                this.hostFestivals(var1_1, CFG.oR.nextInt(3) + 1);
            }
            if (CFG.game.getCiv((int)var1_1).lProvincesWithLowStability.size() > 0) {
                this.assimilateProvinces(var1_1);
            }
            if ((!this.armyOverBudget || CFG.game.getCiv(var1_1).getBordersWithEnemy() == 0) && CFG.game.getCiv(var1_1).getMoney() > 0L && this.getMinMilitarySpendings(var1_1) > CFG.game.getCiv((int)var1_1).iMilitaryUpkeep_PERC + 0.0275f) {
                this.recruitMilitary_MinSpendings(var1_1);
            }
            if (!this.armyOverBudget) {
                this.colonizeProvinces(var1_1);
            }
            if (!CFG.game.getCiv(var1_1).isAtWar() && !CFG.game.getCiv((int)var1_1).civGameData.civPlans.isPreparingForTheWar()) {
                this.regroupArmy_AtPeace(var1_1);
            }
            this.regroupArmyAfterRecruitment(var1_1);
            if (CFG.game.getCiv((int)var1_1).lProvincesWithHighRevRisk.size() > 0) {
                this.prepareArmyForRevolution(var1_1);
            }
            if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.isPreparingForTheWar()) {
                this.prepareForWar_MoveReadyArmies(var1_1);
                for (var2_7 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize - 1; var2_7 >= 0; --var2_7) {
                    var3_2 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get(var2_7);
                    var4_8 = var3_2.iNumOfTurnsLeft;
                    var3_2.iNumOfTurnsLeft = var4_8 - 1;
                    if (var4_8 > 0) continue;
                    var5_9 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var2_7).onCivID;
                    CFG.game.declareWar(var1_1, CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.get((int)var2_7).onCivID, false);
                    for (var4_8 = CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.size() - 1; var4_8 >= 0; --var4_8) {
                        if (CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.get((int)var4_8).MISSION_TYPE != CivArmyMission_Type.PREAPARE_FOR_WAR || CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.get((int)var4_8).MISSION_ID != var5_9) continue;
                        CFG.game.getCiv((int)var1_1).civGameData.civPlans.lArmiesMissions.remove(var4_8);
                    }
                    try {
                        CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.remove(var2_7);
                        CFG.game.getCiv((int)var1_1).civGameData.civPlans.iWarPreparationsSize = CFG.game.getCiv((int)var1_1).civGameData.civPlans.warPreparations.size();
                        continue;
                    }
                    catch (IndexOutOfBoundsException var3_6) {}
                }
            }
            if (CFG.game.getCiv(var1_1).getMovePoints() >= 10 && CFG.game.getCiv(var1_1).getMoney() > 0L) {
                this.buildBuildings(var1_1);
            }
            if (!CFG.game.getCiv(var1_1).isAtWar()) break block76;
            var3_2 = CFG.game.getCiv((int)var1_1).isAtWarWithCivs.iterator();
            block20: while (var3_2.hasNext()) {
                var5_9 = var3_2.next();
                if (!CFG.game.getCiv(var1_1).isAtNuclearWar()) continue;
                while (CFG.game.getCiv(var1_1).getNuclearWeapons() > 0) {
                    block75: {
                        block74: {
                            block71: {
                                block73: {
                                    block72: {
                                        block70: {
                                            block77: {
                                                var6_10 = new ArrayList<E>();
                                                var7_11 = new ArrayList<Integer>();
                                                var2_7 = 0;
                                                for (var4_8 = 0; var4_8 < CFG.game.getCiv(var5_9).getNumOfProvinces(); var2_7 += CFG.game.getProvince(CFG.game.getCiv(var5_9).getProvinceID(var4_8)).getEconomy(), ++var4_8) {
                                                    var7_11.add(CFG.game.getCiv(var5_9).getProvinceID(var4_8));
                                                }
                                                break block77;
                                                while (true) {
                                                    var6_10.add(var7_11.get(var4_8));
                                                    var7_11.remove(var4_8);
                                                    break;
                                                }
                                            }
                                            if (var7_11.size() <= 0) {
                                                var2_7 = ThreadLocalRandom.current().nextInt(0, ThreadLocalRandom.current().nextInt(0, 7));
                                                var4_8 = (Integer)var6_10.get(var2_7);
                                                if (CFG.game.getCiv(var1_1).getMoney() <= (long)DiplomacyManager.getNuclearAttackCost(var4_8, var1_1) || CFG.game.getCiv(var1_1).getMovePoints() <= DiplomacyManager.getColonizeCost_Movement(var4_8, var1_1) || var6_10.size() < var2_7) continue;
                                                if (CFG.game.getProvince(var4_8).getLevelOfBunker() <= 0) {
                                                    var8_14 = DiplomacyManager.getNuclearAttackCost(var4_8, var1_1);
                                                    var9_15 = DiplomacyManager.getColonizeCost_Movement(var4_8, var1_1);
                                                    CFG.game.getProvince(var4_8).setEconomy(CFG.game.getProvince(var4_8).getEconomy() - (CFG.game.getProvince(var4_8).getEconomy() / 2 + CFG.game.getProvince(var4_8).getEconomy() / 3));
                                                    for (var2_7 = 0; var2_7 < CFG.game.getProvince(var4_8).getPopulationData().getNationalitiesSize(); ++var2_7) {
                                                        var10_16 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getCivID();
                                                        var11_17 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation();
                                                        var12_18 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation() / 2;
                                                        var13_19 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation() / 3;
                                                        CFG.game.getProvince(var4_8).getPopulationData().setPopulationOfCivID(var10_16, var11_17 - (var12_18 + var13_19));
                                                    }
                                                    break block70;
                                                }
                                                var8_14 = DiplomacyManager.getNuclearAttackCost(var4_8, var1_1);
                                                var9_15 = DiplomacyManager.getColonizeCost_Movement(var4_8, var1_1);
                                                CFG.game.getProvince(var4_8).setEconomy(CFG.game.getProvince(var4_8).getEconomy() - (CFG.game.getProvince(var4_8).getEconomy() / 2 + CFG.game.getProvince(var4_8).getEconomy() / 3));
                                                for (var2_7 = 0; var2_7 < CFG.game.getProvince(var4_8).getPopulationData().getNationalitiesSize(); ++var2_7) {
                                                    var12_18 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getCivID();
                                                    var10_16 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation();
                                                    var11_17 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation() / 3;
                                                    var13_19 = CFG.game.getProvince(var4_8).getPopulationData().getNational(var2_7).getPopulation() / 4;
                                                    CFG.game.getProvince(var4_8).getPopulationData().setPopulationOfCivID(var12_18, var10_16 - (var11_17 + var13_19));
                                                }
                                                break block71;
                                            }
                                            var4_8 = 0;
                                            var2_7 = 1;
                                            while (true) {
                                                if (var2_7 >= var7_11.size()) ** continue;
                                                if (CFG.game.getProvince((Integer)var7_11.get(var4_8)).getEconomy() < CFG.game.getProvince((Integer)var7_11.get(var2_7)).getEconomy()) {
                                                    var4_8 = var2_7;
                                                }
                                                ++var2_7;
                                            }
                                        }
                                        for (var2_7 = 0; var2_7 < CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getNumOfProvinces(); ++var2_7) {
                                            var7_11 = CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID());
                                            if (CFG.game.getProvince(var7_11.getProvinceID(var2_7)).isOccupied()) continue;
                                            CFG.game.getProvince(var7_11.getProvinceID(var2_7)).setHappiness(CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getHappiness() - CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getHappiness() / 2.0f);
                                            CFG.game.getProvince(var7_11.getProvinceID(var2_7)).setProvinceStability(CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getProvinceStability() - CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getProvinceStability() / 3.0f);
                                        }
                                        try {
                                            CFG.game.getProvince(var4_8).setHappiness(0.0f);
                                            CFG.game.getProvince(var4_8).setProvinceStability(CFG.game.getProvince(var4_8).getProvinceStability() / 3.0f);
                                            CFG.game.getProvince(var4_8).setLevelOfArmoury(0);
                                            CFG.game.getProvince(var4_8).setLevelOfNuclearReactor(0);
                                            if (CFG.game.getProvince(var4_8).getLevelOfFarm() > 0) {
                                                CFG.game.getProvince(var4_8).setLevelOfFarm(0);
                                            }
                                            if (CFG.game.getProvince(var4_8).getLevelOfFort() > 0) {
                                                CFG.game.getProvince(var4_8).setLevelOfFort(0);
                                            }
                                            if (CFG.game.getProvince(var4_8).getLevelOfPort() > 0) {
                                                CFG.game.getProvince(var4_8).setLevelOfPort(0);
                                            }
                                            if (CFG.game.getProvince(var4_8).getLevelOfLibrary() > 0) {
                                                CFG.game.getProvince(var4_8).setLevelOfLibrary(0);
                                            }
                                            CFG.game.getProvince(var4_8).setLevelOfWatchTower(0);
                                            CFG.game.getProvince(var4_8).setLevelOfSupply(0);
                                            if (CFG.game.getProvince(var4_8).getLevelOfWorkshop() > 0) {
                                                CFG.game.getProvince(var4_8).setLevelOfWorkshop(0);
                                            }
                                            CFG.game.getProvince(var4_8).setDrawNuclearExplosion(true);
                                            Game_Render_Province.updateDrawProvinces();
                                            for (var2_7 = 0; var2_7 < CFG.game.getProvince(var4_8).getArmySize(); ++var2_7) {
                                                if (CFG.game.getProvince(var4_8).getArmy(var2_7) <= 0) continue;
                                                CFG.game.getProvince(var4_8).updateArmy(CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getCivID(), CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() - (CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() / 2 + CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() / 3));
                                            }
                                        }
                                        catch (IndexOutOfBoundsException var7_12) {
                                            CFG.exceptionStack(var7_12);
                                            var7_12.printStackTrace();
                                            continue;
                                        }
                                        CFG.game.getCiv(var1_1).setNuclearWeapons(CFG.game.getCiv(var1_1).getNuclearWeapons() - 1);
                                        CFG.game.getCiv(var1_1).setMoney(CFG.game.getCiv(var1_1).getMoney() - (long)var8_14);
                                        CFG.game.getCiv(var1_1).setMovePoints(CFG.game.getCiv(var1_1).getMovePoints() - var9_15);
                                        CFG.gameAction.updateInGame_ProvinceInfo();
                                        CFG.toast.setInView(CFG.langManager.get("NuclearAttacked"));
                                        CFG.soundsManager.playSound(SoundsManager.SOUND_NUCLEAR_EXPLOSION.get(ThreadLocalRandom.current().nextInt(0, SoundsManager.SOUND_NUCLEAR_EXPLOSION.size())));
                                        var7_11 = new Event_GameData();
                                        var6_10 = new StringBuilder();
                                        var7_11.setEventName(var6_10.append(CFG.game.getProvince(var4_8).getName()).append(" ").append(CFG.langManager.get("InRuines")).toString());
                                        var2_7 = ThreadLocalRandom.current().nextInt(0, 100000);
                                        var6_10 = new StringBuilder();
                                        var7_11.setEventTag(var6_10.append("NuclearExplosionA").append(var2_7).toString());
                                        var7_11.getEvent_PopUp().sText = "Test?";
                                        var7_11.getEvent_PopUp().showPopUp = true;
                                        if (Integer.parseInt(Game_Calendar.getYear()) > 1600) {
                                            var6_10 = new StringBuilder();
                                            var7_11.setEventPicture(var6_10.append("/nuclear_event/nuclearExplosion").append(ThreadLocalRandom.current().nextInt(1, 5)).append(".png").toString());
                                        } else {
                                            var7_11.setEventPicture("/nuclear_event/secret.png");
                                        }
                                        var14_20 = var7_11.getEvent_PopUp();
                                        var6_10 = CFG.langManager;
                                        var15_21 /* !! */  = new StringBuilder();
                                        var14_20.sText = var6_10.get(var15_21 /* !! */ .append("NuclearAttacker").append(ThreadLocalRandom.current().nextInt(1, 2)).toString()).replace("%cDefender", CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getCivName()).replace("%cAttacker", CFG.game.getCiv(var1_1).getCivName()).replace("%cName", CFG.game.getProvince(var4_8).getName());
                                        var6_10 = new Event_Decision();
                                        var6_10.sTitle = CFG.langManager.get("ENOkay").split(";")[ThreadLocalRandom.current().nextInt(1, CFG.langManager.get("ENOkay").split(";").length)];
                                        var7_11.lDecisions.add((Event_Decision)var6_10);
                                        var7_11.setCivID(var1_1);
                                        var7_11.setRepeatable(false);
                                        var7_11.setEventDate_Since(Game_Calendar.currentDay, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                                        var7_11.setEventDate_Until(Game_Calendar.currentDay + 1, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                                        var7_11.setWasTriedToRunOnce(true);
                                        var7_11.setWasFired(false);
                                        System.out.println("Hey!");
                                        CFG.eventsManager.addEvent((Event_GameData)var7_11);
                                        var6_10 = CFG.eventsManager;
                                        var7_11 = new StringBuilder();
                                        var6_10.runEvent_Tag(var7_11.append("NuclearExplosionA").append(var2_7).toString());
                                        var7_11 = new Event_GameData();
                                        var6_10 = new StringBuilder();
                                        var7_11.setEventName(var6_10.append(CFG.game.getProvince(var4_8).getName()).append(" ").append(CFG.langManager.get("InRuines")).toString());
                                        var2_7 = ThreadLocalRandom.current().nextInt(0, 100000);
                                        var6_10 = new StringBuilder();
                                        var7_11.setEventTag(var6_10.append("NuclearExplosionD").append(var2_7).toString());
                                        var7_11.getEvent_PopUp().sText = "Test?";
                                        var7_11.getEvent_PopUp().showPopUp = true;
                                        if (Integer.parseInt(Game_Calendar.getYear()) <= 1600) break block72;
                                        var6_10 = new StringBuilder();
                                        var7_11.setEventPicture(var6_10.append("/nuclear_event/nuclearExplosion").append(ThreadLocalRandom.current().nextInt(1, 5)).append(".png").toString());
                                        break block73;
                                    }
                                    var7_11.setEventPicture("/nuclear_event/secret.png");
                                }
                                var15_21 /* !! */  = var7_11.getEvent_PopUp();
                                var6_10 = CFG.langManager;
                                var14_20 = new StringBuilder();
                                var15_21 /* !! */ .sText = var6_10.get(var14_20.append("NuclearDefender").append(ThreadLocalRandom.current().nextInt(1, 2)).toString()).replace("%cDefender", CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getCivName()).replace("%cAttacker", CFG.game.getCiv(var1_1).getCivName()).replace("%cName", CFG.game.getProvince(var4_8).getName());
                                var6_10 = new Event_Decision();
                                var6_10.sTitle = CFG.langManager.get("ENBad").split(";")[ThreadLocalRandom.current().nextInt(1, CFG.langManager.get("ENBad").split(";").length)];
                                var7_11.lDecisions.add((Event_Decision)var6_10);
                                if (CFG.game.getProvince(var4_8).getCivID() == CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()) {
                                    var7_11.setCivID(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                                } else {
                                    var7_11.setCivID(CFG.game.getProvince(var4_8).getCivID());
                                }
                                var7_11.setRepeatable(false);
                                var7_11.setEventDate_Since(Game_Calendar.currentDay, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                                var7_11.setEventDate_Until(Game_Calendar.currentDay + 10, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                                var7_11.setWasTriedToRunOnce(true);
                                var7_11.setWasFired(false);
                                CFG.eventsManager.addEvent((Event_GameData)var7_11);
                                var7_11 = CFG.eventsManager;
                                var6_10 = new StringBuilder();
                                var7_11.runEvent_Tag(var6_10.append("NuclearExplosionD").append(var2_7).toString());
                                CFG.menuManager.updateInGame_TOP_All(var1_1);
                                CFG.menuManager.setVisible_InGame_ProvinceAction_NuclearAttack(false);
                                CFG.menuManager.setVisible_InGame_ProvinceAction_NuclearAttack(true);
                                CFG.game.getCiv(var1_1).setAtNuclearWar();
                                CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).setAtNuclearWar();
                                continue block20;
                            }
                            for (var2_7 = 0; var2_7 < CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getNumOfProvinces(); ++var2_7) {
                                var7_11 = CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID());
                                if (CFG.game.getProvince(var7_11.getProvinceID(var2_7)).isOccupied()) continue;
                                CFG.game.getProvince(var7_11.getProvinceID(var2_7)).setHappiness(CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getHappiness() - CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getHappiness() / 3.0f);
                                CFG.game.getProvince(var7_11.getProvinceID(var2_7)).setProvinceStability(CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getProvinceStability() - CFG.game.getProvince(var7_11.getProvinceID(var2_7)).getProvinceStability() / 3.0f);
                            }
                            try {
                                CFG.game.getProvince(var4_8).setHappiness(0.0f);
                                CFG.game.getProvince(var4_8).setProvinceStability(CFG.game.getProvince(var4_8).getProvinceStability() / 3.0f);
                                CFG.game.getProvince(var4_8).setLevelOfArmoury(0);
                                CFG.game.getProvince(var4_8).setLevelOfNuclearReactor(0);
                                if (CFG.game.getProvince(var4_8).getLevelOfFarm() > 0) {
                                    CFG.game.getProvince(var4_8).setLevelOfFarm(ThreadLocalRandom.current().nextInt(0, CFG.game.getProvince(var4_8).getLevelOfFarm()));
                                }
                                if (CFG.game.getProvince(var4_8).getLevelOfFort() > 0) {
                                    CFG.game.getProvince(var4_8).setLevelOfFort(ThreadLocalRandom.current().nextInt(0, CFG.game.getProvince(var4_8).getLevelOfFort()));
                                }
                                if (CFG.game.getProvince(var4_8).getLevelOfPort() > 0) {
                                    CFG.game.getProvince(var4_8).setLevelOfPort(0);
                                }
                                if (CFG.game.getProvince(var4_8).getLevelOfLibrary() > 0) {
                                    CFG.game.getProvince(var4_8).setLevelOfLibrary(ThreadLocalRandom.current().nextInt(0, CFG.game.getProvince(var4_8).getLevelOfLibrary()));
                                }
                                CFG.game.getProvince(var4_8).setLevelOfWatchTower(0);
                                CFG.game.getProvince(var4_8).setLevelOfSupply(0);
                                if (CFG.game.getProvince(var4_8).getLevelOfWorkshop() > 0) {
                                    CFG.game.getProvince(var4_8).setLevelOfWorkshop(ThreadLocalRandom.current().nextInt(0, CFG.game.getProvince(var4_8).getLevelOfWorkshop()));
                                }
                                CFG.game.getProvince(var4_8).setDrawNuclearExplosion(true);
                                Game_Render_Province.updateDrawProvinces();
                                for (var2_7 = 0; var2_7 < CFG.game.getProvince(var4_8).getArmySize(); ++var2_7) {
                                    if (CFG.game.getProvince(var4_8).getArmy(var2_7) <= 0) continue;
                                    CFG.game.getProvince(var4_8).updateArmy(CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getCivID(), CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() - (CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() / 3 + CFG.game.getProvince(var4_8).getArmy_Obj(var2_7).getArmy() / 4));
                                }
                            }
                            catch (IndexOutOfBoundsException var7_13) {
                                CFG.exceptionStack(var7_13);
                                var7_13.printStackTrace();
                                continue;
                            }
                            CFG.game.getCiv(var1_1).setNuclearWeapons(CFG.game.getCiv(var1_1).getNuclearWeapons() - 1);
                            CFG.game.getCiv(var1_1).setMoney(CFG.game.getCiv(var1_1).getMoney() - (long)var8_14);
                            CFG.game.getCiv(var1_1).setMovePoints(CFG.game.getCiv(var1_1).getMovePoints() - var9_15);
                            CFG.gameAction.updateInGame_ProvinceInfo();
                            CFG.toast.setInView(CFG.langManager.get("NuclearAttacked"));
                            if (!CFG.game.getCivsAtWar(CFG.game.getProvince(var4_8).getCivID(), var1_1)) {
                                CFG.game.declareWar(var1_1, CFG.game.getProvince(var4_8).getCivID(), false);
                                CFG.toast.setInView(CFG.langManager.get("IsWar"), Color.RED);
                                CFG.game.getCiv(var1_1).setAtNuclearWar();
                                CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).setAtNuclearWar();
                            }
                            CFG.soundsManager.playSound(SoundsManager.SOUND_NUCLEAR_EXPLOSION.get(ThreadLocalRandom.current().nextInt(0, SoundsManager.SOUND_NUCLEAR_EXPLOSION.size())));
                            var7_11 = new Event_GameData();
                            var6_10 = new StringBuilder();
                            var7_11.setEventName(var6_10.append(CFG.game.getProvince(var4_8).getName()).append(" ").append(CFG.langManager.get("InRuines")).toString());
                            var2_7 = ThreadLocalRandom.current().nextInt(0, 100000);
                            var6_10 = new StringBuilder();
                            var7_11.setEventTag(var6_10.append("NuclearExplosionA").append(var2_7).toString());
                            var7_11.getEvent_PopUp().sText = "Test?";
                            var7_11.getEvent_PopUp().showPopUp = true;
                            if (Integer.parseInt(Game_Calendar.getYear()) > 1600) {
                                var6_10 = new StringBuilder();
                                var7_11.setEventPicture(var6_10.append("/nuclear_event/nuclearExplosion").append(ThreadLocalRandom.current().nextInt(1, 5)).append(".png").toString());
                            } else {
                                var7_11.setEventPicture("/nuclear_event/secret.png");
                            }
                            var6_10 = var7_11.getEvent_PopUp();
                            var14_20 = CFG.langManager;
                            var15_21 /* !! */  = new StringBuilder();
                            var6_10.sText = var14_20.get(var15_21 /* !! */ .append("NuclearAttacker").append(ThreadLocalRandom.current().nextInt(1, 2)).toString()).replace("%cDefender", CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getCivName()).replace("%cAttacker", CFG.game.getCiv(var1_1).getCivName()).replace("%cName", CFG.game.getProvince(var4_8).getName());
                            var6_10 = new Event_Decision();
                            var6_10.sTitle = CFG.langManager.get("ENOkay").split(";")[ThreadLocalRandom.current().nextInt(1, CFG.langManager.get("ENOkay").split(";").length)];
                            var7_11.lDecisions.add((Event_Decision)var6_10);
                            var7_11.setCivID(var1_1);
                            var7_11.setRepeatable(false);
                            var7_11.setEventDate_Since(Game_Calendar.currentDay, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                            var7_11.setEventDate_Until(Game_Calendar.currentDay + 1, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                            var7_11.setWasTriedToRunOnce(true);
                            var7_11.setWasFired(false);
                            System.out.println("Hey!");
                            CFG.eventsManager.addEvent((Event_GameData)var7_11);
                            var6_10 = CFG.eventsManager;
                            var7_11 = new StringBuilder();
                            var6_10.runEvent_Tag(var7_11.append("NuclearExplosionA").append(var2_7).toString());
                            var7_11 = new Event_GameData();
                            var6_10 = new StringBuilder();
                            var7_11.setEventName(var6_10.append(CFG.game.getProvince(var4_8).getName()).append(" ").append(CFG.langManager.get("InRuines")).toString());
                            var2_7 = ThreadLocalRandom.current().nextInt(0, 100000);
                            var6_10 = new StringBuilder();
                            var7_11.setEventTag(var6_10.append("NuclearExplosionD").append(var2_7).toString());
                            var7_11.getEvent_PopUp().sText = "Test?";
                            var7_11.getEvent_PopUp().showPopUp = true;
                            if (Integer.parseInt(Game_Calendar.getYear()) <= 1600) break block74;
                            var6_10 = new StringBuilder();
                            var7_11.setEventPicture(var6_10.append("/nuclear_event/nuclearExplosion").append(ThreadLocalRandom.current().nextInt(1, 5)).append(".png").toString());
                            break block75;
                        }
                        var7_11.setEventPicture("/nuclear_event/secret.png");
                    }
                    var15_21 /* !! */  = var7_11.getEvent_PopUp();
                    var14_20 = CFG.langManager;
                    var6_10 = new StringBuilder();
                    var15_21 /* !! */ .sText = var14_20.get(var6_10.append("NuclearDefender").append(ThreadLocalRandom.current().nextInt(1, 2)).toString()).replace("%cDefender", CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).getCivName()).replace("%cAttacker", CFG.game.getCiv(var1_1).getCivName()).replace("%cName", CFG.game.getProvince(var4_8).getName());
                    var6_10 = new Event_Decision();
                    var6_10.sTitle = CFG.langManager.get("ENBad").split(";")[ThreadLocalRandom.current().nextInt(1, CFG.langManager.get("ENBad").split(";").length)];
                    var7_11.lDecisions.add((Event_Decision)var6_10);
                    if (CFG.game.getProvince(var4_8).getCivID() == CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()) {
                        var7_11.setCivID(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                    } else {
                        var7_11.setCivID(CFG.game.getProvince(var4_8).getCivID());
                    }
                    var7_11.setRepeatable(false);
                    var7_11.setEventDate_Since(Game_Calendar.currentDay, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                    var7_11.setEventDate_Until(Game_Calendar.currentDay + 1, Game_Calendar.currentMonth, Game_Calendar.currentYear);
                    var7_11.setWasTriedToRunOnce(true);
                    var7_11.setWasFired(false);
                    CFG.eventsManager.addEvent((Event_GameData)var7_11);
                    var6_10 = CFG.eventsManager;
                    var7_11 = new StringBuilder();
                    var6_10.runEvent_Tag(var7_11.append("NuclearExplosionD").append(var2_7).toString());
                    CFG.menuManager.updateInGame_TOP_All(var1_1);
                    CFG.menuManager.setVisible_InGame_ProvinceAction_NuclearAttack(false);
                    CFG.menuManager.setVisible_InGame_ProvinceAction_NuclearAttack(true);
                    CFG.game.getCiv(var1_1).setAtNuclearWar();
                    CFG.game.getCiv(CFG.game.getProvince(var4_8).getCivID()).setAtNuclearWar();
                    continue block20;
                }
            }
        }
        Gdx.app.log(this.TAG, "AI -> turnOrders -> END, " + CFG.game.getCiv(var1_1).getCivName());
        CFG.game.getCiv((int)var1_1).civGameData.moveAtWar_ProvincesLostAndConquered_LastTurn = 0;
    }

    protected final void turnOrdersEssential(int n) {
        this.respondToEvents(n);
        this.updateSentMessages(n);
        this.respondToMessages(n);
        this.diplomacyActions(n);
        this.manageBudget(n);
        this.updateLiberityDesire(n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void updateLiberityDesire(int n) {
        if (CFG.game.getCiv(n).getPuppetOfCivID() != n) {
            boolean bl;
            boolean bl2 = bl = true;
            try {
                if ((float)CFG.game.getCiv(n).getNumOfProvinces() > (float)CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getNumOfProvinces() * 0.85f) {
                    CFG.game.getCiv(n).setVassalLiberityDesire(CFG.game.getCiv(n).getVassalLiberityDesire() + ((float)CFG.oR.nextInt(825) / 1000.0f + 0.425f) * ((float)(CFG.game.getCiv(n).getNumOfProvinces() / CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getNumOfProvinces()) * 0.85f));
                    bl2 = false;
                }
            }
            catch (ArithmeticException arithmeticException) {
                bl2 = bl;
            }
            try {
                if ((float)CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getVassal_Tribute(n) > CFG.game.getCiv((int)n).civGameData.civPersonality.LIBERITY_ACCEPTABLE_TRIBUTE * 20.0f) {
                    CFG.game.getCiv(n).setVassalLiberityDesire(CFG.game.getCiv(n).getVassalLiberityDesire() + CFG.game.getCiv(n).getVassalLiberityDesire() * 0.01f + ((float)CFG.oR.nextInt(100) / 100.0f + 0.325f) * (float)(CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getVassal_Tribute(n) / 20));
                    bl = false;
                } else {
                    bl = bl2;
                    if ((float)CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getVassal_Tribute(n) < CFG.game.getCiv((int)n).civGameData.civPersonality.LIBERITY_ACCEPTABLE_TRIBUTE * 20.0f * 0.5f) {
                        CFG.game.getCiv(n).setVassalLiberityDesire(CFG.game.getCiv(n).getVassalLiberityDesire() - ((float)CFG.oR.nextInt(125) / 100.0f + 0.075f) * (float)(CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getVassal_Tribute(n) / 20));
                        bl = bl2;
                    }
                }
            }
            catch (ArithmeticException arithmeticException) {
                bl = bl2;
            }
            bl2 = bl;
            try {
                if (CFG.game.getCivRelation_OfCivB(n, CFG.game.getCiv(n).getPuppetOfCivID()) < -10.0f) {
                    CFG.game.getCiv(n).setVassalLiberityDesire(CFG.game.getCiv(n).getVassalLiberityDesire() + Math.abs(CFG.game.getCivRelation_OfCivB(n, CFG.game.getCiv(n).getPuppetOfCivID()) / 100.0f) * 3.425f);
                    bl2 = false;
                }
            }
            catch (ArithmeticException arithmeticException) {
                bl2 = bl;
            }
            if (bl2) {
                CFG.game.getCiv(n).setVassalLiberityDesire(CFG.game.getCiv(n).getVassalLiberityDesire() - CFG.game.getCiv(n).getVassalLiberityDesire() * 0.01f);
            }
            if (CFG.game.getCiv(n).getVassalLiberityDesire() > CFG.game.getCiv((int)n).civGameData.civPersonality.LIBERITY_DECLARATION) {
                DiplomacyManager.declarationOfIndependeceByVassal(CFG.game.getCiv(n).getPuppetOfCivID(), n);
            }
        }
    }

    protected void updateMilitarySpendings(int n) {
        CFG.game.getCiv((int)n).iMilitaryUpkeep_Total = (int)CFG.game_NextTurnUpdate.getMilitaryUpkeep_Total(n);
        CFG.game.getCiv((int)n).iMilitaryUpkeep_PERC = CFG.game.getCiv((int)n).iBudget <= 0 && CFG.game.getCiv(n).getNumOfUnits() > 0 ? 100.0f : Math.max(0.0f, (float)CFG.game.getCiv((int)n).iMilitaryUpkeep_Total / (float)CFG.game.getCiv((int)n).iBudget);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void updateSentMessages(int n) {
        try {
            int n2 = CFG.game.getCiv(n).getSentMessagesSize() - 1;
            while (n2 >= 0) {
                if (1.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Message_Type[CFG.game.getCiv((int)n).getSentMessage((int)n2).messageType.ordinal()] != 11 && Game_Calendar.TURN_ID - CFG.game.getCiv((int)n).getSentMessage((int)n2).iSentInTurnID > CFG.game.getCiv((int)n).getCivPersonality().SENT_MESSAGES_DEFAULT_TURNS) {
                    CFG.game.getCiv(n).removeSentMessage(n2);
                }
                --n2;
            }
            return;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
        }
    }

    protected final void useTechnologyPoints(int n) {
        int n2 = CFG.game.getCiv((int)n).civGameData.skills.CASE;
        int n3 = 6 * n2;
        int n4 = 5 * n2;
        if (CFG.game.getCiv((int)n).civGameData.skills.getPointsLeft(n) > 0) {
            ArrayList<AI_Skills> arrayList = new ArrayList<AI_Skills>();
            arrayList.add(new AI_Skills(CFG.game.getCiv((int)n).civGameData.skills.POINTS_POP_GROWTH, n4));
            arrayList.add(new AI_Skills_Eco(CFG.game.getCiv((int)n).civGameData.skills.POINTS_ECONOMY_GROWTH, n4));
            arrayList.add(new AI_Skills_Taxation(CFG.game.getCiv((int)n).civGameData.skills.POINTS_INCOME_TAXATION, n4));
            arrayList.add(new AI_Skills_Production(CFG.game.getCiv((int)n).civGameData.skills.POINTS_INCOME_PRODUCTION, n4));
            arrayList.add(new AI_Skills_Administration(CFG.game.getCiv((int)n).civGameData.skills.POINTS_ADMINISTRATION, 4 * n2));
            arrayList.add(new AI_Skills_Military(CFG.game.getCiv((int)n).civGameData.skills.POINTS_MILITARY_UPKEEP, n3));
            arrayList.add(new AI_Skills_Research(CFG.game.getCiv((int)n).civGameData.skills.POINTS_RESEARCH, n3));
            n3 = CFG.game.getCiv((int)n).civGameData.skills.getPointsLeft(n);
            int n5 = arrayList.size();
            if (CFG.game.getCiv((int)n).civGameData.skills.POINTS_COLONIZATION < 4 * n2) {
                SkillsManager.add_Colonization(n);
                --n3;
            }
            while (n3 > 0) {
                int n6 = 0;
                for (n2 = 0 + 1; n2 < n5; ++n2) {
                    n4 = n6;
                    if (((AI_Skills)arrayList.get(n6)).getScore(n) < ((AI_Skills)arrayList.get(n2)).getScore(n)) {
                        n4 = n2;
                    }
                    n6 = n4;
                }
                ((AI_Skills)arrayList.get(n6)).addPoint_CivID(n);
                --n3;
            }
        }
    }
}

