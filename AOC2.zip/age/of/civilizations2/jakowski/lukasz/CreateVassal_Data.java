/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.GdxRuntimeException;

class CreateVassal_Data {
    private Image flagOfCivilization = null;
    private Image flagOfCivilizationH = null;
    protected int iCapitalProvinceID = -1;
    protected Color oColor = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    protected boolean playAsVassal = false;
    protected String sCivTag = null;

    CreateVassal_Data() {
    }

    protected final void dispose() {
        Image image = this.flagOfCivilizationH;
        if (image != null) {
            image.getTexture().dispose();
            this.flagOfCivilizationH = null;
        }
        if ((image = this.flagOfCivilization) != null) {
            image.getTexture().dispose();
            this.flagOfCivilization = null;
        }
    }

    protected final Image getFlagOfCiv() {
        return this.flagOfCivilization;
    }

    protected final Image getFlagOfCivH() {
        Image image;
        Image image2 = image = this.flagOfCivilizationH;
        if (image == null) {
            image2 = this.flagOfCivilization;
        }
        return image2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void loadFlag() {
        block23: {
            this.dispose();
            if (this.sCivTag == null) {
                return;
            }
            try {
                try {
                    var3_18 = Gdx.files;
                    var4_19 = new StringBuilder();
                    var4_19.append("game/flagsH/");
                    var4_19.append(this.sCivTag);
                    var4_19.append(".png");
                    var2_17 = new Texture(var3_18.internal(var4_19.toString()));
                    this.flagOfCivilizationH = var1_1 = new Image((Texture)var2_17, Texture.TextureFilter.Linear);
                }
                catch (GdxRuntimeException var1_2) {
                    try {
                        var3_18 = Gdx.files;
                        var1_1 = new StringBuilder();
                        var1_1.append("game/flagsH/");
                        var1_1.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var1_1.append(".png");
                        var4_19 = new Texture(var3_18.internal(var1_1.toString()));
                        this.flagOfCivilizationH = var2_17 = new Image((Texture)var4_19, Texture.TextureFilter.Linear);
                    }
                    catch (GdxRuntimeException var1_3) {
                        var5_20 = CFG.isAndroid();
                        if (!var5_20) ** GOTO lbl67
                        try {
                            var4_19 = Gdx.files;
                            var2_17 = new StringBuilder();
                            var2_17.append("game/civilizations_editor/");
                            var2_17.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                            var2_17.append("/");
                            var2_17.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                            var2_17.append("_FLH.png");
                            var1_1 = new Texture(var4_19.local(var2_17.toString()));
                            this.flagOfCivilizationH = var3_18 = new Image((Texture)var1_1, Texture.TextureFilter.Linear);
                        }
                        catch (GdxRuntimeException var1_4) {
                            try {
                                var2_17 = Gdx.files;
                                var4_19 = new StringBuilder();
                                var4_19.append("game/civilizations_editor/");
                                var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                                var4_19.append("/");
                                var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                                var4_19.append("_FLH.png");
                                var1_1 = new Texture(var2_17.internal(var4_19.toString()));
                                this.flagOfCivilizationH = var3_18 = new Image((Texture)var1_1, Texture.TextureFilter.Linear);
                                break block23;
lbl67:
                                // 1 sources

                                var2_17 = Gdx.files;
                                var3_18 = new StringBuilder();
                                var3_18.append("game/civilizations_editor/");
                                var3_18.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                                var3_18.append("/");
                                var3_18.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                                var3_18.append("_FLH.png");
                                var1_1 = new Texture(var2_17.internal(var3_18.toString()));
                                this.flagOfCivilizationH = var4_19 = new Image((Texture)var1_1, Texture.TextureFilter.Linear);
                            }
                            catch (GdxRuntimeException var1_6) {
                                this.dispose();
                            }
                        }
                    }
                }
            }
            catch (OutOfMemoryError var1_5) {
                this.dispose();
            }
        }
        try {
            try {
                var2_17 = Gdx.files;
                var4_19 = new StringBuilder();
                var4_19.append("game/flags/");
                var4_19.append(this.sCivTag);
                var4_19.append(".png");
                var3_18 = new Texture(var2_17.internal(var4_19.toString()));
                this.flagOfCivilization = var1_1 = new Image((Texture)var3_18, Texture.TextureFilter.Linear);
                return;
            }
            catch (GdxRuntimeException var1_7) {
                try {
                    var2_17 = Gdx.files;
                    var1_8 = new StringBuilder();
                    var1_8.append("game/flags/");
                    var1_8.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                    var1_8.append(".png");
                    var4_19 = new Texture(var2_17.internal(var1_8.toString()));
                    this.flagOfCivilization = var3_18 = new Image((Texture)var4_19, Texture.TextureFilter.Linear);
                    return;
                }
                catch (GdxRuntimeException var1_9) {
                    var5_20 = CFG.isAndroid();
                    if (!var5_20) ** GOTO lbl154
                    {
                        catch (GdxRuntimeException var1_15) {
                            this.dispose();
                            return;
                        }
                    }
                    try {
                        var1_10 = Gdx.files;
                        var3_18 = new StringBuilder();
                        var3_18.append("game/civilizations_editor/");
                        var3_18.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var3_18.append("/");
                        var3_18.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var3_18.append("_FL.png");
                        var4_19 = new Texture(var1_10.local(var3_18.toString()));
                        this.flagOfCivilization = var2_17 = new Image((Texture)var4_19, Texture.TextureFilter.Linear);
                        return;
                    }
                    catch (GdxRuntimeException var1_11) {
                        var1_12 = Gdx.files;
                        var4_19 = new StringBuilder();
                        var4_19.append("game/civilizations_editor/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var4_19.append("/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var4_19.append("_FL.png");
                        var3_18 = new Texture(var1_12.internal(var4_19.toString()));
                        this.flagOfCivilization = var2_17 = new Image((Texture)var3_18, Texture.TextureFilter.Linear);
                        return;
lbl154:
                        // 1 sources

                        var2_17 = Gdx.files;
                        var4_19 = new StringBuilder();
                        var4_19.append("game/civilizations_editor/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var4_19.append("/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(this.sCivTag));
                        var4_19.append("_FL.png");
                        var1_13 = new Texture(var2_17.internal(var4_19.toString()));
                        this.flagOfCivilization = var3_18 = new Image(var1_13, Texture.TextureFilter.Linear);
                        return;
                    }
                }
            }
        }
        catch (OutOfMemoryError var1_14) {
            this.dispose();
            return;
        }
    }

    protected final void setCivTag(String string2) {
        this.sCivTag = string2;
        this.loadFlag();
    }
}

