/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.MenuElement;

class Button_Transparent
extends Button {
    protected Button_Transparent(int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init("", n, n2, n3, n4, n5, bl, true, false, false, null);
        this.typeOfElement = MenuElement.TypeOfElement.BUTTON_TRANSPARENT;
    }

    protected Button_Transparent(int n, int n2, int n3, int n4, boolean bl) {
        super.init("", 0, n, n2, n3, n4, bl, true, false, false, null);
        this.typeOfElement = MenuElement.TypeOfElement.BUTTON_TRANSPARENT;
    }
}

