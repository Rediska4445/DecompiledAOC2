/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Terrain;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_View_Army
extends Button {
    protected static final float FONT_SIZE = 0.7f;
    protected static final float FONT_SIZE2 = 0.6f;
    private boolean drawSupply;
    private int iPopulation;
    private int iPopulationPerc;
    private int iPopulationPercWidth;
    private int iPopulationWidth;
    private int iProvinceID;
    private boolean row;

    protected Button_View_Army(int n, String object, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        this.iPopulationPercWidth = 0;
        this.drawSupply = false;
        super.init((String)object, 0, n5, n6, n7, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        boolean bl2 = n % 2 == 0;
        this.row = bl2;
        this.iProvinceID = n2;
        bl2 = bl;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfSupply() > 0) {
            bl2 = true;
        }
        this.drawSupply = bl2;
        this.iPopulation = CFG.game.getProvince(this.iProvinceID).getArmyCivID(n3);
        Object object2 = CFG.glyphLayout;
        object = CFG.fontMain;
        Object object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(this.iPopulation);
        ((GlyphLayout)object2).setText((BitmapFont)object, ((StringBuilder)object3).toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.iPopulationPerc = n4;
        object = CFG.glyphLayout;
        object3 = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(this.iPopulationPerc);
        ((GlyphLayout)object).setText((BitmapFont)object3, ((StringBuilder)object2).toString());
        this.iPopulationPercWidth = (int)(CFG.glyphLayout.width * 0.6f);
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.6f / (float)n;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()));
        Object object = CFG.game.getProvince(this.iProvinceID).getName().length() > 0 ? CFG.game.getProvince(this.iProvinceID).getName() : CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getCivName();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)object, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Army"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        StringBuilder stringBuilder = new StringBuilder();
        object = "";
        stringBuilder.append("");
        CharSequence charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append(this.iPopulation);
        stringBuilder.append(CFG.getNumberWithSpaces(charSequence.toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID(), CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        charSequence.append(CFG.langManager.get("MilitaryUpkeep"));
        charSequence.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString()));
        charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append(this.iPopulationPerc);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append((float)((int)((float)this.iPopulationPerc / (float)this.iPopulation * 100.0f)) / 100.0f);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString(), CFG.COLOR_INGAME_GOLD));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, CFG.PADDING));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("PerUnit")));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        charSequence.append(CFG.langManager.get("Development"));
        charSequence.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString()));
        charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append((float)((int)(CFG.game.getProvince(this.iProvinceID).getDevelopmentLevel() * 100.0f)) / 100.0f);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.development, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        if (CFG.terrainTypesManager.getMilitaryUpkeep(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) != 0.0f) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Terrain(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.terrainTypesManager.getName(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            charSequence = new StringBuilder();
            charSequence.append(CFG.langManager.get("MilitaryUpkeep"));
            charSequence.append(": ");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(charSequence.toString()));
            charSequence = new StringBuilder();
            charSequence.append("");
            if (CFG.terrainTypesManager.getMilitaryUpkeep(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) > 0.0f) {
                object = "+";
            }
            charSequence.append((String)object);
            charSequence.append((int)(CFG.terrainTypesManager.getMilitaryUpkeep(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) * 100.0f));
            charSequence.append("%");
            charSequence = charSequence.toString();
            object = CFG.terrainTypesManager.getMilitaryUpkeep(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) == 0.0f ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : (CFG.terrainTypesManager.getMilitaryUpkeep(CFG.game.getProvince(this.iProvinceID).getTerrainTypeID()) < 0.0f ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, (Color)object));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.7f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iPopulation);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) / 2 + n2 - ImageManager.getImage(Images.top_gold).getHeight(), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())));
        if (this.drawSupply) {
            ImageManager.getImage(Images.b_supply).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) - (int)((float)ImageManager.getImage(Images.b_supply).getWidth() * this.getImageScale(ImageManager.getImage(Images.b_supply).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_supply).getHeight() * this.getImageScale(ImageManager.getImage(Images.b_supply).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_supply).getHeight(), (int)((float)ImageManager.getImage(Images.b_supply).getWidth() * this.getImageScale(ImageManager.getImage(Images.b_supply).getHeight())), (int)((float)ImageManager.getImage(Images.b_supply).getHeight() * this.getImageScale(ImageManager.getImage(Images.b_supply).getHeight())));
        }
        CFG.fontMain.getData().setScale(0.6f);
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iPopulationPerc);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

