/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy_Opinion;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Diplomacy_Opinion2
extends Button_Diplomacy_Opinion {
    private int iText2Width = 0;
    private String sText2;
    protected Color textColor2;

    protected Button_Diplomacy_Opinion2(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, boolean bl) {
        super(n, n2, n4, n5, n6, n7, n8, bl);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n3);
        this.sText2 = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sText2);
        this.iText2Width = (int)CFG.glyphLayout.width;
        this.textColor2 = this.getOpinionColor(n3);
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.getActiveCivInfo());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_relations, 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID, 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("Opinion"));
            ((StringBuilder)object).append(": ");
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append((float)((int)(CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.iCivID) * 10.0f)) / 10.0f);
            String string2 = ((StringBuilder)object).toString();
            object = CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.iCivID) > 0.0f ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.iCivID) == 0.0f ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : CFG.COLOR_TEXT_MODIFIER_NEGATIVE);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(string2, (Color)object);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            object = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_relations, 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.getActiveCivInfo(), 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("Opinion"));
            ((StringBuilder)object2).append(": ");
            object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append((float)((int)(CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.getActiveCivInfo()) * 10.0f)) / 10.0f);
            string2 = ((StringBuilder)object).toString();
            object = CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.getActiveCivInfo()) > 0.0f ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.getActiveCivInfo()) == 0.0f ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : CFG.COLOR_TEXT_MODIFIER_NEGATIVE);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(string2, (Color)object);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() - CFG.CIV_FLAG_HEIGHT / 2 + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawText(spriteBatch, CFG.game.getCiv(this.iCivID).getCivName(), this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.getColor(bl));
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + this.getWidth() - (int)((float)this.getTextWidth() * 0.6f) - CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.textColor);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

