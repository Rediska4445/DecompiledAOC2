/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_TodayPartOf
extends Button {
    private int iCivID;
    private int iPercWidth = 0;
    private boolean row = false;
    private String sPerc;

    protected Button_TodayPartOf(int n, String string2, int n2, int n3, int n4, int n5, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        CharSequence charSequence = n < 0 ? CFG.langManager.get("Undiscovered") : CFG.game.getCiv(n).getCivName();
        stringBuilder.append((String)charSequence);
        super.init(stringBuilder.toString(), 0, n2, n3, n4, n5, bl, true, false, false, null);
        this.iCivID = n;
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("[");
        ((StringBuilder)charSequence).append(string2);
        ((StringBuilder)charSequence).append("%]");
        this.sPerc = ((StringBuilder)charSequence).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sPerc);
        this.iPercWidth = (int)CFG.glyphLayout.width;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        Object object = new ArrayList();
        int n = 0;
        int n2 = 0;
        while (true) {
            if (n >= CFG.formableCivs_GameData.getProvincesSize()) break;
            int n3 = n2;
            if (CFG.game.getProvince(CFG.formableCivs_GameData.getProvinceID(n)).getCivID() == this.iCivID) {
                n3 = n2 + 1;
            }
            ++n;
            n2 = n3;
            continue;
            break;
        }
        try {
            Object object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivID).getCivName());
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(CFG.langManager.get("Provinces"));
            stringBuilder.append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString());
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            stringBuilder = new StringBuilder();
            stringBuilder.append(" ");
            stringBuilder.append(this.sPerc);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            if (!bl && !this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.9f));
            } else {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.65f));
            }
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            spriteBatch.setColor(Color.WHITE);
        } else {
            if (!bl && !this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.625f));
            } else {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.475f));
            }
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, true, false);
            spriteBatch.setColor(Color.WHITE);
        }
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + this.getWidth() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + this.getWidth() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + this.getWidth() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + this.getWidth() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.sText, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH - CFG.PADDING - (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sPerc, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH - CFG.PADDING - (int)((float)this.getTextWidth() * 0.7f) - CFG.PADDING - (int)((float)this.iPercWidth * 0.6f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, new Color(0.56f, 0.56f, 0.56f, 1.0f));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.56f, 0.56f, 0.56f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(0.68f, 0.68f, 0.68f, 1.0f) : new Color(0.82f, 0.82f, 0.82f, 1.0f)) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = n == 0;
        this.row = bl;
    }
}

