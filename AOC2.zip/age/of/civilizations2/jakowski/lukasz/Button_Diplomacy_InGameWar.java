/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_WarDetails;
import age.of.civilizations2.jakowski.lukasz.ViewsManager;
import java.util.List;

class Button_Diplomacy_InGameWar
extends Button_Diplomacy {
    protected Button_Diplomacy_InGameWar(int n, List<Integer> list, int n2, int n3, int n4) {
        super(n, list, n2, n3, n4);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void setAnotherView(boolean bl) {
        if (this.iHoveredID < 0) return;
        int n = CFG.game.getWarID(CFG.getActiveCivInfo(), (Integer)this.lCivs.get(this.iHoveredID));
        if (n >= 0 && n < CFG.game.getWarsSize()) {
            Menu_InGame_WarDetails.WAR_ID = n;
            CFG.menuManager.rebuildInGame_WarDetails();
            return;
        }
        CFG.game.disableDrawCivilizationRegions(CFG.getActiveCivInfo());
        CFG.setActiveCivInfo((Integer)this.lCivs.get(this.iHoveredID));
        try {
            CFG.game.setActiveProvinceID(CFG.game.getCiv(CFG.getActiveCivInfo()).getCapitalProvinceID());
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        CFG.updateActiveCivInfo_InGame();
        if (CFG.viewsManager.getActiveViewID() != ViewsManager.VIEW_DIPLOMACY_MODE) return;
        CFG.game.enableDrawCivilizationRegions(CFG.getActiveCivInfo(), 1);
    }
}

