/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Invest_Development;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option_Invest_Development
extends AI_Build_Option {
    AI_Build_Option_Invest_Development() {
    }

    @Override
    protected AI_Build getData(int n) {
        return new AI_Build_Invest_Development(n, this.getMoney(n));
    }

    @Override
    protected float getScore(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_INVEST_DEVELOPMENT * (1.0f - (float)(CFG.game.getCiv(n).getInvestsSize_Development() * 2) / (float)CFG.game.getCiv(n).getNumOfProvinces()) * ((1.0f - CFG.game.getCiv((int)n).fAverageDevelopment / CFG.game.getCiv(n).getTechnologyLevel()) * 0.45f + 0.65f);
    }
}

