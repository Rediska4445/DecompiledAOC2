/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_BotBar
extends Button {
    protected float FONT_SCALE = 0.8f;
    protected int iMinWidth = 0;

    protected Button_BotBar(String string2, float f, int n, int n2, int n3, boolean bl, boolean bl2) {
        super.init(string2, CFG.PADDING, n, n2, n3, ImageManager.getImage(Images.bot_left).getHeight(), bl, bl2, false, false, null);
        this.FONT_SCALE = f;
        this.iMinWidth = n3;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.bot_left).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.bot_left).getHeight() + n2, this.getWidth() + ImageManager.getImage(Images.bot_left).getWidth() / 2, this.getHeight(), true, true);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.56f, 0.56f, 0.56f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(0.68f, 0.68f, 0.68f, 1.0f) : new Color(0.82f, 0.82f, 0.82f, 1.0f)) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    public void setText(String string2) {
        block3: {
            this.sText = string2;
            this.setWidth(this.iMinWidth);
            try {
                CFG.glyphLayout.setText(CFG.fontMain, string2);
                this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
                this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
                if (super.getWidth() < this.iTextWidth + CFG.PADDING * 2) {
                    this.setWidth(this.iTextWidth + CFG.PADDING * 2);
                }
            }
            catch (NullPointerException nullPointerException) {
                if (!CFG.LOGS) break block3;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }
}

