/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_ViewIcon
extends Button {
    protected Button_ViewIcon(int n, int n2, boolean bl) {
        super.init("", -1, n, n2, 25, 10, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }
}

