/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Color_GameData;
import java.io.Serializable;

class DiplomacyColors_GameData2
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected Color_GameData COLOR_DIPLOMACY_ALLIANCE;
    protected Color_GameData COLOR_DIPLOMACY_AT_WAR;
    protected Color_GameData COLOR_DIPLOMACY_DEFENSIVE_PACT;
    protected Color_GameData COLOR_DIPLOMACY_INDEPENDENCE;
    protected Color_GameData COLOR_DIPLOMACY_MILITARY_ACCESS;
    protected Color_GameData[] COLOR_DIPLOMACY_NEGATIVE;
    protected Color_GameData COLOR_DIPLOMACY_NEUTRAL;
    protected Color_GameData COLOR_DIPLOMACY_OWN_PROVINCES;
    protected Color_GameData COLOR_DIPLOMACY_PACT;
    protected Color_GameData COLOR_DIPLOMACY_PACT_MAX;
    protected Color_GameData[] COLOR_DIPLOMACY_POSITIVE;
    protected Color_GameData COLOR_DIPLOMACY_VASSAL;
    private String sName = "";

    DiplomacyColors_GameData2() {
    }

    protected final String getName() {
        return this.sName;
    }

    protected final void setName(String string2) {
        this.sName = string2;
    }
}

