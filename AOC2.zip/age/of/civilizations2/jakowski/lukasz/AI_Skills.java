/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.SkillsManager;

class AI_Skills {
    protected int iPoints;
    protected int iPointsMax;

    protected AI_Skills(int n, int n2) {
        this.iPoints = n;
        this.iPointsMax = n2;
    }

    protected void addPoint_CivID(int n) {
        SkillsManager.add_PopGrowth(n);
        this.iPoints = CFG.game.getCiv((int)n).civGameData.skills.POINTS_POP_GROWTH;
    }

    protected float getScore(int n) {
        return this.getScore_Personality(n) * (1.0f - (float)this.iPoints / (float)this.iPointsMax);
    }

    protected float getScore_Personality(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.TECH_POP;
    }
}

