/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AoCGame;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_PeaceTreaty;
import age.of.civilizations2.jakowski.lukasz.PeaceTreaty_Data;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import age.of.civilizations2.jakowski.lukasz.ViewsManager;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;

class Button_Statistics_WarDetails
extends Button_Statistics {
    protected static final int ANIMATION_TIMER = 175;
    protected static final float FONT_SCALE = 0.75f;
    protected static final float FONT_SCALE2 = 0.65f;
    protected static final float FONT_SCALE3 = 0.6f;
    protected int ANIMATION_POSX;
    protected long ANIMATION_TIME;
    protected boolean backAnimation;
    protected boolean canPeaceOut;
    protected Image civFlag;
    protected float fAlphaMod;
    protected int iCivID;
    protected String iCivilianDeaths;
    protected int iCivilianDeathsWidth;
    protected String iEconomicLosses;
    protected int iEconomicLossesWidth;
    protected int iParticipation;
    protected long lTime;
    protected Color oColorCivilianDeaths;
    protected Color oColorEconomicLosses;
    protected Color oColorParticipation;
    protected String sProvinces;

    /*
     * Exception decompiling
     */
    protected Button_Statistics_WarDetails(int var1_1, int var2_2, int var3_3, int var4_4, int var5_5, int var6_6, int var7_7, int var8_8, int var9_9, boolean var10_10) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [10[TRYBLOCK]], but top level block is 22[CATCHBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    private final void drawFlag(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
        if (this.civFlag != null) {
            try {
                Color color2 = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.slider_gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(1.0f, 1.0f, 1.0f, 0.1f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(0.0f, 0.0f, 0.0f, 0.35f);
                spriteBatch.setColor(color2);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
            }
            catch (NullPointerException nullPointerException) {
                spriteBatch.setShader(AoCGame.defaultShader);
            }
        } else {
            spriteBatch.setShader(AoCGame.defaultShader);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.825f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * (float)CFG.PADDING), this.getHeight(), false, false);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void actionElement(int var1_1) {
        try {
            block15: {
                block16: {
                    block14: {
                        if (!this.canPeaceOut) break block14;
                        var2_2 = CFG.game.getWarID(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID(), this.getCurrent());
                        if (var2_2 < 0) return;
                        CFG.game.getPlayer((int)CFG.PLAYER_TURNID).iBefore_ActiveProvince = CFG.game.getActiveProvinceID();
                        CFG.game.getPlayer((int)CFG.PLAYER_TURNID).iACTIVE_VIEW_MODE = CFG.viewsManager.getActiveViewID();
                        CFG.viewsManager.disableAllViews();
                        var3_3 = new ArrayList<Boolean>();
                        var4_4 = new ArrayList<Boolean>();
                        var5_6 = CFG.game.getWar(var2_2).getIsAggressor(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                        var6_7 = 0;
                        if (!var5_6) break block15;
                        for (var1_1 = 0; var1_1 < CFG.game.getWar(var2_2).getAggressorsSize(); ++var1_1) {
                            var4_4.add(true);
                        }
                        break block16;
                    }
                    CFG.toast.setInView(CFG.game.getCiv(this.getCurrent()).getCivName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                    if (CFG.FOG_OF_WAR == 2) {
                        if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(this.getCurrent()) && CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(CFG.game.getCiv(this.getCurrent()).getCapitalProvinceID())) {
                            CFG.game.setActiveProvinceID(CFG.game.getCiv(this.getCurrent()).getCapitalProvinceID());
                            CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getActiveProvinceID());
                        }
                    } else {
                        CFG.game.setActiveProvinceID(CFG.game.getCiv(this.getCurrent()).getCapitalProvinceID());
                        CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getActiveProvinceID());
                    }
                    if (CFG.viewsManager.getActiveViewID() != ViewsManager.VIEW_DIPLOMACY_MODE) return;
                    CFG.game.disableDrawCivilizationRegions_Active();
                    CFG.game.enableDrawCivilizationRegions_ActiveProvince();
                    return;
                }
                for (var1_1 = 0; var1_1 < CFG.game.getWar(var2_2).getDefendersSize(); ++var1_1) {
                    var5_6 = CFG.game.getWar(var2_2).getDefenderID(var1_1).getCivID() == this.getCurrent();
                    var3_3.add(var5_6);
                }
                ** break block13
            }
            var1_1 = 0;
            while (true) {
                if (var1_1 >= CFG.game.getWar(var2_2).getAggressorsSize()) break;
                var5_6 = CFG.game.getWar(var2_2).getAggressorID(var1_1).getCivID() == this.getCurrent();
                var4_4.add(var5_6);
                ++var1_1;
                continue;
                break;
            }
            for (var7_8 = var6_7; var7_8 < CFG.game.getWar(var2_2).getDefendersSize(); ++var7_8) {
                var3_3.add(true);
            }
        }
        catch (IndexOutOfBoundsException var4_5) {
            return;
        }
lbl-1000:
        // 2 sources

        {
            Menu_PeaceTreaty.WAR_ID = var2_2;
            CFG.peaceTreatyData = var8_9 = new PeaceTreaty_Data(Menu_PeaceTreaty.WAR_ID, var3_3, var4_4, CFG.game.getWar(var2_2).getIsAggressor(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()));
            CFG.game.resetChooseProvinceData_Immediately();
            CFG.game.resetRegroupArmyData();
            CFG.menuManager.setViewID(Menu.eINGAME_PEACE_TREATY);
            return;
        }
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        if (this.canPeaceOut) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("PeaceNegotiations"), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.getCurrent(), CFG.PADDING, 0));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_truce, CFG.PADDING, 0));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID(), CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.getText(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sProvinces);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Participation"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iParticipation);
        stringBuilder.append("%");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("CivilianDeaths"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iCivilianDeaths);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("EconomicLosses"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iEconomicLosses);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.economy, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("WarWeariness"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((float)((int)(CFG.game.getCiv(this.iCivID).getWarWeariness() * 10000.0f)) / 100.0f);
        stringBuilder.append("%");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_weariness, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.135f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.525f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        this.drawFlag(spriteBatch, n, n2, bl);
        spriteBatch.setColor(new Color(0.06f, 0.06f, 0.1f, 0.45f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.r, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.g, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.b, 0.85f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object;
        try {
            object = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            spriteBatch.setColor((Color)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
        object = ImageManager.getImage(Images.line_32_off1);
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy));
        int n7 = this.getPosY();
        int n8 = CFG.PADDING;
        int n9 = (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2;
        int n10 = ImageManager.getImage(Images.line_32_off1).getHeight();
        int n11 = CFG.PADDING;
        ((Image)object).draw(spriteBatch, n3 + n4 - n5 * 2 - n6 + n, n7 + n8 + n9 - n10 + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n11 * 2, (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        object = ImageManager.getImage(Images.line_32_off1);
        int n12 = this.getPosX();
        n10 = this.getWidth();
        n4 = CFG.PADDING;
        n5 = (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy));
        int n13 = this.getPosY();
        n3 = this.getHeight();
        n9 = CFG.PADDING;
        n11 = CFG.TEXT_HEIGHT;
        n7 = (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2;
        n6 = ImageManager.getImage(Images.line_32_off1).getHeight();
        n8 = CFG.PADDING;
        ((Image)object).draw(spriteBatch, n12 + n10 - n4 * 2 - n5 + n, n13 + n3 - n9 - n11 + n7 - n6 + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n8 * 2, (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.325f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + CFG.PADDING + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2 - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        spriteBatch.setColor(Color.WHITE);
        try {
            if (this.iCivID >= 0) {
                CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            } else {
                ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) / 2 - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)) / 2 + n, this.getPosY() + CFG.PADDING + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        ImageManager.getImage(Images.economy).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy))) / 2 - ImageManager.getImage(Images.economy).getHeight() + n2, (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)), (int)((float)ImageManager.getImage(Images.economy).getHeight() * this.getImageScale(Images.economy)));
        object = new Rectangle(this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, CFG.GAME_HEIGHT - (this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f) + n2), this.getMaxNameWidth(), -CFG.TEXT_HEIGHT);
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        CFG.fontMain.getData().setScale(0.75f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + this.ANIMATION_POSX + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f) + n2, this.getColor(bl));
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.fontMain.getData().setScale(0.65f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iCivilianDeaths);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - this.iCivilianDeathsWidth - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + CFG.PADDING + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.65f) / 2.0f) + n2, this.oColorCivilianDeaths);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iEconomicLosses);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - this.iEconomicLossesWidth - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.economy).getWidth() * this.getImageScale(Images.economy)) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.65f) / 2.0f) + n2, this.oColorEconomicLosses);
        CFG.fontMain.getData().setScale(0.6f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iParticipation);
        ((StringBuilder)object).append("%");
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.ANIMATION_POSX + CFG.PADDING * 3 + (int)Math.min((float)(this.getMaxNameWidth() - CFG.PADDING), (float)this.getTextWidth() * 0.75f) + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f + (float)CFG.TEXT_HEIGHT * 0.75f - (float)CFG.TEXT_HEIGHT * 0.6f) + n2, this.oColorParticipation);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.sProvinces);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.ANIMATION_POSX + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.TEXT_HEIGHT + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, new Color(CFG.COLOR_TEXT_MODIFIER_NEUTRAL.r, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.g, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.b, 0.85f));
        CFG.fontMain.getData().setScale(1.0f);
        if (this.canPeaceOut && this.getIsHovered()) {
            if (this.ANIMATION_POSX < this.getTruceIconWidth()) {
                this.ANIMATION_POSX = (int)(Math.min((float)(System.currentTimeMillis() - this.ANIMATION_TIME) / 175.0f, 1.0f) * (float)this.getTruceIconWidth());
                CFG.setRender_3(true);
            }
            object = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.ANIMATION_POSX, -this.getHeight());
            spriteBatch.flush();
            ScissorStack.pushScissors((Rectangle)object);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.325f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getTruceIconWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getTruceIconWidth(), this.getHeight());
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.675f));
            ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getTruceIconWidth() - 1 + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
            ImageManager.getImage(Images.diplo_truce).draw(spriteBatch, this.getPosX() + this.getTruceIconWidth() / 2 - ImageManager.getImage(Images.diplo_truce).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.diplo_truce).getHeight() / 2 + n2);
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        this.backAnimation = false;
        this.fAlphaMod = 0.0f;
        this.lTime = System.currentTimeMillis();
        return;
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS : Color.WHITE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    protected final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    protected final int getMaxNameWidth() {
        return this.getWidth() / 2;
    }

    @Override
    protected int getSFX() {
        int n = this.canPeaceOut ? SoundsManager.SOUND_CLICK2 : super.getSFX();
        return n;
    }

    protected int getTruceIconWidth() {
        return ImageManager.getImage(Images.diplo_truce).getWidth() + CFG.PADDING * 4;
    }

    @Override
    protected void setIsHovered(boolean bl) {
        super.setIsHovered(bl);
        if (this.canPeaceOut) {
            if (this.getIsHovered()) {
                this.ANIMATION_TIME = System.currentTimeMillis();
                this.ANIMATION_POSX = 0;
            } else {
                this.ANIMATION_TIME = 0L;
                this.ANIMATION_POSX = 0;
            }
        }
    }

    @Override
    protected void setVisible(boolean bl) {
        super.setVisible(bl);
    }
}

