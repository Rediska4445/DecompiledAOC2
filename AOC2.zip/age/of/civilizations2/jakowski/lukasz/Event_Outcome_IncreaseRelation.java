/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_IncreaseRelation
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID2 = -1;
    protected int iValue = 0;

    Event_Outcome_IncreaseRelation() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl;
        boolean bl2 = bl = false;
        try {
            if (this.getValue() == 0) return bl2;
            bl2 = bl;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
        if (this.getCivID() < 0) return bl2;
        bl2 = bl;
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl2;
        bl2 = bl;
        if (this.getCivID2() < 0) return bl2;
        bl2 = bl;
        if (this.getCivID2() >= CFG.game.getCivsSize()) return bl2;
        bl2 = bl;
        if (this.getCivID() == this.getCivID2()) return bl2;
        boolean bl3 = CFG.game.getCivsAtWar(this.getCivID(), this.getCivID2());
        bl2 = bl;
        if (bl3) return bl2;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_INCRELATION);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID2;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected String getConditionText() {
        void var1_5;
        try {
            void var1_3;
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = stringBuilder.append(CFG.langManager.get("UpdateRelation")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ").append(CFG.game.getCiv(this.getCivID2()).getCivName()).append(": ");
            if (this.getValue() > 0) {
                String string2 = "+";
            } else {
                String string3 = "";
            }
            String string4 = stringBuilder2.append((String)var1_3).append(this.getValue()).toString();
            return var1_5;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string5 = CFG.langManager.get("UpdateRelation");
            return var1_5;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList arrayList = new ArrayList();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = arrayList;
            if (!this.canMakeAction()) return object;
            object = new Object();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Relation")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new Object(this.getCivID(), 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object(CFG.game.getCiv(this.getCivID()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object(" - ");
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object(CFG.game.getCiv(this.getCivID2()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object(this.getCivID2(), CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object();
            CharSequence charSequence = ((StringBuilder)object).append(": ");
            object = this.getValue() > 0 ? "+" : "";
            charSequence = charSequence.append((String)object).append(this.getValue()).toString();
            object = this.getValue() > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, (Color)object);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new Object(arrayList2);
            arrayList.add(object);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    @Override
    protected void outcomeAction() {
        if (this.canMakeAction()) {
            CFG.game.setCivRelation_OfCivB(this.getCivID(), this.getCivID2(), Math.max(CFG.game.getCivRelation_OfCivB(this.getCivID(), this.getCivID2()) + (float)this.getValue(), -99.0f));
            CFG.game.setCivRelation_OfCivB(this.getCivID2(), this.getCivID(), Math.max(CFG.game.getCivRelation_OfCivB(this.getCivID2(), this.getCivID()) + (float)this.getValue(), -99.0f));
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID2 = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID2 == n) {
            this.iCivID2 = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID2) return bl2;
        --this.iCivID2;
        return bl;
    }
}

