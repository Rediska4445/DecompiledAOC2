/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics_Flag;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;
import java.util.List;

class Button_Statistics_Alliance_Clip
extends Button_Statistics_Flag {
    protected Button_Statistics_Alliance_Clip(int n, String string2, int n2, int n3, int n4, int n5, int n6) {
        super(n, string2, n2, n3, n4, n5, n6);
    }

    private final float getImageScale() {
        return (float)CFG.TEXT_HEIGHT / (float)CFG.CIV_FLAG_HEIGHT;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(this.getText(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth(), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        try {
            object = new Color(CFG.game.getAlliance(this.iCivID).getColorOfAlliance().getR(), CFG.game.getAlliance(this.iCivID).getColorOfAlliance().getG(), CFG.game.getAlliance(this.iCivID).getColorOfAlliance().getB(), 0.85f);
            spriteBatch.setColor((Color)object);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
            spriteBatch.setColor(Color.WHITE);
            int n3 = CFG.FOG_OF_WAR;
            int n4 = 5;
            if (n3 == 2) {
                for (n3 = CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1 > 5 ? 5 : CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1; n3 >= 0; --n3) {
                    if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getAlliance(this.iCivID).getCivilization(n3))) {
                        CFG.game.getCiv(CFG.game.getAlliance(this.iCivID).getCivilization(n3)).getFlag().draw(spriteBatch, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4 * n3 + 2 + this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - CFG.game.getCiv(CFG.game.getAlliance(this.iCivID).getCivilization(n3)).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
                    } else {
                        ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4 * n3 + 2 + this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
                    }
                    ImageManager.getImage(Images.flag_rect).draw(spriteBatch, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4 * n3 + 2 + this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
                }
            } else {
                for (n3 = CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1 > 5 ? 5 : CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1; n3 >= 0; --n3) {
                    CFG.game.getCiv(CFG.game.getAlliance(this.iCivID).getCivilization(n3)).getFlag().draw(spriteBatch, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4 * n3 + 2 + this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - CFG.game.getCiv(CFG.game.getAlliance(this.iCivID).getCivilization(n3)).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
                    ImageManager.getImage(Images.flag_rect).draw(spriteBatch, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4 * n3 + 2 + this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
                }
            }
            CFG.fontMain.getData().setScale(0.7f);
            object = this.getTextToDraw();
            int n5 = this.getPosX();
            int n6 = this.textPosition.getTextPosition();
            int n7 = (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) * 3 / 4;
            n3 = CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1 > 5 ? n4 : CFG.game.getAlliance(this.iCivID).getCivilizationsSize() - 1;
            CFG.drawTextWithShadow(spriteBatch, (String)object, n5 + n6 + n7 * n3 + 2 + CFG.PADDING + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.RANDOM_CIVILIZATION_COLOR.r, CFG.RANDOM_CIVILIZATION_COLOR.g, CFG.RANDOM_CIVILIZATION_COLOR.b, 0.85f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
            spriteBatch.setColor(Color.WHITE);
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + 2 + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + 2 + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale()));
            CFG.fontMain.getData().setScale(0.7f);
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.textPosition.getTextPosition() + 2 + CFG.PADDING + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale()) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        }
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }
}

