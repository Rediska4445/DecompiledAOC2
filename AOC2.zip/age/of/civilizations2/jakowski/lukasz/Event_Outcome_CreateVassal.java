/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_CreateVassal
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID2 = -1;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Outcome_CreateVassal() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction(int n) {
        try {
            int n2;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getSeaProvince()) return false;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getWasteland() >= 0) return false;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getCivID() != this.getCivID()) {
                if (CFG.game.getCiv(CFG.game.getProvince(this.getProvinces().get(n)).getCivID()).getPuppetOfCivID() != this.getCivID()) return false;
            }
            if ((n2 = this.getCivID()) == (n = this.getCivID2())) return false;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return false;
        }
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CREATEVASSAL);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID2;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("CreateAVassal")).append(": ").append(CFG.game.getCiv(this.getCivID2()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("CreateAVassal");
            return var1_3;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList<Object> arrayList = new ArrayList<Object>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = new StringBuilder();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("CreateAVassal")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.getCivID2()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID2(), CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add(object);
            arrayList2.clear();
            int n = 0;
            while (true) {
                object = arrayList;
                if (n >= this.getProvinces().size()) return object;
                if (this.canMakeAction(n)) {
                    object = new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID2());
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new StringBuilder();
                    menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Controls")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                    arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
                    object = new StringBuilder();
                    StringBuilder stringBuilder = ((StringBuilder)object).append("");
                    object = CFG.game.getProvince(this.getProvinces().get(n)).getName().length() == 0 ? (Serializable)this.getProvinces().get(n) : CFG.game.getProvince(this.getProvinces().get(n)).getName();
                    menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.append(object).toString());
                    arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
                    object = new MenuElement_Hover_v2_Element2(arrayList2);
                    arrayList.add(object);
                    arrayList2.clear();
                }
                ++n;
            }
        }
        catch (NullPointerException nullPointerException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void outcomeAction() {
        if (this.getCivID() < 0) return;
        if (this.getCivID() >= CFG.game.getCivsSize()) return;
        if (this.getCivID2() < 0) return;
        if (this.getCivID2() >= CFG.game.getCivsSize()) return;
        CFG.game.setVassal_OfCiv(this.getCivID(), this.getCivID2());
        int n = 0;
        while (true) {
            if (n < this.lProvinces.size()) {
                if (this.canMakeAction(n)) {
                    CFG.game.getProvince(this.getProvinces().get(n)).setCivID(this.getCivID2(), false);
                    CFG.game.getProvince(this.getProvinces().get(n)).setTrueOwnerOfProvince(this.getCivID2());
                }
            } else {
                CFG.gameAction.updateCivsHappiness(this.getCivID());
                CFG.gameAction.updateCivsHappiness(this.getCivID2());
                if (CFG.game.getCiv(this.getCivID()).getCapitalProvinceID() < 0 || CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getCapitalProvinceID()).getCivID() != this.getCivID()) {
                    CFG.game.moveCapitalToTheLargestCity(this.getCivID());
                }
                CFG.game.buildCivilizationRegions(this.getCivID());
                CFG.game.buildCivilizationRegions(this.getCivID2());
                return;
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
            }
            ++n;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID2 = n;
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID2 == n) {
            this.iCivID2 = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID2) return bl2;
        --this.iCivID2;
        return bl;
    }
}

