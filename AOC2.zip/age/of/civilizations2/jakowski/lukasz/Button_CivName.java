/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_CivName
extends Button {
    private int iCivID;

    protected Button_CivName(int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(CFG.game.getCiv(n).getCivName(), 0, n2, n3, n4, n5, bl, true, false, false, null);
        this.iCivID = n;
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            Object object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID);
            object.add(object2);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("Provinces"));
            ((StringBuilder)object2).append(": ");
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
            object.add(menuElement_Hover_v2_Element_Type_Text);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("");
            ((StringBuilder)object2).append(CFG.game.getCiv(this.iCivID).getNumOfProvinces());
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_TEXT_POPULATION);
            object.add(menuElement_Hover_v2_Element_Type_Text);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (!bl && !this.getIsHovered()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.9f));
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.65f));
        }
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight(), false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() * 4 / 5, this.getHeight(), false, false);
        spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        spriteBatch.setColor(Color.WHITE);
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        catch (NullPointerException nullPointerException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sText, this.getPosX() + CFG.PADDING * 3 + CFG.CIV_FLAG_WIDTH + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.56f, 0.56f, 0.56f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(0.68f, 0.68f, 0.68f, 1.0f) : new Color(0.82f, 0.82f, 0.82f, 1.0f)) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    protected int getWidth() {
        return CFG.PADDING * 3 + CFG.CIV_FLAG_WIDTH + (int)((float)this.getTextWidth() * 0.8f) + CFG.PADDING * 2;
    }
}

