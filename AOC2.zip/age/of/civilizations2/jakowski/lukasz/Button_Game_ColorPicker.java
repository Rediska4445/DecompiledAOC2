/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_ColorPicker
extends Button_Game {
    protected Button_Game_ColorPicker(int n, int n2, int n3, boolean bl) {
        super("", 0, n, n2, n3, bl);
    }

    protected Button_Game_ColorPicker(int n, int n2, boolean bl) {
        super("", 0, n, n2, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.8f));
            ImageManager.getImage(Images.pickeIcon).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.pickeIcon).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.pickeIcon).getHeight() / 2 + n2);
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.pickeIcon).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.pickeIcon).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.pickeIcon).getHeight() / 2 + n2);
        }
    }
}

