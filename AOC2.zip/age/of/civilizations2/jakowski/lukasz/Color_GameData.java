/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Color_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private float fB;
    private float fG;
    private float fR;

    protected Color_GameData(float f, float f2, float f3) {
        this.fR = f;
        this.fB = f3;
        this.fG = f2;
    }

    protected final float getB() {
        return this.fB;
    }

    protected final float getG() {
        return this.fG;
    }

    protected final float getR() {
        return this.fR;
    }

    protected final void setB(float f) {
        this.fB = f;
    }

    protected final void setG(float f) {
        this.fG = f;
    }

    protected final void setR(float f) {
        this.fR = f;
    }
}

