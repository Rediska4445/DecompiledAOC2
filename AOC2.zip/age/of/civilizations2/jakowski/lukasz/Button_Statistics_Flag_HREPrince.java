/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics_Flag;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_Statistics_Flag_HREPrince
extends Button_Statistics_Flag {
    protected static final float TEXT_COST_SCALE = 0.7f;
    protected int iPopulationWidth;
    protected String sPopulation;

    protected Button_Statistics_Flag_HREPrince(int n, String object, int n2, int n3, int n4, int n5, int n6) {
        super(n, (String)object, n2, n3, n4, n5, n6);
        if (n >= 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(CFG.game.getCiv(n).countPopulation());
            this.sPopulation = CFG.getNumberWithSpaces(((StringBuilder)object).toString());
        } else {
            this.sPopulation = "---";
        }
        object = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        ((GlyphLayout)object).setText(bitmapFont, stringBuilder.toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(CFG.langManager.get("Prince"));
            stringBuilder.append(":");
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID, CFG.PADDING, CFG.PADDING);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivID).getCivName());
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawText(spriteBatch, n, n2, bl);
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population, 0.7f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population, 0.7f)) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population, 0.7f)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population, 0.7f)));
        CFG.fontMain.getData().setScale(0.7f);
        String string2 = this.sPopulation;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population, 0.7f));
        int n7 = this.iPopulationWidth;
        int n8 = this.getPosY();
        int n9 = this.getHeight() / 2;
        int n10 = (int)((float)this.iTextHeight * 0.7f / 2.0f);
        Color color2 = !bl && !this.getIsHovered() ? CFG.COLOR_TEXT_POPULATION : CFG.COLOR_TEXT_POPULATION_HOVER;
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 - n5 * 3 - n6 - n7 + n, n8 + n9 - n10 + n2, color2);
        CFG.fontMain.getData().setScale(1.0f);
    }

    protected float getImageScale(int n, float f) {
        return (float)CFG.TEXT_HEIGHT * f / (float)ImageManager.getImage(n).getHeight();
    }
}

