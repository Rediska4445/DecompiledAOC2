/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy_SupportRebels;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Diplomacy_SupportRebelsWithoutProvinces
extends Button_Diplomacy_SupportRebels {
    protected Button_Diplomacy_SupportRebelsWithoutProvinces(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        super(n, n2, n3, n4, n5, n6, n7, n8);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object;
        try {
            object = new Color((float)CFG.game.getCiv(this.iCivA).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getB() / 255.0f, 1.0f);
            spriteBatch.setColor((Color)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        CFG.game.getCiv(this.iCivA).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - CFG.game.getCiv(this.iCivA).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.diplo_revolution).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - this.iRevolutionaryRiskWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(Images.diplo_revolution)) / 2 - ImageManager.getImage(Images.diplo_revolution).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)), (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(Images.diplo_revolution)));
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 5 - this.iRevolutionaryRiskWidth - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 3 + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, this.getColor(bl));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iRevolutionaryRisk);
        ((StringBuilder)object).append("%");
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iRevolutionaryRiskWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, CFG.getColorStep(CFG.COLOR_TEXT_REVOLUTION_MIN, CFG.COLOR_TEXT_REVOLUTION_MAX, this.iRevolutionaryRisk, 100, 1.0f));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.sPopulation);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 4 - this.iRevolutionaryRiskWidth - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_POPULATION);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }
}

