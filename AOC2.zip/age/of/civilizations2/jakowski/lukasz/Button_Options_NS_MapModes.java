/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Options_NS;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Options_NS_MapModes
extends Button_Options_NS {
    protected static final float FONT_SCALE = 0.7f;
    private int iCurrent = 0;

    protected Button_Options_NS_MapModes(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super(string2, n2, n3, n4, n5, n6, bl);
        this.iCurrent = n;
    }

    protected Button_Options_NS_MapModes(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl, boolean bl2) {
        super(string2, n2, n3, n4, n5, n6, bl, bl2);
        this.iCurrent = n;
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Options_NS_MapModes.this.getCheckboxState()) {
                        spriteBatch.setColor(CFG.COLOR_TEXT_CHECKBOX_TRUE);
                    } else {
                        spriteBatch.setColor(CFG.COLOR_TEXT_CHECKBOX_FALSE);
                    }
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Options_NS_MapModes.this.getPosX() + n, Button_Options_NS_MapModes.this.getPosY() + CFG.PADDING / 2 + (Button_Options_NS_MapModes.this.getHeight() - CFG.PADDING) / 4 + n2 - ImageManager.getImage(Images.gradient).getHeight(), Button_Options_NS_MapModes.this.getWidth(), (Button_Options_NS_MapModes.this.getHeight() - CFG.PADDING) * 3 / 4, false, true);
                    spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Options_NS_MapModes.this.getPosX() + n, Button_Options_NS_MapModes.this.getPosY() + CFG.PADDING / 2 + n2 + (Button_Options_NS_MapModes.this.getHeight() - CFG.PADDING) - (Button_Options_NS_MapModes.this.getHeight() - CFG.PADDING) / 5 - ImageManager.getImage(Images.gradient).getHeight(), Button_Options_NS_MapModes.this.getWidth(), (Button_Options_NS_MapModes.this.getHeight() - CFG.PADDING) / 5, false, true);
                    spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.65f));
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Options_NS_MapModes.this.getPosX() + n, Button_Options_NS_MapModes.this.getPosY() + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), Button_Options_NS_MapModes.this.getWidth() / 4, Button_Options_NS_MapModes.this.getHeight(), false, false);
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Options_NS_MapModes.this.getPosX() + Button_Options_NS_MapModes.this.getWidth() - Button_Options_NS_MapModes.this.getWidth() / 4 + n, Button_Options_NS_MapModes.this.getPosY() + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), Button_Options_NS_MapModes.this.getWidth() / 4, Button_Options_NS_MapModes.this.getHeight(), true, false);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f;
        block5: {
            block4: {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
                ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), this.getWidth(), this.getHeight() - CFG.PADDING);
                float f2 = CFG.COLOR_INFO_BOX_GRADIENT.r;
                float f3 = CFG.COLOR_INFO_BOX_GRADIENT.g;
                float f4 = CFG.COLOR_INFO_BOX_GRADIENT.b;
                float f5 = 0.4f;
                float f6 = 0.225f;
                f = bl ? 0.225f : (this.getIsHovered() ? 0.175f : 0.4f);
                spriteBatch.setColor(new Color(f2, f3, f4, f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight() - CFG.PADDING, false, false);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n + this.getWidth() - this.getWidth() / 2, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight() - CFG.PADDING, true, false);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), (this.getHeight() - CFG.PADDING) / 5);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - (this.getHeight() - CFG.PADDING) / 5 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), (this.getHeight() - CFG.PADDING) / 5, false, true);
                f3 = CFG.COLOR_FLAG_FRAME.r;
                f4 = CFG.COLOR_FLAG_FRAME.g;
                f2 = CFG.COLOR_FLAG_FRAME.b;
                f = f5;
                if (!bl) {
                    f = this.getIsHovered() ? f5 : 0.3f;
                }
                spriteBatch.setColor(new Color(f3, f4, f2, f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1, true, false);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1, true, false);
                if (bl) break block4;
                f = f6;
                if (!this.getIsHovered()) break block5;
            }
            f = 0.325f;
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        CFG.drawRect(spriteBatch, this.getPosX() + n - 1, this.getPosY() + CFG.PADDING / 2 + n2 - 2, this.getWidth() + 2, this.getHeight() - CFG.PADDING + 2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        if (this.getTextPos() < 0) {
            if (bl) {
                CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.7f / 2.0f) + n, this.getPosY() + CFG.PADDING / 2 + (this.getHeight() - CFG.PADDING) / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
            } else {
                CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.7f / 2.0f) + n, this.getPosY() + CFG.PADDING / 2 + (this.getHeight() - CFG.PADDING) / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
            }
        } else if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + CFG.PADDING / 2 + (this.getHeight() - CFG.PADDING) / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + CFG.PADDING / 2 + (this.getHeight() - CFG.PADDING) / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected boolean getCheckboxState() {
        boolean bl = this.getCurrent() == CFG.viewsManager.getActiveViewID();
        return bl;
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = !bl && !this.getCheckboxState() ? (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_TOP_VIEWS_HOVER : CFG.COLOR_TEXT_TOP_VIEWS) : CFG.COLOR_TEXT_TOP_VIEWS_NOT_CLICKABLE) : CFG.COLOR_TEXT_TOP_VIEWS_ACTIVE;
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCurrent;
    }

    @Override
    protected void setCurrent(int n) {
        this.iCurrent = n;
    }
}

