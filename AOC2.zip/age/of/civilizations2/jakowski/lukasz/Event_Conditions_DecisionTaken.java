/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Conditions_DecisionTaken
extends Event_Conditions {
    private int iCivID = -1;
    private String sTag = "";

    Event_Conditions_DecisionTaken() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_DECISIONTAKEN);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        block11: {
            var2_3 = var1_1 = "";
            var3_4 = var1_1;
            var4_20 = var1_1;
            try {
                if (CFG.eventsManager.lCreateScenario_Event.getTrigger((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lConditions.get(CFG.eventsManager.iCreateEvent_EditConditionID).getText().length() > 0) {
                    var2_3 = var1_1;
                    var4_21 = var1_1;
                    var5_28 = CFG.eventsManager.lCreateScenario_Event.getTrigger((int)CFG.eventsManager.iCreateEvent_EditTriggerID).lConditions.get(CFG.eventsManager.iCreateEvent_EditConditionID).getText().split("_");
                    var2_3 = var1_1;
                    var4_22 = var1_1;
                    var6_29 = Integer.parseInt(var5_28[1]);
                    var7_30 = 0;
                    break block11;
                }
                ** GOTO lbl43
            }
            catch (IllegalArgumentException var3_11) {
                var3_12 = var2_3;
                ** GOTO lbl43
            }
            catch (IndexOutOfBoundsException var3_18) {
                var3_19 = var4_20;
                ** GOTO lbl43
            }
        }
        while (true) {
            block12: {
                block13: {
                    var2_3 = var1_1;
                    var3_6 = var1_1;
                    var4_24 = var1_1;
                    if (var7_30 >= CFG.eventsManager.getEventsSize()) break block13;
                    var3_7 = var1_1;
                    var2_3 = var1_1;
                    var4_25 = var1_1;
                    if (!var5_28[0].equals(CFG.eventsManager.getEvent(var7_30).getEventTag())) break block12;
                    var2_3 = var1_1;
                    var4_26 = var1_1;
                    var3_8 = CFG.eventsManager.getEvent((int)var7_30).lDecisions.get((int)var6_29).sTitle;
                    var2_3 = var3_8;
                    try {
                        var2_3 = var3_8;
                        var1_1 = new StringBuilder();
                        var2_3 = var3_8;
                        var3_9 = var1_1 = var1_1.append(var3_8).append(" - [").append(CFG.game.getCiv(CFG.eventsManager.getEvent(var7_30).getCivID()).getCivName()).append("]").toString();
                        break block12;
                    }
                    catch (IndexOutOfBoundsException var1_2) {}
                }
                try {
                    var1_1 = new StringBuilder();
                    var2_3 = var1_1.append(CFG.langManager.get("DecisionTaken")).append(": ");
                    var1_1 = var3_13;
                    if (var3_13.length() == 0) {
                        var1_1 = "NOT FOUND!";
                    }
                    var3_14 = var2_3.append((String)var1_1).toString();
                    return var3_15;
                }
                catch (IndexOutOfBoundsException var3_16) {
                    var3_17 = CFG.langManager.get("DecisionTaken");
                    return var3_15;
                }
            }
            ++var7_30;
            var1_1 = var3_10;
        }
    }

    @Override
    protected String getText() {
        return this.sTag;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        if (this.getCivID() >= 0 && this.getCivID() < CFG.game.getCivsSize()) {
            return CFG.game.getCiv(this.getCivID()).getEvent_TookDecision(this.getText());
        }
        int n = 0;
        while (n < CFG.game.getCivsSize()) {
            if (CFG.game.getCiv(n).getEvent_TookDecision(this.getText())) {
                return true;
            }
            ++n;
        }
        return false;
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setText(String string2) {
        this.sTag = string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

