/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;

class CivArmyMission_PrepareForWar
extends CivArmyMission {
    protected int iTurnsRequiredToMoveToFrontLine = 1;

    protected CivArmyMission_PrepareForWar(int n, int n2, int n3, int n4, int n5) {
        this.iArmy = n4;
        this.iProvinceID = n2;
        this.toProvinceID = n3;
        this.MISSION_ID = n5;
        this.iTurnsRequiredToMoveToFrontLine = new RegroupArmy_Data(n, this.iProvinceID, n3).getRouteSize();
        Application application = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CivArmyMission_PrepareForWar -> INIT: ");
        stringBuilder.append(CFG.game.getCiv(n).getCivName());
        stringBuilder.append(", LEFT: ");
        stringBuilder.append(this.iTurnsRequiredToMoveToFrontLine);
        application.log("AoC", stringBuilder.toString());
    }

    @Override
    protected boolean action(int n) {
        RegroupArmy_Data regroupArmy_Data;
        if (this.iProvinceID != this.toProvinceID && (regroupArmy_Data = new RegroupArmy_Data(n, this.iProvinceID, this.toProvinceID)).getRouteSize() > 0) {
            if (regroupArmy_Data.getRouteSize() == 1) {
                return CFG.gameAction.moveArmy(this.iProvinceID, this.toProvinceID, this.iArmy, n, true, false);
            }
            if (CFG.gameAction.moveArmy(this.iProvinceID, regroupArmy_Data.getRoute(0), this.iArmy, n, true, false)) {
                regroupArmy_Data.setFromProvinceID(regroupArmy_Data.getRoute(0));
                regroupArmy_Data.removeRoute(0);
                regroupArmy_Data.setNumOfUnits(this.iArmy);
                CFG.game.getCiv(n).addRegroupArmy(regroupArmy_Data);
                return true;
            }
            return false;
        }
        return true;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        return true;
    }
}

