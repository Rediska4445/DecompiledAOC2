/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Stats
extends Button {
    protected float FONT_SCALE = 0.8f;
    protected int iMinWidth = 0;

    protected Button_Stats(String string2, float f, int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        super.init(string2, CFG.PADDING, n, n2 - 1, n3, n4 + 2, bl, bl2, false, false, null);
        this.FONT_SCALE = f;
        this.iMinWidth = n3;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.56f, 0.56f, 0.56f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(0.68f, 0.68f, 0.68f, 1.0f) : new Color(0.82f, 0.82f, 0.82f, 1.0f)) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void setText(String string2) {
        this.sText = string2;
        this.setWidth(this.iMinWidth);
        try {
            CFG.glyphLayout.setText(CFG.fontMain, string2);
            this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
            this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            if (super.getWidth() < this.iTextWidth + CFG.PADDING * 2) {
                this.setWidth(this.iTextWidth + CFG.PADDING * 2);
            }
            return;
        }
        catch (IllegalArgumentException | NullPointerException runtimeException) {
            return;
        }
    }
}

