/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_JoinAlliance
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID2 = -1;
    protected String sName = "";

    Event_Outcome_JoinAlliance() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl;
        boolean bl2 = bl = false;
        try {
            if (this.getCivID() < 0) return bl2;
            bl2 = bl;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl2;
        bl2 = bl;
        if (this.getCivID2() < 0) return bl2;
        bl2 = bl;
        if (this.getCivID2() >= CFG.game.getCivsSize()) return bl2;
        bl2 = bl;
        if (this.getCivID() == this.getCivID2()) return bl2;
        float f = CFG.game.getCivRelation_OfCivB(this.getCivID(), this.getCivID2());
        bl2 = bl;
        if ((int)f == -100) return bl2;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_JOINALLIANCE);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID2;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("JoinAlliance")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ").append(CFG.game.getCiv(this.getCivID2()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("JoinAlliance");
            return var1_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        ArrayList arrayList = new ArrayList();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        ArrayList arrayList3 = arrayList;
        try {
            if (!this.canMakeAction()) return arrayList3;
            arrayList3 = new ArrayList();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList3)).append(CFG.langManager.get("Alliance")).append(":").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            if (!this.sName.equals("")) {
                arrayList3 = new ArrayList();
                menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList3)).append(" [").append(this.sName).append("]").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            }
            arrayList3 = new ArrayList(this.getCivID(), CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(" - ");
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID2()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(this.getCivID2(), CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(arrayList2);
            arrayList.add(arrayList3);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
    }

    @Override
    protected String getText() {
        return this.sName;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void outcomeAction() {
        if (this.canMakeAction()) {
            if (CFG.game.getCiv(this.getCivID()).getAllianceID() > 0 && CFG.game.getCiv(this.getCivID2()).getAllianceID() == 0) {
                CFG.game.getAlliance(CFG.game.getCiv(this.getCivID()).getAllianceID()).addCivilization(this.getCivID2(), false);
                CFG.game.getCiv(this.getCivID2()).setAllianceID(CFG.game.getCiv(this.getCivID()).getAllianceID(), false);
            } else if (CFG.game.getCiv(this.getCivID()).getAllianceID() == 0 && CFG.game.getCiv(this.getCivID2()).getAllianceID() > 0) {
                CFG.game.getAlliance(CFG.game.getCiv(this.getCivID2()).getAllianceID()).addCivilization(this.getCivID(), false);
                CFG.game.getCiv(this.getCivID()).setAllianceID(CFG.game.getCiv(this.getCivID2()).getAllianceID(), false);
            } else if (CFG.game.getCiv(this.getCivID()).getAllianceID() > 0 && CFG.game.getCiv(this.getCivID2()).getAllianceID() > 0) {
                CFG.game.getAlliance(CFG.game.getCiv(this.getCivID2()).getAllianceID()).removeCivilization(this.getCivID2());
                CFG.game.getAlliance(CFG.game.getCiv(this.getCivID()).getAllianceID()).addCivilization(this.getCivID2(), false);
                CFG.game.getCiv(this.getCivID2()).setAllianceID(CFG.game.getCiv(this.getCivID()).getAllianceID(), false);
            } else {
                CFG.game.addAlliance(CFG.getRandomAllianceName(0));
                CFG.game.getAlliance(CFG.game.getAlliancesSize() - 1).addCivilization(this.getCivID(), false);
                CFG.game.getAlliance(CFG.game.getAlliancesSize() - 1).addCivilization(this.getCivID2(), false);
                CFG.game.getCiv(this.getCivID()).setAllianceID(CFG.game.getAlliancesSize() - 1, false);
                CFG.game.getCiv(this.getCivID2()).setAllianceID(CFG.game.getAlliancesSize() - 1, false);
            }
            if (!this.sName.equals("")) {
                CFG.game.getAlliance(CFG.game.getCiv(this.getCivID()).getAllianceID()).setAllianceName(CFG.langManager.get(this.sName));
            }
        }
        int n = this.getCivID();
        CFG.game.updateCurrentWars(n);
        n = this.getCivID2();
        CFG.game.updateCurrentWars(n);
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID2 = n;
    }

    @Override
    protected void setText(String string2) {
        this.sName = string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID2 == n) {
            this.iCivID2 = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID2) return bl2;
        --this.iCivID2;
        return bl;
    }
}

