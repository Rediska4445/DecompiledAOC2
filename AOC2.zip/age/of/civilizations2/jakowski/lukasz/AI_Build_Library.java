/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import java.util.ArrayList;
import java.util.List;

class AI_Build_Library
extends AI_Build {
    private List<Integer> lBuildCost = new ArrayList<Integer>();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected AI_Build_Library(int n, long l) {
        super(n, l);
        int n2 = 0;
        int n3 = 0;
        try {
            while (n3 < BuildingsManager.getLibrary_MaxLevel()) {
                List list = this.lBuildCost;
                list.add(BuildingsManager.getLibrary_BuildCost(++n3, CFG.game.getCiv(n).getProvinceID(0)));
                list = this.lProvincesToBuild;
                ArrayList arrayList = new ArrayList();
                list.add(arrayList);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        if (l < (long)this.lBuildCost.get(0).intValue()) return;
        for (n3 = n2; n3 < CFG.game.getCiv(n).getNumOfProvinces(); ++n3) {
            if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).isOccupied() || !(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getProvinceStability() > CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MIN_STABILITY) || !(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getRevolutionaryRisk() <= CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MAX_REV_RISK) || !BuildingsManager.canBuildLibrary(CFG.game.getCiv(n).getProvinceID(n3)) || (n2 = CFG.game.getCiv(n).isInConstruction(CFG.game.getCiv(n).getProvinceID(n3), ConstructionType.LIBRARY)) != 0) continue;
            try {
                if (l < (long)this.lBuildCost.get(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getLevelOfLibrary()).intValue()) continue;
                ((List)this.lProvincesToBuild.get(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getLevelOfLibrary())).add(CFG.game.getCiv(n).getProvinceID(n3));
                ++this.iProvincesToBuild_NumOfElements;
                this.iMaxDangerLevel = Math.max(this.iMaxDangerLevel, CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getDangerLevel());
                continue;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        }
    }

    @Override
    protected boolean build(int n, int n2, boolean bl) {
        int n3;
        int n4;
        int n5 = -1;
        float f = 0.0f;
        for (n4 = this.lProvincesToBuild.size() - 1; n4 >= 0; --n4) {
            for (n3 = ((List)this.lProvincesToBuild.get(n4)).size() - 1; n3 >= 0; --n3) {
                float f2;
                if (n5 < 0) {
                    n5 = (Integer)((List)this.lProvincesToBuild.get(n4)).get(n3);
                    f2 = this.getProvinceBuildScore(n, n5);
                } else {
                    f2 = f;
                    if (this.getProvinceBuildScore(n, (Integer)((List)this.lProvincesToBuild.get(n4)).get(n3)) > f) {
                        n5 = (Integer)((List)this.lProvincesToBuild.get(n4)).get(n3);
                        f2 = this.getProvinceBuildScore(n, n5);
                    }
                }
                f = f2;
            }
        }
        boolean bl2 = bl;
        if (n5 >= 0) {
            bl2 = bl;
            if (BuildingsManager.constructLibrary(n5, n)) {
                long l = this.getMoney(n);
                List<Integer> list = this.lBuildCost;
                int n6 = 0;
                if (l > (long)list.get(0).intValue() && BuildingsManager.getLibrary_BuildMovementCost(1) <= CFG.game.getCiv(n).getMovePoints()) {
                    for (n4 = this.lProvincesToBuild.size() - 1; n4 >= 0; --n4) {
                        for (n3 = ((List)this.lProvincesToBuild.get(n4)).size() - 1; n3 >= 0; --n3) {
                            if ((Integer)((List)this.lProvincesToBuild.get(n4)).get(n3) == n5) {
                                ((List)this.lProvincesToBuild.get(n4)).remove(n3);
                                continue;
                            }
                            ++n6;
                        }
                    }
                    if (n6 > 0 && n2 < 4) {
                        return this.build(n, n2 + 1, true);
                    }
                }
                bl2 = true;
            }
        }
        return bl2;
    }

    @Override
    protected int getNumOfAlreadyBuilt(int n) {
        return CFG.game.getCiv((int)n).iNumOf_Libraries;
    }

    protected float getProvinceBuildScore(int n, int n2) {
        return (float)CFG.game.getProvince(n2).getPopulationData().getPopulation() * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE + CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE * CFG.game.getProvince(n2).getProvinceStability()) * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_DANGER_SCORE * (float)CFG.game.getProvince(n2).getDangerLevel() / (float)this.iMaxDangerLevel) * (1.0f - CFG.game.getProvince(n2).getRevolutionaryRisk());
    }
}

