/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Conditions_EventChance
extends Event_Conditions {
    protected int iValue = 40;

    Event_Conditions_EventChance() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_EVENTCHANCE);
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("EventChance")).append(": ").append(this.getValue()).append("%").toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("EventChance");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        if (CFG.oR.nextInt(100) > this.getValue()) return false;
        return true;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }
}

