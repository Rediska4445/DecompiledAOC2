/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Action;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_NextTurn
extends Button_Game {
    protected static final int ANIMATION_T = 1000;
    private int animationState = 0;
    private boolean backAnimation = false;
    private float fAlphaMod = 0.0f;
    private long lTime = 0L;
    private long lTimeAnimation = System.currentTimeMillis();

    protected Button_Game_NextTurn(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (this.getClickable() && (this.getIsHovered() || bl || CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMovePoints() < 8 || CFG.gameAction.getActiveTurnState() != Game_Action.TurnStates.INPUT_ORDERS)) {
            if (this.lTime < System.currentTimeMillis() - 26L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            float f = CFG.COLOR_GRADIENT_TITLE_BLUE.r;
            float f2 = CFG.COLOR_GRADIENT_TITLE_BLUE.g;
            float f3 = CFG.COLOR_GRADIENT_TITLE_BLUE.b;
            float f4 = CFG.gameAction.getActiveTurnState() != Game_Action.TurnStates.INPUT_ORDERS ? 0.775f : 0.45f;
            spriteBatch.setColor(new Color(f, f2, f3, f4 - this.fAlphaMod));
            CFG.setRender_3(true);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
            int n3 = this.animationState;
            if (n3 >= 0) {
                f4 = 0.625f;
                if (n3 == 0) {
                    f2 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 1000.0f, 1.0f);
                    f3 = CFG.COLOR_FLAG_FRAME.r;
                    float f5 = CFG.COLOR_FLAG_FRAME.g;
                    f = CFG.COLOR_FLAG_FRAME.b;
                    if (!this.getIsHovered()) {
                        f4 = 0.525f;
                    }
                    spriteBatch.setColor(new Color(f3, f5, f, f4));
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                    if (this.lTimeAnimation < System.currentTimeMillis() - 1000L) {
                        ++this.animationState;
                        this.lTimeAnimation = System.currentTimeMillis();
                    }
                } else {
                    f3 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 1000.0f, 1.0f);
                    float f6 = CFG.COLOR_FLAG_FRAME.r;
                    f = CFG.COLOR_FLAG_FRAME.g;
                    f2 = CFG.COLOR_FLAG_FRAME.b;
                    if (!this.getIsHovered()) {
                        f4 = 0.525f;
                    }
                    spriteBatch.setColor(new Color(f6, f, f2, f4));
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f3) + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f3), 1);
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f3) + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f3), 1);
                    if (this.lTimeAnimation < System.currentTimeMillis() - 1000L) {
                        this.animationState = 0;
                        this.lTimeAnimation = System.currentTimeMillis();
                    }
                }
                CFG.setRender_3(true);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        if (CFG.gameAction.getActiveTurnState() != Game_Action.TurnStates.INPUT_ORDERS) {
            Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_IMPORTANT_HOVER : CFG.COLOR_BUTTON_GAME_TEXT_IMPORTANT) : CFG.COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE);
            return color2;
        }
        Color color3 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : CFG.COLOR_BUTTON_GAME_TEXT) : CFG.COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE);
        return color3;
    }

    @Override
    protected void setIsHovered(boolean bl) {
        super.setIsHovered(bl);
        this.lTime = System.currentTimeMillis();
    }
}

