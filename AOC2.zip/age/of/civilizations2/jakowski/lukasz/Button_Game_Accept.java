/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_Accept
extends Button_Game {
    private final int ANIMATION_T;
    private int animationState = 0;
    private long lTimeAnimation = 0L;

    protected Button_Game_Accept(int n, int n2, boolean bl) {
        super("", 0, n, n2, bl);
        this.ANIMATION_T = 750;
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (bl) {
            ImageManager.getImage(Images.btn_v_active).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_v_active).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_v_active).getHeight() / 2 + n2);
        } else {
            if (this.getIsHovered()) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.8f));
            }
            ImageManager.getImage(Images.btn_v).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_v).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_v).getHeight() / 2 + n2);
            spriteBatch.setColor(Color.WHITE);
        }
        int n3 = this.animationState;
        if (n3 >= 0) {
            float f = 0.675f;
            if (n3 == 0) {
                float f2 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                float f3 = CFG.COLOR_FLAG_FRAME.r;
                float f4 = CFG.COLOR_FLAG_FRAME.g;
                float f5 = CFG.COLOR_FLAG_FRAME.b;
                if (!this.getIsHovered()) {
                    f = 0.575f;
                }
                spriteBatch.setColor(new Color(f3, f4, f5, f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 750L) {
                    ++this.animationState;
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f6 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                float f7 = CFG.COLOR_FLAG_FRAME.r;
                float f8 = CFG.COLOR_FLAG_FRAME.g;
                float f9 = CFG.COLOR_FLAG_FRAME.b;
                if (!this.getIsHovered()) {
                    f = 0.575f;
                }
                spriteBatch.setColor(new Color(f7, f8, f9, f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6) + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6) + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 750L) {
                    this.animationState = 0;
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
    }
}

