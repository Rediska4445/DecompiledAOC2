/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;

class Civilization_Region_Style {
    Civilization_Region_Style() {
    }

    protected void updatePB(int n, int n2) {
        CFG.game.getProvince(n).getProvinceBordersLandByLand(n2).updateDrawProvinceBorder_CivilizationRegion();
    }
}

