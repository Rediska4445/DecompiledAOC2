/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Close
extends Button {
    protected Button_Close(int n, int n2, int n3, int n4) {
        super.init("", 0, n, n2, n3, n4, true, true, false, false, null);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.btn_close).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
    }
}

