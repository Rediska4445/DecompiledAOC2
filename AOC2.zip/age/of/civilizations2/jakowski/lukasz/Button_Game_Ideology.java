/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Ideology;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

public class Button_Game_Ideology
extends Button_Game {
    private int iIdeologyID;
    private int iIdeologyTextWidth = 0;

    protected Button_Game_Ideology(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n2, n3, n4, n5, bl);
        this.iIdeologyID = n;
        CFG.fontMain.getData().setScale(0.8f);
        CFG.glyphLayout.setText(CFG.fontMain, CFG.ideologiesManager.getIdeology(this.iIdeologyID).getName());
        this.iIdeologyTextWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Government"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.ideologiesManager.getIdeology(this.getCurrent()).getName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Ideology(this.iIdeologyID, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + (this.getWidth() - (CFG.PADDING + CFG.CIV_FLAG_WIDTH + super.getTextWidth())) / 2 + (CFG.PADDING + CFG.CIV_FLAG_WIDTH) + n, this.getPosY() + this.getHeight() / 2 - CFG.PADDING / 2 - this.iTextHeight + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + (this.getWidth() - (CFG.PADDING + CFG.CIV_FLAG_WIDTH + super.getTextWidth())) / 2 + (CFG.PADDING + CFG.CIV_FLAG_WIDTH) + n, this.getPosY() + this.getHeight() / 2 - CFG.PADDING / 2 - this.iTextHeight + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(0.8f);
        String string2 = CFG.ideologiesManager.getIdeology(this.iIdeologyID).getName();
        int n3 = this.getPosX();
        int n4 = (this.getWidth() - this.iIdeologyTextWidth) / 2;
        int n5 = this.getPosY();
        int n6 = this.getHeight() / 2;
        int n7 = CFG.PADDING;
        int n8 = (CFG.TEXT_HEIGHT - CFG.TEXT_HEIGHT) / 2;
        Color color2 = this.getClickable() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : new Color(CFG.COLOR_BUTTON_GAME_TEXT_HOVERED.r, CFG.COLOR_BUTTON_GAME_TEXT_HOVERED.g, CFG.COLOR_BUTTON_GAME_TEXT_HOVERED.b, 0.65f);
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 + n, n5 + n6 + n7 + n8 + n2, color2);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected int getCurrent() {
        return this.iIdeologyID;
    }

    @Override
    protected int getTextPos() {
        return super.getTextWidth();
    }

    @Override
    protected int getTextWidth() {
        int n;
        int n2 = super.getTextWidth();
        int n3 = CFG.PADDING;
        int n4 = CFG.CIV_FLAG_WIDTH;
        int n5 = n = this.iIdeologyTextWidth;
        if (n2 + n3 + n4 > n) {
            n5 = super.getTextWidth();
            n = CFG.PADDING;
            n5 = CFG.CIV_FLAG_WIDTH + (n5 + n);
        }
        return n5;
    }
}

