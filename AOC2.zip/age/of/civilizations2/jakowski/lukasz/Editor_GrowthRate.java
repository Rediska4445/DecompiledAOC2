/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Province_Army;
import age.of.civilizations2.jakowski.lukasz.UndoGrowthRate;
import com.badlogic.gdx.Gdx;
import java.util.ArrayList;
import java.util.List;

class Editor_GrowthRate
extends Editor {
    protected static float currentGrowthRate = 1.0f;
    protected static List<UndoGrowthRate> lUndo;

    public Editor_GrowthRate() {
        lUndo = new ArrayList<UndoGrowthRate>();
    }

    protected static final void actionSave(boolean bl) {
        if (CFG.game.getActiveProvinceID() >= 0 && !CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince()) {
            if (bl) {
                Editor_GrowthRate.addUndo(CFG.game.getActiveProvinceID());
            }
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).setGrowthRate_Population(currentGrowthRate);
            if (CFG.VIEW_SHOW_VALUES) {
                Province_Army province_Army = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getArmy_Obj(0);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append((int)(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getGrowthRate_Population() * 100.0f));
                stringBuilder.append("%");
                province_Army.updateArmyWidth(stringBuilder.toString());
            }
            CFG.game.saveProvince_Info_GameData(CFG.game.getActiveProvinceID());
        }
    }

    private static final void addUndo(int n) {
        if (n < 0) {
            return;
        }
        if (lUndo.size() > 0) {
            List<UndoGrowthRate> list = lUndo;
            if (list.get((int)(list.size() - 1)).iProvinceID != n && currentGrowthRate != CFG.game.getProvince(n).getGrowthRate_Population()) {
                if (lUndo.size() > 50) {
                    lUndo.remove(0);
                    lUndo.add(new UndoGrowthRate(n, CFG.game.getProvince(n).getGrowthRate_Population()));
                } else {
                    lUndo.add(new UndoGrowthRate(n, CFG.game.getProvince(n).getGrowthRate_Population()));
                }
            }
        } else if (currentGrowthRate != CFG.game.getProvince(n).getGrowthRate_Population()) {
            lUndo.add(new UndoGrowthRate(n, CFG.game.getProvince(n).getGrowthRate_Population()));
        }
    }

    protected static void popUndo() {
        if (lUndo.size() > 0) {
            Game game = CFG.game;
            List<UndoGrowthRate> list = lUndo;
            game.setActiveProvinceID(list.get((int)(list.size() - 1)).iProvinceID);
            list = lUndo;
            currentGrowthRate = list.get((int)(list.size() - 1)).fGrowthRate;
            Editor_GrowthRate.actionSave(false);
            if (!CFG.game.getProvince(CFG.game.getActiveProvinceID()).getDrawProvince()) {
                CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getActiveProvinceID());
            }
            list = lUndo;
            list.remove(list.size() - 1);
        }
    }

    @Override
    protected void keyDown(int n) {
        if (Gdx.input.isKeyPressed(21) && (currentGrowthRate = (float)((int)(currentGrowthRate * 100.0f) - 1) / 100.0f) < 0.02f) {
            currentGrowthRate = 0.02f;
        }
        if (Gdx.input.isKeyPressed(22) && (currentGrowthRate = (float)((int)(currentGrowthRate * 100.0f) + 1) / 100.0f) > 1.0f) {
            currentGrowthRate = 1.0f;
        }
        if (Gdx.input.isKeyPressed(62)) {
            Editor_GrowthRate.actionSave(true);
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GROWTH RATE: ");
        stringBuilder.append((int)(currentGrowthRate * 100.0f));
        stringBuilder.append("%");
        return stringBuilder.toString();
    }
}

