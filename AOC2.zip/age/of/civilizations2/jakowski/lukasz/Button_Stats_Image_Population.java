/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Stats;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_Stats_Image_Population
extends Button_Stats {
    private static final int NUM_OF_FLAGS = 2;
    private int iProvinceID = 0;
    private List<Integer> lSorted = new ArrayList<Integer>();

    protected Button_Stats_Image_Population(String string2, float f, int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        super(string2, f, n, n2, n3, n4, bl, bl2);
    }

    private final float getImageScale() {
        return (float)CFG.TEXT_HEIGHT / (float)CFG.CIV_FLAG_HEIGHT;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        block11: {
            int n3;
            int n4;
            int n5;
            block10: {
                ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getTextPos() + (ImageManager.getImage(Images.economy).getWidth() - ImageManager.getImage(Images.population).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.population).getHeight() - ImageManager.getImage(Images.population).getHeight() / 2 + n2, ImageManager.getImage(Images.population).getWidth(), ImageManager.getImage(Images.population).getHeight());
                CFG.fontMain.getData().setScale(this.FONT_SCALE);
                CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + CFG.PADDING + ImageManager.getImage(Images.economy).getWidth() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
                CFG.fontMain.getData().setScale(1.0f);
                try {
                    n5 = CFG.FOG_OF_WAR;
                    n4 = 0;
                    n3 = 0;
                    if (n5 != 2) break block10;
                    n4 = n3;
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    this.setCurrent(this.getCurrent());
                }
                while (true) {
                    if (n4 >= Math.min(this.lSorted.size(), 2)) break block11;
                    if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.lSorted.get(n4)))) {
                        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.lSorted.get(n4))).getFlag().draw(spriteBatch, this.getPosX() + this.getTextPos() + CFG.PADDING + ImageManager.getImage(Images.economy).getWidth() + n + this.getTextWidth() + CFG.PADDING * (n4 + 1) + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) * n4, this.getPosY() - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.lSorted.get(n4))).getFlag().getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                    } else {
                        ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getTextPos() + CFG.PADDING + ImageManager.getImage(Images.economy).getWidth() + n + this.getTextWidth() + CFG.PADDING * (n4 + 1) + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) * n4, this.getPosY() - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                    }
                    Image image = ImageManager.getImage(Images.flag_rect);
                    int n6 = this.getPosX();
                    n5 = this.getTextPos();
                    int n7 = CFG.PADDING;
                    int n8 = ImageManager.getImage(Images.economy).getWidth();
                    int n9 = this.getTextWidth();
                    int n10 = CFG.PADDING;
                    n3 = n4 + 1;
                    image.draw(spriteBatch, n6 + n5 + n7 + n8 + n + n9 + n10 * n3 + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) * n4, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                    n4 = n3;
                    continue;
                    break;
                }
            }
            while (true) {
                if (n4 >= Math.min(this.lSorted.size(), 2)) break;
                Image image = CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.lSorted.get(n4))).getFlag();
                int n11 = this.getPosX();
                int n12 = this.getTextPos();
                int n13 = CFG.PADDING;
                int n14 = ImageManager.getImage(Images.economy).getWidth();
                n5 = this.getTextWidth();
                int n15 = CFG.PADDING;
                n3 = n4 + 1;
                image.draw(spriteBatch, n11 + n12 + n13 + n14 + n + n5 + n15 * n3 + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) * n4, this.getPosY() - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.lSorted.get(n4))).getFlag().getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + CFG.PADDING + ImageManager.getImage(Images.economy).getWidth() + n + this.getTextWidth() + CFG.PADDING * n3 + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) * n4, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                n4 = n3;
                continue;
                break;
            }
        }
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }

    @Override
    protected void setCurrent(int n) {
        this.iProvinceID = n;
        this.lSorted.clear();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (n = 0; n < CFG.game.getProvince(this.iProvinceID).getPopulationData().getNationalitiesSize(); ++n) {
            arrayList.add(n);
        }
        while (arrayList.size() > 0) {
            int n2 = 0;
            for (n = 1; n < arrayList.size(); ++n) {
                int n3 = n2;
                if (CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulationID((Integer)arrayList.get(n2)) < CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulationID((Integer)arrayList.get(n))) {
                    n3 = n;
                }
                n2 = n3;
            }
            this.lSorted.add((Integer)arrayList.get(n2));
            arrayList.remove(n2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void setText(String string2) {
        this.sText = string2;
        this.setWidth(this.iMinWidth);
        try {
            CFG.glyphLayout.setText(CFG.fontMain, string2);
            this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
            this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            if (super.getWidth() < this.iTextWidth + CFG.PADDING * 2 + ImageManager.getImage(Images.economy).getWidth() + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale() + (float)CFG.PADDING) * Math.min(this.lSorted.size(), 2)) {
                this.setWidth(this.iTextWidth + CFG.PADDING * 2 + ImageManager.getImage(Images.economy).getWidth() + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale() + (float)CFG.PADDING) * Math.min(this.lSorted.size(), 2));
            }
            return;
        }
        catch (IllegalArgumentException | NullPointerException runtimeException) {
            return;
        }
    }
}

