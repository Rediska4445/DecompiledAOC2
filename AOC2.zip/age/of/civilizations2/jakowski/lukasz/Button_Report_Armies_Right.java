/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Report_Armies;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Report_Armies_Right
extends Button {
    private int iArmy;
    private int iArmyLost;
    private int iArmyWidth;
    private int iCivID;

    protected Button_Report_Armies_Right(int n, int n2, int n3, int n4, int n5, int n6) {
        this.iCivID = n4;
        this.iArmy = n5;
        this.iArmyLost = n6;
        GlyphLayout glyphLayout = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iArmy);
        glyphLayout.setText(bitmapFont, stringBuilder.toString());
        this.iArmyWidth = (int)CFG.glyphLayout.width;
        super.init("", 0, n, n2, n3, CFG.PADDING + ImageManager.getImage(Images.flag_rect).getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f) + (int)((float)CFG.TEXT_HEIGHT * 0.85f) * 2 + CFG.PADDING * 2, true, true, false, false, null);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivID).getCivName()));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Strength"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iArmy);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Casualties"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iArmyLost);
        String string2 = ((StringBuilder)object).toString();
        object = this.iArmyLost > 0 ? CFG.COLOR_TEXT_MODIFIER_NEGATIVE : CFG.COLOR_TEXT_MODIFIER_NEUTRAL;
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(string2, (Color)object));
        if (this.iArmyLost > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append(" [");
            ((StringBuilder)object).append((int)((float)this.iArmyLost / (float)this.iArmy * 100.0f));
            ((StringBuilder)object).append("%]");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
        }
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.425f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, 0.245f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
        spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 0.175f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - (CFG.PADDING * 2 + ImageManager.getImage(Images.flag_rect).getWidth() + 2) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2 + ImageManager.getImage(Images.flag_rect).getWidth() + 2, this.getHeight(), true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5, false, true);
        float f = this.getIsHovered() ? 0.95f : 0.675f;
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, f));
        CFG.drawRect(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        CFG.drawRect(spriteBatch, this.getPosX() - 1 + n, this.getPosY() - 1 + n2, this.getWidth() + 2, this.getHeight() + 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        CFG.drawRect(spriteBatch, this.getPosX() + 1 + n, this.getPosY() + 1 + n2, this.getWidth() - 2, this.getHeight() - 2);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 0.85f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, ImageManager.getImage(Images.flag_rect).getHeight(), true, false);
        spriteBatch.setColor(Color.WHITE);
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - ImageManager.getImage(Images.flag_rect).getWidth() + n, this.getPosY() + CFG.PADDING - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - ImageManager.getImage(Images.flag_rect).getWidth() + n, this.getPosY() + CFG.PADDING + n2);
        CFG.fontMain.getData().setScale(0.85f);
        Object object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iArmy);
        CFG.drawText(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING - 2 - ImageManager.getImage(Images.flag_rect).getWidth() - CFG.PADDING - (int)((float)this.iArmyWidth * 0.85f) + n, this.getPosY() + CFG.PADDING + ImageManager.getImage(Images.flag_rect).getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f) + n2, Button_Report_Armies.COLOR_ARMY);
        if (this.iArmyLost > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(this.iArmyLost);
            ((StringBuilder)object).append("-");
        } else {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(this.iArmyLost);
        }
        CFG.drawText(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + CFG.PADDING + 2 + n, this.getPosY() + CFG.PADDING + ImageManager.getImage(Images.flag_rect).getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f) + n2, Button_Report_Armies.COLOR_ARMY_LOST);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iArmy - this.iArmyLost);
        String string2 = ((StringBuilder)object).toString();
        int n3 = this.getPosX();
        int n4 = CFG.PADDING;
        int n5 = this.getPosY();
        int n6 = CFG.PADDING;
        int n7 = ImageManager.getImage(Images.flag_rect).getHeight() / 2;
        int n8 = (int)((float)CFG.TEXT_HEIGHT * 0.85f / 2.0f);
        int n9 = (int)((float)CFG.TEXT_HEIGHT * 0.85f);
        int n10 = CFG.PADDING;
        object = this.iArmy - this.iArmyLost == 0 ? Button_Report_Armies.COLOR_ARMY_LOST : Button_Report_Armies.COLOR_ARMY;
        CFG.drawText(spriteBatch, string2, n3 + n4 + 2 + n, n5 + n6 + n7 - n8 + n9 + n10 + n2, (Color)object);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

