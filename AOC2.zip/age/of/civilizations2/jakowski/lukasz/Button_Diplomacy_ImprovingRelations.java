/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Color;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

public class Button_Diplomacy_ImprovingRelations
extends Button {
    protected static final float FONT_SIZE = 0.6f;
    protected int iCivID = 0;
    private int iImprovingRelationsWidth;
    private boolean row = false;
    private String sImprovingRelations;
    private String sImprovingRelations2;

    protected Button_Diplomacy_ImprovingRelations(int n, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl) {
        super.init("", n3, n4, n5, n6, n7, bl, true, false, false);
        this.iCivID = n;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("ImprovingRelations"));
        stringBuilder.append(": ");
        this.sImprovingRelations = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sImprovingRelations);
        this.iImprovingRelationsWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.sImprovingRelations2 = CFG.langManager.get("TurnsX", n2);
    }

    private final float getImageScale() {
        return Math.min((float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(Images.icon_check_false).getHeight(), 1.0f);
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("WithdrawTheDiplomat"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.icon_check_false, CFG.PADDING, CFG.PADDING);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivID).getCivName());
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID, CFG.PADDING, 0);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            object2 = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, CFG.game.getCiv(this.iCivID).getG() / 255, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            Object object3 = new MenuElement_Hover_v2_Element_Type_Color((Color)object2);
            object.add((MenuElement_Hover_v2_Element_Type)object3);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("Opinion"));
            ((StringBuilder)object2).append(": ");
            object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
            object.add((MenuElement_Hover_v2_Element_Type)object3);
            object3 = new StringBuilder();
            ((StringBuilder)object3).append("");
            ((StringBuilder)object3).append((float)((int)(CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()) * 10.0f)) / 10.0f);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), this.getOpinionColor((int)CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID())));
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_relations, CFG.PADDING, 0);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            object3 = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, CFG.game.getCiv(this.iCivID).getG() / 255, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            object2 = new MenuElement_Hover_v2_Element_Type_Color((Color)object3);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object3 = new StringBuilder();
            ((StringBuilder)object3).append("+");
            ((StringBuilder)object3).append((float)((int)(DiplomacyManager.getImproveRelation(CFG.game.getActiveCivID(), this.iCivID) * 100.0f)) / 100.0f);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_relations_inc, CFG.PADDING, CFG.PADDING);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text("-0.5", CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.top_diplomacy_points, CFG.PADDING, CFG.PADDING);
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("PerTurn"));
            object.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sImprovingRelations, this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sImprovingRelations2, this.getPosX() + this.iImprovingRelationsWidth + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.fontMain.getData().setScale(1.0f);
        if (!this.getIsHovered() && !bl) {
            ImageManager.getImage(Images.icon_check_true).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.icon_check_true).getWidth() * this.getImageScale()) + n, this.getPosY() + (int)(((float)this.getHeight() - (float)ImageManager.getImage(Images.icon_check_true).getHeight() * this.getImageScale()) / 2.0f) - ImageManager.getImage(Images.icon_check_true).getHeight() + n2, (int)((float)ImageManager.getImage(Images.icon_check_true).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.icon_check_true).getHeight() * this.getImageScale()));
        } else {
            ImageManager.getImage(Images.icon_check_false).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.icon_check_false).getWidth() * this.getImageScale()) + n, this.getPosY() + (int)(((float)this.getHeight() - (float)ImageManager.getImage(Images.icon_check_false).getHeight() * this.getImageScale()) / 2.0f) - ImageManager.getImage(Images.icon_check_false).getHeight() + n2, (int)((float)ImageManager.getImage(Images.icon_check_false).getWidth() * this.getImageScale()), (int)((float)ImageManager.getImage(Images.icon_check_false).getHeight() * this.getImageScale()));
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    protected final Color getOpinionColor(int n) {
        Color color2 = n > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (n == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        return color2;
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

