/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_EditorFlag
extends Button {
    private int nCivID = 0;

    protected Button_EditorFlag(int n, int n2, int n3, boolean bl) {
        super.init("", 0, n2, n3, ImageManager.getImage(Images.top_flag_frame).getWidth(), CFG.BUTTON_HEIGHT, bl, true, false, false, null);
        this.setCurrent(n);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (CFG.game.getCiv(this.nCivID).getCivTag().equals("ran")) {
            spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.nCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.nCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.nCivID).getB() / 255.0f, 1.0f));
            CFG.game.getCiv(this.nCivID).getFlag().draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2 - CFG.game.getCiv(this.nCivID).getFlag().getHeight(), ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
            spriteBatch.setColor(Color.WHITE);
        } else {
            CFG.game.getCiv(this.nCivID).getFlag().draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2 - CFG.game.getCiv(this.nCivID).getFlag().getHeight(), ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
        }
        if (this.getIsHovered()) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.0375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.425f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + ImageManager.getImage(Images.top_flag_frame).getHeight() - ImageManager.getImage(Images.top_flag_frame).getHeight() / 5 + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2, ImageManager.getImage(Images.top_flag_frame).getWidth(), ImageManager.getImage(Images.top_flag_frame).getHeight() / 5, false, true);
            spriteBatch.setColor(Color.WHITE);
        }
        if (!bl && this.nCivID != CFG.iCreateScenario_AssignProvinces_Civ) {
            ImageManager.getImage(Images.top_flag_frame).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2);
        } else {
            ImageManager.getImage(Images.top_flag_frame_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.BUTTON_HEIGHT / 2 - ImageManager.getImage(Images.top_flag_frame).getHeight() / 2 + n2);
        }
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.941f, 1.0f, 0.0f, 1.0f) : (this.getClickable() ? new Color(0.376f, 0.388f, 0.376f, 1.0f) : new Color(0.674f, 0.09f, 0.066f, 0.5f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.nCivID;
    }

    @Override
    protected void setCurrent(int n) {
        this.nCivID = n;
    }
}

