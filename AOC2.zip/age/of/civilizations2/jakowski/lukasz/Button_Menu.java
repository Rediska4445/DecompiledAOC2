/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu
extends Button {
    protected static final int ANIMATION_T = 750;
    protected static int animationState;
    protected static long lTimeAnimation;

    protected Button_Menu(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false, null);
    }

    protected Button_Menu(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, true, bl2, null);
    }

    protected static final Color getColorLine() {
        return new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.675f);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
        if (this.getClickable() && this.getIsHovered() && !bl && (n3 = animationState++) >= 0) {
            if (n3 == 0) {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    animationState = 0;
                    lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_MENU_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_MENU_TEXT_HOVERED : CFG.COLOR_BUTTON_MENU_TEXT) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected void setIsHovered(boolean bl) {
        super.setIsHovered(bl);
        lTimeAnimation = System.currentTimeMillis();
        animationState = 0;
    }
}

