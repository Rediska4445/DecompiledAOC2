/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Date;
import age.of.civilizations2.jakowski.lukasz.Event_Decision;
import age.of.civilizations2.jakowski.lukasz.Event_PopUp;
import age.of.civilizations2.jakowski.lukasz.Event_Trigger;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Event_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private Event_Date eventDate_Since;
    private Event_Date eventDate_Until;
    private Event_PopUp event_PopUp = new Event_PopUp();
    private int iCivID_Recipient = -1;
    protected List<Event_Decision> lDecisions;
    protected List<Event_Trigger> lTriggers = new ArrayList<Event_Trigger>();
    private boolean repeatable = false;
    private String sEventName = "";
    private String sEventPicture = "";
    private String sEventTag;
    private boolean wasFired = false;
    private boolean wasTriedToRunOnce = false;

    protected Event_GameData() {
        this.lDecisions = new ArrayList<Event_Decision>();
        this.eventDate_Since = new Event_Date();
        this.eventDate_Until = new Event_Date();
        this.sEventTag = System.currentTimeMillis() + CFG.extraRandomTag();
        this.lDecisions = new ArrayList<Event_Decision>();
    }

    protected final void addNewTrigger() {
        this.lTriggers.add(new Event_Trigger());
    }

    protected final void checkDecisions() {
        int n = 0;
        while (n < this.lDecisions.size()) {
            int n2 = n;
            if (this.lDecisions.get((int)n).lOutcomes.size() == 0) {
                n2 = n;
                if (this.lDecisions.get((int)n).sTitle.equals("")) {
                    this.lDecisions.remove(n);
                    n2 = n - 1;
                }
            }
            n = n2 + 1;
        }
    }

    protected final void checkTriggers() {
        int n = 0;
        while (n < this.getTriggersSize()) {
            int n2 = n;
            if (this.getTrigger((int)n).lConditions.size() == 0) {
                this.removeTrigger(n);
                n2 = n - 1;
            }
            n = n2 + 1;
        }
    }

    protected final int getCivID() {
        return this.iCivID_Recipient;
    }

    protected final Event_Date getEventDate_Since() {
        return this.eventDate_Since;
    }

    protected final Event_Date getEventDate_Until() {
        return this.eventDate_Until;
    }

    protected final String getEventName() {
        return this.sEventName;
    }

    protected final String getEventPicture() {
        return this.sEventPicture;
    }

    protected final String getEventTag() {
        return this.sEventTag;
    }

    protected final Event_PopUp getEvent_PopUp() {
        return this.event_PopUp;
    }

    protected final boolean getRepeatable() {
        return this.repeatable;
    }

    protected final Event_Trigger getTrigger(int n) {
        return this.lTriggers.get(n);
    }

    protected final int getTriggersSize() {
        return this.lTriggers.size();
    }

    protected final boolean getWasFired() {
        return this.wasFired;
    }

    protected final boolean getWasTriedToRunOnce() {
        return this.wasTriedToRunOnce;
    }

    protected final void removeTrigger(int n) {
        this.lTriggers.remove(n);
    }

    protected final void setCivID(int n) {
        this.iCivID_Recipient = n;
    }

    protected final void setEventDate_Since(int n, int n2, int n3) {
        this.eventDate_Since.iEventDay = n;
        this.eventDate_Since.iEventMonth = n2;
        this.eventDate_Since.iEventYear = n3;
    }

    protected final void setEventDate_Until(int n, int n2, int n3) {
        this.eventDate_Until.iEventDay = n;
        this.eventDate_Until.iEventMonth = n2;
        this.eventDate_Until.iEventYear = n3;
    }

    protected final void setEventName(String string2) {
        this.sEventName = string2;
    }

    protected final void setEventPicture(String string2) {
        this.sEventPicture = string2;
    }

    protected final void setEventTag(String string2) {
        this.sEventTag = string2;
    }

    protected final void setRepeatable(boolean bl) {
        this.repeatable = bl;
    }

    protected final void setWasFired(boolean bl) {
        this.wasFired = bl;
    }

    protected final void setWasTriedToRunOnce(boolean bl) {
        this.wasTriedToRunOnce = bl;
    }
}

