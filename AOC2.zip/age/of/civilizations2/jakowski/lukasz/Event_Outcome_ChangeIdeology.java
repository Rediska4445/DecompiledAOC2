/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Ideology;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_ChangeIdeology
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iValue = -1;

    Event_Outcome_ChangeIdeology() {
    }

    protected boolean canMakeAction() {
        return false;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CHANGEIDEOLOGY);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("ChangeIdeology")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(" -> ").append(CFG.ideologiesManager.getIdeology(this.getValue()).getName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("ChangeIdeology");
            return var1_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("ChangeIdeology")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.ideologiesManager.getIdeology(this.getValue()).getName(), CFG.ideologiesManager.getIdeology(this.getValue()).getColor());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Ideology(this.getValue(), CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {
            return new ArrayList();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return new ArrayList();
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void outcomeAction() {
        if (this.getValue() < 0) {
            this.iValue = CFG.oR.nextInt(CFG.ideologiesManager.getIdeologiesSize());
        }
        if (this.getCivID() < 0) return;
        if (this.getCivID() >= CFG.game.getCivsSize()) return;
        try {
            CFG.game.getCiv(this.getCivID()).setIdeologyID(this.getValue());
            Object object = CFG.game.getCiv(this.getCivID());
            StringBuilder stringBuilder = new StringBuilder();
            ((Civilization)object).setCivTag(stringBuilder.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.getCivID()).getCivTag())).append(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(this.getCivID()).getIdeologyID()).getExtraTag()).toString());
            ((Civilization)object).updateNextReformation_Start();
            ((Civilization)object).updateNextElection_Start();
            object = CFG.game;
            int n = this.getCivID();
            CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n);
            ((Game)object).getCiv(n).loadFlag();
            n = 0;
            while (true) {
                block8: {
                    block7: {
                        if (n >= CFG.game.getPlayersSize()) break block7;
                        if (CFG.game.getPlayer(n).getCivID() != this.getCivID()) break block8;
                        CFG.game.getPlayer(n).loadPlayersFlag();
                    }
                    CFG.setActiveCivInfo(CFG.getActiveCivInfo());
                    return;
                }
                ++n;
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

