/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_LeaveAlliance
extends Event_Outcome {
    protected int iCivID = -1;

    Event_Outcome_LeaveAlliance() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl;
        boolean bl2 = bl = false;
        try {
            if (this.getCivID() < 0) return bl2;
            bl2 = bl;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl2;
        int n = CFG.game.getCiv(this.getCivID()).getAllianceID();
        bl2 = bl;
        if (n <= 0) return bl2;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_LEAVEALLIANCE);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("LeaveAlliance")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("LeaveAlliance");
            return var1_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        ArrayList arrayList = new ArrayList();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        ArrayList arrayList3 = arrayList;
        try {
            if (!this.canMakeAction()) return arrayList3;
            StringBuilder stringBuilder = new StringBuilder();
            arrayList3 = new ArrayList(stringBuilder.append(CFG.langManager.get("LeaveAlliance")).append(":").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(this.getCivID(), CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(arrayList2);
            arrayList.add(arrayList3);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
    }

    @Override
    protected void outcomeAction() {
        if (this.canMakeAction()) {
            DiplomacyManager.leaveAlliance(this.getCivID());
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

