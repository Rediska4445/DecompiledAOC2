/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;
import java.util.ArrayList;
import java.util.List;

class Event_Conditions_HaveArmy
extends Event_Conditions {
    protected int iCivID = -1;
    protected int iPercentage = 100;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Conditions_HaveArmy() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_HAVEARMY);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("HaveArmy")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("HaveArmy");
            return var1_3;
        }
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    @Override
    protected int getValue() {
        return this.iPercentage;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        int n = 0;
        int n2 = 0;
        while (true) {
            try {
                if (n2 >= this.lProvinces.size()) break;
                int n3 = CFG.game.getProvince(this.lProvinces.get(n2)).getArmyCivID(this.getCivID());
                int n4 = n;
                if (n3 > 0) {
                    n4 = n + 1;
                }
                ++n2;
                n = n4;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                return false;
            }
        }
        if ((float)n / (float)this.lProvinces.size() >= (float)this.getValue() / 100.0f) return true;
        return false;
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    @Override
    protected void setValue(int n) {
        this.iPercentage = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

