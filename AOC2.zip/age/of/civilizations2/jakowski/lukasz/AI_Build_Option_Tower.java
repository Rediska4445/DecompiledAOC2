/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Tower;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option_Tower
extends AI_Build_Option {
    AI_Build_Option_Tower() {
    }

    @Override
    protected AI_Build getData(int n) {
        return new AI_Build_Tower(n, this.getMoney(n));
    }

    @Override
    protected float getScore(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_TOWER * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Towers / Math.max(CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getTower_MaxLevel(), 1)));
    }
}

