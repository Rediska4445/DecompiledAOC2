/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Buildings;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Armoury;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Bunker;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Farm;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Fort;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Library;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_NuclearReactor;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Supply;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Tower;
import age.of.civilizations2.jakowski.lukasz.Construction_GameData_Workshop;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Armoury;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Bunker;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Farm;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Fort;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Library;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_NuclearReactor;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Port;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Supply;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Tower;
import age.of.civilizations2.jakowski.lukasz.Message_Bulit_Workshop;
import age.of.civilizations2.jakowski.lukasz.Save_Civ_GameData;

class BuildingsManager {
    protected static Buildings ACTIVE_BUILDING = Buildings.FORT;
    private static final float[] ARMOURY_BUILD_COST;
    private static final int[] ARMOURY_BUILD_MOVEMENT_COST;
    private static final int[] ARMOURY_CONSTRUCTION;
    private static final String[] ARMOURY_NAMES;
    private static final float[] ARMOURY_TECH_LEVEL;
    protected static final int BONUS_CAPITAL_ATTACK_FROM_CAPITAL = 10;
    protected static final int BONUS_CAPITAL_DEFENSE = 15;
    private static final float[] BUNKER_BUILD_COST;
    private static final int[] BUNKER_BUILD_MOVEMENT_COST;
    private static final int[] BUNKER_CONSTRUCTION;
    private static final int[] BUNKER_DEFENSE_BONUS;
    private static final int[] BUNKER_MAINTENANCE_COST;
    private static final String[] BUNKER_NAMES;
    private static final float[] BUNKER_TECH_LEVEL;
    protected static final int DESTROY_MOVEMENT_COST = 4;
    private static final float[] FARM_BUILD_COST;
    private static final int[] FARM_BUILD_MOVEMENT_COST;
    private static final int[] FARM_CONSTRUCTION;
    private static final float[] FARM_GROWTH_RATE_BONUS;
    private static final int[] FARM_MAINTENANCE_COST;
    private static final String[] FARM_NAMES;
    private static final float[] FARM_TECHNOLOGY_LEVEL;
    private static final float[] FORT_BUILD_COST;
    private static final int[] FORT_BUILD_MOVEMENT_COST;
    private static final int[] FORT_CONSTRUCTION;
    private static final int[] FORT_DEFENSE_BONUS;
    private static final int[] FORT_MAINTENANCE_COST;
    private static final String[] FORT_NAMES;
    private static final float[] FORT_TECH_LEVEL;
    private static final float[] LIBRARY_BUILD_COST;
    private static final int[] LIBRARY_BUILD_MOVEMENT_COST;
    private static final int[] LIBRARY_CONSTRUCTION;
    private static final String[] LIBRARY_NAMES;
    private static final int[] LIBRARY_RESEARCH_PER_POPULATION;
    private static final float[] LIBRARY_TECH_LEVEL;
    private static final float[] NUCLEAR_REACTOR_BUILD_COST;
    private static final int[] NUCLEAR_REACTOR_BUILD_MOVEMENT_COST;
    private static final int[] NUCLEAR_REACTOR_CONSTRUCTION;
    private static final String[] NUCLEAR_REACTOR_NAMES;
    private static final float[] NUCLEAR_REACTOR_TECH_LEVEL;
    private static final float[] PORT_BUILD_COST;
    private static final int[] PORT_BUILD_MOVEMENT_COST;
    private static final int[] PORT_CONSTRUCTION;
    private static final float[] PORT_INCOME_PRODUCTION;
    private static final int[] PORT_MAINTENANCE_COST;
    private static final String[] PORT_NAMES;
    private static final float[] PORT_TECHNOLOGY_LEVEL;
    private static final float[] SUPPLY_BONUS;
    private static final float[] SUPPLY_BUILD_COST;
    private static final int[] SUPPLY_BUILD_MOVEMENT_COST;
    private static final int[] SUPPLY_CONSTRUCTION;
    private static final String[] SUPPLY_NAMES;
    private static final float[] SUPPLY_TECH_LEVEL;
    private static final float[] TOWER_BUILD_COST;
    private static final int[] TOWER_BUILD_MOVEMENT_COST;
    private static final int[] TOWER_CONSTRUCTION;
    private static final int[] TOWER_DEFENSE_BONUS;
    private static final int[] TOWER_MAINTENANCE_COST;
    private static final String[] TOWER_NAMES;
    private static final float[] TOWER_TECHNOLOGY_LEVEL;
    private static final float[] WORKSHOP_BUILD_COST;
    private static final int[] WORKSHOP_BUILD_MOVEMENT_COST;
    private static final int[] WORKSHOP_CONSTRUCTION;
    private static final float[] WORKSHOP_INCOME_PRODUCTION;
    private static final int[] WORKSHOP_MAINTENANCE_COST;
    private static final String[] WORKSHOP_NAMES;
    private static final float[] WORKSHOP_TECHNOLOGY_LEVEL;
    protected static int iBuildInProvinceID;

    static {
        iBuildInProvinceID = 0;
        FORT_NAMES = new String[]{"", "Castle", "Fortress", "Fortress1", "Fortress2", "Fortress3", "Fortress4", "Fortress5", "Fortress6", "Fortress7", "Fortress8"};
        FORT_BUILD_COST = new float[]{0.0f, 0.05f, 0.0865f, 0.1265f, 0.4665f, 0.75f, 1.0f, 1.25f, 1.38f, 1.78f, 2.0f};
        FORT_BUILD_MOVEMENT_COST = new int[]{0, 12, 14, 16, 18, 20, 24, 28, 35, 41, 50};
        FORT_DEFENSE_BONUS = new int[]{0, 10, 30, 60, 90, 120, 150, 180, 220, 250, 300};
        FORT_MAINTENANCE_COST = new int[]{0, 60, 125, 255, 500, 750, 900, 1200, 1500, 2000, 2500};
        FORT_TECH_LEVEL = new float[]{0.0f, 0.25f, 0.5f, 0.75f, 1.0f, 1.5f, 2.0f, 2.5f, 3.5f, 4.0f, 5.0f};
        FORT_CONSTRUCTION = new int[]{0, 2, 5, 10, 15, 24, 30, 38, 40, 50};
        TOWER_NAMES = new String[]{"", "WatchTower", "WatchTower2", "WatchTower3", "WatchTower4", "WatchTower5"};
        TOWER_BUILD_COST = new float[]{0.0f, 0.0425f, 0.0825f, 0.1225f, 0.1855f, 0.2425f};
        TOWER_BUILD_MOVEMENT_COST = new int[]{0, 16, 20, 26, 30, 36};
        TOWER_DEFENSE_BONUS = new int[]{0, 4, 8, 15, 30, 50};
        TOWER_MAINTENANCE_COST = new int[]{0, 35, 60, 100, 200, 250};
        TOWER_TECHNOLOGY_LEVEL = new float[]{0.0f, 0.2f, 0.3f, 0.5f, 0.8f, 1.0f};
        TOWER_CONSTRUCTION = new int[]{0, 2, 5, 10, 16, 22};
        PORT_NAMES = new String[]{"", "Port1", "Port2", "Port3", "Port4", "Port5", "Port6", "Port7", "Port8", "Port9", "Port10"};
        PORT_BUILD_COST = new float[]{0.0f, 0.0685f, 0.1285f, 0.2f, 0.2685f, 0.3485f, 0.4205f, 0.5685f, 0.6666f, 0.8123f, 0.9999f};
        PORT_BUILD_MOVEMENT_COST = new int[]{0, 16, 20, 25, 30, 31, 32, 33, 34, 35, 36};
        PORT_MAINTENANCE_COST = new int[]{0, 60, 130, 255, 555, 757, 999, 1299, 1575, 2003, 2555};
        PORT_TECHNOLOGY_LEVEL = new float[]{0.0f, 0.25f, 0.5f, 0.85f, 1.4f, 2.0f, 2.5f, 3.0f, 3.75f, 4.88f, 5.5f};
        PORT_INCOME_PRODUCTION = new float[]{0.0f, 0.25f, 0.45f, 0.67f, 0.8f, 0.99f, 1.25f, 1.75f, 2.25f, 3.25f, 4.55f};
        PORT_CONSTRUCTION = new int[]{0, 1, 3, 5, 7, 12, 19, 28, 35, 50, 100};
        FARM_NAMES = new String[]{"", "Farm1", "Farm2", "Farm3", "Farm4", "Farm5", "Farm6", "Farm7", "Farm8", "Farm9", "Farm10", "Farm11", "Farm12", "Farm13", "Farm14", "Farm15"};
        FARM_BUILD_COST = new float[]{0.0f, 0.024999999f, 0.049999997f, 0.099999994f, 0.165f, 0.19999999f, 0.25f, 0.5f, 1.0f, 1.2f, 1.5f, 2.0f, 2.5f, 3.0f, 3.5f, 4.5f};
        FARM_BUILD_MOVEMENT_COST = new int[]{0, 14, 16, 18, 24, 26, 40, 60, 100, 100, 100, 100, 100, 100, 100, 100};
        FARM_GROWTH_RATE_BONUS = new float[]{0.0f, 0.05f, 0.1f, 0.15f, 0.2f, 0.25f, 0.4f, 0.5f, 1.0f, 1.25f, 1.75f, 2.25f, 2.66f, 3.0f, 4.0f, 5.25f};
        FARM_MAINTENANCE_COST = new int[]{0, 35, 50, 55, 65, 75, 125, 75, 200, 200, 200, 200, 200, 200, 200, 200, 200};
        FARM_TECHNOLOGY_LEVEL = new float[]{0.0f, 0.15f, 0.3f, 0.4f, 0.55f, 0.7f, 1.0f, 1.5f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f};
        FARM_CONSTRUCTION = new int[]{0, 1, 3, 6, 8, 9, 13, 16, 21, 21, 26, 30, 42, 45, 51, 74};
        LIBRARY_NAMES = new String[]{"", "Library", "University", "ResearchLab", "Library1", "Library2", "Library3", "Library4", "Library5", "Library6", "Library7"};
        LIBRARY_BUILD_COST = new float[]{0.0f, 0.049999997f, 0.099999994f, 0.25f, 0.5f, 1.0f, 1.25f, 1.75f, 2.5f, 4.0f, 5.55f};
        LIBRARY_BUILD_MOVEMENT_COST = new int[]{0, 10, 16, 18, 22, 50, 75, 99, 100, 125, 150};
        LIBRARY_RESEARCH_PER_POPULATION = new int[]{0, 10000, 5000, 1000, 500, 250, 100, 50, 25, 10, 1};
        LIBRARY_TECH_LEVEL = new float[]{0.0f, 0.25f, 0.5f, 0.85f, 1.0f, 1.1f, 1.1f, 1.1f, 1.1f, 1.1f, 1.1f};
        LIBRARY_CONSTRUCTION = new int[]{0, 2, 3, 4, 8, 16, 20, 25, 35, 50, 75};
        ARMOURY_NAMES = new String[]{"", "Armoury"};
        ARMOURY_BUILD_COST = new float[]{0.0f, 0.19999999f};
        ARMOURY_BUILD_MOVEMENT_COST = new int[]{0, 28};
        ARMOURY_TECH_LEVEL = new float[]{0.0f, 0.4f};
        ARMOURY_CONSTRUCTION = new int[]{0, 4};
        NUCLEAR_REACTOR_NAMES = new String[]{"", "NuclearReactor"};
        NUCLEAR_REACTOR_BUILD_COST = new float[]{0.0f, 10.0f};
        NUCLEAR_REACTOR_BUILD_MOVEMENT_COST = new int[]{0, 320};
        NUCLEAR_REACTOR_TECH_LEVEL = new float[]{0.0f, 1.0f};
        NUCLEAR_REACTOR_CONSTRUCTION = new int[]{0, 18};
        BUNKER_NAMES = new String[]{"", "Bunker"};
        BUNKER_BUILD_COST = new float[]{0.0f, 0.65f};
        BUNKER_BUILD_MOVEMENT_COST = new int[]{0, 12};
        BUNKER_DEFENSE_BONUS = new int[]{0, 15};
        BUNKER_TECH_LEVEL = new float[]{0.0f, 0.55f};
        BUNKER_CONSTRUCTION = new int[]{0, 8};
        WORKSHOP_NAMES = new String[]{"", "Workshop1", "Workshop2", "Workshop3", "Workshop4", "Workshop5", "Workshop6", "Workshop7", "Workshop8", "Workshop9", "Workshop10", "Workshop11", "Workshop12", "Workshop13", "Workshop14", "Workshop15"};
        WORKSHOP_BUILD_COST = new float[]{0.0f, 0.024999999f, 0.049999997f, 0.099999994f, 0.165f, 0.19999999f, 0.25f, 0.5f, 1.0f, 1.2f, 1.5f, 2.0f, 2.5f, 3.0f, 3.5f, 4.5f};
        WORKSHOP_BUILD_MOVEMENT_COST = new int[]{0, 14, 16, 18, 24, 26, 40, 60, 100, 100, 100, 100, 100, 100, 100, 100};
        WORKSHOP_INCOME_PRODUCTION = new float[]{0.0f, 0.05f, 0.1f, 0.15f, 0.2f, 0.25f, 0.4f, 0.5f, 1.0f, 1.25f, 1.75f, 2.25f, 2.66f, 3.0f, 4.0f, 5.25f};
        WORKSHOP_MAINTENANCE_COST = new int[]{0, 35, 50, 55, 65, 75, 125, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150};
        WORKSHOP_TECHNOLOGY_LEVEL = new float[]{0.0f, 0.15f, 0.3f, 0.4f, 0.55f, 0.7f, 1.0f, 1.5f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f};
        WORKSHOP_CONSTRUCTION = new int[]{0, 1, 3, 6, 8, 9, 12, 17, 20, 22, 25, 31, 41, 46, 50, 75};
        SUPPLY_NAMES = new String[]{"", "SupplyCamp1", "SupplyCamp2", "SupplyCamp3", "SupplyCamp4", "SupplyCamp5"};
        SUPPLY_BUILD_COST = new float[]{0.0f, 0.049999997f, 0.099999994f, 0.25f, 0.5f, 1.0f};
        SUPPLY_BUILD_MOVEMENT_COST = new int[]{0, 10, 16, 18, 22, 50};
        SUPPLY_TECH_LEVEL = new float[]{0.0f, 0.25f, 0.5f, 0.85f, 1.0f, 1.1f};
        SUPPLY_CONSTRUCTION = new int[]{0, 2, 3, 13, 25, 50};
        SUPPLY_BONUS = new float[]{0.0f, 0.2f, 0.45f, 0.7f, 0.85f, 0.99f};
    }

    BuildingsManager() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildArmoury(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfArmoury() >= BuildingsManager.getArmoury_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfArmoury(CFG.game.getProvince(n).getLevelOfArmoury() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Armoury(n2, n));
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final boolean buildBunker(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfBunker() >= BuildingsManager.getBunker_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfBunker(CFG.game.getProvince(n).getLevelOfBunker() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        int n3 = 0;
        while (true) {
            if (n3 >= CFG.game.getPlayersSize()) {
                CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Bunker(n2, n));
                return true;
            }
            if (CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getNumOfProvinces() > 0) {
                CFG.game.getProvince(n).updateFogOfWar(n3);
            }
            ++n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildFarm(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfFarm() >= BuildingsManager.getFarm_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfFarm(CFG.game.getProvince(n).getLevelOfFarm() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Farm(n2, n));
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final boolean buildFort(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfFort() >= BuildingsManager.getFort_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfFort(CFG.game.getProvince(n).getLevelOfFort() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        int n3 = 0;
        while (true) {
            if (n3 >= CFG.game.getPlayersSize()) {
                CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Fort(n2, n));
                return true;
            }
            if (CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getNumOfProvinces() > 0) {
                CFG.game.getProvince(n).updateFogOfWar(n3);
            }
            ++n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildLibrary(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfLibrary() >= BuildingsManager.getLibrary_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfLibrary(CFG.game.getProvince(n).getLevelOfLibrary() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Library(n2, n));
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildNuclearReactor(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfNuclearReactor() >= BuildingsManager.getNuclearReactor_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfNuclearReactor(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_NuclearReactor(n2, n));
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildPort(int n, int n2) {
        if (CFG.game.getProvince(n).getLevelOfPort() < 0) return false;
        if (CFG.game.getProvince(n).getLevelOfPort() >= BuildingsManager.getPort_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfPort(CFG.game.getProvince(n).getLevelOfPort() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Port(n2, n));
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildSupply(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfSupply() >= BuildingsManager.getSupply_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfSupply(CFG.game.getProvince(n).getLevelOfSupply() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Supply(n2, n));
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final boolean buildTower(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfWatchTower() >= BuildingsManager.getTower_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfWatchTower(CFG.game.getProvince(n).getLevelOfWatchTower() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        int n3 = 0;
        while (true) {
            if (n3 >= CFG.game.getPlayersSize()) {
                CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Tower(n2, n));
                return true;
            }
            if (CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getNumOfProvinces() > 0) {
                for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
                    CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).updateFogOfWar(n3);
                }
            }
            ++n3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean buildWorkshop(int n, int n2) {
        if (CFG.game.getProvince(n).getSeaProvince()) return false;
        if (CFG.game.getProvince(n).getLevelOfWorkshop() >= BuildingsManager.getWorkshop_MaxLevel()) return false;
        CFG.game.getProvince(n).setLevelOfWorkshop(CFG.game.getProvince(n).getLevelOfWorkshop() + 1);
        Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
        ++save_Civ_GameData.iNumOfBuildingsConstructed;
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Bulit_Workshop(n2, n));
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildArmoury(int n) {
        if (CFG.game.getProvince(n).getLevelOfArmoury() >= BuildingsManager.getArmoury_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getArmoury_TechLevel(CFG.game.getProvince(n).getLevelOfArmoury() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getArmoury_BuildMovementCost(CFG.game.getProvince(n).getLevelOfArmoury() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildBunker(int n) {
        if (CFG.game.getProvince(n).getLevelOfBunker() >= BuildingsManager.getBunker_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getBunker_TechLevel(CFG.game.getProvince(n).getLevelOfBunker() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getBunker_BuildMovementCost(CFG.game.getProvince(n).getLevelOfBunker() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildFarm(int n) {
        if (CFG.game.getProvince(n).getLevelOfFarm() >= BuildingsManager.getFarm_MaxLevel()) return false;
        if (!BuildingsManager.canBuildFarm_Terrain(n)) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(CFG.game.getProvince(n).getLevelOfFarm() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getFarm_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFarm() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildFarm_Terrain(int n) {
        if (!(CFG.terrainTypesManager.getPopulationGrowth(CFG.game.getProvince(n).getTerrainTypeID()) >= 0.0f)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildFort(int n) {
        if (CFG.game.getProvince(n).getLevelOfFort() >= BuildingsManager.getFort_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(CFG.game.getProvince(n).getLevelOfFort() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getFort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFort() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildLibrary(int n) {
        if (CFG.game.getProvince(n).getLevelOfLibrary() >= BuildingsManager.getLibrary_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getLibrary_TechLevel(CFG.game.getProvince(n).getLevelOfLibrary() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getLibrary_BuildMovementCost(CFG.game.getProvince(n).getLevelOfLibrary() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildNuclearReactor(int n) {
        if (CFG.game.getProvince(n).getLevelOfNuclearReactor() >= BuildingsManager.getNuclearReactor_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getNuclearReactor_TechLevel(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getNuclearReactor_BuildMovementCost(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildPort(int n) {
        if (CFG.game.getProvince(n).getLevelOfPort() >= BuildingsManager.getPort_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getPort_TechLevel(CFG.game.getProvince(n).getLevelOfPort() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getPort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfPort() + 1)) return false;
        if (CFG.game.getProvince(n).getNeighboringSeaProvincesSize() <= 0) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildSupply(int n) {
        if (CFG.game.getProvince(n).getLevelOfSupply() >= BuildingsManager.getSupply_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getSupply_TechLevel(CFG.game.getProvince(n).getLevelOfSupply() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getSupply_BuildMovementCost(CFG.game.getProvince(n).getLevelOfSupply() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildTower(int n) {
        if (CFG.game.getProvince(n).getLevelOfWatchTower() >= BuildingsManager.getTower_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getTower_TechLevel(CFG.game.getProvince(n).getLevelOfWatchTower() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getTower_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWatchTower() + 1)) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean canBuildWorkshop(int n) {
        if (CFG.game.getProvince(n).getLevelOfWorkshop() >= BuildingsManager.getWorkshop_MaxLevel()) return false;
        if (!(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() >= BuildingsManager.getWorkshop_TechLevel(CFG.game.getProvince(n).getLevelOfWorkshop() + 1))) return false;
        if (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getMovePoints() < BuildingsManager.getWorkshop_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWorkshop() + 1)) return false;
        return true;
    }

    protected static final boolean constructArmoury(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfArmoury() < BuildingsManager.getArmoury_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getArmoury_TechLevel(CFG.game.getProvince(n).getLevelOfArmoury() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getArmoury_BuildMovementCost(CFG.game.getProvince(n).getLevelOfArmoury() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getArmoury_BuildCost(CFG.game.getProvince(n).getLevelOfArmoury() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getArmoury_BuildMovementCost(CFG.game.getProvince(n).getLevelOfArmoury() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getArmoury_BuildCost(CFG.game.getProvince(n).getLevelOfArmoury() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Armoury(n, BuildingsManager.getArmoury_Construction(CFG.game.getProvince(n).getLevelOfArmoury() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructBunker(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfBunker() < BuildingsManager.getBunker_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getBunker_TechLevel(CFG.game.getProvince(n).getLevelOfBunker() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getBunker_BuildMovementCost(CFG.game.getProvince(n).getLevelOfBunker() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getBunker_BuildCost(CFG.game.getProvince(n).getLevelOfBunker() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getBunker_BuildMovementCost(CFG.game.getProvince(n).getLevelOfBunker() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getBunker_BuildCost(CFG.game.getProvince(n).getLevelOfBunker() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Bunker(n, BuildingsManager.getBunker_Construction(CFG.game.getProvince(n).getLevelOfBunker() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructFarm(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfFarm() < BuildingsManager.getFarm_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(CFG.game.getProvince(n).getLevelOfFarm() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getFarm_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFarm() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getFarm_BuildCost(CFG.game.getProvince(n).getLevelOfFarm() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getFarm_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFarm() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getFarm_BuildCost(CFG.game.getProvince(n).getLevelOfFarm() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Farm(n, BuildingsManager.getFarm_Construction(CFG.game.getProvince(n).getLevelOfFarm() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructFort(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfFort() < BuildingsManager.getFort_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(CFG.game.getProvince(n).getLevelOfFort() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getFort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFort() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getFort_BuildCost(CFG.game.getProvince(n).getLevelOfFort() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getFort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfFort() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getFort_BuildCost(CFG.game.getProvince(n).getLevelOfFort() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Fort(n, BuildingsManager.getFort_Construction(CFG.game.getProvince(n).getLevelOfFort() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructLibrary(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfLibrary() < BuildingsManager.getLibrary_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getLibrary_TechLevel(CFG.game.getProvince(n).getLevelOfLibrary() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getLibrary_BuildMovementCost(CFG.game.getProvince(n).getLevelOfLibrary() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getLibrary_BuildCost(CFG.game.getProvince(n).getLevelOfLibrary() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getLibrary_BuildMovementCost(CFG.game.getProvince(n).getLevelOfLibrary() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getLibrary_BuildCost(CFG.game.getProvince(n).getLevelOfLibrary() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Library(n, BuildingsManager.getLibrary_Construction(CFG.game.getProvince(n).getLevelOfLibrary() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructNuclearReactor(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfNuclearReactor() < BuildingsManager.getNuclearReactor_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getNuclearReactor_TechLevel(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getNuclearReactor_BuildMovementCost(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getNuclearReactor_BuildCost(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getNuclearReactor_BuildMovementCost(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getNuclearReactor_BuildCost(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_NuclearReactor(n, BuildingsManager.getNuclearReactor_Construction(CFG.game.getProvince(n).getLevelOfNuclearReactor() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructPort(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (CFG.game.getProvince(n).getLevelOfPort() >= 0) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfPort() < BuildingsManager.getPort_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getPort_TechLevel(CFG.game.getProvince(n).getLevelOfPort() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getPort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfPort() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getPort_BuildCost(CFG.game.getProvince(n).getLevelOfPort() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getPort_BuildMovementCost(CFG.game.getProvince(n).getLevelOfPort() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getPort_BuildCost(CFG.game.getProvince(n).getLevelOfPort() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData(n, BuildingsManager.getPort_Construction(CFG.game.getProvince(n).getLevelOfPort() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructSupply(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfSupply() < BuildingsManager.getSupply_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getSupply_TechLevel(CFG.game.getProvince(n).getLevelOfSupply() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getSupply_BuildMovementCost(CFG.game.getProvince(n).getLevelOfSupply() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getSupply_BuildCost(CFG.game.getProvince(n).getLevelOfSupply() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getSupply_BuildMovementCost(CFG.game.getProvince(n).getLevelOfSupply() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getSupply_BuildCost(CFG.game.getProvince(n).getLevelOfSupply() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Supply(n, BuildingsManager.getSupply_Construction(CFG.game.getProvince(n).getLevelOfSupply() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructTower(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfWatchTower() < BuildingsManager.getTower_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getTower_TechLevel(CFG.game.getProvince(n).getLevelOfWatchTower() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getTower_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWatchTower() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getTower_BuildCost(CFG.game.getProvince(n).getLevelOfWatchTower() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getTower_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWatchTower() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getTower_BuildCost(CFG.game.getProvince(n).getLevelOfWatchTower() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Tower(n, BuildingsManager.getTower_Construction(CFG.game.getProvince(n).getLevelOfWatchTower() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean constructWorkshop(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfWorkshop() < BuildingsManager.getWorkshop_MaxLevel()) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getTechnologyLevel() >= BuildingsManager.getWorkshop_TechLevel(CFG.game.getProvince(n).getLevelOfWorkshop() + 1)) {
                    bl2 = bl;
                    if (CFG.game.getCiv(n2).getMovePoints() >= BuildingsManager.getWorkshop_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWorkshop() + 1)) {
                        bl2 = bl;
                        if (CFG.game.getCiv(n2).getMoney() >= (long)BuildingsManager.getWorkshop_BuildCost(CFG.game.getProvince(n).getLevelOfWorkshop() + 1, n)) {
                            CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - BuildingsManager.getWorkshop_BuildMovementCost(CFG.game.getProvince(n).getLevelOfWorkshop() + 1));
                            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)BuildingsManager.getWorkshop_BuildCost(CFG.game.getProvince(n).getLevelOfWorkshop() + 1, n));
                            CFG.game.getCiv(n2).addNewConstruction(new Construction_GameData_Workshop(n, BuildingsManager.getWorkshop_Construction(CFG.game.getProvince(n).getLevelOfWorkshop() + 1)));
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyArmoury(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfArmoury() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfArmoury(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyBunker(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfBunker() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfBunker(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyFarm(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfFarm() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfFarm(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyFort(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfFort() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfFort(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyLibrary(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfLibrary() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfLibrary(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyNuclearReactor(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfNuclearReactor() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfNuclearReactor(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyPort(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfPort() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfPort(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroySupply(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfSupply() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfSupply(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyTower(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfWatchTower() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfWatchTower(0);
                    if (CFG.game.getCiv(n2).getControlledByPlayer()) {
                        CFG.game.getProvince(n).updateFogOfWar(CFG.game.getPlayerID_ByCivID(n2));
                    }
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    protected static final boolean destroyWorkshop(int n, int n2) {
        boolean bl;
        boolean bl2 = bl = false;
        if (!CFG.game.getProvince(n).getSeaProvince()) {
            bl2 = bl;
            if (CFG.game.getProvince(n).getLevelOfWorkshop() > 0) {
                bl2 = bl;
                if (CFG.game.getCiv(n2).getMovePoints() >= 4) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 4);
                    CFG.game.getProvince(n).setLevelOfWorkshop(0);
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getArmoury_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        int n4 = 0;
        while (true) {
            block5: {
                if (n4 >= CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces()) break;
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(n4)).getLevelOfArmoury() <= 0) break block5;
                ++n3;
            }
            ++n4;
        }
        try {
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = ARMOURY_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.0235f * f3) + f4 * (0.3f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getArmoury_BuildMovementCost(int n) {
        try {
            return ARMOURY_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getArmoury_Construction(int n) {
        try {
            return ARMOURY_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getArmoury_MaxLevel() {
        return ARMOURY_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getArmoury_Name(int n) {
        try {
            return ARMOURY_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return ARMOURY_NAMES[ARMOURY_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return ARMOURY_NAMES[ARMOURY_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getArmoury_TechLevel(int n) {
        try {
            return ARMOURY_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getBunker_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        try {
            for (int i = 0; i < CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces(); ++i) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfBunker() <= 0) continue;
                n3 += CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfBunker();
            }
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = BUNKER_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.004721f * f3) + f4 * (0.0275f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getBunker_BuildMovementCost(int n) {
        try {
            return BUNKER_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getBunker_Construction(int n) {
        try {
            return BUNKER_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getBunker_DefenseBonus(int n) {
        try {
            return BUNKER_DEFENSE_BONUS[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getBunker_MaitenanceCost(int n) {
        try {
            return BUNKER_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getBunker_MaxLevel() {
        return BUNKER_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getBunker_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < BUNKER_TECH_LEVEL.length) {
            if (BUNKER_TECH_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getFort_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getBunker_Name(int n) {
        try {
            return BUNKER_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return BUNKER_NAMES[BUNKER_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return BUNKER_NAMES[BUNKER_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getBunker_TechLevel(int n) {
        try {
            return BUNKER_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getFarm_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        try {
            for (int i = 0; i < CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces(); ++i) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfFarm() <= 0) continue;
                n3 += CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfFarm();
            }
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = FARM_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.00215f * f3) + f4 * (0.015f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFarm_BuildMovementCost(int n) {
        try {
            return FARM_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFarm_Construction(int n) {
        try {
            return FARM_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getFarm_GrowthRateBonus(int n) {
        try {
            return FARM_GROWTH_RATE_BONUS[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return FARM_GROWTH_RATE_BONUS[FARM_GROWTH_RATE_BONUS.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return FARM_GROWTH_RATE_BONUS[FARM_GROWTH_RATE_BONUS.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFarm_MaitenanceCost(int n) {
        try {
            return FARM_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getFarm_MaxLevel() {
        return FARM_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFarm_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < FARM_TECHNOLOGY_LEVEL.length) {
            if (FARM_TECHNOLOGY_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getFarm_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getFarm_Name(int n) {
        try {
            return FARM_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return FARM_NAMES[FARM_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return FARM_NAMES[FARM_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getFarm_TechLevel(int n) {
        try {
            return FARM_TECHNOLOGY_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getFort_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        try {
            for (int i = 0; i < CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces(); ++i) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfFort() <= 0) continue;
                n3 += CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfFort();
            }
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = FORT_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.004721f * f3) + f4 * (0.0275f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFort_BuildMovementCost(int n) {
        try {
            return FORT_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFort_Construction(int n) {
        try {
            return FORT_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFort_DefenseBonus(int n) {
        try {
            return FORT_DEFENSE_BONUS[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFort_MaitenanceCost(int n) {
        try {
            return FORT_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getFort_MaxLevel() {
        return FORT_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getFort_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < FORT_TECH_LEVEL.length) {
            if (FORT_TECH_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getFort_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getFort_Name(int n) {
        try {
            return FORT_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return FORT_NAMES[FORT_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return FORT_NAMES[FORT_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getFort_TechLevel(int n) {
        try {
            return FORT_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getLibrary_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        try {
            for (int i = 0; i < CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces(); ++i) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfLibrary() <= 0) continue;
                n3 += CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfLibrary();
            }
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = LIBRARY_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.00425f * f3) + f4 * (0.135f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getLibrary_BuildMovementCost(int n) {
        try {
            return LIBRARY_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getLibrary_Construction(int n) {
        try {
            return LIBRARY_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getLibrary_MaxLevel() {
        return LIBRARY_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getLibrary_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < LIBRARY_TECH_LEVEL.length) {
            if (LIBRARY_TECH_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getLibrary_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getLibrary_Name(int n) {
        try {
            return LIBRARY_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return LIBRARY_NAMES[LIBRARY_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return LIBRARY_NAMES[LIBRARY_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getLibrary_ResearchPerPopulation(int n) {
        try {
            return LIBRARY_RESEARCH_PER_POPULATION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getLibrary_TechLevel(int n) {
        try {
            return LIBRARY_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getNuclearReactor_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        int n4 = 0;
        while (true) {
            block5: {
                if (n4 >= CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces()) break;
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(n4)).getLevelOfNuclearReactor() <= 0) break block5;
                ++n3;
            }
            ++n4;
        }
        try {
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = NUCLEAR_REACTOR_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.0235f * f3) + f4 * (0.3f * (1.0f - f5))) * (f6 + 1.0f)) * 2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getNuclearReactor_BuildMovementCost(int n) {
        try {
            return NUCLEAR_REACTOR_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getNuclearReactor_Construction(int n) {
        try {
            return NUCLEAR_REACTOR_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getNuclearReactor_MaxLevel() {
        return NUCLEAR_REACTOR_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getNuclearReactor_Name(int n) {
        try {
            return NUCLEAR_REACTOR_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return NUCLEAR_REACTOR_NAMES[NUCLEAR_REACTOR_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return NUCLEAR_REACTOR_NAMES[NUCLEAR_REACTOR_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getNuclearReactor_TechLevel(int n) {
        try {
            return NUCLEAR_REACTOR_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getPort_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        int n4 = 0;
        while (true) {
            block5: {
                if (n4 >= CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces()) break;
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(n4)).getLevelOfPort() <= 0) break block5;
                ++n3;
            }
            ++n4;
        }
        try {
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = PORT_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.00325f * f3) + f4 * (0.015f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getPort_BuildMovementCost(int n) {
        try {
            return PORT_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getPort_Construction(int n) {
        try {
            return PORT_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getPort_IncomeProduction(int n) {
        try {
            return PORT_INCOME_PRODUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return 0.0f;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getPort_MaitenanceCost(int n) {
        try {
            return PORT_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getPort_MaxLevel() {
        return PORT_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getPort_Name(int n) {
        try {
            return PORT_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return PORT_NAMES[PORT_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return PORT_NAMES[PORT_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getPort_TechLevel(int n) {
        try {
            return PORT_TECHNOLOGY_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getSupply_Bonus(int n) {
        try {
            return SUPPLY_BONUS[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return SUPPLY_BONUS[SUPPLY_BONUS.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return SUPPLY_BONUS[SUPPLY_BONUS.length - 1];
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getSupply_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        int n4 = 0;
        while (true) {
            block5: {
                if (n4 >= CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces()) break;
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(n4)).getLevelOfSupply() <= 0) break block5;
                ++n3;
            }
            ++n4;
        }
        try {
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = SUPPLY_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.0115f * f3) + f4 * (0.3f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getSupply_BuildMovementCost(int n) {
        try {
            return SUPPLY_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getSupply_Construction(int n) {
        try {
            return SUPPLY_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getSupply_MaxLevel() {
        return SUPPLY_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getSupply_Name(int n) {
        try {
            return SUPPLY_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return SUPPLY_NAMES[SUPPLY_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return SUPPLY_NAMES[SUPPLY_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getSupply_TechLevel(int n) {
        try {
            return SUPPLY_TECH_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getTower_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        int n4 = 0;
        while (true) {
            block5: {
                if (n4 >= CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces()) break;
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(n4)).getLevelOfWatchTower() <= 0) break block5;
                ++n3;
            }
            ++n4;
        }
        try {
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = TOWER_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.005314f * f3) + f4 * (0.01f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getTower_BuildMovementCost(int n) {
        try {
            return TOWER_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getTower_Construction(int n) {
        try {
            return TOWER_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getTower_DefenseBonus(int n) {
        try {
            return TOWER_DEFENSE_BONUS[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getTower_MaitenanceCost(int n) {
        try {
            return TOWER_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getTower_MaxLevel() {
        return TOWER_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getTower_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < TOWER_TECHNOLOGY_LEVEL.length) {
            if (TOWER_TECHNOLOGY_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getTower_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getTower_Name(int n) {
        try {
            return TOWER_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return TOWER_NAMES[TOWER_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return TOWER_NAMES[TOWER_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getTower_TechLevel(int n) {
        try {
            return TOWER_TECHNOLOGY_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final int getWorkshop_BuildCost(int n, int n2) {
        float f;
        float f2;
        int n3 = 0;
        try {
            for (int i = 0; i < CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getNumOfProvinces(); ++i) {
                if (CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfWorkshop() <= 0) continue;
                n3 += CFG.game.getProvince(CFG.game.getCiv(CFG.game.getProvince(n2).getCivID()).getProvinceID(i)).getLevelOfWorkshop();
            }
            f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
            f = WORKSHOP_BUILD_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
        float f3 = n3;
        float f4 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f5 = CFG.game.getProvince(n2).getDevelopmentLevel();
        float f6 = CFG.terrainTypesManager.getBuildCost(CFG.game.getProvince(n2).getTerrainTypeID());
        return (int)((f2 * (f + 0.002675f * f3) + f4 * (0.025f * (1.0f - f5))) * (f6 + 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getWorkshop_BuildMovementCost(int n) {
        try {
            return WORKSHOP_BUILD_MOVEMENT_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getWorkshop_Construction(int n) {
        try {
            return WORKSHOP_CONSTRUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getWorkshop_IncomeProduction(int n) {
        try {
            return WORKSHOP_INCOME_PRODUCTION[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return WORKSHOP_INCOME_PRODUCTION[WORKSHOP_INCOME_PRODUCTION.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return WORKSHOP_INCOME_PRODUCTION[WORKSHOP_INCOME_PRODUCTION.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getWorkshop_MaitenanceCost(int n) {
        try {
            return WORKSHOP_MAINTENANCE_COST[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0;
        }
    }

    protected static final int getWorkshop_MaxLevel() {
        return WORKSHOP_NAMES.length - 1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getWorkshop_MaxLevel_CanBuild(int n) {
        int n2 = 0;
        while (n2 < WORKSHOP_TECHNOLOGY_LEVEL.length) {
            if (WORKSHOP_TECHNOLOGY_LEVEL[n2] > CFG.game.getCiv(n).getTechnologyLevel()) return n2 - 1;
            ++n2;
        }
        return BuildingsManager.getWorkshop_MaxLevel();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final String getWorkshop_Name(int n) {
        try {
            return WORKSHOP_NAMES[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return WORKSHOP_NAMES[WORKSHOP_NAMES.length - 1];
            CFG.exceptionStack(indexOutOfBoundsException);
            return WORKSHOP_NAMES[WORKSHOP_NAMES.length - 1];
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getWorkshop_TechLevel(int n) {
        try {
            return WORKSHOP_TECHNOLOGY_LEVEL[n];
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return 0.0f;
            CFG.exceptionStack(indexOutOfBoundsException);
            return 0.0f;
        }
    }
}

