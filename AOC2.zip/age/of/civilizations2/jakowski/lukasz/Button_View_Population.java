/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.io.Serializable;
import java.util.ArrayList;

class Button_View_Population
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.6f;
    private int iLargestNationality;
    protected int iLevelWidth;
    private int iPopulationPercWidth;
    private int iPopulationWidth;
    private int iProvinceID;
    protected boolean isAssimiliate;
    private boolean row;
    protected String sLevel;
    private String sPopulation;
    private String sPopulationPerc;

    protected Button_View_Population(int n, String object, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        boolean bl2 = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        this.iPopulationPercWidth = 0;
        this.iLargestNationality = 0;
        this.isAssimiliate = false;
        this.sLevel = "";
        this.iLevelWidth = 0;
        super.init((String)object, 0, n4, n5, n6, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        n4 = 1;
        if (n % 2 == 0) {
            bl2 = true;
        }
        this.row = bl2;
        this.iProvinceID = n2;
        for (n = n4; n < CFG.game.getProvince(this.iProvinceID).getPopulationData().getNationalitiesSize(); ++n) {
            if (CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulationID(this.iLargestNationality) >= CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulationID(n)) continue;
            this.iLargestNationality = n;
        }
        this.iLargestNationality = CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(this.iLargestNationality);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation());
        ((StringBuilder)object).append(CFG.getNumberWithSpaces(stringBuilder.toString()));
        this.sPopulation = ((StringBuilder)object).toString();
        GlyphLayout glyphLayout = CFG.glyphLayout;
        object = CFG.fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        glyphLayout.setText((BitmapFont)object, stringBuilder.toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append((float)((int)((float)CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation() / (float)n3 * 10000.0f)) / 100.0f);
        ((StringBuilder)object).append("%");
        this.sPopulationPerc = ((StringBuilder)object).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sPopulationPerc);
        this.iPopulationPercWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.isAssimiliate = bl;
        if (CFG.game.getProvince(n2).getLevelOfLibrary() > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(CFG.game.getProvince(n2).getLevelOfLibrary());
            this.sLevel = ((StringBuilder)object).toString();
            CFG.glyphLayout.setText(CFG.fontMain, this.sLevel);
            this.iLevelWidth = (int)(CFG.glyphLayout.width * 0.6f);
        }
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void buildElementHover() {
        try {
            Object object;
            ArrayList<MenuElement_Hover_v2_Element2> arrayList;
            block20: {
                Serializable serializable;
                int n;
                ArrayList<Integer> arrayList2;
                ArrayList<MenuElement_Hover_v2_Element_Type> arrayList3;
                block19: {
                    arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
                    arrayList3 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
                    if (this.iProvinceID >= 0) {
                        object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID());
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        object = new MenuElement_Hover_v2_Element_Type_Text(this.getText(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        object = new StringBuilder();
                        ((StringBuilder)object).append("");
                        ((StringBuilder)object).append(CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation());
                        arrayList2 = new ArrayList<Integer>(CFG.getNumberWithSpaces(((StringBuilder)object).toString()), CFG.COLOR_TEXT_POPULATION);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList2));
                        boolean bl = CFG.game.showTurnChangesInformation(CFG.game.getProvince(this.iProvinceID).getCivID());
                        int n2 = 0;
                        int n3 = 0;
                        if (bl) {
                            object = new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, CFG.PADDING);
                            arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                            n = CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population;
                            if (n > 0) {
                                object = new StringBuilder();
                                ((StringBuilder)object).append("+");
                                serializable = new StringBuilder();
                                ((StringBuilder)serializable).append("");
                                ((StringBuilder)serializable).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                                ((StringBuilder)object).append(CFG.getNumberWithSpaces(((StringBuilder)serializable).toString()));
                                arrayList2 = new ArrayList<Integer>(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                                arrayList3.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList2));
                            } else if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population < 0) {
                                object = new StringBuilder();
                                ((StringBuilder)object).append("");
                                ((StringBuilder)object).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                                arrayList2 = new ArrayList<Integer>(CFG.getNumberWithSpaces(((StringBuilder)object).toString()), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                                arrayList3.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList2));
                            } else {
                                arrayList2 = new ArrayList<Integer>();
                                ((StringBuilder)((Object)arrayList2)).append("+");
                                ((StringBuilder)((Object)arrayList2)).append(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_Population);
                                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)((Object)arrayList2)).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                            }
                            object = new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0);
                            arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        } else {
                            object = new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0);
                            arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        }
                        object = new MenuElement_Hover_v2_Element2(arrayList3);
                        arrayList.add((MenuElement_Hover_v2_Element2)object);
                        arrayList3.clear();
                        object = new MenuElement_Hover_v2_Element_Type_Space();
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        object = new MenuElement_Hover_v2_Element2(arrayList3);
                        arrayList.add((MenuElement_Hover_v2_Element2)object);
                        arrayList3.clear();
                        serializable = new ArrayList();
                        arrayList2 = new ArrayList<Integer>();
                        for (n = 0; n < CFG.game.getProvince(this.iProvinceID).getPopulationData().getNationalitiesSize(); ++n) {
                            serializable.add(CFG.game.getProvince(this.iProvinceID).getPopulationData().getCivID(n));
                            arrayList2.add(CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulationID(n));
                        }
                    } else {
                        this.menuElementHover = null;
                        return;
                    }
                    int n4 = 0;
                    while (n4 < serializable.size() - 1) {
                        for (int i = n = n4 + 1; i < serializable.size(); ++i) {
                            if ((Integer)arrayList2.get(n4) >= (Integer)arrayList2.get(i)) continue;
                            int n5 = (Integer)serializable.get(n4);
                            serializable.set(n4, serializable.get(i));
                            serializable.set(i, n5);
                            n5 = (Integer)arrayList2.get(n4);
                            arrayList2.set(n4, (Integer)arrayList2.get(i));
                            arrayList2.set(i, n5);
                        }
                        n4 = n;
                    }
                    n4 = CFG.FOG_OF_WAR;
                    if (n4 != 2) break block19;
                    for (n = n3; n < serializable.size(); ++n) {
                        n4 = CFG.getMetCiv((Integer)serializable.get(n)) ? (Integer)serializable.get(n) : -(n + 1);
                        object = new MenuElement_Hover_v2_Element_Type_Flag(n4);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        Object object2 = new StringBuilder();
                        ((StringBuilder)object2).append("");
                        ((StringBuilder)object2).append(arrayList2.get(n));
                        stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)object2).toString()));
                        object = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        object2 = new StringBuilder();
                        ((StringBuilder)object2).append(" [");
                        ((StringBuilder)object2).append(CFG.getPercentage((Integer)arrayList2.get(n), CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation(), 5));
                        ((StringBuilder)object2).append("%]");
                        object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(" ");
                        object = CFG.getMetCiv((Integer)serializable.get(n)) ? CFG.game.getCiv((Integer)serializable.get(n)).getCivName() : CFG.langManager.get("Unknown");
                        stringBuilder.append((String)object);
                        object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), Color.WHITE);
                        arrayList3.add((MenuElement_Hover_v2_Element_Type)object2);
                        object = new MenuElement_Hover_v2_Element2(arrayList3);
                        arrayList.add((MenuElement_Hover_v2_Element2)object);
                        arrayList3.clear();
                    }
                    break block20;
                }
                for (n = n2; n < serializable.size(); ++n) {
                    object = new MenuElement_Hover_v2_Element_Type_Flag((Integer)serializable.get(n));
                    arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                    Object object3 = new StringBuilder();
                    ((StringBuilder)object3).append("");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(arrayList2.get(n));
                    ((StringBuilder)object3).append(CFG.getNumberWithSpaces(stringBuilder.toString()));
                    object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object3).toString(), CFG.COLOR_TEXT_POPULATION);
                    arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, CFG.PADDING);
                    arrayList3.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new StringBuilder();
                    ((StringBuilder)object).append("[");
                    ((StringBuilder)object).append(CFG.getPercentage((Integer)arrayList2.get(n), CFG.game.getProvince(this.iProvinceID).getPopulationData().getPopulation(), 5));
                    ((StringBuilder)object).append("%]");
                    object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    arrayList3.add((MenuElement_Hover_v2_Element_Type)object3);
                    object = new StringBuilder();
                    ((StringBuilder)object).append(" ");
                    ((StringBuilder)object).append(CFG.game.getCiv((Integer)serializable.get(n)).getCivName());
                    object3 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_RANK_HOVER);
                    arrayList3.add((MenuElement_Hover_v2_Element_Type)object3);
                    object = new MenuElement_Hover_v2_Element2(arrayList3);
                    arrayList.add((MenuElement_Hover_v2_Element2)object);
                    arrayList3.clear();
                }
            }
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.isAssimiliate) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary() > 0) {
            spriteBatch.setColor(Color.WHITE);
            ImageManager.getImage(Images.b_library).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.b_library).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_library).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_library).getHeight(), (int)((float)ImageManager.getImage(Images.b_library).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())), (int)((float)ImageManager.getImage(Images.b_library).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())));
            CFG.fontMain.getData().setScale(0.6f);
            CFG.drawTextWithShadow(spriteBatch, this.sLevel, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.b_library).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())) - CFG.PADDING - this.iLevelWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            CFG.fontMain.getData().setScale(1.0f);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iLargestNationality).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(this.iLargestNationality).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + CFG.PADDING * 2 + (int)((float)this.getTextWidth() * 0.65f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, CFG.COLOR_TEXT_POPULATION);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawText(spriteBatch, this.sPopulationPerc, this.getPosX() + this.getWidth() - CFG.PADDING - this.iPopulationPercWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

