/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_DiplomacyPoints
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iValue = 0;

    Event_Outcome_DiplomacyPoints() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl;
        boolean bl2 = false;
        try {
            if (this.getCivID() == -1) return true;
            bl = bl2;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl2;
        }
        if (this.getCivID() < 0) return bl;
        if (this.getCivID() == 0) return true;
        bl = bl2;
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl;
        int n = CFG.game.getCiv(this.getCivID()).getNumOfProvinces();
        bl = bl2;
        if (n <= 0) return bl;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DIPLOMACYPOINTS);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected String getConditionText() {
        void var1_5;
        try {
            void var1_3;
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = stringBuilder.append(CFG.langManager.get("UpdateDiplomacyPoints")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ");
            if (this.getValue() > 0) {
                String string2 = "+";
            } else {
                String string3 = "";
            }
            String string4 = stringBuilder2.append((String)var1_3).append((float)this.getValue() / 10.0f).toString();
            return var1_5;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string5 = CFG.langManager.get("UpdateDiplomacyPoints");
            return var1_5;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList arrayList = new ArrayList();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = arrayList;
            if (!this.canMakeAction()) return object;
            object = new Object(this.getCivID());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            Object object2 = new StringBuilder();
            object = new Object(((StringBuilder)object2).append(CFG.langManager.get("DiplomacyPoints")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new Object();
            CharSequence charSequence = ((StringBuilder)object).append(" ");
            object = this.getValue() > 0 ? "+" : "";
            charSequence = charSequence.append((String)object).append((float)this.getValue() / 10.0f).toString();
            object = this.getValue() > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (this.getValue() == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, (Color)object);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new Object(arrayList2);
            arrayList.add(object);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    @Override
    protected void outcomeAction() {
        if (this.canMakeAction()) {
            if (this.getCivID() == -1) {
                Civilization civilization;
                int n;
                while ((n = CFG.oR.nextInt(CFG.game.getCivsSize())) == 0 || (civilization = CFG.game.getCiv(n)).getNumOfProvinces() <= 0) {
                }
                civilization.setDiplomacyPoints(civilization.getDiplomacyPoints() + this.getValue());
                if (civilization.getControlledByPlayer()) {
                    CFG.menuManager.updateInGame_TOP_All(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                }
            } else if (this.getCivID() == 0) {
                for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
                    Civilization civilization = CFG.game.getCiv(i);
                    if (civilization.getNumOfProvinces() <= 0) continue;
                    civilization.setDiplomacyPoints(civilization.getDiplomacyPoints() + this.getValue());
                    if (!civilization.getControlledByPlayer()) continue;
                    CFG.menuManager.updateInGame_TOP_All(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                }
            } else {
                CFG.game.getCiv(this.getCivID()).setDiplomacyPoints(CFG.game.getCiv(this.getCivID()).getDiplomacyPoints() + this.getValue());
                if (CFG.game.getCiv(this.getCivID()).getControlledByPlayer()) {
                    CFG.menuManager.updateInGame_TOP_All(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID());
                }
            }
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

