/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Menu_GameEditor_Regions;
import age.of.civilizations2.jakowski.lukasz.Menu_MapEditor_OptimizationRegions;
import age.of.civilizations2.jakowski.lukasz.Region;
import age.of.civilizations2.jakowski.lukasz.UndoOptimizationRegions;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import java.util.ArrayList;
import java.util.List;

class Editor_Regions
extends Editor {
    protected static int activeRegion;
    protected static List<UndoOptimizationRegions> lUndo;

    protected Editor_Regions() {
        lUndo = new ArrayList<UndoOptimizationRegions>();
    }

    protected static final void actionUpdateRegionID(boolean bl) {
        if (CFG.game.getActiveProvinceID() >= 0) {
            if (bl) {
                Editor_Regions.addUndo(CFG.game.getActiveProvinceID());
            }
            for (int i = 0; i < CFG.game.getRegions().size(); ++i) {
                for (int j = 0; j < CFG.game.getRegions().get(i).getProvincesSize(); ++j) {
                    if (CFG.game.getRegions().get(i).getProvince(j) != CFG.game.getActiveProvinceID()) continue;
                    CFG.game.getRegions().get(i).removeProvince(j);
                    CFG.game.getRegions().get(i).buildRegionBounds();
                }
            }
            if (activeRegion >= CFG.game.getRegions().size()) {
                Menu_GameEditor_Regions.lColors.add(CFG.getRandomColor());
                CFG.game.getRegions().add(new Region());
                CFG.game.getRegions().get(CFG.game.getRegions().size() - 1).addProvince(CFG.game.getActiveProvinceID());
                CFG.game.getRegions().get(CFG.game.getRegions().size() - 1).buildRegionBounds();
                CFG.game.updateRegionsSize();
            } else {
                CFG.game.getRegions().get(activeRegion).addProvince(CFG.game.getActiveProvinceID());
                CFG.game.getRegions().get(activeRegion).buildRegionBounds();
            }
            if (Menu_MapEditor_OptimizationRegions.showValues) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).getArmy_Obj(0).updateArmyWidth(CFG.game.getRegionID(CFG.game.getActiveProvinceID()));
            }
            CFG.setRender_3(true);
        }
    }

    private static final void addUndo(int n) {
        if (n < 0) {
            return;
        }
        if (lUndo.size() > 0) {
            List<UndoOptimizationRegions> list = lUndo;
            if (list.get((int)(list.size() - 1)).iProvinceID != n && activeRegion != CFG.game.getRegionID(n)) {
                if (lUndo.size() > 50) {
                    lUndo.remove(0);
                    lUndo.add(new UndoOptimizationRegions(n, CFG.game.getRegionID(n)));
                } else {
                    lUndo.add(new UndoOptimizationRegions(n, CFG.game.getRegionID(n)));
                }
            }
        } else if (activeRegion != CFG.game.getRegionID(n)) {
            lUndo.add(new UndoOptimizationRegions(n, CFG.game.getRegionID(n)));
        }
    }

    protected static void popUndo() {
        if (lUndo.size() > 0) {
            List<UndoOptimizationRegions> list = CFG.game;
            List<UndoOptimizationRegions> list2 = lUndo;
            ((Game)((Object)list)).setActiveProvinceID(list2.get((int)(list2.size() - 1)).iProvinceID);
            list = lUndo;
            activeRegion = ((UndoOptimizationRegions)list.get((int)(list.size() - 1))).iRegionID;
            Editor_Regions.actionUpdateRegionID(false);
            if (!CFG.game.getProvince(CFG.game.getActiveProvinceID()).getDrawProvince()) {
                CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getActiveProvinceID());
            }
            list = lUndo;
            list.remove(list.size() - 1);
        }
    }

    protected static final void saveRegions() {
        int n;
        Object object = Gdx.files;
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("map/");
        ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
        ((StringBuilder)object2).append("data/");
        ((StringBuilder)object2).append("regions");
        object2 = object.local(((StringBuilder)object2).toString());
        int n2 = 0;
        while (n2 < CFG.game.getRegions().size()) {
            n = n2;
            if (CFG.game.getRegions().get(n2).getProvincesSize() == 0) {
                Menu_GameEditor_Regions.lColors.remove(n2);
                CFG.game.getRegions().remove(n2);
                n = n2 - 1;
            }
            n2 = n + 1;
        }
        object = "";
        for (n2 = 0; n2 < CFG.game.getRegions().size(); ++n2) {
            StringBuilder stringBuilder;
            for (n = 0; n < CFG.game.getRegions().get(n2).getProvincesSize(); ++n) {
                stringBuilder = new StringBuilder();
                stringBuilder.append((String)object);
                stringBuilder.append(CFG.game.getRegions().get(n2).getProvince(n));
                stringBuilder.append(";");
                object = stringBuilder.toString();
            }
            if (n2 == CFG.game.getRegions().size() - 1) continue;
            stringBuilder = new StringBuilder();
            stringBuilder.append((String)object);
            stringBuilder.append("\n");
            object = stringBuilder.toString();
        }
        ((FileHandle)object2).writeString((String)object, false);
        CFG.game.loadRegions();
    }

    @Override
    protected void keyDown(int n) {
        if (Gdx.input.isKeyPressed(21)) {
            if (--activeRegion < 0) {
                activeRegion = CFG.game.getRegions().size();
            }
        } else if (Gdx.input.isKeyPressed(22) && ++activeRegion > CFG.game.getRegions().size()) {
            activeRegion = 0;
        }
        if ((Gdx.input.isKeyPressed(20) || Gdx.input.isKeyPressed(19)) && CFG.game.getActiveProvinceID() >= 0) {
            activeRegion = CFG.game.getRegionID(CFG.game.getActiveProvinceID());
        }
        if (Gdx.input.isKeyPressed(62)) {
            Editor_Regions.actionUpdateRegionID(true);
        }
        if (Gdx.input.isKeyPressed(66)) {
            Editor_Regions.saveRegions();
        }
    }

    @Override
    public String toString() {
        CharSequence charSequence;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SET TO REGION ID: ");
        stringBuilder.append(activeRegion);
        if (CFG.game.getActiveProvinceID() >= 0) {
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("\n\nACTIVE PROVINCE REGION ID: ");
            ((StringBuilder)charSequence).append(CFG.game.getRegionID(CFG.game.getActiveProvinceID()));
            ((StringBuilder)charSequence).append("\nNUMBER OF PROVINCES: ");
            ((StringBuilder)charSequence).append(CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getProvincesSize());
            ((StringBuilder)charSequence).append("\nWIDTH: ");
            ((StringBuilder)charSequence).append(CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMaxX() - CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMinX());
            ((StringBuilder)charSequence).append(" [");
            ((StringBuilder)charSequence).append((int)((float)(CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMaxX() - CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMinX()) * 100.0f / (float)CFG.map.getMapBG().getWidth()));
            ((StringBuilder)charSequence).append("%]\nHEIGHT:");
            ((StringBuilder)charSequence).append(CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMaxY() - CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMinY());
            ((StringBuilder)charSequence).append(" [");
            ((StringBuilder)charSequence).append((int)((float)(CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMaxY() - CFG.game.getRegions().get(CFG.game.getRegionID(CFG.game.getActiveProvinceID())).getMinY()) * 100.0f / (float)CFG.map.getMapBG().getHeight()));
            ((StringBuilder)charSequence).append("%]");
            charSequence = ((StringBuilder)charSequence).toString();
        } else {
            charSequence = "";
        }
        stringBuilder.append((String)charSequence);
        return stringBuilder.toString();
    }
}

