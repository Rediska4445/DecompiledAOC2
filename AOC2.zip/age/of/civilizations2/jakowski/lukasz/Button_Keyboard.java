/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Keyboard
extends Button {
    protected Button_Keyboard(String string2, int n, int n2, int n3, int n4, Button.TypeOfButton typeOfButton, boolean bl) {
        super.init(string2, -1, n, n2, n3, n4, bl, true, false, false, typeOfButton);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3 = 1.$SwitchMap$age$of$civilizations2$jakowski$lukasz$Button$TypeOfButton[this.typeOfButton.ordinal()];
        if (n3 != 1) {
            if (n3 != 2) {
                if (n3 != 3) {
                    if (n3 != 4) {
                        if (n3 == 5) {
                            if (bl) {
                                CFG.drawRect_NewGameBox(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                            } else {
                                CFG.drawRect_NewGameBox_EDGE(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                            }
                        }
                    } else if (bl) {
                        CFG.drawRect_NewGameBox(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                    } else {
                        CFG.drawRect_NewGameBox_EDGE(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                    }
                } else if (bl) {
                    CFG.drawRect_NewGameBox_EDGE(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                } else {
                    CFG.drawRect_NewGameBox(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
                }
            } else if (bl) {
                CFG.drawRect_NewGameBox(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
            } else {
                CFG.drawRect_NewGameBox_EDGE(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
            }
        } else if (bl) {
            CFG.drawRect_NewGameBox_EDGE(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        } else {
            CFG.drawRect_NewGameBox(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.3882353f, 0.35686275f, 0.32156864f, 1.0f) : (this.getClickable() ? new Color(0.74509805f, 0.73333335f, 0.7176471f, 1.0f) : new Color(0.49f, 0.49f, 0.49f, 0.5f));
        return color2;
    }
}

