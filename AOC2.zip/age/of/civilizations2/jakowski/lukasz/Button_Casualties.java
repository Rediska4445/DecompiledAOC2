/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

public class Button_Casualties
extends Button {
    private int iPopulationWidth = 0;
    private Color oColorCasualtiesTotal;
    private boolean row = true;
    private String sPopulation;

    protected Button_Casualties(int n, int n2, int n3, int n4, int n5, boolean bl) {
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Casualties"));
        ((StringBuilder)object).append(": ");
        super.init(((StringBuilder)object).toString(), 0, n2, n3, n4, n5, bl, true, false, false, null);
        n = CFG.game.getWar(n).getCasualties_Aggressors() + CFG.game.getWar(n).getCasualties_Defenders();
        object = n == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        this.oColorCasualtiesTotal = object;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(CFG.getNumber_SHORT(n));
        this.sPopulation = ((StringBuilder)object).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sPopulation);
        this.iPopulationWidth = (int)CFG.glyphLayout.width;
    }

    private final float getImageScale(int n) {
        float f = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.8f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.8f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            int n = CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getCasualties_Aggressors() + CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getCasualties_Defenders();
            Object object = n == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            this.oColorCasualtiesTotal = object;
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("Casualties"));
            ((StringBuilder)object).append(": ");
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            ((StringBuilder)object).append(CFG.getNumberWithSpaces(stringBuilder.toString()));
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), this.oColorCasualtiesTotal);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.difficulty_hell, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            if (n > 0) {
                int n2;
                object = new MenuElement_Hover_v2_Element_Type_Space();
                arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                object = new MenuElement_Hover_v2_Element2(arrayList2);
                arrayList.add((MenuElement_Hover_v2_Element2)object);
                arrayList2.clear();
                boolean bl = false;
                for (n = 0; n < CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getAggressorsSize(); ++n) {
                    n2 = CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getAggressorID(n).getCasualties() + CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getAggressorID(n).getCivilianDeaths();
                    if (n2 <= 0) continue;
                    object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getAggressorID(n).getCivID());
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new StringBuilder();
                    ((StringBuilder)object).append(CFG.langManager.get("Casualties"));
                    ((StringBuilder)object).append(": ");
                    object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString());
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    object = new StringBuilder();
                    ((StringBuilder)object).append("");
                    ((StringBuilder)object).append(n2);
                    stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)object).toString()));
                    object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
                    object = new MenuElement_Hover_v2_Element_Type_Image(Images.difficulty_hell, CFG.PADDING, 0);
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new MenuElement_Hover_v2_Element2(arrayList2);
                    arrayList.add((MenuElement_Hover_v2_Element2)object);
                    arrayList2.clear();
                    bl = true;
                }
                n = 0;
                for (int i = 0; i < CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getDefendersSize(); ++i) {
                    int n3 = CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getDefenderID(i).getCasualties() + CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getDefenderID(i).getCivilianDeaths();
                    n2 = n;
                    if (n3 > 0) {
                        n2 = n;
                        if (bl) {
                            n2 = n;
                            if (n == 0) {
                                object = new MenuElement_Hover_v2_Element_Type_Space();
                                arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                                object = new MenuElement_Hover_v2_Element2(arrayList2);
                                arrayList.add((MenuElement_Hover_v2_Element2)object);
                                arrayList2.clear();
                                n2 = 1;
                            }
                        }
                        object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(CFG.peaceTreatyData.peaceTreatyGameData.iWarID).getDefenderID(i).getCivID());
                        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                        object2 = new StringBuilder();
                        ((StringBuilder)object2).append(CFG.langManager.get("Casualties"));
                        ((StringBuilder)object2).append(": ");
                        object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString());
                        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                        object = new StringBuilder();
                        ((StringBuilder)object).append("");
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        stringBuilder.append(n3);
                        ((StringBuilder)object).append(CFG.getNumberWithSpaces(stringBuilder.toString()));
                        object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                        arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
                        object = new MenuElement_Hover_v2_Element_Type_Image(Images.difficulty_hell, CFG.PADDING, 0);
                        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                        object = new MenuElement_Hover_v2_Element2(arrayList2);
                        arrayList.add((MenuElement_Hover_v2_Element2)object);
                        arrayList2.clear();
                    }
                    n = n2;
                }
            }
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (!bl && !this.getIsHovered()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.9f));
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.65f));
        }
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight(), false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() * 4 / 5, this.getHeight(), false, false);
        spriteBatch.setColor(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1, false, false);
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.difficulty_hell).draw(spriteBatch, this.getPosX() + CFG.PADDING * 3 + (int)((float)this.getTextWidth() * 0.8f) + (int)((float)this.iPopulationWidth * 0.8f) + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.difficulty_hell).getHeight() * this.getImageScale(ImageManager.getImage(Images.difficulty_hell).getHeight())) / 2 + n2 - ImageManager.getImage(Images.difficulty_hell).getHeight(), (int)((float)ImageManager.getImage(Images.difficulty_hell).getWidth() * this.getImageScale(ImageManager.getImage(Images.difficulty_hell).getHeight())), (int)((float)ImageManager.getImage(Images.difficulty_hell).getHeight() * this.getImageScale(ImageManager.getImage(Images.difficulty_hell).getHeight())));
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sText, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sPopulation, this.getPosX() + CFG.PADDING * 2 + (int)((float)this.getTextWidth() * 0.8f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.oColorCasualtiesTotal);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.56f, 0.56f, 0.56f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(0.68f, 0.68f, 0.68f, 1.0f) : new Color(0.82f, 0.82f, 0.82f, 1.0f)) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    protected int getWidth() {
        return Math.max(super.getWidth(), CFG.PADDING * 4 + (int)((float)this.getTextWidth() * 0.8f + (float)this.iPopulationWidth * 0.8f + (float)((int)((float)ImageManager.getImage(Images.difficulty_hell).getWidth() * this.getImageScale(ImageManager.getImage(Images.difficulty_hell).getHeight())))) + CFG.PADDING * 2);
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = n == 0;
        this.row = bl;
    }
}

