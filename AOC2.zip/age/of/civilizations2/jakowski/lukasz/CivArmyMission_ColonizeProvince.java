/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_RegroupAfterRecruitment;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_PortToBuild;
import java.io.Serializable;
import java.util.ArrayList;

class CivArmyMission_ColonizeProvince
extends CivArmyMission {
    private int iCivID;
    private int iColonizeProvinceID;

    protected CivArmyMission_ColonizeProvince(int n, int n2) {
        this.toProvinceID = n2;
        this.iColonizeProvinceID = n2;
        this.MISSION_ID = -1;
        this.iCivID = n;
        this.MISSION_TYPE = CivArmyMission_Type.COLONIZE_PROVINCE;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = (int)Math.max((float)CFG.game.getProvincesSize() * 0.01f, 30.0f);
        this.iArmy = 0;
        this.generateColonizeData();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean action(int n) {
        Serializable serializable;
        boolean bl = true;
        if (CFG.game.getProvince(this.iColonizeProvinceID).getCivID() != 0) {
            int n2;
            CFG.game.setCivRelation_OfCivB(this.iCivID, CFG.game.getProvince(this.iColonizeProvinceID).getCivID(), CFG.game.getCivRelation_OfCivB(this.iCivID, CFG.game.getProvince(this.iColonizeProvinceID).getCivID()) - 0.25f - (float)CFG.oR.nextInt(425) / 100.0f);
            serializable = new ArrayList();
            for (n2 = 0; n2 < CFG.game.getProvince(this.toProvinceID).getNeighboringProvincesSize(); ++n2) {
                if (CFG.game.getProvince(this.toProvinceID).getNeighboringProvinces(n2) == this.iColonizeProvinceID || CFG.game.getProvince(CFG.game.getProvince(this.toProvinceID).getNeighboringProvinces(n2)).getSeaProvince() || CFG.game.getProvince(CFG.game.getProvince(this.toProvinceID).getNeighboringProvinces(n2)).getCivID() != 0) continue;
                serializable.add(CFG.game.getProvince(this.toProvinceID).getNeighboringProvinces(n2));
            }
            if (serializable.size() == 0) {
                this.iObsolate = 0;
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
                return bl;
            }
            int n3 = 0;
            for (n2 = serializable.size() - 1; n2 > 0; --n2) {
                int n4 = n3;
                if (CFG.game.getProvince((Integer)serializable.get(n3)).getGrowthRate_Population() < CFG.game.getProvince((Integer)serializable.get(n2)).getGrowthRate_Population()) {
                    n4 = n2;
                }
                n3 = n4;
            }
            this.iColonizeProvinceID = (Integer)serializable.get(n3);
        }
        if (this.iProvinceID != this.toProvinceID) {
            if (this.action_RecruitArmy() && ((RegroupArmy_Data)(serializable = new RegroupArmy_Data_PortToBuild(n, this.iProvinceID, this.toProvinceID))).getRouteSize() > 0) {
                ((RegroupArmy_Data)serializable).getRoute(0);
                if (!CFG.game.getProvince(this.iProvinceID).getSeaProvince() && CFG.game.getProvince(((RegroupArmy_Data)serializable).getRoute(0)).getSeaProvince() && !this.action_BuildPort(this.iProvinceID, ((RegroupArmy_Data)serializable).getRoute(0))) {
                    return false;
                }
                if (CFG.gameAction.moveArmy(this.iProvinceID, ((RegroupArmy_Data)serializable).getRoute(0), this.iArmy, n, true, false)) {
                    this.iProvinceID = ((RegroupArmy_Data)serializable).getRoute(0);
                    return false;
                }
            }
        } else {
            if (DiplomacyManager.colonizeWastelandProvince(this.iColonizeProvinceID, this.iCivID)) {
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
                CFG.game.getCiv(this.iCivID).buildCivPersonality_Colonization();
                boolean bl2 = bl;
                if (CFG.gameAction.moveArmy(this.iProvinceID, this.iColonizeProvinceID, this.iArmy, n, true, false)) return bl2;
                CFG.game.getCiv((int)this.iCivID).civGameData.civPlans.addNewArmyMission(this.iProvinceID, new CivArmyMission_RegroupAfterRecruitment(this.iCivID, this.iProvinceID, this.iColonizeProvinceID, this.iArmy));
                return bl;
            }
            this.lockTreasury();
            return false;
        }
        CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean action_BuildPort(int n, int n2) {
        boolean bl = false;
        if (CFG.game.getProvince(n).getLevelOfPort() != 0) return true;
        if (CFG.game.getProvince(n).getCivID() == this.iCivID) {
            boolean bl2 = bl;
            if (CFG.game.getCiv(this.iCivID).isInConstruction(n, ConstructionType.PORT) != 0) return bl2;
            if (BuildingsManager.constructPort(n, this.iCivID)) {
                return bl;
            }
            this.lockTreasury_Port(n);
            return bl;
        }
        this.generateColonizeData();
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean action_RecruitArmy() {
        boolean bl = false;
        if (CFG.game.getProvince(this.iProvinceID).getArmyCivID(this.iCivID) >= 1) return true;
        if (CFG.game.getProvince(this.iProvinceID).getTrueOwnerOfProvince() != this.iCivID || CFG.game.getProvince(this.iProvinceID).getSeaProvince()) {
            this.generateColonizeData();
            return bl;
        }
        boolean bl2 = bl;
        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).COST_OF_RECRUIT > CFG.game.getCiv(this.iCivID).getMovePoints()) return bl2;
        bl2 = bl;
        if (!CFG.game.getCiv(this.iCivID).recruitArmy_AI(this.iProvinceID, this.iArmy)) return bl2;
        return bl;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        return true;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final boolean generateColonizeData() {
        block33: {
            this.iProvinceID = -1;
            if (CFG.game.getCiv((int)this.iCivID).iBudget < 0) {
                this.iObsolate = 0;
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
                return false;
            }
            var2_2 = new ArrayList<Boolean>();
            for (var3_3 = 0; var3_3 < CFG.map.iNumOfBasins; ++var3_3) {
                var2_2.add(false);
            }
            var4_4 = new ArrayList<Integer>();
            var5_5 = new ArrayList<Integer>();
            for (var3_3 = 0; var3_3 < CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringSeaProvincesSize(); ++var3_3) {
                var2_2.set(CFG.game.getProvince(CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringSeaProvinces(var3_3)).getBasinID(), true);
                var5_5.add(CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringSeaProvinces(var3_3));
            }
            var3_3 = 0;
            while (true) {
                block35: {
                    block36: {
                        block34: {
                            if (var3_3 >= CFG.game.getCiv(this.iCivID).getNumOfProvinces()) break block34;
                            if (CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).isOccupied() || CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).getLevelOfPort() <= 0) break block35;
                            break block36;
                        }
                        if (var4_4.size() > 0) {
                            break;
                        }
                        break block33;
                    }
                    for (var6_6 = 0; var6_6 < CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).getNeighboringSeaProvincesSize(); ++var6_6) {
                        if (!((Boolean)var2_2.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).getNeighboringSeaProvinces(var6_6)).getBasinID())).booleanValue()) continue;
                        var4_4.add(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3));
                        break;
                    }
                }
                ++var3_3;
            }
            var7_7 = -1;
            var8_8 = -1;
            var9_9 = -1;
            var3_3 = var4_4.size() - 1;
            while (true) {
                if (var3_3 < 0) {
                    if (var7_7 < 0) break;
                    this.iArmy = CFG.game.getProvince((Integer)var4_4.get(var7_7)).getArmyCivID(this.iCivID) > 0 ? Math.min(CFG.game.getProvince((Integer)var4_4.get(var7_7)).getArmyCivID(this.iCivID), CFG.oR.nextInt(9) + 1) : Math.max(2, CFG.oR.nextInt(9) + 1);
                    var10_10 = new RegroupArmy_Data(this.iCivID, (Integer)var4_4.get(var7_7), (Integer)var5_5.get(var9_9));
                    if (var10_10.getRouteSize() > 0) {
                        this.iProvinceID = (Integer)var4_4.get(var7_7);
                        this.toProvinceID = (Integer)var5_5.get(var9_9);
                        this.iObsolate = Math.max(this.iObsolate, (int)((float)var10_10.getRouteSize() * 1.25f));
                        this.lockTreasury();
                        return true;
                    }
                    break;
                }
                for (var6_6 = var5_5.size() - 1; var6_6 >= 0; --var6_6) {
                    var10_10 = new RegroupArmy_Data(this.iCivID, (Integer)var4_4.get(var3_3), (Integer)var5_5.get(var6_6));
                    var11_11 = var7_7;
                    var12_12 = var9_9;
                    var13_13 = var8_8;
                    if (var10_10.getRouteSize() > 0) {
                        if (var7_7 < 0) {
                            var11_11 = var3_3;
                            var12_12 = var6_6;
                            var13_13 = var10_10.getRouteSize();
                        } else if (var8_8 > var10_10.getRouteSize()) {
                            var11_11 = var3_3;
                            var12_12 = var6_6;
                            var13_13 = var10_10.getRouteSize();
                        } else {
                            var11_11 = var7_7;
                            var12_12 = var9_9;
                            var13_13 = var8_8;
                            if (var8_8 == var10_10.getRouteSize()) {
                                var11_11 = var7_7;
                                var12_12 = var9_9;
                                var13_13 = var8_8;
                                if (CFG.oR.nextInt(100) < 50) {
                                    var11_11 = var3_3;
                                    var12_12 = var6_6;
                                    var13_13 = var10_10.getRouteSize();
                                }
                            }
                        }
                    }
                    var7_7 = var11_11;
                    var9_9 = var12_12;
                    var8_8 = var13_13;
                }
                --var3_3;
            }
        }
        var4_4.clear();
        var3_3 = 0;
        while (true) {
            block38: {
                block39: {
                    block37: {
                        if (var3_3 >= CFG.game.getCiv(this.iCivID).getNumOfProvinces()) break block37;
                        if (CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).isOccupied()) break block38;
                        break block39;
                    }
                    if (var4_4.size() > 0) {
                        break;
                    }
                    ** GOTO lbl122
                }
                for (var6_6 = 0; var6_6 < CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).getNeighboringSeaProvincesSize(); ++var6_6) {
                    if (!((Boolean)var2_2.get(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3)).getNeighboringSeaProvinces(var6_6)).getBasinID())).booleanValue()) continue;
                    var4_4.add(CFG.game.getCiv(this.iCivID).getProvinceID(var3_3));
                    break;
                }
            }
            ++var3_3;
        }
        var7_7 = -1;
        var8_8 = -1;
        var9_9 = -1;
        var3_3 = var4_4.size() - 1;
        while (true) {
            if (var3_3 >= 0) {
            } else {
                if (var7_7 >= 0) {
                    this.iArmy = CFG.game.getProvince((Integer)var4_4.get(var7_7)).getArmyCivID(this.iCivID) > 0 ? Math.min(CFG.game.getProvince((Integer)var4_4.get(var7_7)).getArmyCivID(this.iCivID), CFG.oR.nextInt(9) + 1) : Math.max(2, CFG.oR.nextInt(9) + 1);
                    var2_2 = new RegroupArmy_Data_PortToBuild(this.iCivID, (Integer)var4_4.get(var7_7), (Integer)var5_5.get(var9_9));
                    if (var2_2.getRouteSize() > 0) {
                        this.iProvinceID = (Integer)var4_4.get(var7_7);
                        this.toProvinceID = (Integer)var5_5.get(var9_9);
                        this.iObsolate = Math.max(this.iObsolate, (int)((float)var2_2.getRouteSize() * 1.25f));
                        this.lockTreasury();
                        return true;
                    }
                }
lbl122:
                // 5 sources

                if (this.iProvinceID >= 0) return true;
                this.iObsolate = 0;
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
                return false;
            }
            for (var6_6 = var5_5.size() - 1; var6_6 >= 0; --var6_6) {
                var2_2 = new RegroupArmy_Data_PortToBuild(this.iCivID, (Integer)var4_4.get(var3_3), (Integer)var5_5.get(var6_6));
                var11_11 = var7_7;
                var12_12 = var9_9;
                var13_13 = var8_8;
                if (var2_2.getRouteSize() > 0) {
                    if (var7_7 < 0) {
                        var11_11 = var3_3;
                        var12_12 = var6_6;
                        var13_13 = var2_2.getRouteSize();
                    } else if (var8_8 > var2_2.getRouteSize()) {
                        var11_11 = var3_3;
                        var12_12 = var6_6;
                        var13_13 = var2_2.getRouteSize();
                    } else {
                        var11_11 = var7_7;
                        var12_12 = var9_9;
                        var13_13 = var8_8;
                        if (var8_8 == var2_2.getRouteSize()) {
                            var11_11 = var7_7;
                            var12_12 = var9_9;
                            var13_13 = var8_8;
                            if (CFG.oR.nextInt(100) < 50) {
                                var11_11 = var3_3;
                                var12_12 = var6_6;
                                var13_13 = var2_2.getRouteSize();
                            }
                        }
                    }
                }
                var7_7 = var11_11;
                var9_9 = var12_12;
                var8_8 = var13_13;
            }
            --var3_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void lockTreasury() {
        block4: {
            block3: {
                int n = (int)((float)DiplomacyManager.getColonizeCost(this.iColonizeProvinceID, this.iCivID) * 1.05f);
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = Math.max(CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury, n);
                if (CFG.game.getCiv((int)this.iCivID).iBudget <= 0) break block3;
                if (CFG.game.getCiv(this.iCivID).getMoney() <= 0L || CFG.game.getCiv(this.iCivID).getMoney() >= (long)n) break block4;
                this.iObsolate = Math.max(this.iObsolate, Math.max(2, (int)Math.ceil((float)CFG.game.getCiv(this.iCivID).getMoney() / (float)n)));
            }
            return;
        }
        this.iObsolate = Math.max(2, this.iObsolate);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void lockTreasury_Port(int n) {
        block4: {
            block3: {
                n = (int)((float)BuildingsManager.getPort_BuildCost(CFG.game.getProvince(n).getLevelOfPort() + 1, n) * 1.05f);
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = Math.max(CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury, n);
                if (CFG.game.getCiv((int)this.iCivID).iBudget <= 0) break block3;
                if (CFG.game.getCiv(this.iCivID).getMoney() <= 0L || CFG.game.getCiv(this.iCivID).getMoney() >= (long)n) break block4;
                this.iObsolate = Math.max(this.iObsolate, Math.max(2, (int)Math.ceil((float)CFG.game.getCiv(this.iCivID).getMoney() / (float)n)));
            }
            return;
        }
        this.iObsolate = Math.max(2, this.iObsolate);
    }
}

