/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_NeighProvinces {
    protected int iDistance;
    protected int iProvinceID;

    protected AI_NeighProvinces(int n, int n2) {
        this.iProvinceID = n;
        this.iDistance = n2;
    }
}

