/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Stats;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Stats_FlagName
extends Button_Stats {
    private int iCivID = 0;

    protected Button_Stats_FlagName(String string2, float f, int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        super(string2, f, n, n2, n3, n4, bl, bl2);
    }

    private final float getImageScale() {
        return (float)CFG.TEXT_HEIGHT / (float)CFG.CIV_FLAG_HEIGHT;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.iCivID < 0) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
        } else {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + CFG.PADDING + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    @Override
    protected void setCurrent(int n) {
        this.iCivID = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void setText(String string2) {
        this.sText = string2;
        this.setWidth(this.iMinWidth);
        try {
            CFG.glyphLayout.setText(CFG.fontMain, string2);
            this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
            this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            if (super.getWidth() < this.iTextWidth + CFG.PADDING * 2 + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) {
                this.setWidth(this.iTextWidth + CFG.PADDING * 2 + (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING);
            }
            return;
        }
        catch (IllegalArgumentException | NullPointerException runtimeException) {
            return;
        }
    }
}

