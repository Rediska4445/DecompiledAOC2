/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Ideologies_Manager;
import java.io.Serializable;

class Civ_Mission_ChangeTypeOfGoverment
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iCost;
    protected int iToIdeologyID;

    protected Civ_Mission_ChangeTypeOfGoverment(int n, int n2) {
        this.iToIdeologyID = n;
        Ideologies_Manager ideologies_Manager = CFG.ideologiesManager;
        this.iCost = Ideologies_Manager.getChangeGovernmentCost(n2);
        this.action(n2);
    }

    protected final boolean action(int n) {
        int n2;
        long l;
        long l2;
        if (CFG.game.getCiv(n).getMoney() >= (long)this.iCost) {
            if (!CFG.ideologiesManager.canBeAdded(n, this.iToIdeologyID)) {
                return true;
            }
            if (DiplomacyManager.changeGovernmentType(n, this.iToIdeologyID)) {
                return true;
            }
            Ideologies_Manager ideologies_Manager = CFG.ideologiesManager;
            this.iCost = Ideologies_Manager.getChangeGovernmentCost(n);
            return false;
        }
        if (DiplomacyManager.canTakeMoreLoans(n) && (l2 = CFG.game.getCiv(n).getMoney()) + (l = (long)DiplomacyManager.takeLoan_MaxValue(n)) >= (long)(n2 = this.iCost)) {
            DiplomacyManager.takeLoan(n, (int)((long)n2 - CFG.game.getCiv(n).getMoney()), 10);
            if (!CFG.ideologiesManager.canBeAdded(n, this.iToIdeologyID)) {
                return true;
            }
            if (DiplomacyManager.changeGovernmentType(n, this.iToIdeologyID)) {
                return true;
            }
        }
        return false;
    }
}

