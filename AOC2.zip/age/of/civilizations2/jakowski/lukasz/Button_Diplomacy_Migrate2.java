/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;

class Button_Diplomacy_Migrate2
extends Button {
    private int iCivID = 0;
    private int iTextCostDiplomacyWidth;
    private int iTextCostGoldWidth;
    private boolean row = true;
    private String sTextCostDiplomacy;
    private String sTextCostGold;
    private String sToProvinceID;
    private int toProvinceID = 0;

    protected Button_Diplomacy_Migrate2(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        CharSequence charSequence = new StringBuilder();
        charSequence.append(CFG.langManager.get("MigrateTo"));
        charSequence.append(": ");
        super.init(charSequence.toString(), 0, n4, n5, n6, Math.max(CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 4, (CFG.TEXT_HEIGHT + CFG.PADDING) * 2 + CFG.PADDING), bl, true, false, false);
        this.iCivID = n3;
        this.toProvinceID = n2;
        charSequence = new StringBuilder();
        charSequence.append("");
        charSequence.append((float)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n3).getIdeologyID()).COST_OF_MOVE / 10.0f);
        this.sTextCostGold = charSequence.toString();
        charSequence = new StringBuilder();
        charSequence.append("+");
        float f = CFG.game.getProvince(n).getIsCapital() ? 0.1f : 0.05f;
        charSequence.append((int)(f * 100.0f));
        charSequence.append("%");
        this.sTextCostDiplomacy = charSequence.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostGold);
        this.iTextCostGoldWidth = (int)(CFG.glyphLayout.width * 0.6f);
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostDiplomacy);
        this.iTextCostDiplomacyWidth = (int)(CFG.glyphLayout.width * 0.6f);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        charSequence = CFG.game.getProvince(n2).getName().length() > 0 ? CFG.game.getProvince(n2).getName() : CFG.langManager.get("NewLand");
        stringBuilder.append((String)charSequence);
        this.sToProvinceID = stringBuilder.toString();
    }

    private final float getImageScale(int n) {
        float f = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID, 0, CFG.PADDING));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.getText()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sToProvinceID, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("MovementPoints"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        stringBuilder = new StringBuilder();
        stringBuilder.append("-");
        stringBuilder.append(this.sTextCostGold);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_movement_points, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Research"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sTextCostDiplomacy);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_RESEARCH));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.research, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        catch (NullPointerException nullPointerException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points)) + n, this.getPosY() + CFG.PADDING / 2 + this.getHeight() / 2 - this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points) / 2.0f) - ImageManager.getImage(Images.top_movement_points).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points)));
        ImageManager.getImage(Images.research).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.research).getWidth() * this.getImageScale(Images.research)) + n, this.getPosY() - CFG.PADDING / 2 + this.getHeight() / 2 + this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.research).getHeight() * this.getImageScale(Images.research) / 2.0f) - ImageManager.getImage(Images.research).getHeight() + n2, (int)((float)ImageManager.getImage(Images.research).getWidth() * this.getImageScale(Images.research)), (int)((float)ImageManager.getImage(Images.research).getHeight() * this.getImageScale(Images.research)));
        CFG.fontMain.getData().setScale(0.6f);
        String string2 = this.sTextCostGold;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = this.iTextCostGoldWidth;
        int n6 = CFG.PADDING;
        int n7 = (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points));
        int n8 = this.getPosY();
        int n9 = CFG.PADDING / 2;
        int n10 = this.getHeight() / 2;
        int n11 = this.getHeight() / 4;
        int n12 = (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f);
        Object object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).COST_OF_MOVE ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawText(spriteBatch, string2, n3 + n4 - n5 - n6 * 3 - n7 + n, n8 + n9 + n10 - n11 - n12 + n2, (Color)object);
        CFG.drawText(spriteBatch, this.sTextCostDiplomacy, this.getPosX() + this.getWidth() - this.iTextCostDiplomacyWidth - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.research).getWidth() * this.getImageScale(Images.research)) + n, this.getPosY() - CFG.PADDING / 2 + this.getHeight() / 2 + this.getHeight() / 4 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, Color.WHITE);
        object = new Rectangle(this.getPosX() + Button_Diplomacy.iDiploWidth + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - this.getRightWidth() - Button_Diplomacy.iDiploWidth, -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        try {
            CFG.drawText(spriteBatch, this.sToProvinceID, this.getPosX() + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    protected final int getRightWidth() {
        return Math.max(this.iTextCostGoldWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points)), this.iTextCostDiplomacyWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.research)));
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }

    @Override
    protected void setMax(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }

    @Override
    protected void setVisible(boolean bl) {
        super.setVisible(bl);
    }
}

