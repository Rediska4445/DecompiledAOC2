/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

interface ColorPicker_AoC_Action {
    public void setActiveProvince_Action();

    public void update();
}

