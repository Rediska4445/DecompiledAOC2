/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_ChangeOwner
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID_ControlledBy = -1;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Outcome_ChangeOwner() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction(int n) {
        try {
            int n2;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getSeaProvince()) return false;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getWasteland() >= 0) return false;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getCivID() != this.getCivID2()) {
                if (this.getCivID2() >= 0) return false;
            }
            if ((n = this.getCivID()) == (n2 = this.getCivID2())) return false;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return false;
        }
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CHANGE_OWNER);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID_ControlledBy;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("Annexation")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("Annexation");
            return var1_3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        int n = 0;
        while (n < this.getProvinces().size()) {
            if (this.canMakeAction(n)) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID()));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Annexation") + ": ", CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                StringBuilder stringBuilder = new StringBuilder().append("");
                Object object = CFG.game.getProvince(this.getProvinces().get(n)).getName().length() == 0 ? (Serializable)this.getProvinces().get(n) : CFG.game.getProvince(this.getProvinces().get(n)).getName();
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.append(object).toString()));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.getProvinces().get(n)).getCivID(), CFG.PADDING, 0));
                arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
                arrayList2.clear();
            }
            ++n;
        }
        return arrayList;
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void outcomeAction() {
        if (this.getCivID() >= 0 && this.getCivID() < CFG.game.getCivsSize()) {
            for (int i = 0; i < this.lProvinces.size(); ++i) {
                try {
                    if (!this.canMakeAction(i)) continue;
                    CFG.game.getProvince(this.lProvinces.get(i)).setCivID(this.getCivID(), false);
                    CFG.game.getProvince(this.lProvinces.get(i)).setTrueOwnerOfProvince(this.getCivID());
                    continue;
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
        }
        CFG.gameAction.updateCivsHappiness(this.getCivID());
        if (this.getCivID2() > 0) {
            CFG.gameAction.updateCivsHappiness(this.getCivID2());
        }
        if (CFG.game.getCiv(this.getCivID()).getCapitalProvinceID() < 0 || CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getCapitalProvinceID()).getCivID() != this.getCivID()) {
            CFG.game.moveCapitalToTheLargestCity(this.getCivID());
        }
        CFG.game.buildCivilizationRegions(this.getCivID());
        if (this.getCivID2() > 0) {
            CFG.game.buildCivilizationRegions(this.getCivID2());
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID_ControlledBy = n;
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID_ControlledBy == n) {
            this.iCivID_ControlledBy = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID_ControlledBy) return bl2;
        --this.iCivID;
        return bl;
    }
}

