/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization_ClosedEmbassy;
import age.of.civilizations2.jakowski.lukasz.Civilization_Diplomacy_ImproveRelations_GameData;
import age.of.civilizations2.jakowski.lukasz.MessageBox_GameData;
import age.of.civilizations2.jakowski.lukasz.Message_Relations_Increase_Ended;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Civilization_Diplomacy_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private int iEmbassyClosedSize = 0;
    private List<Civilization_ClosedEmbassy> lEmabassyClosed;
    private List<Civilization_Diplomacy_ImproveRelations_GameData> lImproveRelations = new ArrayList<Civilization_Diplomacy_ImproveRelations_GameData>();
    protected MessageBox_GameData messageBox;

    Civilization_Diplomacy_GameData() {
        this.lEmabassyClosed = new ArrayList<Civilization_ClosedEmbassy>();
        this.messageBox = new MessageBox_GameData();
    }

    protected final void addEmbeassyClosed(Civilization_ClosedEmbassy civilization_ClosedEmbassy) {
        for (int i = 0; i < this.iEmbassyClosedSize; ++i) {
            if (this.lEmabassyClosed.get((int)i).iCivID != civilization_ClosedEmbassy.iCivID) continue;
            this.lEmabassyClosed.get((int)i).iNumOfTurns = Math.max(this.lEmabassyClosed.get((int)i).iNumOfTurns, civilization_ClosedEmbassy.iNumOfTurns);
            return;
        }
        this.lEmabassyClosed.add(civilization_ClosedEmbassy);
        this.iEmbassyClosedSize = this.lEmabassyClosed.size();
    }

    protected final void addImproveRelations(int n, int n2, int n3) {
        if (CFG.game.getCiv(n2).getCivilization_Diplomacy_GameData().isEmassyClosed(n)) {
            return;
        }
        for (int i = 0; i < this.lImproveRelations.size(); ++i) {
            if (this.lImproveRelations.get((int)i).iWithCivID != n2) continue;
            this.lImproveRelations.get((int)i).iNumOfTurns = n3;
            return;
        }
        if (CFG.game.getCiv(n).getDiplomacyPoints() >= 5) {
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 5);
            this.lImproveRelations.add(new Civilization_Diplomacy_ImproveRelations_GameData(n2, n3, n));
        }
    }

    protected final void clearEmbassyClosed() {
        this.lEmabassyClosed.clear();
        this.iEmbassyClosedSize = 0;
    }

    protected final Civilization_ClosedEmbassy getEmbassyClosed(int n) {
        return this.lEmabassyClosed.get(n);
    }

    protected int getEmbassyClosedSize() {
        return this.iEmbassyClosedSize;
    }

    protected final Civilization_Diplomacy_ImproveRelations_GameData getImproveRelation(int n) {
        return this.lImproveRelations.get(n);
    }

    protected final int getImproveRelationsSize() {
        return this.lImproveRelations.size();
    }

    protected final boolean isEmassyClosed(int n) {
        for (int i = 0; i < this.iEmbassyClosedSize; ++i) {
            if (this.lEmabassyClosed.get((int)i).iCivID != n) continue;
            return true;
        }
        return false;
    }

    protected final int isEmbassyClosed_Turns(int n) {
        for (int i = 0; i < this.iEmbassyClosedSize; ++i) {
            if (this.lEmabassyClosed.get((int)i).iCivID != n) continue;
            return this.lEmabassyClosed.get((int)i).iNumOfTurns;
        }
        return 0;
    }

    protected final void removeEmbassyClosedWithCivID(int n) {
        for (int i = 0; i < this.iEmbassyClosedSize; ++i) {
            if (this.lEmabassyClosed.get((int)i).iCivID != n) continue;
            this.lEmabassyClosed.remove(i);
            this.iEmbassyClosedSize = this.lEmabassyClosed.size();
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void removeImproveRelations(int n, int n2) {
        try {
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() + 5);
            this.lImproveRelations.remove(n2);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final void removeImproveRelations_WithCivID(int n, int n2) {
        int n3 = 0;
        try {
            while (n3 < this.lImproveRelations.size()) {
                if (this.lImproveRelations.get((int)n3).iWithCivID == n2) {
                    CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() + 5);
                    this.lImproveRelations.remove(n3);
                    return;
                }
                ++n3;
            }
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    protected final void runImproveRelations(int n) {
        int n2 = 0;
        while (n2 < this.lImproveRelations.size()) {
            int n3 = n2;
            if (this.lImproveRelations.get(n2).action(n)) {
                CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Relations_Increase_Ended(this.lImproveRelations.get((int)n2).iWithCivID));
                this.lImproveRelations.remove(n2);
                n3 = n2 - 1;
            }
            n2 = n3 + 1;
        }
    }

    protected final void updateEmbassyClosed() {
        for (int i = this.iEmbassyClosedSize - 1; i >= 0; --i) {
            int n;
            Civilization_ClosedEmbassy civilization_ClosedEmbassy = this.lEmabassyClosed.get(i);
            civilization_ClosedEmbassy.iNumOfTurns = n = civilization_ClosedEmbassy.iNumOfTurns - 1;
            if (n > 0) continue;
            this.lEmabassyClosed.remove(i);
            this.iEmbassyClosedSize = this.lEmabassyClosed.size();
        }
    }
}

