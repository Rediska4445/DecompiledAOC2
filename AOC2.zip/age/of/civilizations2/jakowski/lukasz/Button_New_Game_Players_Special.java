/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_New_Game_Players_Special
extends Button_New_Game_Players {
    protected Button_New_Game_Players_Special(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_New_Game_Players_Special(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            CFG.fontMain.getData().setScale(0.8f);
            String string2 = this.getTextToDraw();
            int n3 = this.getPosX();
            int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, string2, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        } else {
            CFG.fontMain.getData().setScale(0.8f);
            String string3 = this.getTextToDraw();
            int n5 = this.getPosX();
            int n6 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, string3, n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        }
    }
}

