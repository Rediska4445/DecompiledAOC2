/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AoCGame;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivBonus_GameData;
import age.of.civilizations2.jakowski.lukasz.CivBonus_Type;
import age.of.civilizations2.jakowski.lukasz.CivFestival;
import age.of.civilizations2.jakowski.lukasz.CivInvest;
import age.of.civilizations2.jakowski.lukasz.CivInvest_Development;
import age.of.civilizations2.jakowski.lukasz.Civilization;
import age.of.civilizations2.jakowski.lukasz.Civilization_ClosedEmbassy;
import age.of.civilizations2.jakowski.lukasz.Civilization_Colonies;
import age.of.civilizations2.jakowski.lukasz.Civilization_SentMessages;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_Annexation;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_Guarantee;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_HaveMilitartyAccess;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_IsNotVassal;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_IsVassal;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_JoinAlliance;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_LeavesAlliance;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_NewColony;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_SignedDefensivePact;
import age.of.civilizations2.jakowski.lukasz.HistoryLog_SignedNonAggressionPact;
import age.of.civilizations2.jakowski.lukasz.HistoryManager;
import age.of.civilizations2.jakowski.lukasz.Ideologies_Manager;
import age.of.civilizations2.jakowski.lukasz.Message;
import age.of.civilizations2.jakowski.lukasz.MessageBox_GameData;
import age.of.civilizations2.jakowski.lukasz.Message_Alliance_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_Alliance_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_AllyJoinedAWar;
import age.of.civilizations2.jakowski.lukasz.Message_CallToArms;
import age.of.civilizations2.jakowski.lukasz.Message_CallToArms_Deny;
import age.of.civilizations2.jakowski.lukasz.Message_CallToArms_Join;
import age.of.civilizations2.jakowski.lukasz.Message_DeclarationOfIndependence_ByVassal;
import age.of.civilizations2.jakowski.lukasz.Message_DefensivePact;
import age.of.civilizations2.jakowski.lukasz.Message_DefensivePact_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_DefensivePact_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_Gift;
import age.of.civilizations2.jakowski.lukasz.Message_Gift_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_Gift_Refused;
import age.of.civilizations2.jakowski.lukasz.Message_GoldenAge;
import age.of.civilizations2.jakowski.lukasz.Message_GoldenAgeMilitary;
import age.of.civilizations2.jakowski.lukasz.Message_GoldenAgeScience;
import age.of.civilizations2.jakowski.lukasz.Message_Independence_Ask;
import age.of.civilizations2.jakowski.lukasz.Message_Independence_Ask_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_Independence_Ask_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_LeftAlliance;
import age.of.civilizations2.jakowski.lukasz.Message_Liberation;
import age.of.civilizations2.jakowski.lukasz.Message_LowHappiness;
import age.of.civilizations2.jakowski.lukasz.Message_LowStability;
import age.of.civilizations2.jakowski.lukasz.Message_MilitaryAccess_Ask;
import age.of.civilizations2.jakowski.lukasz.Message_MilitaryAccess_Ask_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_MilitaryAccess_Ask_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_MilitaryAccess_Give;
import age.of.civilizations2.jakowski.lukasz.Message_NonAggressionPact;
import age.of.civilizations2.jakowski.lukasz.Message_NonAggressionPact_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_NonAggressionPact_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_OfferVasalization;
import age.of.civilizations2.jakowski.lukasz.Message_OpenBudget;
import age.of.civilizations2.jakowski.lukasz.Message_PeaceTreaty;
import age.of.civilizations2.jakowski.lukasz.Message_PeaceTreaty_Rejected;
import age.of.civilizations2.jakowski.lukasz.Message_Plunder;
import age.of.civilizations2.jakowski.lukasz.Message_Plunder_Plundred;
import age.of.civilizations2.jakowski.lukasz.Message_PrepareForWar;
import age.of.civilizations2.jakowski.lukasz.Message_PrepareForWar_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_PrepareForWar_Refused;
import age.of.civilizations2.jakowski.lukasz.Message_RebelsSupported;
import age.of.civilizations2.jakowski.lukasz.Message_Relations_Insult;
import age.of.civilizations2.jakowski.lukasz.Message_TechPoints;
import age.of.civilizations2.jakowski.lukasz.Message_TradeReuest;
import age.of.civilizations2.jakowski.lukasz.Message_TradeReuest_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_TradeReuest_Denied;
import age.of.civilizations2.jakowski.lukasz.Message_TransferControl;
import age.of.civilizations2.jakowski.lukasz.Message_TransferControl_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_TransferControl_Refused;
import age.of.civilizations2.jakowski.lukasz.Message_Type;
import age.of.civilizations2.jakowski.lukasz.Message_Ultimatum;
import age.of.civilizations2.jakowski.lukasz.Message_UltimatumAccepted;
import age.of.civilizations2.jakowski.lukasz.Message_UltimatumRefused;
import age.of.civilizations2.jakowski.lukasz.Message_Uncivilized;
import age.of.civilizations2.jakowski.lukasz.Message_Union;
import age.of.civilizations2.jakowski.lukasz.Message_Union_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_Union_Refused;
import age.of.civilizations2.jakowski.lukasz.Message_Vassalization_Accepted;
import age.of.civilizations2.jakowski.lukasz.Message_Vassalization_Rejected;
import age.of.civilizations2.jakowski.lukasz.PeaceTreaty_GameData;
import age.of.civilizations2.jakowski.lukasz.PeaceTreaty_GameData_MessageData;
import age.of.civilizations2.jakowski.lukasz.Province;
import age.of.civilizations2.jakowski.lukasz.Province_SupportRebels;
import age.of.civilizations2.jakowski.lukasz.Province_SupportRebels_Help;
import age.of.civilizations2.jakowski.lukasz.Save_Civ_GameData;
import age.of.civilizations2.jakowski.lukasz.SupportRebels_Data;
import age.of.civilizations2.jakowski.lukasz.TradeRequest_GameData;
import age.of.civilizations2.jakowski.lukasz.Ultimatum_GameData;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class DiplomacyManager {
    protected static final int ASSIMILATE_NUM_OF_TURNS_MAX = 75;
    protected static final int ASSIMILATE_NUM_OF_TURNS_MIN = 10;
    protected static final int BASE_COST_OF_ASSIMILATE = 265;
    protected static final int BASE_COST_OF_FESTIVAL = 500;
    protected static final int CALL_TO_ARMS_RELATION_ACCEPT = 10;
    protected static final int CALL_TO_ARMS_RELATION_DENY = -15;
    protected static final int CALL_TO_ARMS_RELATION_DENY_INSULT = -20;
    protected static final int COLONIZE_NEW_COLONY_BONUS = 92;
    protected static final int COST_ABADON = 0;
    protected static final int COST_ALLIANCE_LEAVE = 2;
    protected static final int COST_ASSIMILATE = 6;
    protected static final int COST_CALL_TO_ARMS = 0;
    protected static final int COST_CIVILIZE = 10;
    protected static final int COST_FESTIVAL = 8;
    protected static final int COST_INVEST = 12;
    protected static final int COST_INVEST_DEVLOPMENT = 8;
    protected static final float COST_INVEST_ECONOMY_PER_GOLD = 3.5f;
    protected static final float COST_INVEST_ECONOMY_PER_GOLD2 = 6.75f;
    protected static final float COST_INVEST_ECONOMY_PER_GOLD_DEVELOPMENT = 1.075f;
    protected static final int COST_OFFER_ALLIANCE = 20;
    protected static final int COST_OFFER_DECREASERELATIONS = 2;
    protected static final int COST_OFFER_DEFENSIVEPACT = 10;
    protected static final int COST_OFFER_FORMUNION = 22;
    protected static final int COST_OFFER_GIFT = 8;
    protected static final int COST_OFFER_IMPROVERELATIONS = 5;
    protected static final int COST_OFFER_LIBERATEAVASSAL = 2;
    protected static final int COST_OFFER_MILITARYACCESS_ASK = 10;
    protected static final int COST_OFFER_MILITARYACCESS_GIVE = 4;
    protected static final int COST_OFFER_NONAGGRESSIONPACT = 8;
    protected static final int COST_OFFER_PROCLAIMINDEPENDENCE = 5;
    protected static final int COST_OFFER_SUPPORTREBELS = 34;
    protected static final int COST_OFFER_TRADEREQUEST = 10;
    protected static final int COST_OFFER_VASSALIZATION = 16;
    protected static final int COST_TAKE_LOAN = 6;
    protected static final int COST_TRANSFER_CONTROL = 4;
    protected static final int COST_ULTIMATUM = 24;
    protected static final int COST_WAR_PREPARATIONS = 0;
    protected static final int DIPLOMAT_COST_ALLIANCE = 6;
    protected static final int DIPLOMAT_COST_DEFENSIVE_PACT = 3;
    protected static final int DIPLOMAT_COST_FRIENDLY_CIV = 3;
    protected static final int DIPLOMAT_COST_GUARANTEE = 1;
    protected static final int DIPLOMAT_COST_MILITARYACCESS = 1;
    protected static final int DIPLOMAT_COST_NONAGGRESSION = 2;
    protected static final int DIPLOMAT_COST_VASSAL = 1;
    protected static final int FESTIVAL_NUM_OF_TURNS = 7;
    protected static final int FRIENDLY_MIN_RELATION = 44;
    protected static final float GIFT_MAX_PERC_OF_TREASURY = 0.25f;
    protected static final int GIFT_REFUSE_OPINION_CHANGE = -8;
    protected static final int GIFT_REMOVE_RECEIVED_GIFT_INFO_TURNS = 5;
    protected static final int GOLDEN_AGE_EVERY_X_TURNS = 30;
    protected static final int HATED_INSULT = 20;
    protected static final int HATED_MIN_RELATION = -25;
    protected static final int HATED_WAR = 85;
    protected static final int IMPROVERELATIONS_MAX_NUM_OF_TURS = 50;
    protected static final int INSULT_DECREASE_RELATIONS = 30;
    protected static final int INVEST_NUM_OF_TURNS = 10;
    protected static final int INVEST_NUM_OF_TURNS_DEVLOPMENT = 74;
    protected static final int LOAN_MAX_DURATION = 100;
    protected static final int LOAN_MAX_NUM_OF_LOANS = 10;
    protected static final float LOAN_MAX_VALUE_OF_INCOME = 1.0f;
    protected static final int LOAN_MIN_DURATION = 10;
    protected static final int OUDATED_RELATIONS = 6;
    protected static final int OUDATED_RELATIONS_MAX = 15;
    protected static final int OUDATED_RELATIONS_MIN = -20;
    protected static final int PEACETREATY_DEFAULT = 45;
    protected static final int PEACETREATY_MAX_DURATION = 75;
    protected static final int PEACETREATY_MIN_DURATION = 30;
    protected static final float PLUNDER_INCOME_HIGH_REV_RISK_MODIFIER = 0.625f;
    protected static final float PLUNDER_INCOME_MULTIPLY = 1.45f;
    protected static int RELEASED_VASSAL_MIN_OPINION = 25;
    protected static final float SUPPORT_REBELS_ASSIMILATE_COST_MODIFIER = 1.6275f;
    protected static final float SUPPORT_REBELS_ASSIMILATE_PERC = 0.845f;
    protected static final float SUPPORT_REBELS_ASSIMILATE_PERC_EXTRA = 0.125f;
    protected static final int SUPPORT_REBELS_NUM_OF_TURNS_MAX = 35;
    protected static final int SUSPEND_DIPLOMATIC_RELATIONS_MAX = 35;
    protected static final int SUSPEND_DIPLOMATIC_RELATIONS_MIN = 15;
    protected static final int ULTIMATUM_REQUIRED_RELATIONS = -10;
    protected static final int ULTIMATUM_TRUCE_TURNS = 30;
    protected static int WAR_PREPARATIONS_REFUSE_OPINION_CHANGE = -10;
    protected static final int WAR_REPARATIONS_LENGTH = 12;

    DiplomacyManager() {
    }

    protected static final boolean JoinAllianceWar(int n) {
        boolean bl = false;
        List list = DiplomacyManager.callToArmsListOfCivs_AI(n, 0);
        for (int i = 0; i < list.size(); ++i) {
            int n2 = (Integer)list.get(i);
            for (int j = 0; j < CFG.game.getCiv((int)n2).isAtWarWithCivs.size(); ++j) {
                int n3 = CFG.game.getCiv((int)n2).isAtWarWithCivs.get(j);
                if (!DiplomacyManager.isBorderedWith_IncludeSea(n, n3) && !DiplomacyManager.isBorderedWith_IncludeSea(n, n2)) continue;
                int n4 = CFG.game.getWarID(n3, n2);
                CFG.game.joinWar(n, n3, n4);
                bl = true;
            }
        }
        return bl;
    }

    protected static final void acceptAllianceProposal(int n, int n2) {
        if (CFG.game.getCiv(n).getAllianceID() == 0 && CFG.game.getCiv(n2).getAllianceID() == 0) {
            CFG.game.addAlliance(CFG.getRandomAllianceName(0));
            int n3 = CFG.game.getAlliancesSize() - 1;
            if (CFG.game.getCiv(n).getControlledByPlayer()) {
                CFG.game.getAlliance(n3).addCivilization(n);
                CFG.game.getAlliance(n3).addCivilization(n2);
            } else if (CFG.game.getCiv(n2).getControlledByPlayer()) {
                CFG.game.getAlliance(n3).addCivilization(n2);
                CFG.game.getAlliance(n3).addCivilization(n);
            } else {
                CFG.game.getAlliance(n3).addCivilization(n);
                CFG.game.getAlliance(n3).addCivilization(n2);
            }
            CFG.game.getCiv(n).setAllianceID(n3);
            CFG.game.getCiv(n2).setAllianceID(n3);
            CFG.historyManager.addHistoryLog(new HistoryLog_JoinAlliance(n, n3));
            CFG.historyManager.addHistoryLog(new HistoryLog_JoinAlliance(n2, n3));
        } else if (CFG.game.getCiv(n2).getAllianceID() > 0 && CFG.game.getCiv(n).getAllianceID() == 0) {
            CFG.game.getAlliance(CFG.game.getCiv(n2).getAllianceID()).addCivilization(n);
            CFG.game.getCiv(n).setAllianceID(CFG.game.getCiv(n2).getAllianceID());
            CFG.historyManager.addHistoryLog(new HistoryLog_JoinAlliance(n, CFG.game.getCiv(n2).getAllianceID()));
        } else if (CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getCiv(n2).getAllianceID() == 0) {
            CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).addCivilization(n2);
            CFG.game.getCiv(n2).setAllianceID(CFG.game.getCiv(n).getAllianceID());
            CFG.historyManager.addHistoryLog(new HistoryLog_JoinAlliance(n2, CFG.game.getCiv(n).getAllianceID()));
        } else {
            CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).removeCivilization(n);
            CFG.game.getAlliance(CFG.game.getCiv(n2).getAllianceID()).addCivilization(n);
            CFG.game.getCiv(n).setAllianceID(CFG.game.getCiv(n2).getAllianceID());
            CFG.game.getCiv(n).setAllianceID(CFG.game.getCiv(n2).getAllianceID());
        }
        if (CFG.game.getCiv(n).getControlledByPlayer()) {
            CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n));
            CFG.game.getPlayer(CFG.game.getPlayerID_ByCivID(n)).buildMetProvincesAndCivs();
        }
        if (CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n2));
            CFG.game.getPlayer(CFG.game.getPlayerID_ByCivID(n2)).buildMetProvincesAndCivs();
        }
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Alliance_Accepted(n));
    }

    protected static final void acceptCallToArms(int n, int n2, int n3) {
        int n4 = CFG.game.getWarID(n2, n3);
        CFG.game.joinWar(n, n3, n4);
        if (CFG.game.getCivsAtWar(n, n3)) {
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_CallToArms_Join(n, n3, n2));
            CFG.game.setCivRelation_OfCivB(n, n2, CFG.game.getCivRelation_OfCivB(n, n2) + 10.0f);
            CFG.game.setCivRelation_OfCivB(n2, n, CFG.game.getCivRelation_OfCivB(n2, n) + 10.0f);
        }
    }

    protected static final void acceptDefensivePact(int n, int n2, int n3) {
        CFG.game.setDefensivePact(n, n2, n3);
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_DefensivePact_Accepted(n));
        CFG.historyManager.addHistoryLog(new HistoryLog_SignedDefensivePact(n2, n));
    }

    protected static final void acceptGift(int n, int n2, int n3) {
        if (n3 >= 0) {
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() + (long)n3);
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Gift_Accepted(n, n3));
            CFG.game.getCiv((int)n).civGameData.addGift_Received(n2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void acceptGuaranteeIndependence_Ask(int n, int n2, int n3) {
        CFG.game.setGuarantee(n2, n, n3);
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Independence_Ask_Accepted(n));
        try {
            HistoryManager historyManager = CFG.historyManager;
            HistoryLog_Guarantee historyLog_Guarantee = new HistoryLog_Guarantee(n, n2);
            historyManager.addHistoryLog(historyLog_Guarantee);
            return;
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }

    protected static final void acceptMilitaryAccess_Ask(int n, int n2, int n3) {
        CFG.game.setMilitaryAccess(n2, n, n3);
        if (CFG.game.getCivRelation_OfCivB(n, n2) > 0.0f) {
            CFG.game.setCivRelation_OfCivB(n, n2, CFG.game.getCivRelation_OfCivB(n, n2) - Math.max(CFG.game.getCivRelation_OfCivB(n, n2) / 9.325f, 1.127f));
        }
        if (CFG.game.getCivRelation_OfCivB(n2, n) > 0.0f) {
            CFG.game.setCivRelation_OfCivB(n2, n, CFG.game.getCivRelation_OfCivB(n2, n) - Math.max(CFG.game.getCivRelation_OfCivB(n2, n) / 9.325f, 1.127f));
        }
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_MilitaryAccess_Ask_Accepted(n));
        CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n, n2));
    }

    protected static final void acceptMilitaryAccess_Give(int n, int n2, int n3) {
        CFG.game.setMilitaryAccess(n, n2, n3);
        CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n2, n));
    }

    protected static final void acceptNonAggressionPact(int n, int n2, int n3) {
        CFG.game.setCivNonAggressionPact(n, n2, n3);
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_NonAggressionPact_Accepted(n));
        CFG.historyManager.addHistoryLog(new HistoryLog_SignedNonAggressionPact(n2, n));
    }

    protected static final void acceptOfferVasalization(int n, int n2, int n3) {
        int n4;
        CFG.game.getCiv(n).setPuppetOfCivID(n2, false);
        if (CFG.game.getCiv(n2).getControlledByPlayer() && CFG.FOG_OF_WAR > 0 && (n4 = CFG.game.getPlayerID_ByCivID(n2)) >= 0) {
            for (n3 = 0; n3 < CFG.game.getCiv(n).getNumOfProvinces(); ++n3) {
                CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).updateFogOfWar(n4);
            }
        }
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Vassalization_Accepted(n));
        CFG.historyManager.addHistoryLog(new HistoryLog_IsVassal(n2, n));
    }

    /*
     * Exception decompiling
     */
    protected static final void acceptPeaceTreaty(int var0, String var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [47[UNCONDITIONALDOLOOP]], but top level block is 49[UNCONDITIONALDOLOOP]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected static final void acceptPrepareForWar(int n, int n2, int n3, int n4, int n5) {
        CFG.game.getCiv((int)n3).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_PrepareForWar_Accepted(n2, n4));
        CFG.game.getCiv((int)n3).civGameData.civPlans.addNewWarPreparations(n, n3, n4, n5);
        CFG.game.getCiv((int)n2).civGameData.civPlans.addNewWarPreparations(n, n2, n4, n5);
    }

    protected static final void acceptTradeRequest(int n, int n2, TradeRequest_GameData tradeRequest_GameData) {
        ArrayList<Integer> arrayList;
        int n3;
        int n4;
        int n5;
        int n6;
        if (tradeRequest_GameData.listLEFT.militaryAccess) {
            CFG.game.setMilitaryAccess(n, n2, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n2, n));
        }
        if (tradeRequest_GameData.listRight.militaryAccess) {
            CFG.game.setMilitaryAccess(n2, n, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n, n2));
        }
        if (tradeRequest_GameData.listLEFT.iGold > 0) {
            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)tradeRequest_GameData.listLEFT.iGold);
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() + (long)tradeRequest_GameData.listLEFT.iGold);
        }
        if (tradeRequest_GameData.listLEFT.lProvinces.size() > 0) {
            for (n6 = 0; n6 < tradeRequest_GameData.listLEFT.lProvinces.size(); ++n6) {
                if (CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getCivID() != n2 || CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getTrueOwnerOfProvince() != n2) continue;
                n5 = CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getArmy(0);
                n4 = CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getCivID();
                n3 = CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getArmyCivID(n);
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).updateArmy(0);
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).setTrueOwnerOfProvince(n);
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).setCivID(n, false);
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).updateArmy(n4, n5);
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).updateArmy(n, n3);
                arrayList = new ArrayList<Integer>();
                for (n5 = 0; n5 < CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getCivsSize(); ++n5) {
                    arrayList.add(CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getCivID(n5));
                }
                for (n5 = 0; n5 < arrayList.size(); ++n5) {
                    if (CFG.game.getCiv((Integer)arrayList.get(n5)).getPuppetOfCivID() == n || CFG.game.getCiv(n).getPuppetOfCivID() == ((Integer)arrayList.get(n5)).intValue() || CFG.game.getCiv((Integer)arrayList.get(n5)).getAllianceID() > 0 && CFG.game.getCiv((Integer)arrayList.get(n5)).getAllianceID() == CFG.game.getCiv(n).getAllianceID() || CFG.game.getMilitaryAccess((Integer)arrayList.get(n5), n) > 0) continue;
                    CFG.gameAction.accessLost_MoveArmyToClosetsProvince((Integer)arrayList.get(n5), tradeRequest_GameData.listLEFT.lProvinces.get(n6));
                }
                if (!CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getIsCapital()) {
                    CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).removeCapitalCityIcon();
                }
                CFG.game.getProvince(tradeRequest_GameData.listLEFT.lProvinces.get(n6)).getCore().removeCore(tradeRequest_GameData.iCivLEFT);
            }
            CFG.game.buildCivilizationsRegions_TextOver(n2);
            CFG.game.buildCivilizationsRegions_TextOver(n);
        }
        if (tradeRequest_GameData.listLEFT.iDeclarWarOnCivID > 0) {
            CFG.game.declareWar(n2, tradeRequest_GameData.listLEFT.iDeclarWarOnCivID, false);
        }
        if (tradeRequest_GameData.listLEFT.iFormCoalitionAgainst > 0) {
            CFG.game.declareWar(n2, tradeRequest_GameData.listLEFT.iFormCoalitionAgainst, false);
            CFG.game.declareWar(n, tradeRequest_GameData.listLEFT.iFormCoalitionAgainst, false);
            CFG.game.setCivNonAggressionPact(n2, n, 40);
            CFG.game.setMilitaryAccess(n2, n, 40);
            CFG.game.setMilitaryAccess(n, n2, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n, n2));
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n2, n));
        }
        if (tradeRequest_GameData.listLEFT.defensivePact) {
            CFG.game.setDefensivePact(n2, n, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_SignedDefensivePact(n, n2));
        }
        if (tradeRequest_GameData.listLEFT.nonAggressionPact) {
            CFG.game.setCivNonAggressionPact(n2, n, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_SignedNonAggressionPact(n, n2));
        }
        if (tradeRequest_GameData.listLEFT.proclaimIndependence) {
            CFG.game.setGuarantee(n2, n, 100);
            CFG.historyManager.addHistoryLog(new HistoryLog_Guarantee(n2, n));
        }
        if (tradeRequest_GameData.listRight.iGold > 0) {
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)tradeRequest_GameData.listRight.iGold);
            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() + (long)tradeRequest_GameData.listRight.iGold);
        }
        if (tradeRequest_GameData.listRight.lProvinces.size() > 0) {
            for (n6 = 0; n6 < tradeRequest_GameData.listRight.lProvinces.size(); ++n6) {
                if (CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getCivID() != n || CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getTrueOwnerOfProvince() != n) continue;
                n4 = CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getArmy(0);
                n3 = CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getCivID();
                n5 = CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getArmyCivID(n);
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).updateArmy(0);
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).setTrueOwnerOfProvince(n2);
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).setCivID(n2, false);
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).updateArmy(n3, n4);
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).updateArmy(n, n5);
                arrayList = new ArrayList();
                for (n5 = 0; n5 < CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getCivsSize(); ++n5) {
                    arrayList.add(CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getCivID(n5));
                }
                for (n5 = 0; n5 < arrayList.size(); ++n5) {
                    if (CFG.game.getCiv((Integer)arrayList.get(n5)).getPuppetOfCivID() == n2 || CFG.game.getCiv(n2).getPuppetOfCivID() == ((Integer)arrayList.get(n5)).intValue() || CFG.game.getCiv((Integer)arrayList.get(n5)).getAllianceID() > 0 && CFG.game.getCiv((Integer)arrayList.get(n5)).getAllianceID() == CFG.game.getCiv(n2).getAllianceID() || CFG.game.getMilitaryAccess((Integer)arrayList.get(n5), n2) > 0) continue;
                    CFG.gameAction.accessLost_MoveArmyToClosetsProvince((Integer)arrayList.get(n5), tradeRequest_GameData.listRight.lProvinces.get(n6));
                }
                if (!CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getIsCapital()) {
                    CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).removeCapitalCityIcon();
                }
                CFG.game.getProvince(tradeRequest_GameData.listRight.lProvinces.get(n6)).getCore().removeCore(tradeRequest_GameData.iCivRIGHT);
            }
            CFG.game.buildCivilizationsRegions_TextOver(n2);
            CFG.game.buildCivilizationsRegions_TextOver(n);
        }
        if (tradeRequest_GameData.listRight.iDeclarWarOnCivID > 0) {
            CFG.game.declareWar(n, tradeRequest_GameData.listRight.iDeclarWarOnCivID, false);
        }
        if (tradeRequest_GameData.listRight.iFormCoalitionAgainst > 0) {
            CFG.game.declareWar(n2, tradeRequest_GameData.listRight.iFormCoalitionAgainst, false);
            CFG.game.declareWar(n, tradeRequest_GameData.listRight.iFormCoalitionAgainst, false);
            CFG.game.setCivNonAggressionPact(n2, n, 40);
            CFG.game.setMilitaryAccess(n2, n, 40);
            CFG.game.setMilitaryAccess(n, n2, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n2, n));
            CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n, n2));
        }
        if (tradeRequest_GameData.listRight.defensivePact) {
            CFG.game.setDefensivePact(n2, n, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_SignedDefensivePact(n2, n));
        }
        if (tradeRequest_GameData.listRight.nonAggressionPact) {
            CFG.game.setCivNonAggressionPact(n2, n, 40);
            CFG.historyManager.addHistoryLog(new HistoryLog_SignedNonAggressionPact(n, n2));
        }
        if (tradeRequest_GameData.listRight.proclaimIndependence) {
            CFG.game.setGuarantee(n, n2, 100);
            CFG.historyManager.addHistoryLog(new HistoryLog_Guarantee(n2, n));
        }
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TradeReuest_Accepted(n));
    }

    protected static final void acceptTransferControl(int n, int n2, int n3) {
        if (CFG.game.getProvince(n3).getCivID() == n2 && CFG.game.getProvince(n3).isOccupied() && (CFG.game.getCivsAreAllied(n, n2) || CFG.game.getCiv(n).getPuppetOfCivID() == n2 || CFG.game.getCiv(n2).getPuppetOfCivID() == n || CFG.game.getProvince(n3).getTrueOwnerOfProvince() == n)) {
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TransferControl_Accepted(n, n3, n2));
            int n4 = CFG.game.getProvince(n3).getArmyCivID(n2);
            int n5 = CFG.game.getProvince(n3).getArmyCivID(n);
            if (n4 != 0) {
                CFG.game.getProvince(n3).updateArmy(n2, 0);
            }
            if (n5 != 0) {
                CFG.game.getProvince(n3).updateArmy(n, 0);
            }
            CFG.game.getProvince(n3).setCivID(n, false, true);
            if (n4 > 0) {
                CFG.game.getProvince(n3).updateArmy(n2, n4);
            }
            if (n5 > 0) {
                CFG.game.getProvince(n3).updateArmy(n, n5);
            }
        }
    }

    protected static final void acceptUltimatum(int n, int n2, Ultimatum_GameData ultimatum_GameData) {
        if (CFG.game.getCiv(n2).getPuppetOfCivID() == n2 || CFG.game.getCiv(n2).getPuppetOfCivID() == n) {
            int n3;
            int n4;
            ArrayList<Integer> arrayList;
            CFG.game.getCiv(n2).setVassalLiberityDesire(CFG.game.getCiv(n2).getVassalLiberityDesire() * 1.25f + 18.0f + (float)CFG.oR.nextInt(36));
            if (ultimatum_GameData.demandAnexation) {
                arrayList = new ArrayList<Integer>();
                for (n4 = 0; n4 < CFG.game.getCiv(n2).getNumOfProvinces(); ++n4) {
                    arrayList.add(CFG.game.getCiv(n2).getProvinceID(n4));
                }
                for (n4 = 0; n4 < arrayList.size(); ++n4) {
                    if (CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID() != n2 || CFG.game.getProvince((Integer)arrayList.get(n4)).getTrueOwnerOfProvince() != n2) continue;
                    n3 = CFG.game.getProvince((Integer)arrayList.get(n4)).getArmyCivID(n);
                    CFG.game.getProvince((Integer)arrayList.get(n4)).updateArmy(0);
                    CFG.game.getProvince((Integer)arrayList.get(n4)).updateArmy(n, 0);
                    CFG.game.getProvince((Integer)arrayList.get(n4)).setTrueOwnerOfProvince(n);
                    CFG.game.getProvince((Integer)arrayList.get(n4)).setCivID(n, false);
                    CFG.game.getProvince((Integer)arrayList.get(n4)).updateArmy(n, n3);
                    for (n3 = CFG.game.getProvince((Integer)arrayList.get(n4)).getCivsSize() - 1; n3 >= 0; --n3) {
                        if (CFG.game.getCiv(CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3)).getPuppetOfCivID() == n || CFG.game.getCiv(n).getPuppetOfCivID() == CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3) || CFG.game.getCiv(CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3)).getAllianceID() > 0 && CFG.game.getCiv(CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3)).getAllianceID() == CFG.game.getCiv(n).getAllianceID() || CFG.game.getMilitaryAccess(CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3), n) > 0) continue;
                        CFG.gameAction.accessLost_MoveArmyToClosetsProvince(CFG.game.getProvince((Integer)arrayList.get(n4)).getCivID(n3), (Integer)arrayList.get(n4));
                    }
                }
                if (CFG.game.getCiv(n2).getCapitalProvinceID() >= 0) {
                    CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).setIsCapital(false);
                    for (n4 = 0; n4 < CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getCitiesSize(); ++n4) {
                        if (CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getCity(n4).getCityLevel() != CFG.getEditorCityLevel(0)) continue;
                        CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getCity(n4).setCityLevel(CFG.getEditorCityLevel(1));
                    }
                }
                CFG.game.getCiv(n2).buildNumOfUnits();
                arrayList.clear();
                CFG.game.buildCivilizationsRegions_TextOver(n2);
                CFG.game.buildCivilizationsRegions_TextOver(n);
                CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
                CFG.historyManager.addHistoryLog(new HistoryLog_Annexation(n2, n));
            }
            if (ultimatum_GameData.demandVasalization) {
                CFG.game.getCiv(n2).setPuppetOfCivID(n, false);
                if (CFG.game.getCiv(n).getControlledByPlayer() && CFG.FOG_OF_WAR > 0 && (n3 = CFG.game.getPlayerID_ByCivID(n)) >= 0) {
                    for (n4 = 0; n4 < CFG.game.getCiv(n2).getNumOfProvinces(); ++n4) {
                        CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n4)).updateFogOfWar(n3);
                    }
                }
                CFG.historyManager.addHistoryLog(new HistoryLog_IsVassal(n, n2));
            }
            if (ultimatum_GameData.demandMilitaryAccess) {
                CFG.game.setMilitaryAccess(n, n2, Math.max(CFG.game.getMilitaryAccess(n, n2), 40));
                CFG.historyManager.addHistoryLog(new HistoryLog_HaveMilitartyAccess(n2, n));
            }
            if (ultimatum_GameData.demandLiberation.size() > 0) {
                for (n4 = 0; n4 < ultimatum_GameData.demandLiberation.size(); ++n4) {
                    DiplomacyManager.liberateAVassal(n2, ultimatum_GameData.demandLiberation.get(n4));
                    CFG.game.setCivTruce(n2, ultimatum_GameData.demandLiberation.get(n4), 22);
                }
            }
            if (ultimatum_GameData.demandProvinces.size() > 0) {
                for (n4 = 0; n4 < ultimatum_GameData.demandProvinces.size(); ++n4) {
                    if (CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getCivID() != n2 || CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getTrueOwnerOfProvince() != n2) continue;
                    arrayList = new ArrayList();
                    ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
                    for (n3 = 0; n3 < CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getCivsSize(); ++n3) {
                        arrayList.add(CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getCivID(n3));
                        arrayList2.add(CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getArmy(n3));
                    }
                    n3 = CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getArmyCivID(n);
                    int n5 = CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getArmy(0);
                    int n6 = CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getCivID();
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).updateArmy(0);
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).updateArmy(n, 0);
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).setTrueOwnerOfProvince(n);
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).setCivID(n, false);
                    if (!CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).getIsCapital()) {
                        CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).removeCapitalCityIcon();
                    }
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).updateArmy(n, n3);
                    CFG.game.getProvince(ultimatum_GameData.demandProvinces.get(n4)).updateArmy(n6, n5);
                    for (n3 = 0; n3 < arrayList.size(); ++n3) {
                        if (CFG.game.getCiv((Integer)arrayList.get(n3)).getPuppetOfCivID() == n || CFG.game.getCiv(n).getPuppetOfCivID() == ((Integer)arrayList.get(n3)).intValue() || CFG.game.getCiv((Integer)arrayList.get(n3)).getAllianceID() > 0 && CFG.game.getCiv((Integer)arrayList.get(n3)).getAllianceID() == CFG.game.getCiv(n).getAllianceID() || CFG.game.getMilitaryAccess((Integer)arrayList.get(n3), n) > 0) continue;
                        CFG.gameAction.accessLost_MoveArmyToClosetsProvince((Integer)arrayList.get(n3), ultimatum_GameData.demandProvinces.get(n4), (Integer)arrayList2.get(n3));
                    }
                }
                CFG.game.buildCivilizationsRegions_TextOver(n2);
                CFG.game.buildCivilizationsRegions_TextOver(n);
            }
            CFG.game.setCivTruce(n, n2, 30);
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_UltimatumAccepted(n2));
        }
    }

    protected static final void acceptUnionProposal(int n, int n2) {
        if (n != n2 && CFG.game.getCiv(n).getNumOfProvinces() > 0 && CFG.game.getCiv(n2).getNumOfProvinces() > 0) {
            Save_Civ_GameData save_Civ_GameData = CFG.game.getCiv((int)n).civGameData;
            ++save_Civ_GameData.numOfUnions;
            save_Civ_GameData = CFG.game.getCiv((int)n2).civGameData;
            ++save_Civ_GameData.numOfUnions;
            CFG.createUnion(n, n2);
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Union_Accepted(n, 0));
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Union_Accepted(n2, 0));
        }
    }

    protected static final boolean addAssimilate(int n, int n2, int n3) {
        if (n == CFG.game.getProvince(n2).getCivID() && !CFG.game.getProvince(n2).isOccupied() && CFG.game.getCiv(n).getDiplomacyPoints() >= 4 && CFG.game.getCiv(n).getMoney() >= (long)DiplomacyManager.assimilateCost(n2, n3) && CFG.game.getCiv(n).addAssimilate(new CivFestival(n2, n3))) {
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 4);
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)Math.abs(DiplomacyManager.assimilateCost(n2, n3)));
            return true;
        }
        return false;
    }

    protected static final boolean addFestival(int n, int n2) {
        if (n == CFG.game.getProvince(n2).getCivID() && CFG.game.getCiv(n).getMovePoints() >= 8 && CFG.game.getCiv(n).getMoney() >= (long)DiplomacyManager.festivalCost(n2) && CFG.game.getCiv(n).addFestival(new CivFestival(n2, 7))) {
            CFG.game.getCiv(n).setMovePoints(CFG.game.getCiv(n).getMovePoints() - 8);
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)DiplomacyManager.festivalCost(n2));
            return true;
        }
        return false;
    }

    protected static final void addFestivalInAllProvince(int n) {
        int n2 = CFG.game.getCiv((int)n).lProvincesWithLowHappiness.size();
        if (n2 > 0) {
            --n2;
            while (n2 >= 0 && DiplomacyManager.addFestival(n, CFG.game.getCiv((int)n).lProvincesWithLowHappiness.get(n2))) {
                --n2;
            }
        }
    }

    protected static final int assimilateCost(int n, int n2) {
        return (int)((float)((int)((CFG.game_NextTurnUpdate.getProvinceIncome_Taxation(n) * 0.775f + CFG.game_NextTurnUpdate.getProvinceIncome_Production(n) * 0.237f) * (CFG.game.getProvince(n).getDevelopmentLevel() * 0.412f + 0.665f + (float)CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getAssimilatesSize() * 0.0825f) * (CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCapitalProvinceID(), n) + 1.625f) * (1.625f - (float)CFG.game.getProvince(n).getPopulationData().getPopulationOfCivID(CFG.game.getProvince(n).getCivID()) / (float)CFG.game.getProvince(n).getPopulationData().getPopulation())) + 212) / 10.0f * (float)n2);
    }

    protected static final void buildFriendlyCivs() {
        int n;
        for (n = 1; n < CFG.game.getCivsSize(); ++n) {
            CFG.game.getCiv(n).clearFreidnlyCivs();
        }
        n = 1;
        while (n < CFG.game.getCivsSize() - 1) {
            int n2;
            for (int i = n2 = n + 1; i < CFG.game.getCivsSize(); ++i) {
                if (CFG.game.getCivRelation_OfCivB(n, i) > 44.0f) {
                    CFG.game.getCiv(n).addFriendlyCiv(i);
                } else if (CFG.game.getCivRelation_OfCivB(n, i) < -25.0f) {
                    CFG.game.getCiv(n).addHatedCiv(i);
                }
                if (CFG.game.getCivRelation_OfCivB(i, n) > 44.0f) {
                    CFG.game.getCiv(i).addFriendlyCiv(n);
                    continue;
                }
                if (!(CFG.game.getCivRelation_OfCivB(i, n) < -25.0f)) continue;
                CFG.game.getCiv(i).addHatedCiv(n);
            }
            n = n2;
        }
    }

    protected static final List<Integer> callToArmsListOfCivs(int n, int n2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        int n3 = CFG.game.getWarID(n, n2);
        int n4 = CFG.game.getCiv(n).getAllianceID();
        int n5 = 0;
        if (n4 > 0) {
            for (n4 = 0; n4 < CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilizationsSize(); ++n4) {
                if (CFG.game.getCiv(CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n4)).getNumOfProvinces() <= 0 || CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n4) == n || CFG.game.getCivsAtWar(CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n4), n2)) continue;
                arrayList.add(CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n4));
            }
        }
        n2 = 0;
        while (true) {
            n4 = CFG.game.getCiv((int)n).civGameData.iVassalsSize;
            int n6 = 1;
            if (n2 >= n4) break;
            if (!CFG.game.getWar(n3).getIsInDefenders(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n2).iCivID) && !CFG.game.getWar(n3).getIsAggressor(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n2).iCivID) && CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n2).iCivID).getNumOfProvinces() > 0) {
                block10: {
                    for (n4 = 0; n4 < arrayList.size(); ++n4) {
                        if ((Integer)arrayList.get(n4) != CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n2).iCivID) continue;
                        n4 = n6;
                        break block10;
                    }
                    n4 = 0;
                }
                if (n4 == 0) {
                    arrayList.add(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n2).iCivID);
                }
            }
            ++n2;
        }
        if (CFG.game.getCiv(n).getCivID() != CFG.game.getCiv(n).getPuppetOfCivID() && !CFG.game.getWar(n3).getIsInDefenders(CFG.game.getCiv(n).getPuppetOfCivID()) && !CFG.game.getWar(n3).getIsAggressor(CFG.game.getCiv(n).getPuppetOfCivID()) && CFG.game.getCiv(CFG.game.getCiv(n).getPuppetOfCivID()).getNumOfProvinces() > 0) {
            n2 = 0;
            while (true) {
                n4 = n5;
                if (n2 >= arrayList.size()) break;
                if (((Integer)arrayList.get(n2)).intValue() == CFG.game.getCiv(n).getPuppetOfCivID()) {
                    n4 = 1;
                    break;
                }
                ++n2;
            }
            if (n4 == 0) {
                arrayList.add(CFG.game.getCiv(n).getPuppetOfCivID());
            }
        }
        return arrayList;
    }

    protected static final List callToArmsListOfCivs_AI(int n, int n2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (n2 = 1; n2 < CFG.game.getCivsSize(); ++n2) {
            if (n == n2 || CFG.game.getCiv(n2).getNumOfProvinces() <= 0 || !CFG.game.getCivsAreAllied_IncludeVassal(n, n2, true)) continue;
            arrayList.add(n2);
        }
        return arrayList;
    }

    protected static final void callToArms_Denied_SendInsult(int n, int n2, int n3) {
        DiplomacyManager.decreaseRelation(n, n2, 15);
    }

    protected static final boolean canMoveToNaighbooringProvince(int n, int n2) {
        boolean bl = !Game_Calendar.ENABLE_COLONIZATION_NEUTRAL_PROVINCES || CFG.game.getProvince(n).getSeaProvince() || CFG.game.getProvince(n).getCivID() > 0 || CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n2).getIdeologyID()).CAN_BECOME_CIVILIZED >= 0;
        return bl;
    }

    protected static final boolean canTakeMoreLoans(int n) {
        boolean bl = CFG.game.getCiv(n).getLoansSize() < 10;
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean changeGovernmentType(int n, int n2) {
        boolean bl;
        int n3;
        boolean bl2;
        block8: {
            block9: {
                block7: {
                    bl2 = false;
                    n3 = CFG.game.getCiv(n).getIdeologyID();
                    if (CFG.ideologiesManager.getIdeology((int)n3).ELECTION_PERIOD > 0) break block7;
                    n3 = CFG.game.getCiv(n).getIdeologyID();
                    if (CFG.ideologiesManager.getIdeology((int)n3).REFORMATION_PERIOD <= 0) break block8;
                    n3 = CFG.game.getCiv((int)n).civGameData.iChangeGoverment_SinceTurn;
                    bl = bl2;
                    if (Game_Calendar.TURN_ID < n3) return bl;
                    break block9;
                }
                n3 = CFG.game.getCiv(n).getNextElection();
                bl = bl2;
                if (Game_Calendar.TURN_ID < n3) return bl;
            }
            n3 = CFG.game.getCiv(n).getIdeologyID();
            if (CFG.ideologiesManager.getIdeology((int)n3).ELECTION_PERIOD <= 0 && CFG.ideologiesManager.getIdeology((int)n3).REFORMATION_PERIOD > 0 && CFG.game.getCiv(n).getInReformation() <= 0) {
                Civilization civilization = CFG.game.getCiv(n);
                civilization.setInReformation(Game_Calendar.TURN_ID + 50);
                civilization.civGameData.iWillChangeToIdeologyID = n2;
                return bl2;
            }
        }
        if (CFG.game.getCiv(n).getIdeologyID() == n2) {
            return bl2;
        }
        bl = bl2;
        if (CFG.game.getCiv(n).getMoney() < (long)Ideologies_Manager.getChangeGovernmentCost(n)) return bl;
        bl = bl2;
        if (CFG.game.getCiv(n).getMovePoints() < 22) return bl;
        CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)Ideologies_Manager.getChangeGovernmentCost(n));
        CFG.game.getCiv(n).setMovePoints(CFG.game.getCiv(n).getMovePoints() + 25);
        n3 = CFG.game.getCiv(n).getIdeologyID();
        if (CFG.ideologiesManager.getIdeology((int)n3).GOV_GROUP_ID != CFG.ideologiesManager.getIdeology((int)n2).GOV_GROUP_ID || CFG.ideologiesManager.getIdeology((int)n2).POLITICAL_AUTHORITY != (n3 = CFG.ideologiesManager.getIdeology((int)n3).POLITICAL_AUTHORITY)) {
            DiplomacyManager.changeGovernmentType_Revolution(n);
        }
        CFG.game.updateCivilizationIdeology(n, CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n).getCivTag()) + CFG.ideologiesManager.getIdeology(n2).getExtraTag());
        if (CFG.isDesktop() && CFG.game.getCiv(n).getControlledByPlayer() && AoCGame.steamGame != null) {
            AoCGame.steamGame.checkGovermentAchievement(n2);
        }
        for (n2 = 0; n2 < CFG.game.getCiv(n).getCivRegionsSize(); ++n2) {
            CFG.game.getCiv(n).getCivRegion(n2).buildScaleOfText();
        }
        bl = true;
        Civilization civilization = CFG.game.getCiv(n);
        civilization.updateNextReformation_Start();
        civilization.updateNextElection_Start();
        return bl;
    }

    protected static final void changeGovernmentType_Revolution(int n) {
        for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            Object object = CFG.game;
            if (CFG.game.getProvince(((Game)object).getCiv(n).getProvinceID(i)).isOccupied() || CFG.oR.nextInt(100) >= 75) continue;
            float f = (float)CFG.oR.nextInt(100) / 100.0f;
            object = CFG.game;
            object = CFG.game.getProvince(((Game)object).getCiv(n).getProvinceID(i));
            ((Province)object).setRevolutionaryRisk(((Province)object).getRevolutionaryRisk() + f);
        }
    }

    protected static final void checkCivsHatedCivilizations_IfStillExsits() {
        if (Game_Calendar.TURN_ID % 9 == 0) {
            for (int i = Game_Calendar.TURN_ID % 2 + 1; i < CFG.game.getCivsSize(); i += 2) {
                if (CFG.game.getCiv(i).getNumOfProvinces() <= 0) continue;
                for (int j = CFG.game.getCiv(i).getHatedCivsSize() - 1; j >= 0; --j) {
                    if (CFG.game.getCiv(CFG.game.getCiv((int)i).getHatedCiv((int)j).iCivID).getNumOfProvinces() != 0) continue;
                    CFG.game.getCiv(i).removeHatedCiv(CFG.game.getCiv((int)i).getHatedCiv((int)j).iCivID);
                }
            }
        }
    }

    protected static final boolean civilizeCiv(int n) {
        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CAN_BECOME_CIVILIZED >= 0 && CFG.game.getCiv(n).getDiplomacyPoints() >= 10 && CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CIVILIZE_TECH_LEVEL <= CFG.game.getCiv(n).getTechnologyLevel()) {
            int n2;
            CFG.game.getCiv(n).setIdeologyID(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CAN_BECOME_CIVILIZED);
            Civilization civilization = CFG.game.getCiv(n);
            Serializable serializable = new StringBuilder();
            ((StringBuilder)serializable).append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n).getCivTag()));
            ((StringBuilder)serializable).append(CFG.ideologiesManager.getIdeology(CFG.game.getCiv(n).getIdeologyID()).getExtraTag());
            civilization.setCivTag(((StringBuilder)serializable).toString());
            CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n);
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 10);
            if (CFG.game.getPlayerID_ByCivID(n) >= 0) {
                CFG.game.getPlayer(CFG.game.getPlayerID_ByCivID(n)).loadPlayersFlag();
            }
            CFG.viewsManager.disableAllViews();
            for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
                CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).setFromCivID(0);
            }
            CFG.palletManager.loadCivilizationStandardColor(n);
            if (CFG.game.getCiv(n).getNumOfNeighboringNeutralProvinces() > 0) {
                serializable = new ArrayList();
                for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
                    for (int i = 0; i < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvincesSize(); ++i) {
                        serializable.add(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getNeighboringProvinces(i));
                    }
                }
                if (serializable.size() > 0) {
                    CFG.game.getProvince((Integer)serializable.get(CFG.oR.nextInt(serializable.size()))).setCivID(n, false);
                }
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final boolean colonizeWastelandProvince(int n, int n2) {
        boolean bl = false;
        if (CFG.game.getProvince(n).getCivID() < 0 && CFG.game.getProvince(n).getCivID() != 0) {
            return bl;
        }
        boolean bl2 = bl;
        if (CFG.game.getCiv(n2).getMovePoints() < DiplomacyManager.getColonizeCost_Movement(n, n2)) return bl2;
        bl2 = bl;
        if (CFG.game.getCiv(n2).getDiplomacyPoints() < CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_DIPLOMACY_POINTS) return bl2;
        bl2 = bl;
        if (CFG.game.getCiv(n2).getMoney() < (long)DiplomacyManager.getColonizeCost(n, n2)) return bl2;
        bl2 = bl;
        if (!CFG.gameAction.canColonizieWasteland_BorderOrArmy(n, n2)) return bl2;
        int n3 = CFG.game.getProvince(n).getWasteland() >= 0 ? 1 : 0;
        CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - DiplomacyManager.getColonizeCost_Movement(n, n2));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_DIPLOMACY_POINTS);
        CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)DiplomacyManager.getColonizeCost(n, n2));
        CFG.game.getProvince(n).setWasteland(-1);
        CFG.game.getProvince(n).resetArmies(0);
        CFG.game.getProvince(n).setCivID(n2, false, true);
        int n4 = CFG.oR.nextInt(15) + 5;
        CFG.game.getProvince(n).updateArmy(n2, n4);
        CFG.game.getCiv(n2).setNumOfUnits(CFG.game.getCiv(n2).getNumOfUnits() + n4);
        CFG.game.getProvince(n).getCore().addNewCore(n2, Game_Calendar.TURN_ID);
        CFG.game.getProvince(n).setHappiness(Math.max(CFG.game.getProvince(n).getHappiness(), (float)(CFG.oR.nextInt(31) + 62) / 100.0f));
        CFG.game.getProvince(n).setDevelopmentLevel(Math.max(CFG.game.getProvince(n).getDevelopmentLevel(), CFG.game.getCiv(n2).getTechnologyLevel() * (0.125f + (float)CFG.oR.nextInt(100) / 1000.0f)));
        CFG.game.getProvince((int)n).saveProvinceData.iNewColonyBonus = 92;
        if (n3 != 0) {
            CFG.game.getProvince(n).getPopulationData().setPopulationOfCivID(n2, Math.max(CFG.oR.nextInt(460) + 299, CFG.game.getProvince(n).getPopulationData().getPopulationOfCivID(n2)));
            CFG.game.getProvince(n).setEconomy(Math.max(CFG.game.getProvince(n).getEconomy(), CFG.oR.nextInt(76) + 42));
            CFG.game.buildWastelandLevels();
        }
        n3 = 0;
        while (true) {
            block10: {
                block9: {
                    if (n3 >= CFG.game.getProvince(n).getPopulationData().getNationalitiesSize()) break block9;
                    if (CFG.game.getProvince(n).getPopulationData().getCivID(n3) != 0) break block10;
                    float f = 0.375f + (float)CFG.oR.nextInt(35) / 100.0f;
                    CFG.game.getProvince(n).getPopulationData().setPopulationOfCivID(n2, CFG.game.getProvince(n).getPopulationData().getPopulationOfCivID(n2) + (int)((float)CFG.game.getProvince(n).getPopulationData().getPopulationID(n3) * f));
                    CFG.game.getProvince(n).getPopulationData().setPopulationOfCivID(CFG.game.getProvince(n).getPopulationData().getCivID(n3), CFG.game.getProvince(n).getPopulationData().getPopulationID(n3) - (int)((float)CFG.game.getProvince(n).getPopulationData().getPopulationID(n3) * f));
                }
                CFG.game.getCiv((int)n2).civGameData.lColonies_Founded.add(new Civilization_Colonies(n));
                CFG.oAI.buildProvinceData(n);
                if (CFG.game.getActiveProvinceID() == n) {
                    CFG.game.setActiveProvinceID(-1);
                    CFG.game.setActiveProvinceID(n);
                }
                try {
                    HistoryManager historyManager = CFG.historyManager;
                    HistoryLog_NewColony historyLog_NewColony = new HistoryLog_NewColony(n2, n);
                    historyManager.addHistoryLog(historyLog_NewColony);
                    return true;
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    return true;
                }
                catch (NullPointerException nullPointerException) {
                    return true;
                }
            }
            ++n3;
        }
    }

    protected static final void controlOccupiedProvinceFrom(int n, int n2) {
        Object object;
        for (int i = 0; i < ((Civilization)(object = CFG.game.getCiv(n))).getNumOfProvinces(); ++i) {
            int n3 = ((Civilization)object).getProvinceID(i);
            if (((Province)(object = CFG.game.getProvince(n3))).getTrueOwnerOfProvince() != n2) continue;
            ((Province)object).setTrueOwnerOfProvince(n);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final void declarationOfIndependeceByVassal(int n, int n2) {
        if (CFG.game.getCivTruce(n, n2) > 0) {
            return;
        }
        if (CFG.NO_LIBERITY) return;
        if (CFG.game.getCiv(n2).getPuppetOfCivID() != n) return;
        CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
        CFG.game.getCiv(n2).setVassalLiberityDesire(0.0f);
        if (CFG.game.getMilitaryAccess(n, n2) <= 0) {
            CFG.gameAction.accessLost_UpdateArmies(n2, n);
        }
        if (CFG.game.getMilitaryAccess(n2, n) <= 0) {
            CFG.gameAction.accessLost_UpdateArmies(n, n2);
        }
        if (CFG.FOG_OF_WAR > 0) {
            if (CFG.game.getPlayerID_ByCivID(n) >= 0) {
                CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n));
            }
            if (CFG.game.getPlayerID_ByCivID(n2) >= 0) {
                CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n2));
            }
        }
        CFG.historyManager.addHistoryLog(new HistoryLog_IsNotVassal(n, n2));
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Liberation(n));
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_DeclarationOfIndependence_ByVassal(n2));
        if (CFG.game.getCiv(n).getControlledByPlayer()) return;
        CFG.game.getCiv(n).addSentMessages(new Civilization_SentMessages(n2, Message_Type.LIBERATION_OF_VASSAL));
    }

    protected static final void declineAllianceProposal(int n, int n2) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Alliance_Denied(n));
    }

    protected static final void declineCallToArms(int n, int n2, int n3) {
        if (!CFG.game.getCivsAtWar(n, n3)) {
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_CallToArms_Deny(n, n3, n2));
            Game game = CFG.game;
            float f = CFG.game.getCivRelation_OfCivB(n, n2);
            float f2 = -99.0f;
            f = f > -100.0f && CFG.game.getCivRelation_OfCivB(n, n2) - 15.0f <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n, n2) - 15.0f;
            game.setCivRelation_OfCivB(n, n2, f);
            game = CFG.game;
            f = CFG.game.getCivRelation_OfCivB(n2, n) > -100.0f && CFG.game.getCivRelation_OfCivB(n2, n) - 15.0f <= -100.0f ? f2 : CFG.game.getCivRelation_OfCivB(n2, n) - 15.0f;
            game.setCivRelation_OfCivB(n2, n, f);
        }
    }

    protected static final void declineDefensivePact(int n, int n2, int n3) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_DefensivePact_Denied(n));
    }

    protected static final void declineGift(int n, int n2, int n3) {
        CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() + (long)n3);
        Game game = CFG.game;
        float f = CFG.game.getCivRelation_OfCivB(n, n2);
        float f2 = -99.0f;
        f = f > -100.0f && CFG.game.getCivRelation_OfCivB(n, n2) - 8.0f <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n, n2) - 8.0f;
        game.setCivRelation_OfCivB(n, n2, f);
        game = CFG.game;
        f = CFG.game.getCivRelation_OfCivB(n2, n) > -100.0f && CFG.game.getCivRelation_OfCivB(n2, n) - 8.0f <= -100.0f ? f2 : CFG.game.getCivRelation_OfCivB(n2, n) - 8.0f;
        game.setCivRelation_OfCivB(n2, n, f);
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Gift_Refused(n, n3));
    }

    protected static final void declineGuaranteeIndependence_Ask(int n, int n2, int n3) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Independence_Ask_Denied(n));
    }

    protected static final void declineMilitaryAccess_Ask(int n, int n2, int n3) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_MilitaryAccess_Ask_Denied(n));
    }

    protected static final void declineMilitaryAccess_Give(int n, int n2, int n3) {
    }

    protected static final void declineNonAggressionPact(int n, int n2, int n3) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_NonAggressionPact_Denied(n));
    }

    protected static final void declineOfferVasalization(int n, int n2, int n3) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Vassalization_Rejected(n));
    }

    protected static final void declinePeaceTreaty(int n, String string2) {
        int n2 = CFG.game.getPeaceTreaty_GameDataID(string2);
        int n3 = 0;
        int n4 = 0;
        while (true) {
            if (n4 >= CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Aggressors.size()) break;
            if (CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Aggressors.get((int)n4).peaceTreatyAccepted) {
                CFG.game.getCiv((int)CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Aggressors.get((int)n4).iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_PeaceTreaty_Rejected(n));
            }
            ++n4;
        }
        for (int i = n3; i < CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Defenders.size(); ++i) {
            if (!CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Defenders.get((int)i).peaceTreatyAccepted) continue;
            CFG.game.getCiv((int)CFG.game.lPeaceTreaties.get((int)n2).peaceTreaty_GameData.lCivsDemands_Defenders.get((int)i).iCivID).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_PeaceTreaty_Rejected(n));
        }
        CFG.game.lPeaceTreaties.remove(n2);
    }

    protected static final void declinePrepareForWar(int n, int n2, int n3, int n4, int n5) {
        CFG.game.getCiv((int)n3).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_PrepareForWar_Refused(n2, n4));
        Game game = CFG.game;
        float f = CFG.game.getCivRelation_OfCivB(n2, n3);
        float f2 = -99.0f;
        f = f > -100.0f && CFG.game.getCivRelation_OfCivB(n2, n3) + (float)WAR_PREPARATIONS_REFUSE_OPINION_CHANGE <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n2, n3) + (float)WAR_PREPARATIONS_REFUSE_OPINION_CHANGE;
        game.setCivRelation_OfCivB(n2, n3, f);
        game = CFG.game;
        if (CFG.game.getCivRelation_OfCivB(n3, n2) > -100.0f && CFG.game.getCivRelation_OfCivB(n3, n2) + (float)WAR_PREPARATIONS_REFUSE_OPINION_CHANGE <= -100.0f) {
            f = f2;
        } else {
            f = CFG.game.getCivRelation_OfCivB(n3, n2);
            f = (float)WAR_PREPARATIONS_REFUSE_OPINION_CHANGE + f;
        }
        game.setCivRelation_OfCivB(n3, n2, f);
    }

    protected static final void declineTradeRequest(int n, int n2, TradeRequest_GameData tradeRequest_GameData) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TradeReuest_Denied(n));
    }

    protected static final void declineTransferControl(int n, int n2, int n3) {
        if (CFG.game.getProvince(n3).getCivID() == n2 && CFG.game.getProvince(n3).isOccupied() && (CFG.game.getCivsAreAllied(n, n2) || CFG.game.getCiv(n).getPuppetOfCivID() == n2 || CFG.game.getCiv(n2).getPuppetOfCivID() == n)) {
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TransferControl_Refused(n, n3, n2));
        }
    }

    protected static final void declineUnionProposal(int n, int n2) {
        CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Union_Refused(n, 0));
    }

    protected static boolean decreaseRelation(int n, int n2, int n3) {
        if (CFG.game.getCiv(n).getDiplomacyPoints() >= 2) {
            CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 2);
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Relations_Insult(n));
            CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().removeImproveRelations_WithCivID(n, n2);
            CFG.game.getCiv(n2).getCivilization_Diplomacy_GameData().removeImproveRelations_WithCivID(n2, n);
            CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().addEmbeassyClosed(new Civilization_ClosedEmbassy(n2, n3));
            CFG.game.getCiv(n2).getCivilization_Diplomacy_GameData().addEmbeassyClosed(new Civilization_ClosedEmbassy(n, n3));
            float f = DiplomacyManager.getDecreaseRelation(n, n2);
            Game game = CFG.game;
            float f2 = CFG.game.getCivRelation_OfCivB(n, n2);
            float f3 = -99.0f;
            f2 = f2 > -100.0f && CFG.game.getCivRelation_OfCivB(n, n2) + f <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n, n2) + f;
            game.setCivRelation_OfCivB(n, n2, f2);
            f2 = f * 0.415f;
            game = CFG.game;
            f2 = CFG.game.getCivRelation_OfCivB(n2, n) > -100.0f && CFG.game.getCivRelation_OfCivB(n2, n) + f2 <= -100.0f ? f3 : CFG.game.getCivRelation_OfCivB(n2, n) + f2;
            game.setCivRelation_OfCivB(n2, n, f2);
            DiplomacyManager.worldRecations((int)Math.min(30.0f, CFG.game.getCivRelation_OfCivB(n, n2) + 100.0f) / 3, n, n2);
            DiplomacyManager.updateFriendlyCiv(n, n2);
            return true;
        }
        return false;
    }

    protected static final int festivalCost(int n) {
        return (int)((CFG.game_NextTurnUpdate.getProvinceIncome_Taxation(n) + CFG.game_NextTurnUpdate.getProvinceIncome_Production(n)) * (CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getTechnologyLevel() * 0.1625f + 0.6425f + (float)CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getFestivalsSize() * 0.2f)) + 500;
    }

    protected static final float festivalHappinessPerTurn(int n) {
        return (1.0f - CFG.game.getProvince(n).getHappiness()) * 0.006f + 0.0145f;
    }

    protected static final float festivalHappinessPerTurn_NeighboringProvinces() {
        return 0.0045f;
    }

    protected static int getAllianceProposal_Negative(int n, int n2) {
        int n3;
        int n4 = n3 = DiplomacyManager.getAllianceProposal_Negative_Opinion(n, n2) + 0 + DiplomacyManager.getAllianceProposal_Negative_Goverment(n, n2) + DiplomacyManager.getAllianceProposal_Negative_HRE(n, n2) + DiplomacyManager.getAllianceProposal_Negative_CivIsAtWar(n) + DiplomacyManager.getAllianceProposal_Negative_EmbassyClosed(n, n2) + DiplomacyManager.getAllianceProposal_Negative_HaveACore(n, n2) + DiplomacyManager.getAllianceProposal_Negative_Distance(n, n2);
        if (DiplomacyManager.getAllianceProposale_CivStrength(n, n2) < 0) {
            n4 = n3 + DiplomacyManager.getAllianceProposale_CivStrength(n, n2);
        }
        return n4;
    }

    protected static int getAllianceProposal_Negative_CivIsAtWar(int n) {
        if (CFG.game.getCiv(n).isAtWar()) {
            return 0;
        }
        return 0;
    }

    protected static int getAllianceProposal_Negative_Distance(int n, int n2) {
        float f = 2.0f;
        for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            for (int j = 0; j < CFG.game.getCiv(n2).getNumOfProvinces(); ++j) {
                f = Math.min(f, CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(n).getProvinceID(i), CFG.game.getCiv(n2).getProvinceID(j)));
            }
        }
        return (int)(-CFG.gameAges.getAge_DistanceDiplomacy(Game_Calendar.CURRENT_AGEID) * f);
    }

    protected static int getAllianceProposal_Negative_EmbassyClosed(int n, int n2) {
        if (!CFG.game.getCiv(n).getCivilization_Diplomacy_GameData().isEmassyClosed(n2) && !CFG.game.getCiv(n2).getCivilization_Diplomacy_GameData().isEmassyClosed(n)) {
            return 0;
        }
        return -1000;
    }

    protected static int getAllianceProposal_Negative_Goverment(int n, int n2) {
        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).GOV_GROUP_ID == CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n2).getIdeologyID()).GOV_GROUP_ID) {
            return 0;
        }
        if (CFG.game.getCiv(n).getIdeologyID() != CFG.game.getCiv(n2).getIdeologyID()) {
            return -24;
        }
        return 0;
    }

    protected static int getAllianceProposal_Negative_HRE(int n, int n2) {
        if (CFG.game.getCiv(n).getIsPartOfHolyRomanEmpire() && !CFG.game.getCiv(n2).getIsPartOfHolyRomanEmpire() || !CFG.game.getCiv(n).getIsPartOfHolyRomanEmpire() && CFG.game.getCiv(n2).getIsPartOfHolyRomanEmpire()) {
            return -15;
        }
        return 0;
    }

    protected static int getAllianceProposal_Negative_HaveACore(int n, int n2) {
        int n3 = 0;
        int n4 = 0;
        for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            int n5 = n4;
            if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getHaveACore(n2)) {
                n5 = n4 + 1;
            }
            n4 = n5;
        }
        n = n3;
        if (n4 > 0) {
            n = -Math.min((n4 - 1) * 5 + 15, 20);
        }
        return n;
    }

    protected static int getAllianceProposal_Negative_IsAVassal(int n, int n2) {
        n = CFG.game.getCiv(n).getPuppetOfCivID() != n && CFG.game.getCiv(n).getPuppetOfCivID() != n2 ? -100 : 0;
        return n;
    }

    protected static int getAllianceProposal_Negative_Opinion(int n, int n2) {
        float f = CFG.game.getCivRelation_OfCivB(n2, n);
        float f2 = CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_OPINION;
        int n3 = 0;
        if (f - f2 < 0.0f) {
            f2 = (CFG.game.getCivRelation_OfCivB(n2, n) - CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_OPINION) / 5.0f;
            if (CFG.game.getCivRelation_OfCivB(n2, n) < 0.0f) {
                n3 = 5;
            }
            return (int)(f2 - (float)n3);
        }
        return 0;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static int getAllianceProposal_Negative_PowerfulAllies(int n, int n2) {
        int n3;
        int n4;
        block12: {
            int n5;
            int n6;
            block14: {
                block11: {
                    int n7;
                    int n8;
                    n6 = -1;
                    try {
                        n4 = CFG.game.getCiv(n).getAllianceID();
                        if (n4 <= 0) break block11;
                        n8 = 0;
                        n7 = 0;
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        n5 = 0;
                        break block14;
                    }
                    while (true) {
                        block13: {
                            n5 = n7;
                            n3 = n6;
                            n4 = n7;
                            try {
                                if (n8 >= CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilizationsSize()) break block12;
                                n4 = n7;
                                n5 = n7;
                                if (n == CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n8)) break block13;
                                n5 = n7;
                                n5 = n4 = n7 - (int)Math.min(0.0f, (float)CFG.game.getCiv(CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n8)).getRankScore() / (float)CFG.game.getCiv(n).getRankScore() * 0.0f);
                                n7 = DiplomacyManager.getAllianceProposal_Negative_Opinion(n2, CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilization(n8));
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                break block14;
                            }
                            n4 += (int)((float)n7 * 0.0f);
                        }
                        ++n8;
                        n7 = n4;
                    }
                }
                n4 = 0;
                n3 = n6;
                break block12;
            }
            n3 = n6;
            n4 = n5;
            if (CFG.LOGS) {
                void var8_10;
                CFG.exceptionStack((Throwable)var8_10);
                n4 = n5;
                n3 = n6;
            }
        }
        while (n3 < CFG.game.getCivsSize()) {
            n2 = n4;
            if (n3 != n) {
                n2 = n4;
                if (CFG.game.getCiv(n3).getPuppetOfCivID() == n) {
                    n2 = n4;
                    if (CFG.game.getCiv(n).getNumOfProvinces() > 0) {
                        n2 = n4 - 1;
                    }
                }
            }
            ++n3;
            n4 = n2;
        }
        return n4;
    }

    protected static int getAllianceProposal_Positive(int n, int n2) {
        int n3;
        int n4 = n3 = DiplomacyManager.getAllianceProposal_Positive_Opinion(n, n2) + 0 + DiplomacyManager.getAllianceProposal_Positive_Goverment(n, n2);
        if (DiplomacyManager.getAllianceProposale_CivStrength(n, n2) > 0) {
            n4 = n3 + DiplomacyManager.getAllianceProposale_CivStrength(n, n2);
        }
        return n4 + DiplomacyManager.getAllianceProposal_Positive_HRE(n, n2);
    }

    protected static int getAllianceProposal_Positive_Goverment(int n, int n2) {
        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).GOV_GROUP_ID == CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n2).getIdeologyID()).GOV_GROUP_ID) {
            if (CFG.game.getCiv(n).getIdeologyID() == CFG.game.getCiv(n2).getIdeologyID()) {
                return 20;
            }
            return 6;
        }
        return 0;
    }

    protected static int getAllianceProposal_Positive_HRE(int n, int n2) {
        if (CFG.game.getCiv(n).getIsPartOfHolyRomanEmpire() && CFG.game.getCiv(n2).getIsPartOfHolyRomanEmpire()) {
            return 25;
        }
        return 0;
    }

    protected static int getAllianceProposal_Positive_Opinion(int n, int n2) {
        if (CFG.game.getCivRelation_OfCivB(n2, n) - CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_OPINION > 0.0f) {
            return (int)((CFG.game.getCivRelation_OfCivB(n2, n) - CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_OPINION) / 1.0f);
        }
        return 0;
    }

    protected static int getAllianceProposale_CivStrength(int n, int n2) {
        return (int)(-CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_STRENTGH / 1.0f + CFG.game.getCiv((int)n2).civGameData.civPersonality.RESPONSE_ALLIANCE_STRENTGH / 1.0f * Math.min((float)CFG.game.getCiv(n).getRankScore() / (float)CFG.game.getCiv(n2).getRankScore(), 1.0f));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean getCivIsInRange(int n, int n2) {
        Civilization civilization = CFG.game.getCiv(n);
        float f = CFG.ideologiesManager.getIdeology((int)civilization.getIdeologyID()).DIPLOMACY_RANGE;
        float f2 = CFG.gameAges.getAge_DiplomacyRange(Game_Calendar.CURRENT_AGEID);
        if (CFG.game.getCiv(n).getNumOfProvinces() <= 0) return false;
        if (CFG.game.getCiv(n2).getNumOfProvinces() <= 0) return false;
        civilization = CFG.game.getCiv(n);
        if (CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(civilization.getCapitalProvinceID(), CFG.game.getCiv(n2).getCapitalProvinceID()) <= f * f2) return true;
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean getCivIsInRange_War(int n, int n2) {
        Civilization civilization = CFG.game.getCiv(n);
        float f = CFG.ideologiesManager.getIdeology((int)civilization.getIdeologyID()).CONTROL_RANGE;
        float f2 = CFG.gameAges.getAge_ControlRange(Game_Calendar.CURRENT_AGEID);
        if (CFG.game.getCiv(n).getNumOfProvinces() <= 0) return false;
        if (CFG.game.getCiv(n2).getNumOfProvinces() <= 0) return false;
        civilization = CFG.game.getCiv(n);
        if (CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(civilization.getCapitalProvinceID(), CFG.game.getCiv(n2).getCapitalProvinceID()) <= f * f2 * 2.0f) return true;
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final int getColonizeCost(int n, int n2) {
        float f = 2.5625f;
        float f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f3 = CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_GOLD_PERC;
        float f4 = CFG.game.getProvince(n).getGrowthRate_Population();
        float f5 = CFG.game.getCiv(n2).getCapitalProvinceID() >= 0 ? 3.475f * CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(CFG.game.getCiv(n2).getCapitalProvinceID(), n) : 2.5625f;
        float f6 = DiplomacyManager.getColonizeCost_OwnNeighboringProvincesModifier(n, n2);
        float f7 = DiplomacyManager.getColonizeCost_ContinentAndRegion_Modifier(n, n2);
        float f8 = CFG.game.getCiv((int)n2).civGameData.fModifier_ColonizationCost;
        if (CFG.game.getCiv(n2).getTechnologyLevel() < Game_Calendar.COLONIZATION_TECH_LEVEL) {
            f = 2.675f + (Game_Calendar.COLONIZATION_TECH_LEVEL - CFG.game.getCiv(n2).getTechnologyLevel()) * 8.25f;
        }
        return (int)((f5 * 0.1325f + (0.0845f * f4 + f3)) * f2 * f6 * f7 * (2.5625f - f8) * f);
    }

    protected static final int getColonizeCost_AI(int n) {
        float f = 1.0f;
        float f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f3 = CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_GOLD_PERC;
        float f4 = CFG.game.getCiv((int)n).civGameData.fModifier_ColonizationCost;
        if (CFG.game.getCiv(n).getTechnologyLevel() < Game_Calendar.COLONIZATION_TECH_LEVEL) {
            f = 2.675f + (Game_Calendar.COLONIZATION_TECH_LEVEL - CFG.game.getCiv(n).getTechnologyLevel()) * 8.25f;
        }
        return (int)(f * (f2 * (f3 + 0.021125f + 0.0795f) * (1.0f - f4)));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final float getColonizeCost_ContinentAndRegion_Modifier(int n, int n2) {
        if (CFG.game.getCiv(n2).getCapitalProvinceID() < 0) return 1.0f;
        if (CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getContinent() == CFG.game.getProvince(n).getContinent()) {
            if (CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getRegion() != CFG.game.getProvince(n).getRegion()) return 0.865f;
            return 0.815f;
        }
        if (CFG.game.getProvince(CFG.game.getCiv(n2).getCapitalProvinceID()).getRegion() != CFG.game.getProvince(n).getRegion()) return 1.0f;
        return 0.915f;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final int getColonizeCost_Movement(int n, int n2) {
        float f;
        float f2 = CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_MOVEMENT_POINTS;
        float f3 = CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_MOVEMENT_POINTS;
        if (CFG.game.getCiv(n2).getCapitalProvinceID() >= 0) {
            f = 1.6275f * CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(CFG.game.getCiv(n2).getCapitalProvinceID(), n);
            return (int)Math.min(40.0f, f * f3 + f2);
        }
        f = 2.0f;
        return (int)Math.min(40.0f, f * f3 + f2);
    }

    protected static final float getColonizeCost_OwnNeighboringProvincesModifier(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(n).getNeighboringProvincesSize(); ++i) {
            int n4 = n3;
            if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringProvinces(i)).getCivID() == n2) {
                n4 = n3 + 1;
            }
            n3 = n4;
        }
        return 1.0f - 0.4f * (float)n3 / (float)Math.max(CFG.game.getProvince(n).getNeighboringProvincesSize(), 1);
    }

    protected static final int getCostOfCurrentDiplomaticActions(int n) {
        int n2 = CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilizationsSize() > 1 ? 6 : 0;
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            int n3 = n2;
            if (CFG.game.getCiv(i).getNumOfProvinces() > 0) {
                n3 = n2;
                if (i != n) {
                    n3 = n2;
                    if (CFG.game.getCivNonAggressionPact(n, i) > 0) {
                        n3 = n2 + 2;
                    }
                    n2 = n3;
                    if (CFG.game.getGuarantee(n, i) > 0) {
                        n2 = n3 + 1;
                    }
                    n3 = n2;
                    if (CFG.game.getDefensivePact(n, i) > 0) {
                        n3 = n2 + 3;
                    }
                    n2 = n3;
                    if (CFG.game.getMilitaryAccess(n, i) > 0) {
                        n2 = n3 + 1;
                    }
                    n3 = n2 + CFG.game.getCiv((int)n).civGameData.iVassalsSize * 1 + DiplomacyManager.getCostOfFriendlyCivs(n);
                }
            }
            n2 = n3;
        }
        return n2;
    }

    protected static final int getCostOfCurrentDiplomaticActionsUpdate(int n) {
        n = CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilizationsSize() > 1 ? 6 : 0;
        return n;
    }

    protected static final int getCostOfFriendlyCivs(int n) {
        return CFG.game.getCiv(n).getFriendlyCivsSize() * 3;
    }

    protected static float getDecreaseRelation(int n, int n2) {
        float f = -((float)CFG.oR.nextInt(27) / 100.0f + 26.25f);
        return 0.4f * f + f * 0.725f * ((CFG.game.getCivRelation_OfCivB(n2, n) + 100.0f) / 200.0f);
    }

    protected static float getImproveRelation(int n, int n2) {
        return ((float)CFG.oR.nextInt(121) / 100.0f + 0.8425f) * (Math.min(CFG.game.getCivRelation_OfCivB(n2, n) + 100.0f, 145.0f) / 250.0f) * Math.min(Math.max(0.325f, (float)CFG.game.getCiv(n).getRankScore() / (float)CFG.game.getCiv(n2).getRankScore()), 1.0f) + 0.125f;
    }

    protected static final float getLikelihoodScore(int n) {
        return (float)(Math.min(Math.max(n, -100), 100) + 100) / 200.0f;
    }

    public static int getNuclearAttackCost(int n, int n2) {
        return 50000 + DiplomacyManager.getNuclearAttackCost2(n, n2) / 2;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final int getNuclearAttackCost2(int n, int n2) {
        float f = 15.0f;
        float f2 = CFG.game.getGameScenarios().getScenario_StartingPopulation();
        float f3 = CFG.gameAges.getAge((int)Game_Calendar.CURRENT_AGEID).COLONIZE_COST_GOLD_PERC;
        float f4 = CFG.game.getProvince(n).getGrowthRate_Population();
        float f5 = CFG.game.getCiv(n2).getCapitalProvinceID() >= 0 ? 20.0f * CFG.game_NextTurnUpdate.getDistanceFromCapital_PercOfMax(CFG.game.getCiv(n2).getCapitalProvinceID(), n) : 15.0f;
        float f6 = DiplomacyManager.getColonizeCost_OwnNeighboringProvincesModifier(n, n2);
        float f7 = DiplomacyManager.getColonizeCost_ContinentAndRegion_Modifier(n, n2);
        float f8 = CFG.game.getCiv((int)n2).civGameData.fModifier_ColonizationCost;
        if (CFG.game.getCiv(n2).getTechnologyLevel() < Game_Calendar.COLONIZATION_TECH_LEVEL) {
            f = 2.675f + (Game_Calendar.COLONIZATION_TECH_LEVEL - CFG.game.getCiv(n2).getTechnologyLevel()) * 8.25f;
        }
        return (int)((f5 * 0.1325f + (0.0845f * f4 + f3)) * f2 * f6 * f7 * (15.0f - f8) * f);
    }

    protected static int getNumOfCivsInTheGame() {
        int n = 0;
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            int n2 = n;
            if (CFG.game.getCiv(i).getNumOfProvinces() > 0) {
                n2 = n + 1;
            }
            n = n2;
        }
        return n;
    }

    protected static final float getSUPPORT_REBELS_ASSIMILATE_PERC(int n) {
        if (n <= 1) {
            return 0.845f;
        }
        return Math.min(1.0f, (float)(n / 4)) * 0.125f + 0.845f;
    }

    protected static String getTradeRequest_LikelihoodOfSuccess_Text() {
        if (!CFG.game.getCiv(CFG.tradeRequest.iCivRIGHT).getControlledByPlayer()) {
            return CFG.langManager.get("Medium");
        }
        return CFG.langManager.get("NoData");
    }

    protected static final void goldenAge_Military(int n) {
        Object object = Gdx.app;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MILITARY: ");
        stringBuilder.append(CFG.game.getCiv(n).getCivName());
        object.log("AoC", stringBuilder.toString());
        object = new CivBonus_GameData();
        ((CivBonus_GameData)object).iTurnsLeft = 10;
        ((CivBonus_GameData)object).BONUS_TYPE = CivBonus_Type.GOLDEN_AGE_MILITARY;
        ((CivBonus_GameData)object).fModifier_AttackBonus = (float)CFG.oR.nextInt(6) / 100.0f + 0.08f;
        ((CivBonus_GameData)object).fModifier_MilitaryUpkeep = -0.14f - (float)CFG.oR.nextInt(6) / 100.0f;
        ((CivBonus_GameData)object).fModifier_MovementPoints = (float)CFG.oR.nextInt(10) / 100.0f + 0.06f;
        if (CFG.game.getCiv(n).addNewBonus((CivBonus_GameData)object)) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_GoldenAgeMilitary(n, ((CivBonus_GameData)object).iTurnsLeft));
        }
    }

    protected static final void goldenAge_Prosperity(int n) {
        Application application = Gdx.app;
        Serializable serializable = new StringBuilder();
        serializable.append("PROSPERITY: ");
        serializable.append(CFG.game.getCiv(n).getCivName());
        application.log("AoC", serializable.toString());
        serializable = new CivBonus_GameData();
        ((CivBonus_GameData)serializable).iTurnsLeft = 8;
        ((CivBonus_GameData)serializable).BONUS_TYPE = CivBonus_Type.GOLDEN_AGE_PROSPERITY;
        ((CivBonus_GameData)serializable).fModifier_PopGrowth = (float)CFG.oR.nextInt(10) / 100.0f + 0.1f;
        ((CivBonus_GameData)serializable).fModifier_EconomyGrowth = (float)CFG.oR.nextInt(5) / 100.0f + 0.08f;
        ((CivBonus_GameData)serializable).fModifier_IncomeTaxation = (float)CFG.oR.nextInt(6) / 100.0f + 0.06f;
        if (CFG.game.getCiv(n).addNewBonus((CivBonus_GameData)serializable)) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_GoldenAge(n, ((CivBonus_GameData)serializable).iTurnsLeft));
        }
    }

    protected static final void goldenAge_Science(int n) {
        Application application = Gdx.app;
        Serializable serializable = new StringBuilder();
        serializable.append("SCIENCE: ");
        serializable.append(CFG.game.getCiv(n).getCivName());
        application.log("AoC", serializable.toString());
        serializable = new CivBonus_GameData();
        ((CivBonus_GameData)serializable).iTurnsLeft = 8;
        ((CivBonus_GameData)serializable).BONUS_TYPE = CivBonus_Type.GOLDEN_AGE_SCIENCE;
        ((CivBonus_GameData)serializable).fModifier_Research = (float)CFG.oR.nextInt(10) / 100.0f + 0.15f;
        ((CivBonus_GameData)serializable).fModifier_DefenseBonus = (float)CFG.oR.nextInt(6) / 100.0f + 0.1f;
        ((CivBonus_GameData)serializable).fModifier_IncomeProduction = (float)CFG.oR.nextInt(8) / 100.0f + 0.06f;
        if (CFG.game.getCiv(n).addNewBonus((CivBonus_GameData)serializable)) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_GoldenAgeScience(n, ((CivBonus_GameData)serializable).iTurnsLeft));
        }
    }

    protected static boolean improveRelation(int n, int n2) {
        int n3 = CFG.game.getCiv(n).getNumOfProvinces();
        boolean bl = false;
        if (n3 == 0) {
            return false;
        }
        if (CFG.game.getCiv(n2).getCivilization_Diplomacy_GameData().isEmassyClosed(n)) {
            return false;
        }
        if (CFG.game.getCiv(n).getDiplomacyPoints() >= 5 && !CFG.game.getCivsAtWar(n, n2)) {
            float f = DiplomacyManager.getImproveRelation(n, n2);
            float f2 = DiplomacyManager.getImproveRelation(n2, n);
            if (CFG.game.getCivRelation_OfCivB(n, n2) < 44.0f) {
                bl = true;
            }
            CFG.game.setCivRelation_OfCivB(n, n2, CFG.game.getCivRelation_OfCivB(n, n2) + f2 * 0.9175f);
            CFG.game.setCivRelation_OfCivB(n2, n, CFG.game.getCivRelation_OfCivB(n2, n) + f);
            if (bl) {
                DiplomacyManager.updateFriendlyCiv(n, n2);
            }
            return true;
        }
        return false;
    }

    protected static final boolean invest(int n, int n2, int n3) {
        if (CFG.game.getProvince(n).getCivID() == n2 && CFG.game.getCiv(n2).getMovePoints() >= 12) {
            int n4 = n3;
            if (CFG.game.getCiv(n2).getMoney() < (long)n3) {
                n4 = (int)CFG.game.getCiv(n2).getMoney();
            }
            if (n4 > 0 && (n3 = DiplomacyManager.invest_EconomyByGold(n, n4)) > 0) {
                int n5 = Math.max(n3 / 10, 1);
                if (CFG.game.getCiv(n2).addInvest(new CivInvest(n, 10, n3, n5))) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 12);
                    CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)n4);
                    return true;
                }
            }
        }
        return false;
    }

    protected static final boolean investDevelopment(int n, int n2, int n3) {
        if (CFG.game.getProvince(n).getCivID() == n2 && CFG.game.getCiv(n2).getMovePoints() >= 8) {
            float f;
            int n4 = n3;
            if (CFG.game.getCiv(n2).getMoney() < (long)n3) {
                n4 = (int)CFG.game.getCiv(n2).getMoney();
            }
            if (n4 > 0 && (f = DiplomacyManager.invest_DevelopmentByGold(n, n4)) > 0.0f) {
                float f2 = Math.max(f / 10.0f, 1.0E-5f);
                if (CFG.game.getCiv(n2).addInvest_Development(new CivInvest_Development(n, 10, f, f2))) {
                    CFG.game.getCiv(n2).setMovePoints(CFG.game.getCiv(n2).getMovePoints() - 8);
                    CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)n4);
                    return true;
                }
            }
        }
        return false;
    }

    protected static final float invest_DevelopmentByGold(int n, int n2) {
        return (float)n2 / ((float)CFG.game.getGameScenarios().getScenario_StartingPopulation() * 1.075f) * (CFG.gameAges.getAge_Economy_GrowthRate(Game_Calendar.CURRENT_AGEID) * 100.0f * 0.625f + 0.375f);
    }

    protected static final int invest_EconomyByGold(int n, int n2) {
        return (int)((float)n2 / 3.5f * (Math.min(1.0f, CFG.game.getProvince(n).getDevelopmentLevel() * 1.75f) * 0.125f + 0.875f) * (CFG.gameAges.getAge_Economy_GrowthRate(Game_Calendar.CURRENT_AGEID) * 0.625f * 10.0f + 0.375f));
    }

    protected static final int invest_MaxDevelopment_Gold(int n, int n2) {
        return (int)Math.max(Math.min(Math.min(CFG.game.getCiv(n2).getTechnologyLevel() + 0.01f - CFG.game.getProvince(n).getDevelopmentLevel(), Math.max(CFG.game.getProvince(n).getDevelopmentLevel(), 0.1f) * 0.725f) * ((float)CFG.game.getGameScenarios().getScenario_StartingPopulation() * 1.075f * (CFG.gameAges.getAge_Economy_GrowthRate(Game_Calendar.CURRENT_AGEID) * 100.0f * 100.0f + 0.375f)), (float)CFG.game.getCiv(n2).getMoney()), 0.0f);
    }

    protected static final int invest_MaxEconomy(int n, int n2) {
        return (int)Math.min((float)CFG.game.getProvince(n).getEconomy() * 0.375f, (float)CFG.game.getProvince(n).getPopulationData().getPopulation() * 0.26854f);
    }

    protected static final int invest_MaxEconomy_Gold(int n, int n2) {
        return Math.max((int)Math.min(Math.min((float)CFG.game.getProvince(n).getEconomy() * 0.325f, (float)CFG.game.getProvince(n).getPopulationData().getPopulation() * 0.265f) * (CFG.game.getProvince(n).getDevelopmentLevel() * 0.35f + 100.0f) * 6.75f, (float)CFG.game.getCiv(n2).getMoney()), 0);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final boolean isBorderedWith_IncludeSea(int n, int n2) {
        boolean bl = false;
        Civilization civilization = CFG.game.getCiv(n);
        Civilization civilization2 = CFG.game.getCiv(n2);
        if (civilization.getBordersWithCiv(n2)) return true;
        boolean bl2 = bl;
        if (civilization.getSeaAccess() <= 0) return bl2;
        if (civilization2.getSeaAccess() > 0) return true;
        return bl;
    }

    protected static final void joinAWar(int n, int n2, int n3) {
        int n4 = CFG.game.getWarID(n2, n3);
        CFG.game.joinWar(n, n3, n4);
        if (CFG.game.getCivsAtWar(n, n3)) {
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_AllyJoinedAWar(n, n3, n2));
            CFG.game.setCivRelation_OfCivB(n, n2, CFG.game.getCivRelation_OfCivB(n, n2) + 5.0f);
            CFG.game.setCivRelation_OfCivB(n2, n, CFG.game.getCivRelation_OfCivB(n2, n) + 5.0f);
        }
    }

    protected static final void kickFromAlliance(int n, int n2) {
        if (CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getCiv(n).getAllianceID() < CFG.game.getAlliancesSize() && CFG.game.getCiv(n).getAllianceID() == CFG.game.getCiv(n2).getAllianceID()) {
            int n3;
            int n4;
            int n5;
            int n6;
            int n7 = CFG.game.getCiv(n).getAllianceID();
            CFG.game.getAlliance(n7).removeCivilization(n);
            Object object = CFG.game.getCiv(n);
            int n8 = 0;
            ((Civilization)object).setAllianceID(0);
            for (n6 = 0; n6 < CFG.game.getAlliance(n7).getCivilizationsSize(); ++n6) {
                if (!CFG.game.getCiv(CFG.game.getAlliance(n7).getCivilization(n6)).getControlledByPlayer()) continue;
                if (CFG.game.getAlliance(n7).getCivilization(n6) == n && (n5 = CFG.game.getPlayerID_ByCivID(n)) >= 0) {
                    for (n4 = 0; n4 < CFG.game.getCiv(n2).getNumOfProvinces(); ++n4) {
                        CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n4)).updateFogOfWar(n5);
                    }
                    for (n4 = 0; n4 < CFG.game.getCiv((int)n2).civGameData.lVassals.size(); ++n4) {
                        for (n3 = 0; n3 < CFG.game.getCiv(CFG.game.getCiv((int)n2).civGameData.lVassals.get((int)n4).iCivID).getNumOfProvinces(); ++n3) {
                            CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n2).civGameData.lVassals.get((int)n4).iCivID).getProvinceID(n4)).updateFogOfWar(n5);
                        }
                    }
                }
                if (CFG.game.getAlliance(n7).getCivilization(n6) != n || (n5 = CFG.game.getPlayerID_ByCivID(n)) < 0) continue;
                for (n4 = 0; n4 < CFG.game.getCiv(n).getNumOfProvinces(); ++n4) {
                    CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n4)).updateFogOfWar(n5);
                }
                for (n4 = 0; n4 < CFG.game.getCiv((int)n).civGameData.lVassals.size(); ++n4) {
                    for (n3 = 0; n3 < CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n4).iCivID).getNumOfProvinces(); ++n3) {
                        CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n4).iCivID).getProvinceID(n4)).updateFogOfWar(n5);
                    }
                }
            }
            for (n6 = 0; n6 < CFG.game.getAlliance(n7).getCivilizationsSize(); ++n6) {
                if (!CFG.game.getCiv(CFG.game.getAlliance(n7).getCivilization(n6)).getControlledByPlayer() || (n5 = CFG.game.getPlayerID_ByCivID(CFG.game.getAlliance(n7).getCivilization(n6))) < 0) continue;
                for (n4 = 0; n4 < CFG.game.getCiv(n).getNumOfProvinces(); ++n4) {
                    CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n4)).updateFogOfWar(n5);
                }
                for (n4 = 0; n4 < CFG.game.getCiv((int)n).civGameData.lVassals.size(); ++n4) {
                    for (n3 = 0; n3 < CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n4).iCivID).getNumOfProvinces(); ++n3) {
                        CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n4).iCivID).getProvinceID(n4)).updateFogOfWar(n5);
                    }
                }
            }
            object = CFG.game;
            float f = CFG.game.getCivRelation_OfCivB(n, n2);
            float f2 = -99.0f;
            f = f > -100.0f && CFG.game.getCivRelation_OfCivB(n, n2) + (float)-25 <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n, n2) + (float)-25;
            ((Game)object).setCivRelation_OfCivB(n, n2, f);
            object = CFG.game;
            f = CFG.game.getCivRelation_OfCivB(n2, n) > -100.0f && CFG.game.getCivRelation_OfCivB(n2, n) + (float)-25 <= -100.0f ? f2 : CFG.game.getCivRelation_OfCivB(n2, n) + (float)-25;
            ((Game)object).setCivRelation_OfCivB(n2, n, f);
            for (n2 = n8; n2 < CFG.game.getAlliance(n7).getCivilizationsSize(); ++n2) {
                CFG.game.getCiv((int)CFG.game.getAlliance((int)n7).getCivilization((int)n2)).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_LeftAlliance(n, n7));
            }
            CFG.historyManager.addHistoryLog(new HistoryLog_LeavesAlliance(n, n7));
        }
    }

    protected static final void leaveAlliance(int n) {
        if (CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getCiv(n).getAllianceID() < CFG.game.getAlliancesSize()) {
            int n2;
            int n3 = CFG.game.getCiv(n).getAllianceID();
            CFG.game.getAlliance(n3).removeCivilization(n);
            Object object = CFG.game.getCiv(n);
            int n4 = 0;
            ((Civilization)object).setAllianceID(0);
            int n5 = n4;
            if (CFG.game.getCiv(n).getControlledByPlayer()) {
                int n6 = CFG.game.getPlayerID_ByCivID(n);
                n2 = 0;
                while (true) {
                    int n7;
                    int n8;
                    n5 = n4;
                    if (n2 >= CFG.game.getAlliance(n3).getCivilizationsSize()) break;
                    if (CFG.game.getCiv(CFG.game.getAlliance(n3).getCivilization(n2)).getControlledByPlayer() && (n8 = CFG.game.getPlayerID_ByCivID(CFG.game.getAlliance(n3).getCivilization(n2))) >= 0) {
                        for (n5 = 0; n5 < CFG.game.getCiv(n).getNumOfProvinces(); ++n5) {
                            CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n5)).updateFogOfWar(n8);
                        }
                        for (n5 = 0; n5 < CFG.game.getCiv((int)n).civGameData.lVassals.size(); ++n5) {
                            for (n7 = 0; n7 < CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n5).iCivID).getNumOfProvinces(); ++n7) {
                                CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)n).civGameData.lVassals.get((int)n5).iCivID).getProvinceID(n5)).updateFogOfWar(n8);
                            }
                        }
                    }
                    if (n6 >= 0) {
                        for (n5 = 0; n5 < CFG.game.getCiv(CFG.game.getAlliance(n3).getCivilization(n2)).getNumOfProvinces(); ++n5) {
                            CFG.game.getProvince(CFG.game.getCiv(CFG.game.getAlliance(n3).getCivilization(n2)).getProvinceID(n5)).updateFogOfWar(n6);
                        }
                        for (n5 = 0; n5 < CFG.game.getCiv((int)CFG.game.getAlliance((int)n3).getCivilization((int)n2)).civGameData.lVassals.size(); ++n5) {
                            for (n7 = 0; n7 < CFG.game.getCiv(CFG.game.getCiv((int)CFG.game.getAlliance((int)n3).getCivilization((int)n2)).civGameData.lVassals.get((int)n5).iCivID).getNumOfProvinces(); ++n7) {
                                CFG.game.getProvince(CFG.game.getCiv(CFG.game.getCiv((int)CFG.game.getAlliance((int)n3).getCivilization((int)n2)).civGameData.lVassals.get((int)n5).iCivID).getProvinceID(n5)).updateFogOfWar(n6);
                            }
                        }
                    }
                    ++n2;
                }
            }
            while (n5 < CFG.game.getAlliance(n3).getCivilizationsSize()) {
                object = CFG.game;
                n2 = CFG.game.getAlliance(n3).getCivilization(n5);
                float f = CFG.game.getCivRelation_OfCivB(n, CFG.game.getAlliance(n3).getCivilization(n5));
                float f2 = -99.0f;
                f = f > -100.0f && CFG.game.getCivRelation_OfCivB(n, CFG.game.getAlliance(n3).getCivilization(n5)) + (float)-10 <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(n, CFG.game.getAlliance(n3).getCivilization(n5)) + (float)-10;
                ((Game)object).setCivRelation_OfCivB(n, n2, f);
                object = CFG.game;
                n2 = CFG.game.getAlliance(n3).getCivilization(n5);
                f = CFG.game.getCivRelation_OfCivB(CFG.game.getAlliance(n3).getCivilization(n5), n) > -100.0f && CFG.game.getCivRelation_OfCivB(CFG.game.getAlliance(n3).getCivilization(n5), n) + (float)-10 <= -100.0f ? f2 : CFG.game.getCivRelation_OfCivB(CFG.game.getAlliance(n3).getCivilization(n5), n) + (float)-10;
                ((Game)object).setCivRelation_OfCivB(n2, n, f);
                CFG.game.getCiv((int)CFG.game.getAlliance((int)n3).getCivilization((int)n5)).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_LeftAlliance(n, n3));
                ++n5;
            }
            CFG.historyManager.addHistoryLog(new HistoryLog_LeavesAlliance(n, n3));
        }
    }

    protected static final void liberateAVassal(int n, int n2) {
        if (CFG.game.getCiv(n2).getPuppetOfCivID() == n) {
            CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
            if (CFG.game.getMilitaryAccess(n, n2) <= 0) {
                CFG.gameAction.accessLost_UpdateArmies(n2, n);
            }
            if (CFG.game.getMilitaryAccess(n2, n) <= 0) {
                CFG.gameAction.accessLost_UpdateArmies(n, n2);
            }
            if (CFG.FOG_OF_WAR > 0) {
                if (CFG.game.getPlayerID_ByCivID(n) >= 0) {
                    CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n));
                }
                if (CFG.game.getPlayerID_ByCivID(n2) >= 0) {
                    CFG.gameAction.buildFogOfWar(CFG.game.getPlayerID_ByCivID(n2));
                }
            }
            CFG.historyManager.addHistoryLog(new HistoryLog_IsNotVassal(n, n2));
            CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Liberation(n));
            if (!CFG.game.getCiv(n).getControlledByPlayer()) {
                CFG.game.getCiv(n).addSentMessages(new Civilization_SentMessages(n2, Message_Type.LIBERATION_OF_VASSAL));
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final void plunder(int n, int n2, int n3) {
        if (CFG.game.getProvince(n2).getIsSupplied() == n) {
            return;
        }
        int n4 = DiplomacyManager.plunderTreasuryIncome(n, n2, n3);
        float f = DiplomacyManager.plunder_Happiness(n, n2, n3);
        int n5 = (int)(4.0 + Math.ceil((float)CFG.game.getProvince(n2).getEconomy() * DiplomacyManager.plunder_LossesEconomy_Perc(n, n2, n3)));
        float f2 = CFG.game.getProvince(n2).getDevelopmentLevel() * DiplomacyManager.plunder_LossesDevelopment_Perc(n, n2, n3);
        float f3 = DiplomacyManager.plunder_RevolutionaryRisk(n, n2, n3);
        int n6 = DiplomacyManager.plunder_Population(n, n2, n3);
        int n7 = CFG.game.getProvince(n2).getPopulationData().getPopulation();
        n3 = CFG.game.getProvince(n2).getEconomy();
        CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() + (long)n4);
        CFG.game.getProvince(n2).setEconomy(CFG.game.getProvince(n2).getEconomy() - n5);
        CFG.game.getProvince(n2).setDevelopmentLevel(CFG.game.getProvince(n2).getDevelopmentLevel() - f2);
        CFG.game.getProvince(n2).setHappiness(CFG.game.getProvince(n2).getHappiness() - f);
        CFG.game.getProvince(n2).setRevolutionaryRisk(CFG.game.getProvince(n2).getRevolutionaryRisk() + CFG.gameAges.getAge_RevolutionaryRiskModifier(Game_Calendar.CURRENT_AGEID) * f3);
        CFG.gameAction.updatePopulationLosses(n2, n6);
        int n8 = CFG.game.getWarID(n, CFG.game.getProvince(n2).getTrueOwnerOfProvince());
        if (n8 >= 0) {
            CFG.game.updateWarStatistics(n8, n, CFG.game.getProvince(n2).getTrueOwnerOfProvince(), Math.max(n7 - CFG.game.getProvince(n2).getPopulationData().getPopulation(), 0), Math.max(n3 - CFG.game.getProvince(n2).getEconomy(), 0));
        }
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Plunder(n, n2, n4, n5, f2, f, n6));
        if (!CFG.game.getCiv(CFG.game.getProvince(n2).getTrueOwnerOfProvince()).getControlledByPlayer()) return;
        CFG.game.getCiv((int)CFG.game.getProvince((int)n2).getTrueOwnerOfProvince()).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Plunder_Plundred(n, n2, n5, f2, f, n6));
    }

    protected static final float plunderEfficiency(int n, int n2, int n3) {
        return Math.min(1.0f, (float)n3 / DiplomacyManager.plunderEfficiency_RequiredMAX(n, n2));
    }

    protected static final float plunderEfficiency_RequiredMAX(int n, int n2) {
        return (float)CFG.game.getProvince(n2).getPopulationData().getPopulation() * (0.1375f - Math.min(CFG.game.getCiv(n).getTechnologyLevel(), 1.0f) * 0.035f);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final void plunderProvince(int n, int n2, int n3) {
        int n4;
        if (CFG.game.getCiv(n).getMovePoints() < CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_PLUNDER) {
            return;
        }
        if (n2 < 0) return;
        if (!CFG.game.getProvince(n2).getIsSupplied()) return;
        if (CFG.game.getProvince(n2).getSeaProvince()) return;
        int n5 = 0;
        int n6 = 0;
        while (true) {
            n4 = n5;
            if (n6 >= CFG.game.getCiv(n).getMoveUnitsPlunderSize()) break;
            if (CFG.game.getCiv(n).getMoveUnits_Plunder(n6).getFromProvinceID() == n2) {
                n4 = n5 = CFG.game.getCiv(n).getMoveUnits_Plunder(n6).getNumOfUnits();
                if (n3 != 0) break;
                CFG.game.getCiv(n).removePlunder(n6);
                CFG.game.getProvince(n2).updateArmy(n, CFG.game.getProvince(n2).getArmyCivID(n) + n5);
                if (n5 <= 0) return;
                CFG.game.getCiv(n).setMovePoints(CFG.game.getCiv(n).getMovePoints() + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_PLUNDER);
                return;
            }
            ++n6;
        }
        n6 = n3;
        if (n3 > CFG.game.getProvince(n2).getArmyCivID(n) + n4) {
            n6 = CFG.game.getProvince(n2).getArmyCivID(n) + n4;
        }
        if (n6 <= 0) return;
        CFG.game.getCiv(n).newPlunder(n2, n6);
        CFG.game.getProvince(n2).updateArmy(n, CFG.game.getProvince(n2).getArmyCivID(n) + n4 - n6);
        if (n4 != 0) return;
        CFG.game.getCiv(n).setMovePoints(CFG.game.getCiv(n).getMovePoints() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_PLUNDER);
    }

    protected static final int plunderProvinceIncome(int n, int n2, int n3) {
        return (int)(CFG.game_NextTurnUpdate.getProvinceIncome_Taxation(n2) + CFG.game_NextTurnUpdate.getProvinceIncome_Production(n2));
    }

    protected static final int plunderTreasuryIncome(int n, int n2, int n3) {
        return (int)((float)DiplomacyManager.plunderProvinceIncome(n, n2, n3) * 26.25f * DiplomacyManager.plunderEfficiency(n, n2, n3) * (1.0f - CFG.game.getProvince(n2).getRevolutionaryRisk() * 0.375f));
    }

    protected static final float plunder_Happiness(int n, int n2, int n3) {
        return ((float)CFG.oR.nextInt(426) / 10000.0f + 0.0425f) * DiplomacyManager.plunderEfficiency(n, n2, n3);
    }

    protected static final float plunder_LossesDevelopment_Perc(int n, int n2, int n3) {
        return ((float)CFG.oR.nextInt(625) / 10000.0f + 0.0425f) * DiplomacyManager.plunderEfficiency(n, n2, n3);
    }

    protected static final float plunder_LossesEconomy_Perc(int n, int n2, int n3) {
        return ((float)CFG.oR.nextInt(525) / 10000.0f + 0.0425f) * DiplomacyManager.plunderEfficiency(n, n2, n3);
    }

    protected static final int plunder_Population(int n, int n2, int n3) {
        return (int)Math.min((float)n3 * ((float)CFG.oR.nextInt(412) / 10000.0f + 0.2f), (float)CFG.game.getProvince(n2).getPopulationData().getPopulation() * 0.2f);
    }

    protected static final float plunder_RevolutionaryRisk(int n, int n2, int n3) {
        return Math.max(((float)CFG.oR.nextInt(268) / 10000.0f + 0.011861f) * DiplomacyManager.plunderEfficiency(n, n2, n3), 0.034378f);
    }

    protected static final void refuseUltimatum(int n, int n2, Ultimatum_GameData ultimatum_GameData) {
        if (CFG.game.getCiv(n2).getPuppetOfCivID() == n) {
            CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
        }
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_UltimatumRefused(n2));
    }

    protected static final void refuseUltimatum_AcceptWar(int n, int n2) {
        Game game = CFG.game;
        if (CFG.game.getCiv(n2).getPuppetOfCivID() == n) {
            CFG.game.getCiv(n2).setPuppetOfCivID(n2, false);
        }
        game.declareWar(n, n2, false);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected static final void repayLoan(int n, int n2) {
        try {
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)(CFG.game.getCiv((int)n).getLoan((int)n2).iTurnsLeft * CFG.game.getCiv((int)n).getLoan((int)n2).iGoldPerTurn));
            CFG.game.getCiv(n).removeLoan(n2);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    protected static void runRelationsOutDated() {
        for (int i = Game_Calendar.TURN_ID % 6; i < CFG.game.getCivsSize(); i += 6) {
            if (CFG.game.getCiv(i).getNumOfProvinces() <= 0) continue;
            for (int j = 1; j < CFG.game.getCivsSize(); ++j) {
                if (CFG.game.getCiv(j).getNumOfProvinces() <= 0) continue;
                if (CFG.game.getCivRelation_OfCivB(i, j) > 15.0f) {
                    CFG.game.setCivRelation_OfCivB(i, j, CFG.game.getCivRelation_OfCivB(i, j) - 0.625f);
                    continue;
                }
                if (!(CFG.game.getCivRelation_OfCivB(i, j) < -20.0f)) continue;
                CFG.game.setCivRelation_OfCivB(i, j, CFG.game.getCivRelation_OfCivB(i, j) + 0.535f);
            }
        }
    }

    protected static final void sendAllianceProposal(int n, int n2) {
        if (CFG.game.getCiv(n).getAllianceID() > 0 && CFG.game.getAlliance(CFG.game.getCiv(n).getAllianceID()).getCivilizationsSize() > 0) {
            CFG.game.getCiv((int)CFG.game.getAlliance((int)CFG.game.getCiv((int)n).getAllianceID()).getCivilization((int)0)).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message(n2, 0));
        } else {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message(n2, 0));
        }
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 20);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.JOIN_ALLIANCE));
        }
    }

    protected static final void sendCallToArms(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_CallToArms(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() + 0);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.WAR_DECLARED_ON_ALLY));
        }
    }

    protected static final void sendDefensivePactProposal(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_DefensivePact(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 10);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.DEFENSIVEPACT));
        }
    }

    protected static final void sendGift(int n, int n2, int n3) {
        int n4 = n3;
        if ((float)CFG.game.getCiv(n2).getMoney() * 1.0f < (float)n3) {
            n4 = (int)Math.max(0.0f, (float)CFG.game.getCiv(n2).getMoney() * 1.0f);
        }
        if (n4 > 0) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Gift(n2, n4));
            CFG.game.getCiv(n2).setMoney(CFG.game.getCiv(n2).getMoney() - (long)n4);
            CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 8);
            if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
                CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.GIFT));
            }
        }
    }

    protected static final void sendGuaranteeIndependence_AskProposal(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Independence_Ask(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 10);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.GUARANTEE_ASK));
        }
    }

    protected static void sendLowHappiness() {
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            int n;
            block3: {
                if (CFG.game.getCiv(i).getNumOfProvinces() < 0) continue;
                if (CFG.game.getCiv(i).getHappiness() < 50) {
                    CFG.game.getCiv((int)i).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_LowHappiness(i, 0));
                }
                if (CFG.game.getCiv((int)i).lProvincesWithLowStability.size() <= 0) continue;
                for (n = CFG.game.getCiv((int)i).lProvincesWithLowStability.size() - 1; n >= 0; --n) {
                    if (!(CFG.game.getProvince(CFG.game.getCiv((int)i).lProvincesWithLowStability.get(n)).getProvinceStability() < 75.0f)) continue;
                    n = 1;
                    break block3;
                }
                n = 0;
            }
            if (n == 0) continue;
            CFG.game.getCiv((int)i).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_LowStability(i, 0));
        }
    }

    protected static final void sendMilitaryAccess_AskProposal(int n, int n2, int n3) {
        if (CFG.game.getCiv(n2).getDiplomacyPoints() >= 10) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_MilitaryAccess_Ask(n2, n3));
            CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 10);
            if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
                CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.MILITARY_ACCESS_ASK));
            }
        }
    }

    protected static final void sendMilitaryAccess_GiveProposal(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_MilitaryAccess_Give(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 4);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.MILITARY_ACCESS_GIVE));
        }
    }

    protected static final void sendNonAggressionProposal(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_NonAggressionPact(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 8);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.NONAGGRESSIONPACT));
        }
    }

    protected static final void sendOfferVasalizationProposal(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_OfferVasalization(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 16);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.OFFERVASALIZATION));
        }
    }

    protected static final void sendPeaceTreaty(boolean bl, int n, PeaceTreaty_GameData peaceTreaty_GameData) {
        block9: {
            Serializable serializable;
            int n2;
            int n3;
            int n4;
            Object object;
            Object object2;
            try {
                CFG.peaceTreatyData.preparePeaceTreatyToSend(n);
                object2 = CFG.game.lPeaceTreaties;
                object = new PeaceTreaty_GameData_MessageData(peaceTreaty_GameData);
                object2.add((PeaceTreaty_GameData_MessageData)object);
                object = CFG.game.lPeaceTreaties.get((int)(CFG.game.lPeaceTreaties.size() - 1)).PEACE_TREATY_TAG;
                n4 = 0;
                n3 = 0;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (!CFG.LOGS) break block9;
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            while (true) {
                n2 = n4;
                if (n3 >= peaceTreaty_GameData.lCivsDemands_Defenders.size()) break;
                if (!peaceTreaty_GameData.lCivsDemands_Defenders.get((int)n3).peaceTreatyAccepted) {
                    object2 = CFG.game.getCiv((int)peaceTreaty_GameData.lCivsDemands_Defenders.get((int)n3).iCivID).getCivilization_Diplomacy_GameData().messageBox;
                    serializable = new Message_PeaceTreaty(n, (String)object);
                    ((MessageBox_GameData)object2).addMessage((Message)serializable);
                }
                ++n3;
                continue;
                break;
            }
            while (true) {
                if (n2 < peaceTreaty_GameData.lCivsDemands_Aggressors.size()) {
                    if (!peaceTreaty_GameData.lCivsDemands_Aggressors.get((int)n2).peaceTreatyAccepted) {
                        serializable = CFG.game.getCiv((int)peaceTreaty_GameData.lCivsDemands_Aggressors.get((int)n2).iCivID).getCivilization_Diplomacy_GameData().messageBox;
                        object2 = new Message_PeaceTreaty(n, (String)object);
                        ((MessageBox_GameData)serializable).addMessage((Message)object2);
                    }
                    ++n2;
                    continue;
                }
                break;
            }
        }
    }

    protected static final void sendPrepareForWar(int n, int n2, int n3, int n4, int n5) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_PrepareForWar(n2, n3, Game_Calendar.TURN_ID + n4, n5));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() + 0);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.PREPARE_FOR_WAR));
        }
    }

    protected static void sendTechPointsMessages() {
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            if (CFG.game.getCiv(i).getNumOfProvinces() <= 0) continue;
            if (CFG.game.getCiv((int)i).civGameData.skills.getPointsLeft(i) > 0) {
                CFG.game.getCiv((int)i).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TechPoints(i));
            }
            CFG.game.getCiv((int)i).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_OpenBudget(i));
        }
    }

    protected static final boolean sendTradeRequest(int n, int n2, TradeRequest_GameData tradeRequest_GameData) {
        if (CFG.game.getCiv(n2).getDiplomacyPoints() >= 10) {
            CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TradeReuest(n2, tradeRequest_GameData));
            CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 10);
            if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
                CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.TRADE_REQUEST));
            }
            return true;
        }
        return false;
    }

    protected static final void sendTransferControl(int n, int n2, int n3) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_TransferControl(n2, n3));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() + 0);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.TRANSFER_CONTROL));
        }
    }

    protected static final boolean sendUltimatum(int n, int n2, Ultimatum_GameData ultimatum_GameData, int n3) {
        block6: {
            block5: {
                if (CFG.game.getCivRelation_OfCivB(n, n2) > 50.0f) {
                    return false;
                }
                if (CFG.game.getCiv(n).getPuppetOfCivID() != n && CFG.game.getCiv(n).getPuppetOfCivID() != n2) break block5;
                if (CFG.game.getCiv(n2).getDiplomacyPoints() < 24) break block6;
                CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Ultimatum(n2, ultimatum_GameData, n3));
                CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 24);
            }
            if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
                CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.ULTIMATUM));
            }
            return true;
        }
        return false;
    }

    protected static void sendUncivilizedMessages() {
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            if (!CFG.game.getCiv(i).getControlledByPlayer() || CFG.game.getCiv(i).getNumOfProvinces() <= 0 || CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)i).getIdeologyID()).CAN_BECOME_CIVILIZED < 0) continue;
            CFG.game.getCiv((int)i).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Uncivilized(i));
        }
    }

    protected static final void sendUnionProposal(int n, int n2) {
        CFG.game.getCiv((int)n).getCivilization_Diplomacy_GameData().messageBox.addMessage(new Message_Union(n2, 0));
        CFG.game.getCiv(n2).setDiplomacyPoints(CFG.game.getCiv(n2).getDiplomacyPoints() - 22);
        if (!CFG.game.getCiv(n2).getControlledByPlayer()) {
            CFG.game.getCiv(n2).addSentMessages(new Civilization_SentMessages(n, Message_Type.UNION));
        }
    }

    protected static final SupportRebels_Data supportRebels(int n) {
        SupportRebels_Data supportRebels_Data = new SupportRebels_Data();
        for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            for (int j = 0; j < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivsSize(); ++j) {
                int n2;
                block3: {
                    if (CFG.game.getCiv(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j)).getNumOfProvinces() > 0) continue;
                    for (n2 = 0; n2 < supportRebels_Data.lMovements.size(); ++n2) {
                        if (supportRebels_Data.lMovements.get(n2).intValue() != CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j)) continue;
                        supportRebels_Data.lPopulation.set(n2, supportRebels_Data.lPopulation.get(n2) + CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getPopulationData().getPopulationOfCivID(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j)));
                        supportRebels_Data.lUnrest.set(n2, supportRebels_Data.lUnrest.get(n2) + (int)(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getRevolutionaryRisk() * 100.0f));
                        supportRebels_Data.lProvinces.set(n2, supportRebels_Data.lProvinces.get(n2) + 1);
                        n2 = 0;
                        break block3;
                    }
                    n2 = 1;
                }
                if (n2 == 0) continue;
                supportRebels_Data.lMovements.add(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j));
                supportRebels_Data.lPopulation.add(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getPopulationData().getPopulationOfCivID(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j)));
                supportRebels_Data.lUnrest.add((int)(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getRevolutionaryRisk() * 100.0f));
                supportRebels_Data.lProvinces.add(1);
            }
        }
        return supportRebels_Data;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final boolean supportRebels(int n, int n2, int n3, int n4) {
        Object object;
        int n5;
        int n6;
        int n7 = n4;
        if (CFG.game.getCiv(n).getMoney() < (long)n4) {
            n7 = (int)CFG.game.getCiv(n).getMoney();
        }
        int n8 = 0;
        if (n7 <= 0) {
            return false;
        }
        if (CFG.game.getCiv(n).getDiplomacyPoints() < 34) {
            return false;
        }
        CFG.game.getCiv(n).setDiplomacyPoints(CFG.game.getCiv(n).getDiplomacyPoints() - 34);
        CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() - (long)n7);
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
        ArrayList<Integer> arrayList3 = new ArrayList<Integer>();
        n4 = 0;
        for (n6 = 0; n6 < CFG.game.getCiv(n2).getNumOfProvinces(); ++n6) {
            n5 = n4;
            if (CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n6)).getCore().getHaveACore(n3)) {
                arrayList.add(CFG.game.getCiv(n2).getProvinceID(n6));
                arrayList2.add(CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n6)).getPopulationData().getPopulationOfCivID(n3) + 1);
                arrayList3.add((int)((float)DiplomacyManager.assimilateCost(CFG.game.getCiv(n2).getProvinceID(n6), 1) * 1.6275f));
                n5 = n4 + (CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n6)).getPopulationData().getPopulationOfCivID(n3) + 1);
            }
            n4 = n5;
        }
        try {
            object = CFG.game.getCiv((int)n2).getCivilization_Diplomacy_GameData().messageBox;
            Message_RebelsSupported message_RebelsSupported = new Message_RebelsSupported(n3, (Integer)arrayList.get(0));
            ((MessageBox_GameData)object).addMessage(message_RebelsSupported);
            n5 = n4;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            n5 = n4;
        }
        while (arrayList.size() > 0 && n7 > 0) {
            int n9;
            block15: {
                n6 = CFG.oR.nextInt(n5);
                for (n4 = 0; n4 < arrayList.size(); ++n4) {
                    if (n6 < 0 || n6 > (Integer)arrayList2.get(n4) + 0) {
                        continue;
                    }
                    break block15;
                }
                n4 = 0;
            }
            if (!(Math.floor(n7 / (Integer)arrayList3.get(n4)) > 0.0) || (n6 = (int)Math.floor(n7 / (Integer)arrayList3.get(n4))) <= 1) break;
            n6 = n9 = CFG.oR.nextInt(n6) + 1;
            if (n9 > 35) {
                n6 = 35;
            }
            object = CFG.game.getProvince((Integer)arrayList.get(n4)).addSupportRebels(new Province_SupportRebels(n, n3, n6));
            n7 = n6 = n7 - (Integer)arrayList3.get(n4) * ((Province_SupportRebels_Help)object).iTurns;
            if (!((Province_SupportRebels_Help)object).max) continue;
            n5 -= ((Integer)arrayList2.get(n4)).intValue();
            arrayList.remove(n4);
            arrayList2.remove(n4);
            arrayList3.remove(n4);
            n7 = n6;
        }
        arrayList.clear();
        arrayList2.clear();
        n5 = 0;
        for (n = 0; n < CFG.game.getCiv(n2).getNumOfProvinces(); ++n) {
            n4 = n5;
            if (CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n)).getPopulationData().getPopulationOfCivID(n3) > 0) {
                arrayList.add(CFG.game.getCiv(n2).getProvinceID(n));
                arrayList2.add(CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n)).getPopulationData().getPopulationOfCivID(n3));
                n4 = n5 + (Integer)arrayList2.get(arrayList2.size() - 1);
            }
            n5 = n4;
        }
        float f = (float)n7 / ((float)n5 * 0.11625f * 5.0f);
        n = n8;
        while (n < arrayList.size()) {
            float f2 = (float)((Integer)arrayList2.get(n)).intValue() / (float)CFG.game.getProvince((Integer)arrayList.get(n)).getPopulationData().getPopulation();
            CFG.game.getProvince((Integer)arrayList.get(n)).setRevolutionaryRisk(CFG.gameAges.getAge_RevolutionaryRiskModifier(Game_Calendar.CURRENT_AGEID) * CFG.game.getProvince((Integer)arrayList.get(n)).getRevolutionaryRisk() + 1.0f * f * f2 * (1.01f - CFG.game.getProvince((Integer)arrayList.get(n)).getHappiness()));
            ++n;
        }
        return true;
    }

    protected static final int supportRebels_MaxGold(List<Integer> list) {
        int n = list.size();
        int n2 = 1;
        for (int i = 0; i < n; ++i) {
            n2 += (int)((float)DiplomacyManager.assimilateCost(list.get(i), 35) * 1.6275f);
        }
        return n2 * 2;
    }

    protected static final List<Integer> supportRebels_Provinces(int n, int n2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        block0: for (int i = 0; i < CFG.game.getCiv(n).getNumOfProvinces(); ++i) {
            for (int j = 0; j < CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivsSize(); ++j) {
                if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(i)).getCore().getCivID(j) != n2) continue;
                arrayList.add(CFG.game.getCiv(n).getProvinceID(i));
                continue block0;
            }
        }
        return arrayList;
    }

    protected static final void takeLoan(int n, int n2, int n3) {
        if (DiplomacyManager.canTakeMoreLoans(n) && n2 > 0 && n3 >= 10 && n3 <= 100) {
            if (!DiplomacyManager.canTakeMoreLoans(n)) {
                return;
            }
            int n4 = n2;
            if (n2 > DiplomacyManager.takeLoan_MaxValue(n)) {
                n4 = DiplomacyManager.takeLoan_MaxValue(n);
            }
            CFG.game.getCiv(n).setMoney(CFG.game.getCiv(n).getMoney() + (long)n4);
            Civilization civilization = CFG.game.getCiv(n);
            float f = n4;
            civilization.addLoan((int)Math.max(Math.ceil((f + DiplomacyManager.takeLoan_InterestRate(n, n4, n3) * f / 100.0f) / (float)n3), 1.0), n3);
            CFG.game.getCiv(n).setMovePoints(CFG.game.getCiv(n).getMovePoints() - 22);
        }
    }

    protected static final float takeLoan_InterestRate(int n, int n2, int n3) {
        if (n2 == 0) {
            return 0.0f;
        }
        return (float)CFG.game.getCiv(n).getLoansSize() * 1.0f + 45.0f + ((float)CFG.game.getCiv(n).getLoansSize() / 10.0f + 15.0f) * (float)(n3 - 10) / 15.0f;
    }

    protected static final int takeLoan_MaxValue(int n) {
        return (int)Math.max((float)(CFG.game.getCiv((int)n).iIncomeTaxation + CFG.game.getCiv((int)n).iIncomeProduction) * 1.0f, 45.0f);
    }

    protected static final int takeLoan_MinValue() {
        return 100;
    }

    protected static final void updateFriendlyCiv(int n, int n2) {
        if (CFG.game.getCivRelation_OfCivB(n, n2) > 44.0f) {
            if (CFG.game.getCiv(n2).addFriendlyCiv(n)) {
                CFG.game.getCiv(n).removeHatedCiv(n2);
            }
        } else if (CFG.game.getCivRelation_OfCivB(n, n2) < -25.0f && CFG.game.getCiv(n).addHatedCiv(n2)) {
            CFG.game.getCiv(n2).removeFriendlyCiv(n);
        }
        if (CFG.game.getCivRelation_OfCivB(n2, n) > 44.0f) {
            if (CFG.game.getCiv(n).addFriendlyCiv(n2)) {
                CFG.game.getCiv(n2).removeHatedCiv(n);
            }
        } else if (CFG.game.getCivRelation_OfCivB(n2, n) < -25.0f && CFG.game.getCiv(n2).addHatedCiv(n)) {
            CFG.game.getCiv(n).removeFriendlyCiv(n2);
        }
    }

    protected static final void updateGoldenAge() {
        block38: {
            int n;
            int n2;
            int n3;
            int n4;
            block39: {
                block37: {
                    n4 = 1;
                    int n5 = 1;
                    n3 = 1;
                    int n6 = 1;
                    n2 = 1;
                    int n7 = 1;
                    for (n = 1; n < CFG.game.getCivsSize(); ++n) {
                        if (CFG.game.getCiv(n).getNumOfProvinces() <= 0) continue;
                        CFG.game.getCiv(n).setGoldenAge_Prosperity(CFG.game.getCiv(n).getGoldenAge_Prosperity() + (int)((CFG.game.getCiv(n).getSpendings_Goods() - CFG.ideologiesManager.getIdeology(CFG.game.getCiv(n).getIdeologyID()).getMin_Goods(n)) * 100.0f) + (int)((CFG.game.getCiv(n).getSpendings_Investments() - CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).MIN_INVESTMENTS) * 100.0f));
                        CFG.game.getCiv(n).setGoldenAge_Science(CFG.game.getCiv(n).getGoldenAge_Science() + (int)(CFG.game.getCiv(n).getSpendings_Research() * 100.0f));
                        CFG.game.getCiv(n).setGoldenAge_Military(CFG.game.getCiv(n).getGoldenAge_Military() + CFG.game_NextTurnUpdate.getMilitarySpendings(n, CFG.game.getCiv((int)n).iBudget));
                    }
                    if (Game_Calendar.TURN_ID % 30 != 10) break block37;
                    if (DiplomacyManager.getNumOfCivsInTheGame() > 7) {
                        int n8 = 0;
                        n = 0;
                        for (n4 = 1; n4 < CFG.game.getCivsSize(); ++n4) {
                            n2 = n8;
                            n3 = n;
                            if (CFG.game.getCiv(n4).getNumOfProvinces() > 0) {
                                n2 = n8 + CFG.game.getCiv(n4).getGoldenAge_Science();
                                n3 = n + 1;
                            }
                            n8 = n2;
                            n = n3;
                        }
                        float f = (float)Math.ceil((float)n8 / (float)Math.max(n, 1));
                        ArrayList<Integer> arrayList = new ArrayList<Integer>();
                        n4 = 0;
                        for (n = 1; n < CFG.game.getCivsSize(); ++n) {
                            n3 = n4;
                            if (CFG.game.getCiv(n).getNumOfProvinces() > 0) {
                                n3 = n4;
                                if ((float)CFG.game.getCiv(n).getGoldenAge_Science() >= f) {
                                    n3 = n4 + CFG.game.getCiv(n).getGoldenAge_Science();
                                    arrayList.add(n);
                                }
                            }
                            n4 = n3;
                        }
                        if (n4 > 0) {
                            n3 = CFG.oR.nextInt(n4);
                            n = 0;
                            for (n4 = 0; n4 < arrayList.size(); ++n4) {
                                if (n3 >= n && n3 < CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Science() + n) {
                                    DiplomacyManager.goldenAge_Science((Integer)arrayList.get(n4));
                                    CFG.game.getCiv((Integer)arrayList.get(n4)).setGoldenAge_Science(0);
                                    break;
                                }
                                n += CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Science();
                            }
                        }
                        arrayList.clear();
                        for (n = n7; n < CFG.game.getCivsSize(); ++n) {
                            CFG.game.getCiv(n).setGoldenAge_Science((int)((float)CFG.game.getCiv(n).getGoldenAge_Science() * 0.3f));
                        }
                    } else {
                        for (n = n4; n < CFG.game.getCivsSize(); ++n) {
                            CFG.game.getCiv(n).setGoldenAge_Science((int)((float)CFG.game.getCiv(n).getGoldenAge_Science() * 0.15f));
                        }
                    }
                    break block38;
                }
                if (Game_Calendar.TURN_ID % 50 != 15) break block39;
                if (DiplomacyManager.getNumOfCivsInTheGame() > 7) {
                    int n9 = 0;
                    n = 0;
                    for (n4 = 1; n4 < CFG.game.getCivsSize(); ++n4) {
                        n2 = n9;
                        n3 = n;
                        if (CFG.game.getCiv(n4).getNumOfProvinces() > 0) {
                            n2 = n9 + CFG.game.getCiv(n4).getGoldenAge_Military();
                            n3 = n + 1;
                        }
                        n9 = n2;
                        n = n3;
                    }
                    float f = (float)Math.ceil((float)n9 / (float)Math.max(n, 1));
                    ArrayList<Integer> arrayList = new ArrayList<Integer>();
                    n3 = 0;
                    for (n4 = 1; n4 < CFG.game.getCivsSize(); ++n4) {
                        n = n3;
                        if (CFG.game.getCiv(n4).getNumOfProvinces() > 0) {
                            n = n3;
                            if ((float)CFG.game.getCiv(n4).getGoldenAge_Military() >= f) {
                                n = n3 + CFG.game.getCiv(n4).getGoldenAge_Military();
                                arrayList.add(n4);
                            }
                        }
                        n3 = n;
                    }
                    if (n3 > 0) {
                        n3 = CFG.oR.nextInt(n3);
                        n = 0;
                        for (n4 = 0; n4 < arrayList.size(); ++n4) {
                            if (n3 >= n && n3 < CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Military() + n) {
                                DiplomacyManager.goldenAge_Military((Integer)arrayList.get(n4));
                                CFG.game.getCiv((Integer)arrayList.get(n4)).setGoldenAge_Military(0);
                                break;
                            }
                            n += CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Military();
                        }
                    }
                    arrayList.clear();
                    for (n = n5; n < CFG.game.getCivsSize(); ++n) {
                        CFG.game.getCiv(n).setGoldenAge_Military((int)((float)CFG.game.getCiv(n).getGoldenAge_Military() * 0.3f));
                    }
                } else {
                    for (n = n3; n < CFG.game.getCivsSize(); ++n) {
                        CFG.game.getCiv(n).setGoldenAge_Military((int)((float)CFG.game.getCiv(n).getGoldenAge_Military() * 0.15f));
                    }
                }
                break block38;
            }
            if (Game_Calendar.TURN_ID % 50 != 20) break block38;
            if (DiplomacyManager.getNumOfCivsInTheGame() > 7) {
                n2 = 0;
                n = 0;
                for (n3 = 1; n3 < CFG.game.getCivsSize(); ++n3) {
                    int n10 = n2;
                    n4 = n;
                    if (CFG.game.getCiv(n3).getNumOfProvinces() > 0) {
                        n10 = n2 + CFG.game.getCiv(n3).getGoldenAge_Prosperity();
                        n4 = n + 1;
                    }
                    n2 = n10;
                    n = n4;
                }
                float f = (float)Math.ceil((float)n2 / (float)Math.max(n, 1));
                ArrayList<Integer> arrayList = new ArrayList<Integer>();
                n = 0;
                for (n4 = 1; n4 < CFG.game.getCivsSize(); ++n4) {
                    n3 = n;
                    if (CFG.game.getCiv(n4).getNumOfProvinces() > 0) {
                        n3 = n;
                        if ((float)CFG.game.getCiv(n4).getGoldenAge_Prosperity() >= f) {
                            n3 = n + CFG.game.getCiv(n4).getGoldenAge_Prosperity();
                            arrayList.add(n4);
                        }
                    }
                    n = n3;
                }
                if (n > 0) {
                    n3 = CFG.oR.nextInt(n);
                    n = 0;
                    for (n4 = 0; n4 < arrayList.size(); ++n4) {
                        if (n3 >= n && n3 < CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Prosperity() + n) {
                            DiplomacyManager.goldenAge_Prosperity((Integer)arrayList.get(n4));
                            CFG.game.getCiv((Integer)arrayList.get(n4)).setGoldenAge_Prosperity(0);
                            break;
                        }
                        n += CFG.game.getCiv((Integer)arrayList.get(n4)).getGoldenAge_Prosperity();
                    }
                }
                arrayList.clear();
                for (n = n6; n < CFG.game.getCivsSize(); ++n) {
                    CFG.game.getCiv(n).setGoldenAge_Prosperity((int)((float)CFG.game.getCiv(n).getGoldenAge_Prosperity() * 0.15f));
                }
            } else {
                for (n = n2; n < CFG.game.getCivsSize(); ++n) {
                    CFG.game.getCiv(n).setGoldenAge_Prosperity((int)((float)CFG.game.getCiv(n).getGoldenAge_Prosperity() * 0.1f));
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void updatePlayersFriendlyCivs() {
        if (CFG.SPECTATOR_MODE) return;
        int n = 0;
        try {
            while (n < CFG.game.getPlayersSize()) {
                if (CFG.game.getCiv(CFG.game.getPlayer(n).getCivID()).getNumOfProvinces() > 0) {
                    for (int i = CFG.game.getCiv(CFG.game.getPlayer(n).getCivID()).getFriendlyCivsSize() - 1; i >= 0; --i) {
                        if (!(CFG.game.getCivRelation_OfCivB(CFG.game.getCiv((int)CFG.game.getPlayer((int)n).getCivID()).getFriendlyCiv((int)i).iCivID, CFG.game.getPlayer(n).getCivID()) < 39.0f)) continue;
                        CFG.game.getCiv(CFG.game.getPlayer(n).getCivID()).removeFriendlyCiv(CFG.game.getCiv((int)CFG.game.getPlayer((int)n).getCivID()).getFriendlyCiv((int)i).iCivID);
                    }
                }
                ++n;
            }
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    protected static final void vassalDeclareIndependence_Fine(int n, int n2) {
        CFG.game.acceptPeaceOffer(n, n2, 30);
    }

    protected static final void vassalDeclareIndependence_War(int n, int n2) {
        CFG.game.declareWar(n, n2, true);
    }

    protected static final void worldRecations(int n, int n2, int n3) {
        for (int i = 1; i < CFG.game.getCivsSize(); ++i) {
            if (CFG.game.getCiv(i).getNumOfProvinces() <= 0 || i == n2 || i == n3 || CFG.game.getCivsAtWar(i, n2)) continue;
            float f = CFG.game_NextTurnUpdate.getDistanceFromAToB_PercOfMax(CFG.game.getCiv(i).getCapitalProvinceID(), CFG.game.getCiv(n3).getCapitalProvinceID());
            float f2 = f < 0.375f ? (float)n / 20.0f * (1.5f - f) : 0.0f;
            float f3 = -f2 + (float)n * (-(CFG.game.getCivRelation_OfCivB(i, n3) + (float)(n / 5)) / 100.0f) * Math.max(1.5f - f * 1.35f, 0.01f);
            Game game = CFG.game;
            f2 = CFG.game.getCivRelation_OfCivB(i, n2);
            f = -99.0f;
            f2 = f2 > -100.0f && CFG.game.getCivRelation_OfCivB(i, n2) + f3 <= -100.0f ? -99.0f : CFG.game.getCivRelation_OfCivB(i, n2) + f3;
            game.setCivRelation_OfCivB(i, n2, f2);
            game = CFG.game;
            f2 = CFG.game.getCivRelation_OfCivB(n2, i) > -100.0f && CFG.game.getCivRelation_OfCivB(n2, i) + f3 <= -100.0f ? f : CFG.game.getCivRelation_OfCivB(n2, i) + f3;
            game.setCivRelation_OfCivB(n2, i, f2);
        }
    }
}

