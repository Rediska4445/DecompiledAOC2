/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civ_Mission_ChangeTypeOfGoverment;
import age.of.civilizations2.jakowski.lukasz.Civilization;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Save_Civ_GameData;
import java.io.Serializable;
import java.util.ArrayList;

class AI_Style_Communism
extends AI_Style {
    protected AI_Style_Communism() {
        this.TAG = "COMMUNISM";
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT = 0.14f;
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM = 15;
        this.PERSONALITY_MIN_HAPPINESS_DEFAULT = 56;
        this.PERSONALITY_MIN_HAPPINESS_RANDOM = 18;
        this.PERSONALITY_FORGIVNESS_DEFAULT = 0.6f;
        this.PERSONALITY_FORGIVNESS_RANDOM = 80;
    }

    @Override
    protected void buildStartingBuildings(int n) {
        block3: {
            super.buildStartingBuildings(n);
            try {
                if (CFG.game.getCiv(n).getCapitalProvinceID() >= 0 && CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getWorkshop_TechLevel(1) * 0.92f) {
                    CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfWorkshop(Math.max(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getLevelOfWorkshop(), 1));
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (!CFG.LOGS) break block3;
                CFG.exceptionStack(indexOutOfBoundsException);
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void sendGiftToFriendlyCiv(int n) {
        block7: {
            block6: {
                if (Game_Calendar.TURN_ID < CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID) break block6;
                if (!CFG.game.getCiv(n).isAtWar()) break block7;
                CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 10 + CFG.oR.nextInt(15);
            }
            return;
        }
        if (CFG.game.getCiv(n).getMoney() > 0L && CFG.game.getCiv((int)n).iBudget > 0) {
            if (CFG.game.getCiv(n).getFriendlyCivsSize() > 0) {
                DiplomacyManager.sendGift(CFG.game.getCiv((int)n).getFriendlyCiv((int)CFG.oR.nextInt((int)CFG.game.getCiv((int)n).getFriendlyCivsSize())).iCivID, n, (int)Math.ceil((float)CFG.game.getCiv((int)n).iBudget * (0.05f + (float)CFG.oR.nextInt(75) / 1000.0f)));
                CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 5 + CFG.oR.nextInt(8);
                return;
            }
            CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 10 + CFG.oR.nextInt(10);
            return;
        }
        CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 6 + CFG.oR.nextInt(8);
    }

    protected final void shouldChangeTypeOfGoverment(int n) {
        block7: {
            Object object;
            int n2;
            boolean bl;
            block9: {
                block8: {
                    if (CFG.game.getCiv(n).isAtWar()) break block7;
                    bl = false;
                    n2 = CFG.game.getCiv(n).getIdeologyID();
                    if (CFG.ideologiesManager.getIdeology((int)n2).ELECTION_PERIOD <= 0) break block8;
                    object = CFG.game.getCiv(n);
                    if (Game_Calendar.TURN_ID < ((Civilization)object).getNextElection()) break block7;
                    break block9;
                }
                bl = true;
                n2 = CFG.game.getCiv((int)n).civGameData.iChangeGoverment_SinceTurn;
                if (Game_Calendar.TURN_ID < n2 || CFG.game.getCiv(n).getInReformation() > 0 || CFG.game.getCiv(n).getSupportRate() >= 60.0f || CFG.game.getCiv(n).isAtWar()) break block7;
            }
            if (CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment == null) {
                object = CFG.ideologiesManager.canChangeToIdeology(n);
                Serializable serializable = new ArrayList<Integer>();
                for (n2 = 0; n2 < object.size(); ++n2) {
                    if (!((Boolean)object.get(n2)).booleanValue()) continue;
                    serializable.add(n2);
                }
                if (serializable.size() > 0) {
                    object = CFG.game.getCiv((int)n).civGameData;
                    serializable = new Civ_Mission_ChangeTypeOfGoverment((Integer)serializable.get(CFG.oR.nextInt(serializable.size())), n);
                    if (!bl) {
                        CFG.unionFlagsToGenerate_Manager.addFlagToLoad(n);
                        ((Save_Civ_GameData)object).changeTypeOfGoverment = serializable;
                    }
                }
            }
        }
    }

    @Override
    protected void turnOrders(int n) {
        super.turnOrders(n);
    }
}

