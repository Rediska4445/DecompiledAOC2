/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_New_Game_Players_Anim
extends Button_New_Game_Players {
    protected static final int ANIMATION_T = 750;
    protected static int animationState;
    protected static long lTimeAnimation;

    protected Button_New_Game_Players_Anim(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_New_Game_Players_Anim(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        if (bl) {
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.new_game_box_hover).getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight());
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.new_game_box_hover).getWidth() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, ImageManager.getImage(Images.new_game_box_hover).getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight(), true);
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, this.getWidth() - ImageManager.getImage(Images.new_game_box_hover).getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), false, true);
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.new_game_box_hover).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, ImageManager.getImage(Images.new_game_box_hover).getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), true, true);
        } else {
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.new_game_box).getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight());
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.new_game_box).getWidth() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box).getHeight() + n2, ImageManager.getImage(Images.new_game_box).getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight(), true);
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight() * 2 + n2, this.getWidth() - ImageManager.getImage(Images.new_game_box).getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), false, true);
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.new_game_box).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight() * 2 + n2, ImageManager.getImage(Images.new_game_box).getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), true, true);
        }
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.215f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 4);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.325f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        if (this.getClickable() && this.getIsHovered() && (n3 = animationState++) >= 0) {
            if (n3 == 0) {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.375f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.375f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    animationState = 0;
                    lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void setIsHovered(boolean bl) {
        super.setIsHovered(bl);
        lTimeAnimation = System.currentTimeMillis();
        animationState = 0;
    }
}

