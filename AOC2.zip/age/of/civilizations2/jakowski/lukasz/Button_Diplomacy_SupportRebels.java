/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_SupportRebels;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Diplomacy_SupportRebels
extends Button_Statistics {
    protected static final float FONT_SCALE = 0.7f;
    protected int iCivA;
    protected int iPopulationWidth;
    protected int iProvinces;
    protected int iProvincesWidth;
    protected int iRevolutionaryRisk;
    protected int iRevolutionaryRiskWidth;
    protected String sPopulation;

    protected Button_Diplomacy_SupportRebels(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        Object object = CFG.game.getCiv(n2).getCivName();
        int n9 = CFG.isAndroid() ? (int)Math.max((float)CFG.BUTTON_HEIGHT * 0.6f, (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 6)) : CFG.TEXT_HEIGHT + CFG.PADDING * 4;
        super((String)object, 0, n6, n7, n8, n9, false);
        this.iCivA = n2;
        boolean bl = n % 2 == 0;
        this.row = bl;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(n3);
        this.sPopulation = CFG.getNumberWithSpaces(((StringBuilder)object).toString());
        this.iRevolutionaryRisk = n4;
        this.iProvinces = n5;
        CFG.glyphLayout.setText(CFG.fontMain, this.sPopulation);
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.7f);
        Object object2 = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iProvinces);
        ((GlyphLayout)object2).setText(bitmapFont, ((StringBuilder)object).toString());
        this.iProvincesWidth = (int)(CFG.glyphLayout.width * 0.7f);
        object = CFG.glyphLayout;
        bitmapFont = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(n4);
        ((StringBuilder)object2).append("%");
        ((GlyphLayout)object).setText(bitmapFont, ((StringBuilder)object2).toString());
        this.iRevolutionaryRiskWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Diplomacy_SupportRebels.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.2f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.15f));
                    }
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, Button_Diplomacy_SupportRebels.this.getPosX() + n, Button_Diplomacy_SupportRebels.this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + 1 + n2, Button_Diplomacy_SupportRebels.this.getWidth(), Button_Diplomacy_SupportRebels.this.getHeight() - 2, true, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_SupportRebels.this.getPosX() + n, Button_Diplomacy_SupportRebels.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy_SupportRebels.this.getWidth(), Button_Diplomacy_SupportRebels.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_SupportRebels.this.getPosX() + n, Button_Diplomacy_SupportRebels.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Diplomacy_SupportRebels.this.getHeight() - 1 + n2 - Button_Diplomacy_SupportRebels.this.getHeight() / 4, Button_Diplomacy_SupportRebels.this.getWidth(), Button_Diplomacy_SupportRebels.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivA, 0, CFG.PADDING));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivA).getCivName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Population"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sPopulation, CFG.COLOR_TEXT_POPULATION));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("RevolutionaryRisk"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iRevolutionaryRisk);
        ((StringBuilder)object).append("%");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.getColorStep(CFG.COLOR_TEXT_REVOLUTION_MIN, CFG.COLOR_TEXT_REVOLUTION_MAX, this.iRevolutionaryRisk, 100, 1.0f)));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_revolution, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = DiplomacyManager.supportRebels_Provinces(Menu_InGame_SupportRebels.iOnCivID, this.getCurrent());
        if (object.size() > 0) {
            int n;
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            ArrayList arrayList3 = new ArrayList();
            while (object.size() > 0) {
                int n2 = 0;
                for (n = 1; n < object.size(); ++n) {
                    int n3 = n2;
                    if (CFG.game.getProvince((Integer)object.get(n2)).getPopulationData().getPopulationOfCivID(this.getCurrent()) < CFG.game.getProvince((Integer)object.get(n)).getPopulationData().getPopulationOfCivID(this.getCurrent())) {
                        n3 = n;
                    }
                    n2 = n3;
                }
                arrayList3.add(object.get(n2));
                object.remove(n2);
            }
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("Provinces"));
            ((StringBuilder)object).append(": ");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(arrayList3.size());
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.provinces, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            for (n = 0; n < arrayList3.size() && n < 14; ++n) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.getCurrent()));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                object = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince((Integer)arrayList3.get(n)) ? CFG.game.getProvince((Integer)arrayList3.get(n)).getName() : CFG.langManager.get("Undiscovered");
                stringBuilder.append((String)object);
                stringBuilder.append(": ");
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                stringBuilder = new StringBuilder();
                stringBuilder.append("");
                object = new StringBuilder();
                ((StringBuilder)object).append("");
                ((StringBuilder)object).append(CFG.game.getProvince((Integer)arrayList3.get(n)).getPopulationData().getPopulationOfCivID(this.getCurrent()));
                stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)object).toString()));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_POPULATION));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.population, CFG.PADDING, 0));
                arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
                arrayList2.clear();
            }
        }
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.15f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.05f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        if (this.row) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.625f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object;
        try {
            object = new Color((float)CFG.game.getCiv(this.iCivA).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getB() / 255.0f, 1.0f);
            spriteBatch.setColor((Color)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        CFG.game.getCiv(this.iCivA).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - CFG.game.getCiv(this.iCivA).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.diplo_revolution).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - this.iRevolutionaryRiskWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(Images.diplo_revolution)) / 2 - ImageManager.getImage(Images.diplo_revolution).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)), (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(Images.diplo_revolution)));
        ImageManager.getImage(Images.provinces).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 5 - this.iRevolutionaryRiskWidth - this.iProvincesWidth - (int)((float)ImageManager.getImage(Images.provinces).getWidth() * this.getImageScale(Images.provinces)) - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.provinces).getHeight() * this.getImageScale(Images.provinces)) / 2 - ImageManager.getImage(Images.provinces).getHeight() + n2, (int)((float)ImageManager.getImage(Images.provinces).getWidth() * this.getImageScale(Images.provinces)), (int)((float)ImageManager.getImage(Images.provinces).getHeight() * this.getImageScale(Images.provinces)));
        ImageManager.getImage(Images.population).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 7 - this.iRevolutionaryRiskWidth - this.iProvincesWidth - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.provinces).getWidth() * this.getImageScale(Images.provinces)) - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) - (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)) / 2 - ImageManager.getImage(Images.population).getHeight() + n2, (int)((float)ImageManager.getImage(Images.population).getWidth() * this.getImageScale(Images.population)), (int)((float)ImageManager.getImage(Images.population).getHeight() * this.getImageScale(Images.population)));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 3 + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, this.getColor(bl));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iRevolutionaryRisk);
        ((StringBuilder)object).append("%");
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iRevolutionaryRiskWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, CFG.getColorStep(CFG.COLOR_TEXT_REVOLUTION_MIN, CFG.COLOR_TEXT_REVOLUTION_MAX, this.iRevolutionaryRisk, 100, 1.0f));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.iProvinces);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 4 - this.iRevolutionaryRiskWidth - this.iProvincesWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.sPopulation);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 6 - this.iRevolutionaryRiskWidth - this.iProvincesWidth - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(Images.diplo_revolution)) - (int)((float)ImageManager.getImage(Images.provinces).getWidth() * this.getImageScale(Images.provinces)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_POPULATION);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivA;
    }

    protected final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

