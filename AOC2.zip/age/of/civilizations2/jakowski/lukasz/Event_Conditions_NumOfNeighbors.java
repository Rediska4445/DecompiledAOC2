/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;
import java.util.ArrayList;

class Event_Conditions_NumOfNeighbors
extends Event_Conditions {
    protected int iCivID = -1;
    protected int iValue = 0;

    Event_Conditions_NumOfNeighbors() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFNEIGHBORS);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("NumberOfNeighbors")).append(" >= ").append(this.getValue()).append(", ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("NumberOfNeighbors");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected boolean outCondition() {
        int n;
        int n2;
        ArrayList<Integer> arrayList;
        try {
            arrayList = new ArrayList<Integer>();
            for (n2 = 0; n2 < CFG.game.getCiv(this.getCivID()).getNumOfProvinces(); ++n2) {
                block4: for (n = 0; n < CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n2)).getNeighboringProvincesSize(); ++n) {
                    if (CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n2)).getNeighboringProvinces(n)).getCivID() <= 0 || CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n2)).getNeighboringProvinces(n)).getCivID() == this.getCivID()) continue;
                    boolean bl = true;
                    int n3 = 0;
                    while (true) {
                        block9: {
                            boolean bl2;
                            block8: {
                                bl2 = bl;
                                if (n3 >= arrayList.size()) break block8;
                                if (((Integer)arrayList.get(n3)).intValue() != CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n2)).getNeighboringProvinces(n)).getCivID()) break block9;
                                bl2 = false;
                            }
                            if (!bl2) continue block4;
                            arrayList.add(CFG.game.getProvince(CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n2)).getNeighboringProvinces(n)).getCivID());
                            continue block4;
                        }
                        ++n3;
                    }
                }
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return false;
        }
        {
            n2 = arrayList.size();
            n = this.getValue();
            if (n2 < n) return false;
            return true;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

