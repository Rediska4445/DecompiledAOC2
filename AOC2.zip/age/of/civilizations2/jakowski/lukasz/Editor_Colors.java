/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization_Color;
import age.of.civilizations2.jakowski.lukasz.Civilization_GameData3;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Pallet_Manager;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.io.IOException;
import java.util.Random;

public class Editor_Colors
extends Editor {
    private int iActiveColorID;
    private int iActivePaletteID = 1;
    private Civilization_Color lastColor = new Civilization_Color();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void keyDown(int var1_1) {
        if (!Gdx.input.isKeyPressed(20) || CFG.game.getActiveProvinceID() < 0 || CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID() <= 0) ** GOTO lbl34
        var2_2 = new Random();
        var3_3 = Gdx.files.internal("game/civilizations/Age_of_Civilizations").readString().split(";");
        block4: while (true) {
            this.iActiveColorID = var2_2.nextInt(Pallet_Manager.NUM_OF_COLORS);
            var1_1 = 0;
            while (true) {
                block15: {
                    block16: {
                        if (var1_1 < ((String[])var3_3).length) {
                            var4_5 = Gdx.files;
                            var5_7 = new StringBuilder();
                            var5_7.append("game/civilizations_colors/");
                            var5_7.append(this.iActivePaletteID);
                            var5_7.append("/");
                            var5_7.append((String)var3_3[var1_1]);
                            var6_8 = Integer.parseInt(var4_5.internal(var5_7.toString()).readString());
                            var7_9 = this.iActiveColorID;
                            if (var6_8 != var7_9) break block15;
                            var1_1 = 0;
                            break block16;
                        }
                        var1_1 = 1;
                    }
                    if (var1_1 == 0) continue block4;
                    this.lastColor.iR = CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getR();
                    this.lastColor.iG = CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getG();
                    this.lastColor.iB = CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getB();
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR(CFG.oR.nextInt(256));
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG(CFG.oR.nextInt(256));
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB(CFG.oR.nextInt(256));
lbl34:
                    // 2 sources

                    if (Gdx.input.isKeyPressed(67) && CFG.game.getActiveProvinceID() >= 0 && CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID() > 0) {
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR(this.lastColor.iR);
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG(this.lastColor.iG);
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB(this.lastColor.iB);
                    }
                    if (Gdx.input.isKeyPressed(21)) {
                        --this.iActivePaletteID;
                        if (this.iActivePaletteID < 1) {
                            this.iActivePaletteID = 1;
                        }
                    }
                    if (Gdx.input.isKeyPressed(22)) {
                        ++this.iActivePaletteID;
                    }
                    if (Gdx.input.isKeyPressed(62)) {
                        CFG.game.getActiveProvinceID();
                    }
                    if (Gdx.input.isKeyPressed(19) && CFG.game.getActiveProvinceID() >= 0) {
                        if (!CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince() && CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID() != 0) {
                            try {
                                var2_2 = Gdx.files;
                                var3_3 = new StringBuilder();
                                var3_3.append("game/civilizations/");
                                var3_3.append(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivTag());
                                var3_3 = (Civilization_GameData3)CFG.deserialize(var2_2.internal(var3_3.toString()).readBytes());
                                CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR(var3_3.getR());
                                CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG(var3_3.getG());
                                CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB(var3_3.getB());
                            }
                            catch (IOException | ClassNotFoundException var3_4) {}
                        } else {
                            CFG.palletManager.loadCivilizationsPaletteOfColors(this.iActivePaletteID);
                        }
                    }
                    if (Gdx.input.isKeyPressed(66) == false) return;
                    if (CFG.game.getActiveProvinceID() < 0) return;
                    if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID() <= 0) return;
                    var2_2 = Gdx.files;
                    var3_3 = new StringBuilder();
                    var3_3.append("game/civilizations_colors/");
                    var3_3.append(this.iActivePaletteID);
                    var3_3.append("/");
                    var3_3.append(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivTag());
                    var3_3 = var2_2.local(var3_3.toString());
                    var2_2 = new StringBuilder();
                    var2_2.append("");
                    var2_2.append(this.iActiveColorID);
                    var3_3.writeString(var2_2.toString(), false);
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR(CFG.oR.nextInt(256));
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG(CFG.oR.nextInt(256));
                    CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB(CFG.oR.nextInt(256));
                    return;
                    catch (GdxRuntimeException var4_6) {}
                }
                ++var1_1;
            }
            break;
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ACTIVE PALETTEID: ");
        stringBuilder.append(this.iActivePaletteID);
        return stringBuilder.toString();
    }
}

