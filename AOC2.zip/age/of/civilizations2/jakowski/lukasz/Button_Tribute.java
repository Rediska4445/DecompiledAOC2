/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Tribute
extends Button_Build {
    protected static final float FONTSIZE2 = 0.6f;
    protected int iDateWidth;
    protected int iEconomyWidth;
    protected Color oColor = Color.WHITE;
    protected String sDate = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getCivName();
    protected String sEconomy;
    protected String sProvinceName;

    protected Button_Tribute(String string2, int n, int n2, int n3, int n4) {
        super(string2, n, 0, 0, n2, n3, n4, true, false, 0, 0.0f);
        CFG.glyphLayout.setText(CFG.fontMain, this.sDate);
        this.iDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.setMin(40);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.ideologiesManager.getIdeology(this.iImageID).getCrownImageScaled().draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.ideologiesManager.getIdeology(this.iImageID).getCrownImageScaled().getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.ideologiesManager.getIdeology(this.iImageID).getCrownImageScaled().getHeight() / 2 + n2);
        try {
            CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - CFG.CIV_FLAG_WIDTH + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sEconomy, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.oColor);
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + CFG.PADDING + this.iEconomyWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.7f)) / 2 - CFG.PADDING / 2 - ImageManager.getImage(Images.top_gold).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.7f)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.7f)));
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected void setMin(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        CharSequence charSequence = n > 0 ? "+" : "";
        stringBuilder.append((String)charSequence);
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(n);
        stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)charSequence).toString()));
        this.sEconomy = stringBuilder.toString();
        this.oColor = n > 0 ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEUTRAL;
        CFG.glyphLayout.setText(CFG.fontMain, this.sEconomy);
        this.iEconomyWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }
}

