/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Menu_ArrowRight
extends Button_Menu {
    protected Button_Menu_ArrowRight(int n, int n2, int n3, int n4, boolean bl) {
        super("", 0, n, n2, n3, n4, bl);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
        if (bl) {
            ImageManager.getImage(Images.arrow_active).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.arrow_active).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.arrow_active).getHeight() / 2 + n2, true);
        } else {
            ImageManager.getImage(Images.arrow).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.arrow).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.arrow).getHeight() / 2 + n2, true);
        }
    }
}

