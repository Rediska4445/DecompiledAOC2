/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Add
extends Button {
    protected Button_Add(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.getClickable()) {
            if (bl) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.75f));
            } else if (this.getIsHovered()) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.8f));
            } else {
                spriteBatch.setColor(Color.WHITE);
            }
        } else if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.35f));
        } else {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.5f));
        }
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btn_add).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth(), this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight());
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth() + n, this.getPosY() - ImageManager.getImage(Images.btn_add).getHeight() + n2, ImageManager.getImage(Images.btn_add).getWidth(), this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight(), true);
        ImageManager.getImage(Images.btn_add).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight() * 2 + n2, this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth(), ImageManager.getImage(Images.btn_add).getHeight(), false, true);
        ImageManager.getImage(Images.btn_add).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_add).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.btn_add).getHeight() + n2, true, true);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? new Color(0.82f, 0.82f, 0.82f, 1.0f) : new Color(0.7f, 0.7f, 0.7f, 1.0f)) : new Color(0.764f, 0.764f, 0.764f, 0.6f));
        return color2;
    }
}

