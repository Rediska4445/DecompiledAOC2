/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_Report_Units
extends Button {
    private float fSplitPosX;
    private int iAttackers;
    private int iAttackersEND_ID;
    private int iAttackersSize;
    private int iCivsSize;
    private int iDefenders;
    private int iDefendersWidth;
    private List<Integer> lCivID = new ArrayList<Integer>();
    private List<Float> lCivWidth = new ArrayList<Float>();

    protected Button_Report_Units(int n, int n2, int n3, int n4) {
        int n5;
        int n6 = 0;
        this.iAttackersSize = 0;
        this.iCivsSize = 0;
        this.fSplitPosX = 0.0f;
        this.iAttackers = 0;
        this.iDefenders = 0;
        this.iDefendersWidth = 0;
        int n7 = CFG.reportData.getTotalArmy();
        this.iAttackers = CFG.reportData.getAttackersArmy();
        this.iDefenders = CFG.reportData.getDefendersArmy();
        GlyphLayout glyphLayout = CFG.glyphLayout;
        Object object = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iDefenders);
        glyphLayout.setText((BitmapFont)object, stringBuilder.toString());
        this.iDefendersWidth = (int)CFG.glyphLayout.width;
        for (n5 = 0; n5 < CFG.reportData.lAttackers_Armies.size(); ++n5) {
            this.lCivID.add(CFG.reportData.lAttackers_IDs.get(n5));
            this.lCivWidth.add(Float.valueOf((float)CFG.reportData.lAttackers_Armies.get(n5).intValue() / (float)n7));
        }
        this.iAttackersEND_ID = CFG.reportData.lAttackers_Armies.size();
        for (n5 = 0; n5 < CFG.reportData.lDefenders_Armies.size(); ++n5) {
            this.lCivID.add(CFG.reportData.lDefenders_IDs.get(n5));
            this.lCivWidth.add(Float.valueOf((float)CFG.reportData.lDefenders_Armies.get(n5).intValue() / (float)n7));
        }
        n5 = 0;
        while (true) {
            if (n5 >= this.lCivWidth.size()) break;
            this.lCivWidth.get(n5).floatValue();
            ++n5;
        }
        for (int i = n6; i < this.iAttackersEND_ID; ++i) {
            this.fSplitPosX += this.lCivWidth.get(i).floatValue();
        }
        this.iCivsSize = this.lCivID.size();
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(n7);
        super.init(((StringBuilder)object).toString(), -1, n, n2, n3, n4, true, true, false, false, null);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Attackers"));
        stringBuilder.append(" ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iAttackers);
        stringBuilder.append(" - ");
        stringBuilder.append(this.iDefenders);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        stringBuilder = new StringBuilder();
        stringBuilder.append(" ");
        stringBuilder.append(CFG.langManager.get("Defenders"));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3 = 0;
        for (int i = 0; i < this.iCivsSize; ++i) {
            spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.lCivID.get(i)).getR() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getG() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getB() / 255.0f, 0.6f));
            ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n3 + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, (int)(this.lCivWidth.get(i).floatValue() * (float)this.getWidth()), this.getHeight());
            spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.lCivID.get(i)).getR() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getG() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getB() / 255.0f, 0.3f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n3 + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)(this.lCivWidth.get(i).floatValue() * (float)this.getWidth()), this.getHeight());
            spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.lCivID.get(i)).getR() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getG() / 255.0f, (float)CFG.game.getCiv(this.lCivID.get(i)).getB() / 255.0f, 0.65f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n3 + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)(this.lCivWidth.get(i).floatValue() * (float)this.getWidth()), this.getHeight() * 3 / 5);
            n3 += (int)(this.lCivWidth.get(i).floatValue() * (float)this.getWidth());
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, (int)(this.fSplitPosX * (float)this.getWidth()), this.getHeight(), false, true);
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + this.getWidth() - (this.getWidth() - (int)(this.fSplitPosX * (float)this.getWidth())) + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth() - (int)(this.fSplitPosX * (float)this.getWidth()), this.getHeight(), true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.225f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.785f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + (int)(this.fSplitPosX * (float)this.getWidth()) + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.85f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.75f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() + 1 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
        spriteBatch.setColor(CFG.COLOR_NEW_GAME_EDGE_LINE);
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), ImageManager.getImage(Images.pix255_255_255).getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.3f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), ImageManager.getImage(Images.line_32_off1).getHeight());
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iAttackers);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iDefenders);
        CFG.drawText(spriteBatch, stringBuilder.toString(), this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)this.iDefendersWidth * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.0f, 0.0f, 0.0f, 1.0f) : (this.getClickable() ? (this.getIsHovered() ? new Color(1.0f, 1.0f, 1.0f, 0.5f) : new Color(1.0f, 1.0f, 1.0f, 0.425f)) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }
}

