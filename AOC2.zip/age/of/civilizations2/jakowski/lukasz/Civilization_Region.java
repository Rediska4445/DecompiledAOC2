/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.Game_Render;
import age.of.civilizations2.jakowski.lukasz.Point_XY;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.CatmullRomSpline;
import com.badlogic.gdx.math.Vector;
import com.badlogic.gdx.math.Vector2;
import java.util.ArrayList;
import java.util.List;

class Civilization_Region {
    protected boolean drawName = true;
    private float fAngle = 0.0f;
    private float fontScale = 1.0f;
    private boolean haveNotOccupiedProvince = false;
    private int iAvaragePointPosX = 0;
    private int iAvaragePointPosY = 0;
    protected int iAveragePotential = 0;
    private int iCharMaxHeight = 0;
    private int iCharMaxWidth = 0;
    private int iMaxX = 0;
    private int iMaxY = 0;
    private int iMinX = 0;
    private int iMinY = 0;
    private int iProvincesSize;
    private int iRegionID;
    protected boolean isKeyRegion = false;
    private boolean isSupplied = false;
    protected List<Integer> lCostalineProvinces;
    private List<Point_XY> lPoints = new ArrayList<Point_XY>();
    private List<Float> lPointsAngle = new ArrayList<Float>();
    private List<Integer> lProvinces;
    private boolean seaAccess = false;
    private boolean seaAccess_HavePort = false;
    private List<Integer> shortestLine = null;
    private List<Boolean> triedToUse = new ArrayList<Boolean>();

    protected Civilization_Region() {
    }

    protected Civilization_Region(int n, int n2) {
        this.lProvinces = new ArrayList<Integer>();
        this.shortestLine = new ArrayList<Integer>();
        this.lCostalineProvinces = new ArrayList<Integer>();
        this.iRegionID = n2;
        this.addProvince(n);
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void buildAvaragePoint() {
        long l;
        long l2;
        Game game = CFG.game;
        List<Integer> list = this.lProvinces;
        List<Integer> list2 = this.shortestLine;
        int n = 0;
        int n2 = game.getProvince(list.get(list2.get(0))).getMinX();
        int n3 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getMaxX();
        int n4 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getMinY();
        int n5 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getMaxY();
        int n6 = n2;
        if (CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMinX() < n2) {
            n6 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMinX();
        }
        n2 = n3;
        if (CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMaxX() > n3) {
            n2 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMaxX();
        }
        n3 = n4;
        if (CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMinY() < n4) {
            n3 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMinY();
        }
        n4 = n5;
        if (CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMaxY() > n5) {
            n4 = CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getMaxY();
        }
        long l3 = l2 = 0L;
        n5 = 0;
        while (n < this.getProvincesSize()) {
            long l4;
            int n7;
            block10: {
                int n8;
                block11: {
                    block13: {
                        block12: {
                            block9: {
                                if (CFG.game.getProvince(this.getProvince(n)).getCenterX() + CFG.game.getProvince(this.getProvince(n)).getShiftX() < n6 || CFG.game.getProvince(this.getProvince(n)).getCenterX() + CFG.game.getProvince(this.getProvince(n)).getShiftX() > n2) break block9;
                                n7 = n5;
                                l = l3;
                                l4 = l2;
                                if (CFG.game.getProvince(this.getProvince(n)).getCenterY() + CFG.game.getProvince(this.getProvince(n)).getShiftY() < n3) break block10;
                                n7 = n5;
                                l = l3;
                                l4 = l2;
                                if (CFG.game.getProvince(this.getProvince(n)).getCenterY() + CFG.game.getProvince(this.getProvince(n)).getShiftY() > n4) break block10;
                                l3 += (long)(CFG.game.getProvince(this.getProvince(n)).getCenterX() + CFG.game.getProvince(this.getProvince(n)).getShiftX());
                                n7 = CFG.game.getProvince(this.getProvince(n)).getCenterY();
                                n8 = CFG.game.getProvince(this.getProvince(n)).getShiftY();
                                break block11;
                            }
                            if (CFG.game.getProvince(this.getProvince(n)).getMinX() > n6 && CFG.game.getProvince(this.getProvince(n)).getMinX() <= n2) break block12;
                            n7 = n5;
                            l = l3;
                            l4 = l2;
                            if (CFG.game.getProvince(this.getProvince(n)).getMaxX() <= n6) break block10;
                            n7 = n5;
                            l = l3;
                            l4 = l2;
                            if (CFG.game.getProvince(this.getProvince(n)).getMaxX() > n2) break block10;
                        }
                        if (CFG.game.getProvince(this.getProvince(n)).getMinY() >= n3 && CFG.game.getProvince(this.getProvince(n)).getMinY() <= n4) break block13;
                        n7 = n5;
                        l = l3;
                        l4 = l2;
                        if (CFG.game.getProvince(this.getProvince(n)).getMaxY() < n3) break block10;
                        n7 = n5;
                        l = l3;
                        l4 = l2;
                        if (CFG.game.getProvince(this.getProvince(n)).getMaxY() > n4) break block10;
                    }
                    l3 += (long)(CFG.game.getProvince(this.getProvince(n)).getCenterX() + CFG.game.getProvince(this.getProvince(n)).getShiftX());
                    n7 = CFG.game.getProvince(this.getProvince(n)).getCenterY();
                    n8 = CFG.game.getProvince(this.getProvince(n)).getShiftY();
                }
                l4 = l2 + (long)(n7 + n8);
                n7 = n5 + 1;
                l = l3;
            }
            ++n;
            n5 = n7;
            l3 = l;
            l2 = l4;
        }
        n6 = n5;
        if (n5 == 0) {
            n6 = 1;
        }
        l = n6;
        this.iAvaragePointPosX = (int)(l3 / l);
        this.iAvaragePointPosY = (int)(l2 / l);
    }

    /*
     * Exception decompiling
     */
    private final void buildDrawData() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [9[TRYBLOCK], 15[TRYBLOCK]], but top level block is 35[CATCHBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    private final void buildMinMaxBounds() {
        block9: {
            int n;
            try {
                this.iMinX = CFG.game.getProvince(this.lProvinces.get(0)).getMinX();
                this.iMaxX = CFG.game.getProvince(this.lProvinces.get(0)).getMaxX();
                this.iMinY = CFG.game.getProvince(this.lProvinces.get(0)).getMinY();
                this.iMaxY = CFG.game.getProvince(this.lProvinces.get(0)).getMaxY();
                n = 1;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (!CFG.LOGS) break block9;
                CFG.exceptionStack(indexOutOfBoundsException);
            }
            while (true) {
                if (n < this.iProvincesSize) {
                    if (CFG.game.getProvince(this.lProvinces.get(n)).getMinX() < this.iMinX) {
                        this.iMinX = CFG.game.getProvince(this.lProvinces.get(n)).getMinX();
                    }
                    if (CFG.game.getProvince(this.lProvinces.get(n)).getMaxX() > this.iMaxX) {
                        this.iMaxX = CFG.game.getProvince(this.lProvinces.get(n)).getMaxX();
                    }
                    if (CFG.game.getProvince(this.lProvinces.get(n)).getMinY() < this.iMinY) {
                        this.iMinY = CFG.game.getProvince(this.lProvinces.get(n)).getMinY();
                    }
                    if (CFG.game.getProvince(this.lProvinces.get(n)).getMaxY() > this.iMaxY) {
                        this.iMaxY = CFG.game.getProvince(this.lProvinces.get(n)).getMaxY();
                    }
                    ++n;
                    continue;
                }
                break;
            }
        }
    }

    private final boolean canBeUsedInPath(int n) {
        boolean bl;
        int n2 = 0;
        int n3 = 0;
        for (int i = 0; i < CFG.game.getProvince(this.lProvinces.get(n)).getNeighboringProvincesSize(); ++i) {
            if (CFG.game.getProvince(this.lProvinces.get(n)).getCivID() == CFG.game.getProvince(CFG.game.getProvince(this.lProvinces.get(n)).getNeighboringProvinces(i)).getCivID()) {
                ++n3;
                continue;
            }
            ++n2;
        }
        boolean bl2 = bl = true;
        if (n2 > 0) {
            bl2 = n3 > 1 ? bl : false;
        }
        return bl2;
    }

    private final Point_XY canDrawTextProperly(int n, int n2) {
        this.buildAvaragePoint();
        ArrayList<Point_XY> arrayList = new ArrayList<Point_XY>();
        int n3 = CFG.game.getProvince(n).getCenterX() + CFG.game.getProvince(n).getShiftX();
        int n4 = CFG.game.getProvince(n2).getCenterX() + CFG.game.getProvince(n2).getShiftX();
        float f = (float)(n4 - n3) * 0.15f;
        int n5 = (int)Math.abs(f);
        int n6 = -1;
        int n7 = n3 > n4 ? -1 : 1;
        int n8 = (int)Math.abs(f);
        int n9 = n4 > n3 ? -1 : 1;
        int n10 = CFG.game.getProvince(n).getCenterY() + CFG.game.getProvince(n).getShiftY();
        int n11 = CFG.game.getProvince(n2).getCenterY() + CFG.game.getProvince(n2).getShiftY();
        f = (float)(n11 - n10) * 0.15f;
        int n12 = (int)Math.abs(f);
        n2 = n10 > n11 ? -1 : 1;
        int n13 = (int)Math.abs(f);
        if (n11 <= n10) {
            n6 = 1;
        }
        int n14 = CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameLength() * 10;
        Vector2[] arrvector2 = new Vector2[n14];
        f = n5 * n7 + n3;
        float f2 = n12 * n2 + n10;
        Vector2 vector2 = new Vector2(f, f2);
        Vector2 vector22 = new Vector2(f, f2);
        Object object = new Vector2(this.iAvaragePointPosX, this.iAvaragePointPosY);
        f2 = n4 + n8 * n9;
        f = n11 + n13 * n6;
        object = new CatmullRomSpline((Vector[])new Vector2[]{vector2, vector22, object, new Vector2(f2, f), new Vector2(f2, f)}, false);
        for (n2 = 0; n2 < n14; ++n2) {
            arrvector2[n2] = new Vector2();
            ((CatmullRomSpline)object).valueAt(arrvector2[n2], (float)n2 / ((float)n14 - 1.0f));
        }
        n7 = 0;
        n2 = 0;
        while (n7 < (n4 = n14 - 1)) {
            n9 = (int)arrvector2[n7].x;
            n6 = (int)arrvector2[n7].y;
            n2 += this.getLineWidth(n9, n6, (int)arrvector2[++n7].x, (int)arrvector2[n7].y);
        }
        arrayList.add(new Point_XY((int)arrvector2[0].x, (int)arrvector2[0].y));
        try {
            n2 /= CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameLength() - 1;
        }
        catch (ArithmeticException arithmeticException) {
            if (CFG.LOGS) {
                CFG.exceptionStack(arithmeticException);
            }
            n2 = 0;
        }
        n9 = 0;
        block4: for (n7 = 1; n7 < CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameLength(); ++n7) {
            n6 = 0;
            while (n9 < n4) {
                n5 = (int)arrvector2[n9].x;
                n3 = (int)arrvector2[n9].y;
                n14 = n9 + 1;
                if ((n3 = this.getLineWidth(n5, n3, (int)arrvector2[n14].x, (int)arrvector2[n14].y) + n6) >= n2 && n6 <= n2) {
                    arrayList.add(new Point_XY((int)arrvector2[n9].x, (int)arrvector2[n9].y));
                    continue block4;
                }
                n6 = n3;
                n9 = n14;
            }
        }
        for (n2 = arrayList.size() - 1; n2 >= 0; --n2) {
            n7 = CFG.game.setProvinceID_Point(((Point_XY)arrayList.get(n2)).getPosX(), ((Point_XY)arrayList.get(n2)).getPosY() - CFG.TEXT_HEIGHT / 2);
            if (n7 < 0 || CFG.game.getProvince(n7).getSeaProvince() || CFG.game.getProvince(n).getCivID() == CFG.game.getProvince(n7).getCivID()) continue;
            return (Point_XY)arrayList.get(n2);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void addProvince(int n) {
        int n2;
        this.lProvinces.add(n);
        this.iProvincesSize = this.lProvinces.size();
        if (CFG.game.getProvince(n).getNeighboringSeaProvincesSize() > 0) {
            this.lCostalineProvinces.add(n);
        }
        if (CFG.game.getProvince(n).getIsCapital()) {
            this.isKeyRegion = true;
        }
        CFG.game.getProvince(n).setCivRegionID(this.iRegionID);
        if (!this.seaAccess) {
            for (n2 = 0; n2 < CFG.game.getProvince(n).getNeighboringSeaProvincesSize(); ++n2) {
                if (CFG.game.getProvince(CFG.game.getProvince(n).getNeighboringSeaProvinces(n2)).getLevelOfPort() != -2) continue;
                this.seaAccess = true;
                break;
            }
        }
        if (this.seaAccess && !this.seaAccess_HavePort && CFG.game.getProvince(n).getLevelOfPort() > 0) {
            this.seaAccess_HavePort = true;
        }
        if (!this.haveNotOccupiedProvince) {
            n2 = CFG.game.getProvince(n).getCivID();
            if (!CFG.game.getCiv((int)n2).civGameData.haveNotMoney && (CFG.game.getProvince(n).getLevelOfSupply() > 0 || this.seaAccess_HavePort || CFG.game.getProvince(n).getIsCapital())) {
                this.haveNotOccupiedProvince = true;
            }
        }
    }

    protected final boolean buildRegionPath() {
        this.drawName = false;
        this.buildMinMaxBounds();
        int n = this.lProvinces.size();
        Boolean bl = true;
        if (n == 1) {
            return false;
        }
        if (this.lProvinces.size() > 2) {
            Object object;
            int n2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            block42: {
                if (!CFG.settingsManager.DRAW_CIVILIZATIONS_NAMES_OVER_PRPOVINCES_IN_GAME) {
                    return false;
                }
                if (this.triedToUse.size() == 0) {
                    for (n = 0; n < this.iProvincesSize; ++n) {
                        this.triedToUse.add(false);
                    }
                }
                for (n = 0; n < this.iProvincesSize; ++n) {
                    if (!CFG.game.getProvince(this.lProvinces.get(n)).getBelowZero()) continue;
                    return false;
                }
                for (n = 0; n < this.iProvincesSize; ++n) {
                    n8 = n;
                    if (this.triedToUse.get(n).booleanValue()) {
                        continue;
                    }
                    break block42;
                }
                n8 = -1;
            }
            if (n8 == -1) {
                return false;
            }
            int n9 = (int)Math.sqrt(Math.pow(this.iMinX - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterX(), 2.0) + Math.pow(this.iMaxY - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterY(), 2.0));
            int n10 = (int)Math.sqrt(Math.pow(this.iMaxX - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterX(), 2.0) + Math.pow(this.iMinY - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterY(), 2.0));
            int n11 = (int)Math.sqrt(Math.pow(this.iMaxX - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterX(), 2.0) + Math.pow(this.iMaxY - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterY(), 2.0));
            int n12 = (int)Math.sqrt(Math.pow(this.iMinX - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterX(), 2.0) + Math.pow(this.iMinY - CFG.game.getProvince(this.lProvinces.get(n8)).getCenterY(), 2.0));
            n = n8 + 1;
            int n13 = n7 = (n6 = (n5 = (n4 = (n3 = (n2 = n8)))));
            int n14 = n8;
            n8 = n12;
            while (n < this.iProvincesSize) {
                int n15;
                if (this.triedToUse.get(n).booleanValue()) {
                    n12 = n6;
                    n6 = n11;
                    n15 = n10;
                } else {
                    int n16 = this.iMinX;
                    int n17 = this.iMaxY;
                    n12 = n6;
                    object = CFG.game;
                    n15 = n7;
                    n6 = ((Game)object).getProvince(this.lProvinces.get(n)).getCenterX();
                    object = CFG.game;
                    int n18 = ((Game)object).getProvince(this.lProvinces.get(n)).getShiftX();
                    int n19 = CFG.game.getProvince(this.lProvinces.get(n)).getCenterY();
                    object = CFG.game;
                    n7 = n5;
                    if ((n6 = this.getLineWidth(n16, n17, n6 + n18, n19 + ((Game)object).getProvince(this.lProvinces.get(n)).getShiftY())) < n9) {
                        n5 = n;
                        n14 = n6;
                    } else {
                        n5 = n14;
                        n14 = n9;
                    }
                    n6 = this.getLineWidth(this.iMaxX, this.iMinY, CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX(), CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY());
                    n9 = n10;
                    if (n6 < n10) {
                        n9 = n6;
                        n7 = n;
                    }
                    n10 = this.getLineWidth(this.iMaxX, this.iMaxY, CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX(), CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY());
                    n6 = n11;
                    if (n10 < n11) {
                        n6 = n10;
                        n12 = n;
                    }
                    n17 = this.getLineWidth(this.iMinX, this.iMinY, CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX(), CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY());
                    n10 = n8;
                    n11 = n15;
                    if (n17 < n8) {
                        n10 = n17;
                        n11 = n;
                    }
                    n8 = n13;
                    if (CFG.game.getProvince(this.lProvinces.get(n13)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n13)).getShiftY() < CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY()) {
                        n8 = n;
                    }
                    n13 = n2;
                    if (CFG.game.getProvince(this.lProvinces.get(n2)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n2)).getShiftY() > CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY()) {
                        n13 = n;
                    }
                    n2 = n3;
                    if (CFG.game.getProvince(this.lProvinces.get(n3)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n3)).getShiftX() > CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX()) {
                        n15 = CFG.game.getProvince(this.lProvinces.get(n)).getCenterY();
                        n16 = CFG.game.getProvince(this.lProvinces.get(n)).getShiftY();
                        n17 = this.iMinY;
                        n2 = n3;
                        if (n15 + n16 >= n17 + (this.iMaxY - n17) / 2) {
                            n2 = n;
                        }
                    }
                    if (CFG.game.getProvince(this.lProvinces.get(n4)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n4)).getShiftX() < CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX() && (n15 = CFG.game.getProvince(this.lProvinces.get(n)).getCenterY()) + (n17 = CFG.game.getProvince(this.lProvinces.get(n)).getShiftY()) <= (n3 = this.iMinY) + (this.iMaxY - n3) / 2) {
                        n4 = n;
                    }
                    n17 = n14;
                    n14 = n5;
                    n5 = n7;
                    n15 = n9;
                    n3 = n2;
                    n9 = n17;
                    n2 = n13;
                    n13 = n8;
                    n7 = n11;
                    n8 = n10;
                }
                ++n;
                n11 = n6;
                n6 = n12;
                n10 = n15;
            }
            if (this.getLineWidth(n14, n5) > this.getLineWidth(n6, n7)) {
                if (this.getLineWidth(n14, n5) > this.getLineWidth(n13, n2)) {
                    if (this.getLineWidth(n14, n5) > this.getLineWidth(n3, n4)) {
                        this.shortestLine.add(n14);
                        this.shortestLine.add(n5);
                    } else {
                        this.shortestLine.add(n3);
                        this.shortestLine.add(n4);
                    }
                } else if (this.getLineWidth(n13, n2) > this.getLineWidth(n3, n4)) {
                    this.shortestLine.add(n13);
                    this.shortestLine.add(n2);
                } else {
                    this.shortestLine.add(n3);
                    this.shortestLine.add(n4);
                }
            } else if (this.getLineWidth(n6, n7) > this.getLineWidth(n13, n2)) {
                if (this.getLineWidth(n6, n7) > this.getLineWidth(n3, n4)) {
                    this.shortestLine.add(n6);
                    this.shortestLine.add(n7);
                } else {
                    this.shortestLine.add(n3);
                    this.shortestLine.add(n4);
                }
            } else if (this.getLineWidth(n13, n2) > this.getLineWidth(n3, n4)) {
                this.shortestLine.add(n13);
                this.shortestLine.add(n2);
            } else {
                this.shortestLine.add(n3);
                this.shortestLine.add(n4);
            }
            if (CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getCenterX() > CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getCenterX()) {
                n = this.shortestLine.get(0);
                object = this.shortestLine;
                object.set(0, object.get(1));
                this.shortestLine.set(1, n);
            }
            if (this.shortestLine.size() != 0 && this.shortestLine.get(0) != this.shortestLine.get(1)) {
                object = this.canDrawTextProperly(this.lProvinces.get(this.shortestLine.get(0)), this.lProvinces.get(this.shortestLine.get(1)));
                if (object != null) {
                    if (this.getLineWidth(((Point_XY)object).getPosX(), ((Point_XY)object).getPosY(), CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getCenterX() + CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getShiftX(), CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getCenterY() + CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(0))).getShiftY()) < this.getLineWidth(((Point_XY)object).getPosX(), ((Point_XY)object).getPosY(), CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getCenterX() + CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getShiftX(), CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getCenterY() + CFG.game.getProvince(this.lProvinces.get(this.shortestLine.get(1))).getShiftY())) {
                        this.triedToUse.set(this.shortestLine.get(0), bl);
                    } else {
                        this.triedToUse.set(this.shortestLine.get(1), bl);
                    }
                    this.shortestLine.clear();
                    return this.buildRegionPath();
                }
                this.triedToUse.clear();
                this.buildScaleOfText();
            } else {
                this.shortestLine.clear();
                this.triedToUse.clear();
                return false;
            }
        }
        this.updateDrawRegionName();
        return true;
    }

    /*
     * Exception decompiling
     */
    protected final void buildScaleOfText() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 7[CATCHBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    protected final boolean checkRegionBordersWithEnemy(int n) {
        for (n = 0; n < this.getProvincesSize(); ++n) {
            if (!CFG.game.getProvince(this.getProvince(n)).getBordersWithEnemy()) continue;
            return true;
        }
        return false;
    }

    protected final boolean containsProvince(int n) {
        for (int i = 0; i < this.iProvincesSize; ++i) {
            if (this.lProvinces.get(i) != n) continue;
            return true;
        }
        return false;
    }

    protected final void drawCivilizationName(SpriteBatch spriteBatch, int n, int n2, float f, float f2, int n3, int n4) {
        CFG.fontBorder.getData().setScale(f);
        for (n2 = 0; n2 < CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameLength(); ++n2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameCharacter(n2));
            CFG.drawTextRotatedBorder(spriteBatch, stringBuilder.toString(), CFG.map.getMapCoordinates().getPosX() + this.lPoints.get(n2).getPosX(), CFG.map.getMapCoordinates().getPosY() + this.lPoints.get(n2).getPosY() - n4 / 2, new Color(1.0f, 1.0f, 1.0f, Game_Render.CIVILIZATION_NAMES_ALPHA), this.lPointsAngle.get(n2).floatValue());
        }
    }

    protected final void drawCivilizationName_SecondSideOfMap(SpriteBatch spriteBatch, int n, int n2, float f, float f2, int n3, int n4) {
        if (CFG.game.getProvince(n).getTranslateProvincePosX() > 0) {
            CFG.fontBorder.getData().setScale(f);
            for (n2 = 0; n2 < CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameLength(); ++n2) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(CFG.game.getCiv(CFG.game.getProvince(n).getCivID()).getCivNameCharacter(n2));
                CFG.drawTextRotatedBorder(spriteBatch, stringBuilder.toString(), CFG.map.getMapCoordinates().getSecondSideOfMap_MoveX() + CFG.map.getMapCoordinates().getPosX() + this.lPoints.get(n2).getPosX(), CFG.map.getMapCoordinates().getPosY() + this.lPoints.get(n2).getPosY() - n4 / 2, new Color(1.0f, 1.0f, 1.0f, Game_Render.CIVILIZATION_NAMES_ALPHA), this.lPointsAngle.get(n2).floatValue());
            }
        }
    }

    protected final float getAngle() {
        return this.fAngle;
    }

    protected final int getCharMaxHeight() {
        return this.iCharMaxHeight;
    }

    protected final int getCharMaxWidth() {
        return this.iCharMaxWidth;
    }

    protected final float getFontScale() {
        return this.fontScale;
    }

    protected final boolean getHaveNotOccupiedProvince() {
        return this.haveNotOccupiedProvince;
    }

    protected final boolean getIsSupplied() {
        return this.isSupplied;
    }

    protected int getLineWidth(int n, int n2) {
        return this.getLineWidth(CFG.game.getProvince(this.lProvinces.get(n)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftX(), CFG.game.getProvince(this.lProvinces.get(n)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n)).getShiftY(), CFG.game.getProvince(this.lProvinces.get(n2)).getCenterX() + CFG.game.getProvince(this.lProvinces.get(n2)).getShiftX(), CFG.game.getProvince(this.lProvinces.get(n2)).getCenterY() + CFG.game.getProvince(this.lProvinces.get(n2)).getShiftY());
    }

    protected int getLineWidth(int n, int n2, int n3, int n4) {
        return (int)Math.sqrt(Math.pow(n - n3, 2.0) + Math.pow(n2 - n4, 2.0));
    }

    protected float getLinesAngle(int n, int n2, int n3, int n4) {
        return (float)(Math.atan2(n2 - n4, -n + n3) * 180.0 / Math.PI);
    }

    protected final int getProvince(int n) {
        return this.lProvinces.get(n);
    }

    protected final int getProvincesSize() {
        return this.iProvincesSize;
    }

    protected final int getRegionID() {
        return this.iRegionID;
    }

    protected final boolean getSeaAccess() {
        return this.seaAccess;
    }

    protected final boolean getSeaAccess_HavePort() {
        return this.seaAccess_HavePort;
    }

    protected final boolean getSeaAccess_HavePort_Check() {
        for (int i = 0; i < this.getProvincesSize(); ++i) {
            if (CFG.game.getProvince(this.getProvince(i)).getLevelOfPort() <= 0) continue;
            return true;
        }
        return false;
    }

    protected final List<Integer> getShortestPath() {
        return this.shortestLine;
    }

    protected final void removeProvince(int n) {
        CFG.game.getProvince(this.lProvinces.get(n)).setCivRegionID(-1);
        for (int i = 0; i < this.lCostalineProvinces.size(); ++i) {
            if (this.lCostalineProvinces.get(i) != this.lProvinces.get(n)) continue;
            this.lCostalineProvinces.remove(i);
            break;
        }
        this.lProvinces.remove(n);
        this.iProvincesSize = this.lProvinces.size();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected final void removeProvinceID(int var1_1) {
        block19: {
            block20: {
                block21: {
                    block18: {
                        for (var2_2 = 0; var2_2 < this.iProvincesSize; ++var2_2) {
                            if (this.lProvinces.get(var2_2) != var1_1) continue;
                            this.lProvinces.remove(var2_2);
                            this.iProvincesSize = this.lProvinces.size();
                            var2_2 = 0;
lbl7:
                            // 2 sources

                            while (true) {
                                if (var2_2 < this.lCostalineProvinces.size()) {
                                    if (this.lCostalineProvinces.get(var2_2) != var1_1) break block18;
                                    this.lCostalineProvinces.remove(var2_2);
                                }
                                CFG.game.getProvince(var1_1).setCivRegionID(-1);
                                break;
                            }
                            break;
                        }
                        if (!this.seaAccess) break block20;
                        break block21;
                    }
                    ++var2_2;
                    ** while (true)
                }
                this.seaAccess = false;
                var2_2 = 0;
                block2: while (true) {
                    if (var2_2 >= this.iProvincesSize) {
                        if (!this.seaAccess) {
                            this.seaAccess_HavePort = false;
                            break;
                        }
                        if (!this.seaAccess_HavePort) break;
                        break block19;
                    }
                    var3_3 = 0;
                    while (true) {
                        block23: {
                            block22: {
                                var4_4 = var2_2;
                                if (var3_3 >= CFG.game.getProvince(this.getProvince(var2_2)).getNeighboringSeaProvincesSize()) break block22;
                                if (CFG.game.getProvince(CFG.game.getProvince(this.getProvince(var2_2)).getNeighboringSeaProvinces(var3_3)).getLevelOfPort() != -2) break block23;
                                this.seaAccess = true;
                                var4_4 = this.iProvincesSize;
                            }
                            var2_2 = var4_4 + 1;
                            continue block2;
                        }
                        ++var3_3;
                    }
                    break;
                }
            }
lbl43:
            // 3 sources

            while (true) {
                if (this.haveNotOccupiedProvince == false) return;
                if (CFG.game.getProvince(var1_1).getLevelOfSupply() <= 0 && !this.seaAccess_HavePort) {
                    if (CFG.game.getProvince(var1_1).getIsCapital() == false) return;
                }
                this.haveNotOccupiedProvince = false;
                var1_1 = 0;
                while (var1_1 < this.iProvincesSize) {
                    var2_2 = CFG.game.getProvince(this.getProvince(var1_1)).getCivID();
                    if (!CFG.game.getCiv((int)var2_2).civGameData.haveNotMoney && (CFG.game.getProvince(this.getProvince(var1_1)).getLevelOfSupply() > 0 || this.seaAccess_HavePort || CFG.game.getProvince(this.getProvince(var1_1)).getIsCapital())) {
                        this.haveNotOccupiedProvince = true;
                        return;
                    }
                    ++var1_1;
                }
                return;
            }
        }
        this.seaAccess_HavePort = false;
        var2_2 = 0;
        while (true) {
            if (var2_2 >= this.iProvincesSize) ** GOTO lbl43
            if (CFG.game.getProvince(this.getProvince(var2_2)).getLevelOfPort() > 0) {
                this.seaAccess_HavePort = true;
                ** continue;
            }
            ++var2_2;
        }
    }

    protected final boolean setIsSupplied(boolean bl) {
        this.isSupplied = bl;
        return this.getIsSupplied();
    }

    protected final void setRegionID(int n) {
        this.iRegionID = n;
        for (int i = 0; i < this.iProvincesSize; ++i) {
            CFG.game.getProvince(i).setCivRegionID(n);
        }
    }

    protected final void setSeaAccess_HavePort(boolean bl) {
        this.seaAccess_HavePort = bl;
    }

    protected final void updateDrawRegionName() {
        this.drawName = true;
        if (CFG.FOG_OF_WAR == 2) {
            for (int i = 0; i < this.lProvinces.size(); ++i) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(this.lProvinces.get(i))) continue;
                this.drawName = false;
                break;
            }
        }
    }
}

