/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Tribute_Vassal
extends Button_Build {
    private int iCivID;
    private int iIdelogyID;

    protected Button_Tribute_Vassal(String string2, int n, int n2, int n3, int n4) {
        super(string2, Images.diplo_vassal, 0, 0, n2, n3, Button_Diplomacy.iDiploWidth, true, false, 0, 0.0f);
        this.setHeight(CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 4);
        this.iIdelogyID = n;
        this.iCivID = n4;
    }

    @Override
    protected void actionElement(int n) {
        if (CFG.game.getCiv(this.iCivID).getCapitalProvinceID() >= 0) {
            CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getCiv(this.iCivID).getCapitalProvinceID());
            CFG.toast.setInView(CFG.game.getProvince(CFG.game.getCiv(this.iCivID).getCapitalProvinceID()).getName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        }
    }

    @Override
    protected void buildElementHover() {
        this.menuElementHover = CFG.ideologiesManager.getIdeologyHover_Just(this.iIdelogyID);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.ideologiesManager.getIdeology(this.iIdelogyID).getCrownImageScaled().draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.ideologiesManager.getIdeology(this.iIdelogyID).getCrownImageScaled().getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.ideologiesManager.getIdeology(this.iIdelogyID).getCrownImageScaled().getHeight() / 2 + n2);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        }
    }
}

