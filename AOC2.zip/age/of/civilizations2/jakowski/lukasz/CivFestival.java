/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class CivFestival
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iProvinceID;
    protected int iTurnsLeft;

    protected CivFestival(int n, int n2) {
        this.iProvinceID = n;
        this.iTurnsLeft = n2;
    }
}

