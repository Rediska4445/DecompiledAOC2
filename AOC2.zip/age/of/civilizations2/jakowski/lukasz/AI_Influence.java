/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class AI_Influence
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iCivID;
    protected int iMinRelation;
    protected int iUntilTurnID;

    protected AI_Influence(int n, int n2, int n3) {
        this.iCivID = n;
        this.iMinRelation = n2;
        this.iUntilTurnID = n3;
    }
}

