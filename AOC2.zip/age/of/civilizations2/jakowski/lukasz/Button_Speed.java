/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Speed
extends Button {
    protected Button_Speed(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f = CFG.COLOR_GRADIENT_TITLE_BLUE.r;
        float f2 = CFG.COLOR_GRADIENT_TITLE_BLUE.g;
        float f3 = CFG.COLOR_GRADIENT_TITLE_BLUE.b;
        float f4 = bl ? 0.8f : (this.getIsHovered() ? 0.65f : 0.5f);
        spriteBatch.setColor(new Color(f, f2, f3, f4));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
        f3 = CFG.COLOR_GRADIENT_TITLE_BLUE.r;
        f = CFG.COLOR_GRADIENT_TITLE_BLUE.g;
        f2 = CFG.COLOR_GRADIENT_TITLE_BLUE.b;
        f4 = bl ? 0.45f : (this.getIsHovered() ? 0.35f : 0.275f);
        spriteBatch.setColor(new Color(f3, f, f2, f4));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING, this.getHeight(), true, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING, this.getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_NEW_GAME_EDGE_LINE.r, CFG.COLOR_NEW_GAME_EDGE_LINE.b, CFG.COLOR_NEW_GAME_EDGE_LINE.b, 0.45f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(CFG.COLOR_NEW_GAME_EDGE_LINE);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, 1, this.getHeight() / 2, false, true);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, 1, this.getHeight() / 2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
        CFG.drawText(spriteBatch, string2, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_RANK_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_RANK_HOVER : CFG.COLOR_TEXT_RANK) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

