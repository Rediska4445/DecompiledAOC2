/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Toast;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Editor_NeighboringProvinces
extends Editor {
    protected int activeProvinceID = -1;

    Editor_NeighboringProvinces() {
    }

    protected static final void updateProvince(int n) {
        Object object = Gdx.files;
        String[] arrstring = new StringBuilder();
        arrstring.append("map/");
        arrstring.append(CFG.map.getFile_ActiveMap_Path());
        arrstring.append("update/");
        arrstring.append(n);
        object = object.internal(arrstring.toString()).readString().split(";");
        arrstring = object[0].split(",");
        String[] arrstring2 = object[1].split(",");
        ArrayList<Short> arrayList = new ArrayList<Short>();
        object = new ArrayList();
        for (int i = 0; i < arrstring.length; ++i) {
            arrayList.add((short)Integer.parseInt(arrstring[i]));
            object.add((short)Integer.parseInt(arrstring2[i]));
        }
        try {
            CFG.game.getProvince(n).setPoints(arrayList, (List<Short>)object);
            CFG.game.getProvince(n).buildProvinceBG(true);
            CFG.game.getProvince(n).loadProvinceBG();
            CFG.game.buildGameProvinceData(CFG.game.getActiveProvinceID());
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            Toast toast = CFG.toast;
            object = new StringBuilder();
            ((StringBuilder)object).append("FILE NOT FOUND: [map/");
            ((StringBuilder)object).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object).append("update/");
            ((StringBuilder)object).append(n);
            ((StringBuilder)object).append("]");
            toast.setInView(((StringBuilder)object).toString());
        }
    }

    @Override
    protected void keyDown(int n) {
        Serializable serializable;
        int n2;
        Object object;
        Object object2;
        Object object3;
        if (Gdx.input.isKeyPressed(62)) {
            CFG.MANAGE_DIPLOMACY_ADD_NEW_PACT_CIV2 = this.activeProvinceID = CFG.game.getActiveProvinceID();
            CFG.menuManager.rebuildMapEditor_Connections_IDs(this.activeProvinceID);
        }
        n = CFG.game.getActiveProvinceID();
        int n3 = 0;
        int n4 = 0;
        if (n >= 0) {
            if (Gdx.input.isKeyPressed(19)) {
                object3 = Gdx.files;
                object2 = new StringBuilder();
                ((StringBuilder)object2).append("map/");
                ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
                ((StringBuilder)object2).append("updatePB/");
                ((StringBuilder)object2).append(CFG.game.getActiveProvinceID());
                object2 = object3.internal(((StringBuilder)object2).toString()).readString().split(";");
                object = object2[0].split(",");
                object3 = object2[1].split(",");
                object2 = object2[2].split(",");
                n2 = Integer.parseInt((String)object[0]);
                object = new ArrayList();
                serializable = new ArrayList();
                n = 0;
                while (true) {
                    if (n >= ((String[])object3).length) break;
                    object.add((short)Integer.parseInt(object3[n]));
                    serializable.add((short)Integer.parseInt(object2[n]));
                    ++n;
                    continue;
                    break;
                }
                try {
                    CFG.game.getProvince(CFG.game.getActiveProvinceID()).removeProvinceBorder(n2);
                    CFG.game.getProvince(CFG.game.getActiveProvinceID()).addProvinceBorder(n2, (List<Short>)object, (List<Short>)((Object)serializable));
                    CFG.game.buildGameProvinceData(CFG.game.getActiveProvinceID());
                }
                catch (GdxRuntimeException gdxRuntimeException) {
                    object3 = CFG.toast;
                    object2 = new StringBuilder();
                    ((StringBuilder)object2).append("FILE NOT FOUND: [map/");
                    ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
                    ((StringBuilder)object2).append("updatePB/");
                    ((StringBuilder)object2).append(CFG.game.getActiveProvinceID());
                    ((StringBuilder)object2).append("]");
                    ((Toast)object3).setInView(((StringBuilder)object2).toString());
                }
            } else if (Gdx.input.isKeyPressed(20)) {
                Editor_NeighboringProvinces.updateProvince(CFG.game.getActiveProvinceID());
            }
        }
        if (Gdx.input.isKeyPressed(45)) {
            if (CFG.game.getActiveProvinceID() < 0) {
                return;
            }
            object3 = object2 = "";
            for (n = 0; n < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize(); ++n) {
                object = new StringBuilder();
                ((StringBuilder)object).append((String)object2);
                ((StringBuilder)object).append("");
                ((StringBuilder)object).append(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n) / CFG.map.getMapBG().getMapScale());
                ((StringBuilder)object).append(",");
                object2 = ((StringBuilder)object).toString();
                object = new StringBuilder();
                ((StringBuilder)object).append((String)object3);
                ((StringBuilder)object).append("");
                ((StringBuilder)object).append(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n) / CFG.map.getMapBG().getMapScale());
                ((StringBuilder)object).append(",");
                object3 = ((StringBuilder)object).toString();
            }
            object3 = Gdx.files;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("map/");
            ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
            ((StringBuilder)object2).append("MAP_POINTS");
            object = object3.local(((StringBuilder)object2).toString());
            ((FileHandle)object).writeString("", false);
            for (n = 0; n < CFG.game.getProvincesSize(); ++n) {
                object3 = object2 = "";
                for (n2 = 0; n2 < CFG.game.getProvince(n).getPointsSize(); ++n2) {
                    serializable = new StringBuilder();
                    ((StringBuilder)serializable).append((String)object2);
                    ((StringBuilder)serializable).append("");
                    ((StringBuilder)serializable).append(CFG.game.getProvince(n).getPointsX(n2) / CFG.map.getMapBG().getMapScale());
                    object2 = CFG.game.getProvince(n).getPointsSize() - 1 == n2 ? "" : ",";
                    ((StringBuilder)serializable).append((String)object2);
                    object2 = ((StringBuilder)serializable).toString();
                    serializable = new StringBuilder();
                    ((StringBuilder)serializable).append((String)object3);
                    ((StringBuilder)serializable).append("");
                    ((StringBuilder)serializable).append(CFG.game.getProvince(n).getPointsY(n2) / CFG.map.getMapBG().getMapScale());
                    object3 = CFG.game.getProvince(n).getPointsSize() - 1 == n2 ? "" : ",";
                    ((StringBuilder)serializable).append((String)object3);
                    object3 = ((StringBuilder)serializable).toString();
                }
                serializable = new StringBuilder();
                ((StringBuilder)serializable).append((String)object2);
                ((StringBuilder)serializable).append("\n");
                ((FileHandle)object).writeString(((StringBuilder)serializable).toString(), true);
                object2 = new StringBuilder();
                ((StringBuilder)object2).append((String)object3);
                ((StringBuilder)object2).append("\n");
                ((FileHandle)object).writeString(((StringBuilder)object2).toString(), true);
            }
        }
        if (this.activeProvinceID < 0) {
            return;
        }
        if (Gdx.input.isKeyPressed(66) && this.activeProvinceID != CFG.game.getActiveProvinceID()) {
            for (n = 0; n < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getNeighboringProvincesSize(); ++n) {
                if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getNeighboringProvinces(n) != this.activeProvinceID) continue;
                return;
            }
            for (n = 0; n < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getNeighboringSeaProvincesSize(); ++n) {
                if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getNeighboringSeaProvinces(n) != this.activeProvinceID) continue;
                return;
            }
            for (n = 0; n < CFG.game.getProvince(this.activeProvinceID).getNeighboringSeaProvincesSize(); ++n) {
                if (CFG.game.getProvince(this.activeProvinceID).getNeighboringSeaProvinces(n) != CFG.game.getActiveProvinceID()) continue;
                return;
            }
            if (CFG.game.getProvince(this.activeProvinceID).getSeaProvince()) {
                CFG.game.getProvince(this.activeProvinceID).addNeighboringProvince(CFG.game.getActiveProvinceID());
            } else if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince()) {
                CFG.game.getProvince(this.activeProvinceID).addNeighboringSeaProvince(CFG.game.getActiveProvinceID());
                CFG.game.getProvince(this.activeProvinceID).setLevelOfPort(1);
            } else {
                CFG.game.getProvince(this.activeProvinceID).addNeighboringProvince(CFG.game.getActiveProvinceID());
            }
            if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).addNeighboringProvince(this.activeProvinceID);
            } else if (CFG.game.getProvince(this.activeProvinceID).getSeaProvince()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).addNeighboringSeaProvince(this.activeProvinceID);
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setLevelOfPort(1);
            } else {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).addNeighboringProvince(this.activeProvinceID);
            }
            object2 = new ArrayList();
            object3 = new ArrayList();
            for (n2 = 0; n2 < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize(); ++n2) {
                if (CFG.game.getProvince(this.activeProvinceID).getPointsSize() > 0) {
                    block90: {
                        int n5;
                        int n6;
                        int n7 = CFG.game.getProvince(this.activeProvinceID).getPointsSize();
                        int n8 = 0;
                        for (n6 = 0; n6 < n7; ++n6) {
                            n = n8;
                            if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize() - 1) == CFG.game.getProvince(this.activeProvinceID).getPointsX(n6)) {
                                n = n8;
                                if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize() - 1) == CFG.game.getProvince(this.activeProvinceID).getPointsY(n6)) {
                                    n = 1;
                                }
                            }
                            n8 = n;
                        }
                        if (n8 != 0) {
                            n7 = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize();
                            n = 0;
                            for (n8 = 0; n8 < n7; ++n8) {
                                n6 = n;
                                if (CFG.game.getProvince(this.activeProvinceID).getPointsX(CFG.game.getProvince(this.activeProvinceID).getPointsSize() - 1) == CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n8)) {
                                    n6 = n;
                                    if (CFG.game.getProvince(this.activeProvinceID).getPointsY(CFG.game.getProvince(this.activeProvinceID).getPointsSize() - 1) == CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n8)) {
                                        n6 = 1;
                                    }
                                }
                                n = n6;
                            }
                            if (n == 0) {
                                n6 = 0;
                                for (n = CFG.game.getProvince(this.activeProvinceID).getPointsSize() - 1; n >= 0; --n) {
                                    block88: {
                                        block89: {
                                            if (n6 == 0) {
                                                n5 = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize();
                                                n7 = 0;
                                                while (true) {
                                                    n8 = n6;
                                                    if (n7 >= n5) break block88;
                                                    if (CFG.game.getProvince(this.activeProvinceID).getPointsX(n) == CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n7) && CFG.game.getProvince(this.activeProvinceID).getPointsY(n) == CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n7)) {
                                                        object2.add((short)CFG.game.getProvince(this.activeProvinceID).getPointsX(n));
                                                        object3.add((short)CFG.game.getProvince(this.activeProvinceID).getPointsY(n));
                                                        n8 = 1;
                                                        break block88;
                                                    }
                                                    ++n7;
                                                }
                                            }
                                            n7 = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize();
                                            for (n8 = 0; n8 < n7; ++n8) {
                                                if (CFG.game.getProvince(this.activeProvinceID).getPointsX(n) != CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n8) || CFG.game.getProvince(this.activeProvinceID).getPointsY(n) != CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n8)) continue;
                                                object2.add((short)CFG.game.getProvince(this.activeProvinceID).getPointsX(n));
                                                object3.add((short)CFG.game.getProvince(this.activeProvinceID).getPointsY(n));
                                                n7 = 0;
                                                break block89;
                                            }
                                            n7 = 1;
                                        }
                                        n8 = n6;
                                        if (n7 != 0) break block90;
                                    }
                                    n6 = n8;
                                }
                            } else {
                                for (n = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize() - 1; n >= 0; --n) {
                                    block91: {
                                        n8 = CFG.game.getProvince(this.activeProvinceID).getPointsSize();
                                        for (n6 = 0; n6 < n8; ++n6) {
                                            if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n) != CFG.game.getProvince(this.activeProvinceID).getPointsX(n6) || CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n) != CFG.game.getProvince(this.activeProvinceID).getPointsY(n6)) continue;
                                            n6 = 1;
                                            break block91;
                                        }
                                        n6 = 0;
                                    }
                                    if (n6 != 0) continue;
                                    while (++n < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize() - 1) {
                                        object2.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n));
                                        object3.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n));
                                    }
                                    break;
                                }
                                for (n = 0; n < CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize(); ++n) {
                                    block92: {
                                        for (n6 = 0; n6 < CFG.game.getProvince(this.activeProvinceID).getPointsSize(); ++n6) {
                                            if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n) != CFG.game.getProvince(this.activeProvinceID).getPointsX(n6) || CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n) != CFG.game.getProvince(this.activeProvinceID).getPointsY(n6)) continue;
                                            n6 = 1;
                                            break block92;
                                        }
                                        n6 = 0;
                                    }
                                    if (n6 != 0) {
                                        object2.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n));
                                        object3.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n));
                                        continue;
                                    }
                                    break;
                                }
                            }
                        } else {
                            n6 = 0;
                            for (n = CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsSize() - 1; n >= 0; --n) {
                                block93: {
                                    block94: {
                                        if (n6 == 0) {
                                            n5 = CFG.game.getProvince(this.activeProvinceID).getPointsSize();
                                            n7 = 0;
                                            while (true) {
                                                n8 = n6;
                                                if (n7 >= n5) break block93;
                                                if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n) == CFG.game.getProvince(this.activeProvinceID).getPointsX(n7) && CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n) == CFG.game.getProvince(this.activeProvinceID).getPointsY(n7)) {
                                                    object2.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n));
                                                    object3.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n));
                                                    n8 = 1;
                                                    break block93;
                                                }
                                                ++n7;
                                            }
                                        }
                                        n7 = CFG.game.getProvince(this.activeProvinceID).getPointsSize();
                                        for (n8 = 0; n8 < n7; ++n8) {
                                            if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n) != CFG.game.getProvince(this.activeProvinceID).getPointsX(n8) || CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n) != CFG.game.getProvince(this.activeProvinceID).getPointsY(n8)) continue;
                                            object2.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsX(n));
                                            object3.add((short)CFG.game.getProvince(CFG.game.getActiveProvinceID()).getPointsY(n));
                                            n7 = 0;
                                            break block94;
                                        }
                                        n7 = 1;
                                    }
                                    n8 = n6;
                                    if (n7 != 0) break block90;
                                }
                                n6 = n8;
                            }
                        }
                    }
                    n = 1;
                } else {
                    n = 0;
                }
                if (n != 0) break;
            }
            for (n = 0; n < object2.size(); ++n) {
                object2.set(n, (short)((Short)object2.get(n) / CFG.map.getMapBG().getMapScale()));
                object3.set(n, (short)((Short)object3.get(n) / CFG.map.getMapBG().getMapScale()));
            }
            if (this.activeProvinceID > CFG.game.getActiveProvinceID()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).addProvinceBorder(this.activeProvinceID, (List<Short>)object2, (List<Short>)object3);
            } else {
                CFG.game.getProvince(this.activeProvinceID).addProvinceBorder(CFG.game.getActiveProvinceID(), (List<Short>)object2, (List<Short>)object3);
            }
            CFG.game.buildGameProvinceData(this.activeProvinceID);
            CFG.game.buildGameProvinceData(CFG.game.getActiveProvinceID());
            object3 = CFG.toast;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("Added"));
            ((StringBuilder)object2).append(" [");
            ((StringBuilder)object2).append(this.activeProvinceID);
            ((StringBuilder)object2).append(" - ");
            ((StringBuilder)object2).append(CFG.game.getActiveProvinceID());
            ((StringBuilder)object2).append("]");
            ((Toast)object3).setInView(((StringBuilder)object2).toString());
            CFG.menuManager.rebuildMapEditor_Connections_IDs(this.activeProvinceID);
        }
        if (Gdx.input.isKeyPressed(41) && this.activeProvinceID != CFG.game.getActiveProvinceID()) {
            object2 = new ArrayList();
            object3 = new ArrayList();
            if (this.activeProvinceID > CFG.game.getActiveProvinceID()) {
                for (n = 0; n < CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandByLand((int)this.activeProvinceID).lPointsX.size(); ++n) {
                    object2.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandByLand((int)this.activeProvinceID).lPointsX.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandByLand((int)this.activeProvinceID).lPointsX.size() - 1 - n)));
                    object3.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandByLand((int)this.activeProvinceID).lPointsY.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandByLand((int)this.activeProvinceID).lPointsY.size() - 1 - n)));
                }
                if (object2.size() == 0) {
                    for (n = 0; n < CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandBySea((int)this.activeProvinceID).lPointsX.size(); ++n) {
                        object2.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandBySea((int)this.activeProvinceID).lPointsX.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandBySea((int)this.activeProvinceID).lPointsX.size() - 1 - n)));
                        object3.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandBySea((int)this.activeProvinceID).lPointsY.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersLandBySea((int)this.activeProvinceID).lPointsY.size() - 1 - n)));
                    }
                }
                if (object2.size() == 0) {
                    for (n = n4; n < CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersSeaBySea((int)this.activeProvinceID).lPointsX.size(); ++n) {
                        object2.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersSeaBySea((int)this.activeProvinceID).lPointsX.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersSeaBySea((int)this.activeProvinceID).lPointsX.size() - 1 - n)));
                        object3.add(Short.valueOf(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersSeaBySea((int)this.activeProvinceID).lPointsY.get(CFG.game.getProvince((int)CFG.game.getActiveProvinceID()).getProvinceBordersSeaBySea((int)this.activeProvinceID).lPointsY.size() - 1 - n)));
                    }
                }
            } else {
                for (n = 0; n < CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandByLand((int)CFG.game.getActiveProvinceID()).lPointsX.size(); ++n) {
                    object2.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandByLand((int)CFG.game.getActiveProvinceID()).lPointsX.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandByLand((int)CFG.game.getActiveProvinceID()).lPointsX.size() - 1 - n)));
                    object3.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandByLand((int)CFG.game.getActiveProvinceID()).lPointsY.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandByLand((int)CFG.game.getActiveProvinceID()).lPointsY.size() - 1 - n)));
                }
                if (object2.size() == 0) {
                    for (n = 0; n < CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandBySea((int)CFG.game.getActiveProvinceID()).lPointsX.size(); ++n) {
                        object2.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandBySea((int)CFG.game.getActiveProvinceID()).lPointsX.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandBySea((int)CFG.game.getActiveProvinceID()).lPointsX.size() - 1 - n)));
                        object3.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandBySea((int)CFG.game.getActiveProvinceID()).lPointsY.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersLandBySea((int)CFG.game.getActiveProvinceID()).lPointsY.size() - 1 - n)));
                    }
                }
                if (object2.size() == 0) {
                    for (n = n3; n < CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersSeaBySea((int)CFG.game.getActiveProvinceID()).lPointsX.size(); ++n) {
                        object2.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersSeaBySea((int)CFG.game.getActiveProvinceID()).lPointsX.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersSeaBySea((int)CFG.game.getActiveProvinceID()).lPointsX.size() - 1 - n)));
                        object3.add(Short.valueOf(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersSeaBySea((int)CFG.game.getActiveProvinceID()).lPointsY.get(CFG.game.getProvince((int)this.activeProvinceID).getProvinceBordersSeaBySea((int)CFG.game.getActiveProvinceID()).lPointsY.size() - 1 - n)));
                    }
                }
            }
            if (this.activeProvinceID > CFG.game.getActiveProvinceID()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).removeProvinceBorder(this.activeProvinceID);
            } else {
                CFG.game.getProvince(this.activeProvinceID).removeProvinceBorder(CFG.game.getActiveProvinceID());
            }
            if (this.activeProvinceID > CFG.game.getActiveProvinceID()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).addProvinceBorder(this.activeProvinceID, (List<Short>)object2, (List<Short>)object3);
            } else {
                CFG.game.getProvince(this.activeProvinceID).addProvinceBorder(CFG.game.getActiveProvinceID(), (List<Short>)object2, (List<Short>)object3);
            }
            CFG.game.buildGameProvinceData(this.activeProvinceID);
            CFG.game.buildGameProvinceData(CFG.game.getActiveProvinceID());
        }
        if (Gdx.input.isKeyPressed(67) && this.activeProvinceID != CFG.game.getActiveProvinceID()) {
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).removeNeighboringProvince(this.activeProvinceID);
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).removeNeighboringSeaProvince(this.activeProvinceID);
            CFG.game.getProvince(this.activeProvinceID).removeNeighboringProvince(CFG.game.getActiveProvinceID());
            CFG.game.getProvince(this.activeProvinceID).removeNeighboringSeaProvince(CFG.game.getActiveProvinceID());
            if (!CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince() && CFG.game.getProvince(CFG.game.getActiveProvinceID()).getNeighboringSeaProvincesSize() == 0) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).setLevelOfPort(-1);
            }
            if (!CFG.game.getProvince(this.activeProvinceID).getSeaProvince() && CFG.game.getProvince(this.activeProvinceID).getNeighboringSeaProvincesSize() == 0) {
                CFG.game.getProvince(this.activeProvinceID).setLevelOfPort(-1);
            }
            if (this.activeProvinceID > CFG.game.getActiveProvinceID()) {
                CFG.game.getProvince(CFG.game.getActiveProvinceID()).removeProvinceBorder(this.activeProvinceID);
            } else {
                CFG.game.getProvince(this.activeProvinceID).removeProvinceBorder(CFG.game.getActiveProvinceID());
            }
            CFG.game.buildGameProvinceData(this.activeProvinceID);
            CFG.game.buildGameProvinceData(CFG.game.getActiveProvinceID());
            object3 = CFG.toast;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append(CFG.langManager.get("Removed"));
            ((StringBuilder)object2).append(" [");
            ((StringBuilder)object2).append(this.activeProvinceID);
            ((StringBuilder)object2).append(" - ");
            ((StringBuilder)object2).append(CFG.game.getActiveProvinceID());
            ((StringBuilder)object2).append("]");
            ((Toast)object3).setInView(((StringBuilder)object2).toString());
            CFG.menuManager.rebuildMapEditor_Connections_IDs(this.activeProvinceID);
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ACTIVE PROVINCE ID: ");
        stringBuilder.append(this.activeProvinceID);
        stringBuilder.append("\n\nSPACE -> SET ACTIVE PROVINCE\nENTER -> ADD CONNECTION\nBACKSPACE -> REMOVE CONNECTION\nM -> REFLECT PROVINCE BORDER\n\nUP -> UPDATE PB VIA FILE\nDOWN -> UPDATE PROVINCE VIA FILE");
        return stringBuilder.toString();
    }
}

