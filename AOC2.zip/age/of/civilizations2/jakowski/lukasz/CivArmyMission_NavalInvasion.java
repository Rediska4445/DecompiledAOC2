/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_NeighProvinces;
import age.of.civilizations2.jakowski.lukasz.AI_ProvinceInfo_War;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_AtWar;
import com.badlogic.gdx.Gdx;
import java.util.ArrayList;

class CivArmyMission_NavalInvasion
extends CivArmyMission {
    private int iCivID;
    protected int moveArmyInNextXTurns = 1;
    protected int numOfUnitsMoved = 0;

    protected CivArmyMission_NavalInvasion(int n, int n2, int n3) {
        this.iProvinceID = n2;
        this.toProvinceID = n3;
        this.MISSION_ID = -1;
        this.iCivID = n;
        this.MISSION_TYPE = CivArmyMission_Type.NAVAL_INVASION;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = 10;
        this.iArmy = (int)((float)CFG.game.getProvince(n2).getArmyCivID(n) * ((float)CFG.oR.nextInt(25) / 100.0f + 0.685f));
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean action(int n) {
        if (!CFG.game.getCivsAtWar(n, CFG.game.getProvince(this.toProvinceID).getCivID())) {
            if (!CFG.game.getCivsAreAllied(n, CFG.game.getProvince(this.toProvinceID).getCivID())) {
                this.iObsolate = 0;
                return true;
            }
            if (!CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getCivRegion(CFG.game.getProvince(this.toProvinceID).getCivRegionID()).checkRegionBordersWithEnemy(n)) {
                this.iObsolate = 0;
                return true;
            }
        }
        if (CFG.game.getProvince(this.iProvinceID).getBordersWithEnemy()) {
            this.iObsolate = 0;
            return true;
        }
        if (CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getCivRegion(CFG.game.getProvince(this.iProvinceID).getCivRegionID()).checkRegionBordersWithEnemy(n)) {
            this.iObsolate = 0;
            return true;
        }
        if ((float)CFG.game.getCiv(n).getMovePoints() < (float)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE * 2.5f) {
            return false;
        }
        Object object = Gdx.app;
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("NavalInvasion -> ");
        ((StringBuilder)object2).append(CFG.game.getCiv(n).getCivName());
        object.log("AoC", ((StringBuilder)object2).toString());
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfPort() <= 0 || this.action_BuildPort(this.iProvinceID, this.toProvinceID)) {
            int n2;
            int n3;
            int n4;
            object = Gdx.app;
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("NavalInvasion -> 000, moveArmyInNextXTurns: ");
            ((StringBuilder)object2).append(this.moveArmyInNextXTurns);
            object.log("AoC", ((StringBuilder)object2).toString());
            if (CFG.game.getProvince(this.iProvinceID).getArmyCivID(n) > 0) {
                n4 = this.moveArmyInNextXTurns;
                this.moveArmyInNextXTurns = n4 - 1;
                if (n4 <= 0) {
                    object = new RegroupArmy_Data_AtWar(n, this.iProvinceID, this.toProvinceID);
                    if (((RegroupArmy_Data)object).getRouteSize() <= 0) {
                        this.iObsolate = 0;
                        return true;
                    }
                    int n5 = CFG.game.getProvince(this.iProvinceID).getArmyCivID(n);
                    if (CFG.game.getCivsAtWar(n, CFG.game.getProvince(this.toProvinceID).getCivID())) {
                        n3 = 0;
                        n4 = 0;
                        while (true) {
                            n2 = n4;
                            if (n3 < CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getCivRegion(CFG.game.getProvince(this.toProvinceID).getCivRegionID()).getProvincesSize()) {
                                n4 += CFG.game.getProvinceArmy(CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getCivRegion(CFG.game.getProvince(this.toProvinceID).getCivRegionID()).getProvince(n3));
                                ++n3;
                                continue;
                            }
                            break;
                        }
                    } else {
                        if (!CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getCivRegion(CFG.game.getProvince(this.toProvinceID).getCivRegionID()).checkRegionBordersWithEnemy(n)) {
                            this.iObsolate = 0;
                            return true;
                        }
                        n2 = 0;
                    }
                    object2 = Gdx.app;
                    Object object3 = new StringBuilder();
                    ((StringBuilder)object3).append("NavalInvasion -> enemyArmy: ");
                    ((StringBuilder)object3).append(n2);
                    object2.log("AoC", ((StringBuilder)object3).toString());
                    float f = n2;
                    if (0.825f * f > (float)CFG.game.getCiv(n).getNumOfUnits()) {
                        this.moveArmyInNextXTurns = Math.max(this.moveArmyInNextXTurns, 3);
                        Gdx.app.log("AoC", "NavalInvasion -> enemyArmy: RETURN 000");
                        return false;
                    }
                    if (0.915f * f > (float)(this.numOfUnitsMoved + n5)) {
                        this.moveArmyInNextXTurns = Math.max(this.moveArmyInNextXTurns, 3);
                        Gdx.app.log("AoC", "NavalInvasion -> enemyArmy: RETURN 1111");
                        return false;
                    }
                    float f2 = n5;
                    if (f2 > f * 1.175f) {
                        double d;
                        double d2;
                        double d3;
                        if ((float)CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getMoney() + Math.max(0.0f, (float)CFG.game.getCiv((int)CFG.game.getProvince((int)this.toProvinceID).getCivID()).iBudget * 1.5f) > 0.0f) {
                            if (f2 > (float)((long)n2 + CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getMoney() / 5L) * 1.175f) {
                                d3 = n5;
                                d2 = CFG.oR.nextInt(10) + 5;
                                d = Math.ceil((f + ((float)CFG.game.getCiv(CFG.game.getProvince(this.toProvinceID).getCivID()).getMoney() + Math.max(0.0f, (float)CFG.game.getCiv((int)CFG.game.getProvince((int)this.toProvinceID).getCivID()).iBudget * 1.5f)) / 10.0f) * 1.175f * ((float)CFG.oR.nextInt(925) / 1000.0f + 1.745f));
                                Double.isNaN(d2);
                                n4 = (int)Math.min(d3, d2 + d);
                                Gdx.app.log("AoC", "NavalInvasion -> enemyArmy: UPDATE 000");
                            } else {
                                n4 = n5;
                            }
                        } else {
                            d3 = n5;
                            d2 = CFG.oR.nextInt(10) + 5;
                            d = Math.ceil(f * ((float)CFG.oR.nextInt(925) / 1000.0f + 1.745f));
                            Double.isNaN(d2);
                            n4 = (int)Math.min(d3, d2 + d);
                            Gdx.app.log("AoC", "NavalInvasion -> enemyArmy: UPDATE 111");
                        }
                    } else {
                        n4 = n5;
                    }
                    if ((float)n4 > (float)CFG.game.getCiv(n).getNumOfUnits() * ((float)CFG.oR.nextInt(150) / 1000.0f + 0.525f)) {
                        n3 = n4 = (int)((float)(CFG.game.getCiv(n).getNumOfUnits() - this.numOfUnitsMoved) * ((float)CFG.oR.nextInt(150) / 1000.0f + 0.525f));
                        if (n4 <= 0) {
                            this.moveArmyInNextXTurns = ((RegroupArmy_Data)object).getRouteSize() + 6;
                            this.iArmy = 0;
                            return false;
                        }
                    } else {
                        n3 = n4;
                        if ((float)(this.numOfUnitsMoved + n4) > (float)CFG.game.getCiv(n).getNumOfUnits() * 0.525f) {
                            this.moveArmyInNextXTurns = ((RegroupArmy_Data)object).getRouteSize() + 5;
                            this.iArmy = 0;
                            return false;
                        }
                    }
                    n4 = n3;
                    if (CFG.game.getCiv(n).getBordersWithEnemy() == 0) {
                        n4 = n3;
                        if (CFG.game.getProvince(this.iProvinceID).getCivID() == n) {
                            n4 = n3;
                            if (CFG.game.getProvince(this.toProvinceID).getCivID() != n) {
                                n4 = (int)Math.ceil((float)n3 * ((float)CFG.oR.nextInt(33) / 100.0f + 0.46f));
                            }
                        }
                    }
                    object3 = Gdx.app;
                    object2 = new StringBuilder();
                    ((StringBuilder)object2).append("NavalInvasion -> enemyArmy: tArmyToRecruit_PRE: ");
                    ((StringBuilder)object2).append(n4);
                    object3.log("AoC", ((StringBuilder)object2).toString());
                    if (((RegroupArmy_Data)object).getRouteSize() == 1) {
                        if (CFG.gameAction.moveArmy(this.iProvinceID, this.toProvinceID, n4, n, true, false)) {
                            this.moveArmyInNextXTurns = 3;
                            this.numOfUnitsMoved += n4;
                            CFG.game.getCiv((int)n).civGameData.iNextPossibleNavalInvastionTurnID = Game_Calendar.TURN_ID + 4 + ((RegroupArmy_Data)object).getRouteSize() + CFG.oR.nextInt(14);
                            this.iObsolate = 0;
                            return true;
                        }
                        this.moveArmyInNextXTurns = 1;
                    } else if (CFG.gameAction.moveArmy(this.iProvinceID, ((RegroupArmy_Data)object).getRoute(0), n4, n, true, false)) {
                        ((RegroupArmy_Data)object).setFromProvinceID(((RegroupArmy_Data)object).getRoute(0));
                        ((RegroupArmy_Data)object).removeRoute(0);
                        ((RegroupArmy_Data)object).setNumOfUnits(n4);
                        CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)object);
                        this.moveArmyInNextXTurns = 3;
                        this.numOfUnitsMoved += n4;
                        CFG.game.getCiv((int)n).civGameData.iNextPossibleNavalInvastionTurnID = Game_Calendar.TURN_ID + 4 + ((RegroupArmy_Data)object).getRouteSize() + CFG.oR.nextInt(14);
                        this.iObsolate = 0;
                        return true;
                    }
                }
            }
            Gdx.app.log("AoC", "NavalInvasion -> 111");
            this.action_RecruitArmy(n);
            Gdx.app.log("AoC", "NavalInvasion -> 222");
            if (CFG.game.getCiv(n).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE && this.iObsolate > 1 && (object2 = CFG.oAI.getAllNeighboringProvincesInRange_Regroup_ForNavalInvasion(this.iProvinceID, n, this.iObsolate, new ArrayList<AI_NeighProvinces>(), new ArrayList<Integer>())).size() > 0) {
                while (CFG.game.getCiv(n).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_RECRUIT + CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE && object2.size() > 0) {
                    n3 = 0;
                    for (n4 = object2.size() - 1; n4 > 0; --n4) {
                        n2 = n3;
                        if (CFG.game.getProvince(((AI_NeighProvinces)object2.get((int)n4)).iProvinceID).getArmyCivID(n) > CFG.game.getProvince(((AI_NeighProvinces)object2.get((int)n3)).iProvinceID).getArmyCivID(n)) {
                            n2 = n4;
                        }
                        n3 = n2;
                    }
                    n4 = CFG.game.getProvince(((AI_NeighProvinces)object2.get((int)n3)).iProvinceID).getArmyCivID(n) - CFG.game.getCiv((int)n).civGameData.civPlans.haveMission_Army(((AI_NeighProvinces)object2.get((int)n3)).iProvinceID);
                    if (n4 > 0 && ((RegroupArmy_Data)(object = new RegroupArmy_Data(n, ((AI_NeighProvinces)object2.get((int)n3)).iProvinceID, this.iProvinceID))).getRouteSize() > 0) {
                        if (((RegroupArmy_Data)object).getRouteSize() == 1) {
                            CFG.gameAction.moveArmy(((AI_NeighProvinces)object2.get((int)n3)).iProvinceID, this.iProvinceID, n4, n, true, false);
                        } else if (CFG.gameAction.moveArmy(((AI_NeighProvinces)object2.get((int)n3)).iProvinceID, ((RegroupArmy_Data)object).getRoute(0), n4, n, true, false)) {
                            ((RegroupArmy_Data)object).setFromProvinceID(((RegroupArmy_Data)object).getRoute(0));
                            ((RegroupArmy_Data)object).removeRoute(0);
                            ((RegroupArmy_Data)object).setNumOfUnits(n4);
                            CFG.game.getCiv(n).addRegroupArmy((RegroupArmy_Data)object);
                        }
                    }
                    object2.remove(n3);
                }
            }
            Gdx.app.log("AoC", "NavalInvasion -> 333");
        }
        this.iArmy = (int)((float)CFG.game.getProvince(this.iProvinceID).getArmyCivID(n) * ((float)CFG.oR.nextInt(25) / 100.0f + 0.685f));
        return false;
    }

    protected final boolean action_BuildPort(int n, int n2) {
        if (CFG.game.getProvince(n).getLevelOfPort() == 0) {
            if (CFG.game.getProvince(n).getCivID() == this.iCivID) {
                if (CFG.game.getCiv(this.iCivID).isInConstruction(n, ConstructionType.PORT) == 0) {
                    if (BuildingsManager.constructPort(n, this.iCivID)) {
                        this.iObsolate = 10;
                        return false;
                    }
                    this.lockTreasury_Port(n);
                }
                return false;
            }
            this.iObsolate = 0;
            return false;
        }
        return true;
    }

    protected final boolean action_RecruitArmy(int n) {
        Gdx.app.log("AoC", "NavalInvasion -> action_RecruitArmy");
        if (CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).COST_OF_RECRUIT <= CFG.game.getCiv(this.iCivID).getMovePoints()) {
            ArrayList<AI_ProvinceInfo_War> arrayList = new ArrayList<AI_ProvinceInfo_War>();
            arrayList.add(new AI_ProvinceInfo_War(this.iProvinceID, 100, true));
            CFG.oAI.getAI_Style(CFG.game.getCiv(n).getAI_Style()).moveAtWar_Recruit(n, arrayList, new ArrayList<Integer>(), true);
        }
        Gdx.app.log("AoC", "NavalInvasion -> action_RecruitArmy END");
        return true;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        return true;
    }

    protected final void lockTreasury_Port(int n) {
        n = (int)((float)BuildingsManager.getPort_BuildCost(CFG.game.getProvince(n).getLevelOfPort() + 1, n) * 1.05f);
        CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = Math.max(CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury, n);
        if (CFG.game.getCiv((int)this.iCivID).iBudget > 0 && CFG.game.getCiv(this.iCivID).getMoney() > 0L) {
            CFG.game.getCiv(this.iCivID).getMoney();
        }
    }
}

