/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Alliances_Names_GameData_Bundle;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Alliances_Names_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private List<Alliances_Names_GameData_Bundle> lBundles = new ArrayList<Alliances_Names_GameData_Bundle>();
    private String sPackageName = "";

    protected Alliances_Names_GameData() {
    }

    protected final void addBundle(String string2) {
        this.lBundles.add(new Alliances_Names_GameData_Bundle(string2));
    }

    protected final Alliances_Names_GameData_Bundle getBundle(int n) {
        return this.lBundles.get(n);
    }

    protected final String getPackageName() {
        return this.sPackageName;
    }

    protected final int getSize() {
        return this.lBundles.size();
    }

    protected final void removeBundle(int n) {
        this.lBundles.remove(n);
    }

    protected final void setPackageName(String string2) {
        this.sPackageName = string2;
    }
}

