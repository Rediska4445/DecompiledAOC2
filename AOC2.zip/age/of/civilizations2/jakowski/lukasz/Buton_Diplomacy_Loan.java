/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Buton_Diplomacy_Loan
extends Button_Statistics {
    private static final float FONT_SCALE = 0.7f;
    private static final float FONT_SCALE2 = 0.6f;
    private int iCivA;
    private int iMoneyPerTurn;
    private int iTurnLeftDateWidth;
    private int iTurnLeftWidth;
    private String sTurnLeft;
    private String sTurnLeftDate;

    protected Buton_Diplomacy_Loan(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n4);
        super(stringBuilder.toString(), 0, n6, n7, n8, Math.max(CFG.TEXT_HEIGHT + CFG.PADDING * 4, (int)((float)CFG.BUTTON_HEIGHT * 0.6f)), false);
        boolean bl = n % 2 == 0;
        this.row = bl;
        this.iCivA = n2;
        this.iMoneyPerTurn = n3;
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("TurnsX", n5));
        stringBuilder.append(" ");
        this.sTurnLeft = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sTurnLeft);
        this.iTurnLeftWidth = (int)(CFG.glyphLayout.width * 0.6f);
        stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        stringBuilder.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + n5));
        stringBuilder.append("]");
        this.sTurnLeftDate = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sTurnLeftDate);
        this.iTurnLeftDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
    }

    private final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Buton_Diplomacy_Loan.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.2f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.15f));
                    }
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, Buton_Diplomacy_Loan.this.getPosX() + n, Buton_Diplomacy_Loan.this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + 1 + n2, Buton_Diplomacy_Loan.this.getWidth(), Buton_Diplomacy_Loan.this.getHeight() - 2, true, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Buton_Diplomacy_Loan.this.getPosX() + n, Buton_Diplomacy_Loan.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Buton_Diplomacy_Loan.this.getWidth(), Buton_Diplomacy_Loan.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Buton_Diplomacy_Loan.this.getPosX() + n, Buton_Diplomacy_Loan.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Buton_Diplomacy_Loan.this.getHeight() - 1 + n2 - Buton_Diplomacy_Loan.this.getHeight() / 4, Buton_Diplomacy_Loan.this.getWidth(), Buton_Diplomacy_Loan.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("GoldPerTurn"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.iMoneyPerTurn);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("Total"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.getText());
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.15f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.05f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        if (this.row) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.625f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Color color2;
        try {
            color2 = new Color((float)CFG.game.getCiv(this.iCivA).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivA).getB() / 255.0f, 1.0f);
            spriteBatch.setColor(color2);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        CFG.game.getCiv(this.iCivA).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - CFG.game.getCiv(this.iCivA).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        CFG.fontMain.getData().setScale(0.7f);
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + CFG.PADDING * 4 + 2 + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold)) / 2 - ImageManager.getImage(Images.top_gold).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold)));
        ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + this.getWidth() - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)) - CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time)) / 2 - ImageManager.getImage(Images.time).getHeight() + n2, (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)), (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time)));
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect));
        int n5 = CFG.PADDING;
        int n6 = this.getPosY();
        int n7 = this.getHeight() / 2;
        int n8 = (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f);
        color2 = bl ? CFG.COLOR_INGAME_GOLD_ACTIVE : (this.getIsHovered() ? CFG.COLOR_INGAME_GOLD_HOVER : CFG.COLOR_INGAME_GOLD);
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 + n5 * 3 + 2 + n, n6 + n7 - n8 + n2, color2);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sTurnLeft, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)) - this.iTurnLeftWidth - this.iTurnLeftDateWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sTurnLeftDate, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)) - this.iTurnLeftDateWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS : CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        return color2;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

