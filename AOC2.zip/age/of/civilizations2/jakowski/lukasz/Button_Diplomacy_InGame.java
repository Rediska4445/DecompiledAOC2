/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ViewsManager;
import java.util.List;

class Button_Diplomacy_InGame
extends Button_Diplomacy {
    protected Button_Diplomacy_InGame(int n, List<Integer> list, int n2, int n3, int n4) {
        super(n, list, n2, n3, n4);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void setAnotherView(boolean var1_1) {
        block11: {
            block10: {
                if (this.iHoveredID < 0) return;
                if ((Integer)this.lCivs.get(this.iHoveredID) < 0) return;
                CFG.game.disableDrawCivilizationRegions(CFG.getActiveCivInfo());
                CFG.setActiveCivInfo((Integer)this.lCivs.get(this.iHoveredID));
                if (CFG.FOG_OF_WAR == 2) {
                    if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(CFG.game.getCiv(CFG.getActiveCivInfo()).getCapitalProvinceID())) {
                        CFG.game.setActiveProvinceID(CFG.game.getCiv(CFG.getActiveCivInfo()).getCapitalProvinceID());
                        break block10;
                    }
                    var2_2 = 0;
                    break block11;
                }
                CFG.game.setActiveProvinceID(CFG.game.getCiv(CFG.getActiveCivInfo()).getCapitalProvinceID());
            }
lbl14:
            // 4 sources

            while (true) {
                CFG.updateActiveCivInfo_InGame();
                if (CFG.viewsManager.getActiveViewID() != ViewsManager.VIEW_DIPLOMACY_MODE) return;
                if (CFG.FOG_OF_WAR == 2) {
                    CFG.game.enableDrawCivilizationRegions_FogOfWar(CFG.getActiveCivInfo(), 1);
                    return;
                }
                CFG.game.enableDrawCivilizationRegions(CFG.getActiveCivInfo(), 1);
                return;
            }
        }
        while (true) {
            block12: {
                try {
                    if (var2_2 >= CFG.game.getCiv(CFG.getActiveCivInfo()).getNumOfProvinces()) ** GOTO lbl14
                    if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetProvince(CFG.game.getCiv(CFG.getActiveCivInfo()).getProvinceID(var2_2))) {
                        CFG.game.setActiveProvinceID(CFG.game.getCiv(CFG.getActiveCivInfo()).getProvinceID(var2_2));
                    }
                    break block12;
                }
                catch (IndexOutOfBoundsException var3_3) {}
                ** continue;
            }
            ++var2_2;
        }
    }
}

