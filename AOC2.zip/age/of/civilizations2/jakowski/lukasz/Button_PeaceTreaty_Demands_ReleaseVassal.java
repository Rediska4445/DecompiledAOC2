/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Toast;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;

class Button_PeaceTreaty_Demands_ReleaseVassal
extends Button {
    protected static int MAX_WDITH_LEFT = 0;
    protected static final float TEXT_SCALE = 0.7f;
    protected int iCivID = 0;
    protected int iReleaseCivID = 0;
    protected int iValueWidth = 0;
    protected boolean row = false;
    protected String sValue;
    protected int toReleaseByCivID = 0;

    protected Button_PeaceTreaty_Demands_ReleaseVassal(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, boolean bl) {
        super.init(CFG.game.getCiv(n2).getCivName(), 0, n5, n6, n7, n8, bl, true, false, false);
        this.iCivID = n;
        this.iReleaseCivID = n2;
        this.toReleaseByCivID = n3;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n4);
        this.sValue = stringBuilder.toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sValue);
        this.iValueWidth = (int)(CFG.glyphLayout.width * 0.7f);
        MAX_WDITH_LEFT = Math.max((int)((float)ImageManager.getImage(Images.city).getWidth() * this.getImageScale(ImageManager.getImage(Images.city).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect))) + CFG.PADDING * 4;
    }

    @Override
    protected void actionElement(int n) {
        this.iCivID = CFG.peaceTreatyData.takeReleaseVassal(this.toReleaseByCivID, this.iReleaseCivID, CFG.peaceTreatyData.iBrushCivID, this.iCivID);
        if (CFG.menuManager.getInGame_PeaceTreaty()) {
            CFG.menuManager.rebuildInGame_PeaceTreaty_Scores();
        }
        if (this.iCivID > 0) {
            Toast toast = CFG.toast;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(CFG.langManager.get("ReleaseAVassal"));
            stringBuilder.append(": ");
            stringBuilder.append(CFG.game.getCiv(this.iReleaseCivID).getCivName());
            toast.setInView(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            CFG.toast.setTimeInView(1500);
        }
    }

    @Override
    protected void buildElementHover() {
        int n;
        int n2;
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        int n3 = this.iCivID;
        if (n3 > 0) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(n3));
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("ReleaseAVassal"));
        stringBuilder.append(":");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iReleaseCivID, CFG.PADDING, CFG.PADDING));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.getText(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_vassal, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        for (n3 = 0; n3 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.size(); ++n3) {
            if (CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).iCivID != this.toReleaseByCivID) continue;
            for (n2 = 0; n2 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).lReleasableCivs.size(); ++n2) {
                if (CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).lReleasableCivs.get((int)n2).iCivID != this.iReleaseCivID) continue;
                for (n = 0; n < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.size() && n < 8; ++n) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iReleaseCivID));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince(CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.get(n)).getName(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" ");
                    stringBuilder.append(CFG.game.getProvinceValue(CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Defenders.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.get(n)));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.victoryPoints, CFG.PADDING, 0));
                    arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
                    arrayList2.clear();
                }
            }
        }
        for (n3 = 0; n3 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.size(); ++n3) {
            if (CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).iCivID != this.toReleaseByCivID) continue;
            for (n2 = 0; n2 < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).lReleasableCivs.size(); ++n2) {
                if (CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).lReleasableCivs.get((int)n2).iCivID != this.iReleaseCivID) continue;
                for (n = 0; n < CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.size() && n < 8; ++n) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iReleaseCivID));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince(CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.get(n)).getName(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" ");
                    stringBuilder.append(CFG.game.getProvinceValue(CFG.peaceTreatyData.peaceTreatyGameData.lCivsDemands_Aggressors.get((int)n3).lReleasableCivs.get((int)n2).lProvinces.get(n)));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.victoryPoints, CFG.PADDING, 0));
                    arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
                    arrayList2.clear();
                }
            }
        }
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, MAX_WDITH_LEFT, this.getHeight());
        spriteBatch.setColor(new Color((float)CFG.game.getCiv(this.iReleaseCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iReleaseCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iReleaseCivID).getB() / 255.0f, 0.125f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, MAX_WDITH_LEFT * 3 / 4, this.getHeight());
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.375f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() - 1 + MAX_WDITH_LEFT + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + 1 + MAX_WDITH_LEFT + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 - 1 + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + 1 + n, this.getPosY() + CFG.PADDING - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - CFG.PADDING * 2);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.875f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(Color.WHITE);
        try {
            if (this.iCivID > 0) {
                CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)) / 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)) / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)) / 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)));
            } else {
                ImageManager.getImage(Images.diplo_vassal).draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT / 2 - (int)((float)ImageManager.getImage(Images.diplo_vassal).getWidth() * this.getImageScale(ImageManager.getImage(Images.diplo_vassal).getHeight())) / 2 + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.diplo_vassal).getHeight() * this.getImageScale(ImageManager.getImage(Images.diplo_vassal).getHeight())) / 2 - ImageManager.getImage(Images.diplo_vassal).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_vassal).getWidth() * this.getImageScale(ImageManager.getImage(Images.diplo_vassal).getHeight())), (int)((float)ImageManager.getImage(Images.diplo_vassal).getHeight() * this.getImageScale(ImageManager.getImage(Images.diplo_vassal).getHeight())));
            }
        }
        catch (IndexOutOfBoundsException | NullPointerException runtimeException) {}
        ImageManager.getImage(Images.victoryPoints).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.victoryPoints).getWidth() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())) + n, this.getPosY() + 1 + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.victoryPoints).getHeight() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())) / 2 + n2 - ImageManager.getImage(Images.victoryPoints).getHeight(), (int)((float)ImageManager.getImage(Images.victoryPoints).getWidth() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())), (int)((float)ImageManager.getImage(Images.victoryPoints).getHeight() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())));
        Rectangle rectangle = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - CFG.PADDING * 3 - this.iValueWidth - (int)((float)ImageManager.getImage(Images.victoryPoints).getWidth() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors(rectangle);
        CFG.game.getCiv(this.iReleaseCivID).getFlag().draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)) / 2 - CFG.game.getCiv(this.iReleaseCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + MAX_WDITH_LEFT + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale2(Images.flag_rect)));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + MAX_WDITH_LEFT + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale2(Images.flag_rect)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.drawText(spriteBatch, this.sValue, this.getPosX() + this.getWidth() - CFG.PADDING * 3 - this.iValueWidth - (int)((float)ImageManager.getImage(Images.victoryPoints).getWidth() * this.getImageScale(ImageManager.getImage(Images.victoryPoints).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_LEFT_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    protected final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.8f / (float)n;
    }

    protected final float getImageScale2(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }

    @Override
    protected void setMin(int n) {
        this.iCivID = n;
    }
}

