/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Civ_Task;
import age.of.civilizations2.jakowski.lukasz.Civ_Task_Type;

class Civ_Task_Assimilate
extends Civ_Task {
    protected Civ_Task_Assimilate(int n) {
        this.taskType = Civ_Task_Type.ASSIMILATE_PROVINCE;
        this.iProvinceID = n;
    }
}

