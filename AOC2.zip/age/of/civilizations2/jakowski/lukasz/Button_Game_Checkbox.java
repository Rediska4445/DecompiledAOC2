/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_Checkbox
extends Button {
    protected Button_Game_Checkbox(String string2, int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        super.init(string2, n, n2, n3, n4, CFG.BUTTON_HEIGHT, bl, true, false, bl2, null);
        super.setCheckbox(true);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            if (this.getCheckboxState()) {
                ImageManager.getImage(Images.btn_clear_checkbox_false).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btnh_clear).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth(), ImageManager.getImage(Images.btnh_clear).getHeight());
                ImageManager.getImage(Images.btn_clear_checkbox_false).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth() + n, this.getPosY() + n2, true);
            } else {
                ImageManager.getImage(Images.btn_clear_checkbox_true).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btnh_clear).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth(), ImageManager.getImage(Images.btnh_clear).getHeight());
                ImageManager.getImage(Images.btn_clear_checkbox_true).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth() + n, this.getPosY() + n2, true);
            }
        } else if (this.getCheckboxState()) {
            ImageManager.getImage(Images.btn_clear_checkbox_true).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btnh_clear).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth(), ImageManager.getImage(Images.btnh_clear).getHeight());
            ImageManager.getImage(Images.btn_clear_checkbox_true).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth() + n, this.getPosY() + n2, true);
        } else {
            ImageManager.getImage(Images.btn_clear_checkbox_false).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.btnh_clear).getHeight() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth(), ImageManager.getImage(Images.btnh_clear).getHeight());
            ImageManager.getImage(Images.btn_clear_checkbox_false).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_clear).getWidth() + n, this.getPosY() + n2, true);
        }
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getCheckboxState() ? (this.getIsHovered() ? new Color(0.33f, 0.48f, 0.008f, 1.0f) : new Color(0.396f, 0.576f, 0.012f, 1.0f)) : (this.getIsHovered() ? new Color(0.584f, 0.075f, 0.004f, 1.0f) : new Color(0.643f, 0.113f, 0.008f, 1.0f))) : new Color(0.674f, 0.09f, 0.066f, 0.5f));
        return color2;
    }
}

