/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Diplo_Actions;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Diplo_Opinions
extends Button_Diplo_Actions {
    protected Button_Diplo_Opinions(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (CFG.menuManager.getVisible_InGame_CivInfo_Stats_Opinions()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.625f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - 2, this.getHeight() - 2, false, false);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - 2, CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 + this.getHeight() - 2 - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - 2, CFG.PADDING, false, true);
        if (bl || this.getIsHovered()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, false, false);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING, this.getHeight() - 2, false, false);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.diplo_relations).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (ImageManager.getImage(Images.diplo_relations).getWidth() + CFG.PADDING + (int)((float)this.getTextWidth() * 0.6f)) / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.diplo_relations).getHeight() / 2 + n2);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + this.getWidth() / 2 - (ImageManager.getImage(Images.diplo_relations).getWidth() + CFG.PADDING + (int)((float)this.getTextWidth() * 0.6f)) / 2 + CFG.PADDING + ImageManager.getImage(Images.diplo_relations).getWidth() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }
}

