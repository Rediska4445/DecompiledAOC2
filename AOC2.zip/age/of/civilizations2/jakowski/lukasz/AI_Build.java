/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.CFG;
import java.util.ArrayList;
import java.util.List;

class AI_Build {
    protected int iMaxDangerLevel = 0;
    protected int iProvincesToBuild_NumOfElements = 0;
    protected List<List<Integer>> lProvincesToBuild = new ArrayList<List<Integer>>();

    protected AI_Build(int n, long l) {
    }

    protected boolean build(int n, int n2, boolean bl) {
        return false;
    }

    protected long getMoney(int n) {
        if (CFG.game.getCiv(n).getMoney() < AI_Style.getMoney_MinReserve(n)) {
            return 0L;
        }
        return CFG.game.getCiv(n).getMoney() - AI_Style.getMoney_MinReserve(n);
    }

    protected int getNumOfAlreadyBuilt(int n) {
        return 0;
    }
}

