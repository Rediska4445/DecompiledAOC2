/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_AddArmy
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iValue = 0;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    Event_Outcome_AddArmy() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction(int n) {
        try {
            if (CFG.game.getProvince(this.getProvinces().get(n)).getWasteland() >= 0) return false;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getCivID() == this.getCivID()) return true;
            if (CFG.game.getCiv(this.getCivID()).getAllianceID() > 0) {
                if (CFG.game.getCiv(this.getCivID()).getAllianceID() == CFG.game.getCiv(CFG.game.getProvince(this.getProvinces().get(n)).getCivID()).getAllianceID()) return true;
            }
            if (CFG.game.getCiv(CFG.game.getProvince(this.getProvinces().get(n)).getCivID()).getPuppetOfCivID() == this.getCivID()) return true;
            if (CFG.game.getProvince(this.getProvinces().get(n)).getCivID() == CFG.game.getCiv(this.getCivID()).getPuppetOfCivID()) return true;
            n = CFG.game.getMilitaryAccess(this.getCivID(), CFG.game.getProvince(this.getProvinces().get(n)).getCivID());
            if (n <= 0) return false;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return false;
        }
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_ADDARMY);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("AddArmy")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ").append(this.getValue()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("AddArmy");
            return var1_3;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        try {
            ArrayList<Object> arrayList = new ArrayList<Object>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            int n = 0;
            while (true) {
                Object object = arrayList;
                if (n >= this.getProvinces().size()) return object;
                if (this.canMakeAction(n)) {
                    object = new MenuElement_Hover_v2_Element_Type_Flag(this.getCivID());
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    StringBuilder stringBuilder = new StringBuilder();
                    object = CFG.game.getProvince(this.getProvinces().get(n)).getName().length() == 0 ? (Serializable)this.getProvinces().get(n) : CFG.game.getProvince(this.getProvinces().get(n)).getName();
                    Object object2 = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.append(object).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
                    stringBuilder = new StringBuilder();
                    stringBuilder = stringBuilder.append("+");
                    object2 = new StringBuilder();
                    object = new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.append(CFG.getNumberWithSpaces(((StringBuilder)object2).append("").append(this.getValue()).toString())).append(" ").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Units"));
                    arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                    object = new MenuElement_Hover_v2_Element2(arrayList2);
                    arrayList.add(object);
                    arrayList2.clear();
                }
                ++n;
            }
        }
        catch (NullPointerException nullPointerException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    @Override
    protected List<Integer> getProvinces() {
        return this.lProvinces;
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    @Override
    protected void outcomeAction() {
        if (this.getCivID() >= 0 && this.getCivID() < CFG.game.getCivsSize()) {
            for (int i = 0; i < this.getProvinces().size(); ++i) {
                if (!this.canMakeAction(i)) continue;
                CFG.game.getProvince(this.getProvinces().get(i)).updateArmy(this.getCivID(), CFG.game.getProvince(this.getProvinces().get(i)).getArmyCivID(this.getCivID()) + this.getValue());
            }
            CFG.game.getCiv(this.getCivID()).buildNumOfUnits();
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setProvinces(List<Integer> list) {
        this.lProvinces.clear();
        for (int i = 0; i < list.size(); ++i) {
            this.lProvinces.add(list.get(i));
        }
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

