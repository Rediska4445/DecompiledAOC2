/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_ScenarioLoad
extends Button_Menu {
    private int iLoadID;
    private String sScenarioDate;
    private String sScenarioName;

    protected Button_Menu_ScenarioLoad(int n, String charSequence, int n2, String string2, int n3, int n4, int n5, int n6, boolean bl) {
        super(CFG.langManager.getCiv((String)charSequence), (int)(CFG.GUI_SCALE * 50.0f), n3, n4, n5, n6, bl);
        this.iLoadID = n;
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("Civilizations"));
        ((StringBuilder)charSequence).append(": ");
        ((StringBuilder)charSequence).append(n2);
        this.sScenarioName = ((StringBuilder)charSequence).toString();
        this.sScenarioDate = string2;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + this.getTextPos() / 2 - ImageManager.getImage(Images.time).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.time).getHeight() / 2 + n2);
        CFG.fontMain.getData().setScale(0.9f);
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = this.getTextPos();
        int n5 = this.getPosY();
        int n6 = this.getHeight() / 2;
        int n7 = (int)((float)CFG.TEXT_HEIGHT * 0.9f + (float)CFG.PADDING + (float)CFG.TEXT_HEIGHT * 0.7f) / 2;
        Color color2 = this.getIsHovered() ? CFG.COLOR_TEXT_CNG_TOP_SCENARIO_NAME_HOVER : CFG.COLOR_TEXT_CNG_TOP_SCENARIO_NAME;
        CFG.drawText(spriteBatch, string2, n3 + n4 + n, n5 + n6 - n7 + n2, color2);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.sScenarioName, this.getPosX() + this.getTextPos() + CFG.PADDING + (int)((float)this.getTextWidth() * 0.9f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.9f + (float)CFG.PADDING + (float)CFG.TEXT_HEIGHT * 0.7f) / 2 + (int)((float)CFG.TEXT_HEIGHT * 0.9f - (float)CFG.TEXT_HEIGHT * 0.7f) + n2, new Color(0.67f, 0.67f, 0.67f, 1.0f));
        CFG.drawText(spriteBatch, this.sScenarioDate, this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.9f + (float)CFG.PADDING + (float)CFG.TEXT_HEIGHT * 0.7f) / 2 + CFG.PADDING + (int)((float)CFG.TEXT_HEIGHT * 0.9f) + n2, new Color(0.58f, 0.58f, 0.58f, 1.0f));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected int getCurrent() {
        return this.iLoadID;
    }
}

