/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_View_Unrest
extends Button {
    protected static final float FONT_SIZE = 0.7f;
    protected static final float FONT_SIZE2 = 0.7f;
    private int iPopulationWidth;
    private int iProvinceID;
    private boolean row;
    private String sPopulation;

    protected Button_View_Unrest(int n, String object, int n2, int n3, int n4, int n5) {
        boolean bl = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        super.init((String)object, 0, n3, n4, n5, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        if (n % 2 == 0) {
            bl = true;
        }
        this.row = bl;
        this.iProvinceID = n2;
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append((int)(CFG.game.getProvince(this.iProvinceID).getRevolutionaryRisk() * 100.0f));
        ((StringBuilder)object).append("%");
        this.sPopulation = ((StringBuilder)object).toString();
        object = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        ((GlyphLayout)object).setText(bitmapFont, stringBuilder.toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.7f);
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID()));
        CharSequence charSequence = CFG.game.getProvince(this.iProvinceID).getName().length() > 0 ? CFG.game.getProvince(this.iProvinceID).getName() : CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getCivName();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("RevolutionaryRisk"));
        ((StringBuilder)charSequence).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append((int)(CFG.game.getProvince(this.iProvinceID).getRevolutionaryRisk() * 100.0f));
        ((StringBuilder)charSequence).append("%");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_ECONOMY));
        if (!CFG.game.showTurnChangesInformation(CFG.game.getProvince(this.iProvinceID).getCivID()) && !CFG.game.getProvince(this.iProvinceID).civSupportsRebels(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID())) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_revolution, CFG.PADDING, 0));
        } else {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_revolution, CFG.PADDING, CFG.PADDING));
            if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_RevRisk > 0.0f) {
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append("+");
                ((StringBuilder)charSequence).append(String.format("%.2f", Float.valueOf(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_RevRisk * 100.0f)).replace(',', '.'));
                ((StringBuilder)charSequence).append("%");
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
            } else if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_RevRisk < 0.0f) {
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append("");
                ((StringBuilder)charSequence).append(String.format("%.2f", Float.valueOf(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.turnChange_RevRisk * 100.0f)).replace(',', '.'));
                ((StringBuilder)charSequence).append("%");
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE));
            } else {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text("+0%", CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0));
        }
        if (CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.iSupportRebelsSize > 0) {
            int n;
            int n2;
            int n3;
            ArrayList<Integer> arrayList3 = new ArrayList<Integer>();
            ArrayList<Integer> arrayList4 = new ArrayList<Integer>();
            ArrayList arrayList5 = new ArrayList();
            for (n3 = 0; n3 < CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.iSupportRebelsSize; ++n3) {
                block11: {
                    n2 = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iRebelsCivID) ? CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iRebelsCivID : CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iRebelsCivID * -1;
                    for (n = arrayList3.size() - 1; n >= 0; --n) {
                        if ((Integer)arrayList3.get(n) != n2) continue;
                        arrayList4.set(n, Math.max((Integer)arrayList4.get(n), CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iTurnsLeft));
                        ((List)arrayList5.get(n)).add(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iByCivID);
                        n = 1;
                        break block11;
                    }
                    n = 0;
                }
                if (n != 0) continue;
                arrayList3.add(n2);
                arrayList4.add(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iTurnsLeft);
                arrayList5.add(new ArrayList());
                ((List)arrayList5.get(arrayList5.size() - 1)).add(CFG.game.getProvince((int)this.iProvinceID).saveProvinceData.lSupportRebels.get((int)n3).iByCivID);
                if (arrayList3.size() >= 4) break;
            }
            int n4 = arrayList3.size();
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID()));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince(this.iProvinceID).getName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append(" - ");
            ((StringBuilder)charSequence).append(CFG.langManager.get("SupportRebels"));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_revolution, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            for (n3 = 0; n3 < n4; ++n3) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag((Integer)arrayList3.get(n3)));
                charSequence = (Integer)arrayList3.get(n3) > 0 ? CFG.game.getCiv((Integer)arrayList3.get(n3)).getCivName() : CFG.langManager.get("Undiscovered");
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
                for (n2 = 0; n2 < ((List)arrayList5.get(n3)).size() && n2 < 10; ++n2) {
                    n = !CFG.SPECTATOR_MODE && !CFG.game.isAlly(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID(), (Integer)((List)arrayList5.get(n3)).get(n2)) ? -((Integer)((List)arrayList5.get(n3)).get(n2)).intValue() : (Integer)((List)arrayList5.get(n3)).get(n2);
                    int n5 = n2 == 0 ? CFG.PADDING : 0;
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(n, n5, 0));
                }
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append(" ");
                ((StringBuilder)charSequence).append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + (Integer)arrayList4.get(n3)));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append(" [");
                ((StringBuilder)charSequence).append(CFG.langManager.get("TurnsX", (Integer)arrayList4.get(n3)));
                ((StringBuilder)charSequence).append("]");
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_RANK_HOVER));
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0));
                arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
                arrayList2.clear();
            }
        }
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sPopulation);
        CFG.drawTextWithShadow(spriteBatch, stringBuilder.toString(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, CFG.getColorStep(CFG.COLOR_TEXT_REVOLUTION_MIN, CFG.COLOR_TEXT_REVOLUTION_MAX, (int)(CFG.game.getProvince(this.iProvinceID).getRevolutionaryRisk() * 100.0f), 100, 1.0f));
        ImageManager.getImage(Images.diplo_revolution).draw(spriteBatch, this.getPosX() + CFG.PADDING * 3 + this.iPopulationWidth + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(ImageManager.getImage(Images.diplo_revolution).getHeight())) / 2 + n2 - ImageManager.getImage(Images.diplo_revolution).getHeight(), (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * this.getImageScale(ImageManager.getImage(Images.diplo_revolution).getHeight())), (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * this.getImageScale(ImageManager.getImage(Images.diplo_revolution).getHeight())));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

