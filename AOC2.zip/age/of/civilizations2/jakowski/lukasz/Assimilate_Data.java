/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class Assimilate_Data {
    protected float fScore;
    protected int iProvinceID;

    protected Assimilate_Data(int n, float f) {
        this.iProvinceID = n;
        this.fScore = f;
    }
}

