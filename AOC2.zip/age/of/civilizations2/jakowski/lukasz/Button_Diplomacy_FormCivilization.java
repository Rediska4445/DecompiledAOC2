/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.util.ArrayList;

class Button_Diplomacy_FormCivilization
extends Button {
    private int iTextCostDiplomacyWidth;
    private int iTextCostGoldWidth;
    private Image lFlag = null;
    private boolean row = false;
    private String sCivTag;
    private String sTextCostDiplomacy;
    private String sTextCostGold;

    protected Button_Diplomacy_FormCivilization(String string2, int n, int n2, int n3, boolean bl, boolean bl2) {
        super.init(CFG.langManager.get("FormX", CFG.langManager.getCiv(string2)), 0, n, n2, n3, Math.max(CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 4, (CFG.TEXT_HEIGHT + CFG.PADDING) * 2 + CFG.PADDING), bl, true, true, bl2);
        this.sCivTag = string2;
        this.sTextCostGold = "10000";
        this.sTextCostDiplomacy = "2.4";
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostGold);
        this.iTextCostGoldWidth = (int)(CFG.glyphLayout.width * 0.6f);
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostDiplomacy);
        this.iTextCostDiplomacyWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.loadFlag(this.sCivTag);
    }

    private final void disposeFlag() {
        Image image = this.lFlag;
        if (image != null) {
            image.getTexture().dispose();
            this.lFlag = null;
        }
    }

    private final float getImageScale(int n) {
        float f = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void loadFlag(String var1_1) {
        this.disposeFlag();
        try {
            try {
                var4_17 = Gdx.files;
                var5_22 = new StringBuilder();
                var5_22.append("game/flags/");
                var5_22.append(var1_1);
                var5_22.append(".png");
                var3_12 = new Texture(var4_17.internal(var5_22.toString()));
                this.lFlag = var2_4 = new Image(var3_12, Texture.TextureFilter.Nearest);
                return;
            }
            catch (GdxRuntimeException var2_5) {
                try {
                    var4_18 = Gdx.files;
                    var2_6 = new StringBuilder();
                    var2_6.append("game/flags/");
                    var2_6.append(CFG.ideologiesManager.getRealTag(var1_1));
                    var2_6.append(".png");
                    var3_13 = new Texture(var4_18.internal(var2_6.toString()));
                    this.lFlag = var5_23 = new Image(var3_13, Texture.TextureFilter.Nearest);
                    return;
                }
                catch (GdxRuntimeException var2_7) {
                    var6_27 = CFG.isAndroid();
                    if (!var6_27) ** GOTO lbl68
                    {
                        catch (GdxRuntimeException var1_3) {
                            this.lFlag = null;
                            return;
                        }
                    }
                    try {
                        var2_8 = Gdx.files;
                        var3_14 = new StringBuilder();
                        var3_14.append("game/civilizations_editor/");
                        var3_14.append(var1_1);
                        var3_14.append("/");
                        var3_14.append(var1_1);
                        var3_14.append("_FL.png");
                        var4_19 = new Texture(var2_8.local(var3_14.toString()));
                        this.lFlag = var5_24 = new Image(var4_19, Texture.TextureFilter.Nearest);
                        return;
                    }
                    catch (GdxRuntimeException var2_9) {
                        var4_20 = Gdx.files;
                        var3_15 = new StringBuilder();
                        var3_15.append("game/civilizations_editor/");
                        var3_15.append(var1_1);
                        var3_15.append("/");
                        var3_15.append(var1_1);
                        var3_15.append("_FL.png");
                        var2_10 = new Texture(var4_20.internal(var3_15.toString()));
                        this.lFlag = var5_25 = new Image(var2_10, Texture.TextureFilter.Nearest);
                        return;
lbl68:
                        // 1 sources

                        var3_16 = Gdx.files;
                        var4_21 = new StringBuilder();
                        var4_21.append("game/civilizations_editor/");
                        var4_21.append(var1_1);
                        var4_21.append("/");
                        var4_21.append(var1_1);
                        var4_21.append("_FL.png");
                        var5_26 = new Texture(var3_16.internal(var4_21.toString()));
                        this.lFlag = var2_11 = new Image(var5_26, Texture.TextureFilter.Nearest);
                        return;
                    }
                }
            }
        }
        catch (OutOfMemoryError var1_2) {
            this.lFlag = null;
            return;
        }
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Diplomacy_FormCivilization.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.3f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.3f));
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Diplomacy_FormCivilization.this.getPosX() + n, Button_Diplomacy_FormCivilization.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_Diplomacy_FormCivilization.this.getWidth() / 6, Button_Diplomacy_FormCivilization.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Diplomacy_FormCivilization.this.getPosX() + n, Button_Diplomacy_FormCivilization.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_Diplomacy_FormCivilization.this.getWidth() / 10, Button_Diplomacy_FormCivilization.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_FormCivilization.this.getPosX() + n, Button_Diplomacy_FormCivilization.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy_FormCivilization.this.getWidth(), CFG.PADDING, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_FormCivilization.this.getPosX() + n, Button_Diplomacy_FormCivilization.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Diplomacy_FormCivilization.this.getHeight() - 1 + n2 - CFG.PADDING, Button_Diplomacy_FormCivilization.this.getWidth(), CFG.PADDING, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            int n = this.getCheckboxState() ? Images.icon_check_true : Images.icon_check_false;
            Object object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(this.getText());
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            n = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney() >= 10000L ? Images.icon_check_true : Images.icon_check_false;
            object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("Cost"));
            ((StringBuilder)object).append(": ");
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString());
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney() >= 10000L ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text("10000", (Color)object);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            n = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= 24 ? Images.icon_check_true : Images.icon_check_false;
            object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("DiplomacyPoints"));
            ((StringBuilder)object).append(": ");
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString());
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= 24 ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text("2.4", (Color)object);
            arrayList2.add(menuElement_Hover_v2_Element_Type_Text);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.top_diplomacy_points, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            n = CFG.game.isAtPeace(CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getCivID()) ? Images.icon_check_true : Images.icon_check_false;
            object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AtPeace"));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            n = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getCivID() == CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getPuppetOfCivID() ? Images.icon_check_true : Images.icon_check_false;
            object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("IsNotAVassal"));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            n = CFG.doesNotExists_FormableCiv(this.sCivTag) ? Images.icon_check_true : Images.icon_check_false;
            object = new MenuElement_Hover_v2_Element_Type_Image(n);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("XDoesNotExist", CFG.langManager.getCiv(this.sCivTag)));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            this.lFlag.draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - this.lFlag.getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        catch (NullPointerException nullPointerException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold)) + n, this.getPosY() + CFG.PADDING / 2 + this.getHeight() / 2 - this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold) / 2.0f) - ImageManager.getImage(Images.top_gold).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold)));
        ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)) + n, this.getPosY() - CFG.PADDING / 2 + this.getHeight() / 2 + this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points) / 2.0f) - ImageManager.getImage(Images.top_diplomacy_points).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points)));
        CFG.fontMain.getData().setScale(0.6f);
        String string2 = this.sTextCostGold;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = this.iTextCostGoldWidth;
        int n6 = CFG.PADDING;
        int n7 = (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold));
        int n8 = this.getPosY();
        int n9 = CFG.PADDING / 2;
        int n10 = this.getHeight() / 2;
        int n11 = this.getHeight() / 4;
        int n12 = (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f);
        Object object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney() >= 10000L ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawText(spriteBatch, string2, n3 + n4 - n5 - n6 * 2 - n7 + n, n8 + n9 + n10 - n11 - n12 + n2, (Color)object);
        string2 = this.sTextCostDiplomacy;
        n4 = this.getPosX();
        n10 = this.getWidth();
        n8 = this.iTextCostDiplomacyWidth;
        n6 = CFG.PADDING;
        n7 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points));
        n3 = this.getPosY();
        n9 = CFG.PADDING / 2;
        n11 = this.getHeight() / 2;
        n5 = this.getHeight() / 4;
        n12 = (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f);
        object = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= 24 ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawText(spriteBatch, string2, n4 + n10 - n8 - n6 * 2 - n7 + n, n3 - n9 + n11 + n5 - n12 + n2, (Color)object);
        object = new Rectangle(this.getPosX() + Button_Diplomacy.iDiploWidth + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - this.getRightWidth() - Button_Diplomacy.iDiploWidth, -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.getColor(bl));
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    protected final int getRightWidth() {
        return Math.max(this.iTextCostGoldWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold)), this.iTextCostDiplomacyWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_diplomacy_points)));
    }

    @Override
    protected void setMax(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }

    @Override
    protected void setVisible(boolean bl) {
        super.setVisible(bl);
        this.disposeFlag();
    }
}

