/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_Main;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Menu_Classic_YT
extends Button_Menu {
    protected Button_Menu_Classic_YT(int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(null, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_Classic_YT(int n, int n2, int n3, int n4, boolean bl) {
        super(null, 0, n, n2, n3, n4, bl);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("YouTube"));
        stringBuilder.append(".");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (!bl && !this.getIsHovered()) {
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), true, false);
        } else {
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), true, false);
        }
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        if (this.getClickable()) {
            if (bl) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
            } else if (this.getIsHovered()) {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.65f));
            } else {
                spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, Menu_Main.ICONS_ALPHA));
            }
        } else {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.05f));
        }
        ImageManager.getImage(Images.logo_yt).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.logo_yt).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.logo_yt).getHeight() / 2 + n2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
    }

    @Override
    protected int getCurrent() {
        return this.iTextPositionX;
    }
}

