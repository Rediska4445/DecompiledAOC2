/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

public enum CivBonus_Type {
    BONUS,
    GOLDEN_AGE_PROSPERITY,
    GOLDEN_AGE_SCIENCE,
    GOLDEN_AGE_MILITARY;

}

