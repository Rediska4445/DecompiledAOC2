/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class CivInvest
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iEconomyLeft;
    protected int iEconomyPerTurn;
    protected int iProvinceID;
    protected int iTurnsLeft;

    protected CivInvest(int n, int n2, int n3, int n4) {
        this.iProvinceID = n;
        this.iTurnsLeft = n2;
        this.iEconomyLeft = n3;
        this.iEconomyPerTurn = n4;
    }
}

