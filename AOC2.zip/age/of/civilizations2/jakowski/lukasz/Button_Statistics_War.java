/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.LanguageManager;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Statistics_War
extends Button_Statistics {
    private static final float FONT_SCALE = 0.7f;
    private static final float FONT_SCALE2 = 0.6f;
    protected static long lTime;
    private float fAttackersPerc;
    private int iAggressor;
    private int iDefender;
    private int iWarDateWidth;
    private int iWarID;
    private Color oColorCasualtiesTotal;
    private String sCasualtiesTotal;
    private String sDefenderName;
    private String sWarDate;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected Button_Statistics_War(int var1_1, int var2_2, int var3_3, int var4_4, int var5_5, int var6_6) {
        block10: {
            block7: {
                block9: {
                    block8: {
                        block6: {
                            block4: {
                                block5: {
                                    if (CFG.FOG_OF_WAR != 2) break block4;
                                    if (CFG.game.getWar(var3_3).getAggressorsSize() != 1) break block5;
                                    if (!CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(var1_1)) ** GOTO lbl-1000
                                    var7_7 = CFG.game.getCiv(var1_1).getCivName();
                                    break block6;
                                }
                                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetAlliance(CFG.game.getCiv(var1_1).getAllianceID())) {
                                    var7_7 = CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getAllianceName();
                                } else lbl-1000:
                                // 2 sources

                                {
                                    var7_7 = CFG.langManager.get("Undiscovered");
                                }
                                break block6;
                            }
                            var7_7 = CFG.game.getWar(var3_3).getAggressorsSize() == 1 ? CFG.game.getCiv(var1_1).getCivName() : CFG.game.getAlliance(CFG.game.getCiv(var1_1).getAllianceID()).getAllianceName();
                        }
                        super((String)var7_7, 0, var4_4, var5_5, var6_6, CFG.TEXT_HEIGHT + CFG.PADDING * 3 + CFG.PADDING * 2 + CFG.PADDING);
                        this.iWarID = 0;
                        this.iWarDateWidth = 0;
                        if (CFG.FOG_OF_WAR != 2) break block7;
                        this.iAggressor = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(var1_1) != false ? var1_1 : -1;
                        this.iDefender = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(var2_2) != false ? var2_2 : -1;
                        if (CFG.game.getWar(var3_3).getDefendersSize() != 1) break block8;
                        if (!CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(var2_2)) ** GOTO lbl-1000
                        var7_7 = CFG.game.getCiv(var2_2).getCivName();
                        break block9;
                    }
                    if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetAlliance(CFG.game.getCiv(var2_2).getAllianceID())) {
                        var7_7 = CFG.game.getAlliance(CFG.game.getCiv(var2_2).getAllianceID()).getAllianceName();
                    } else lbl-1000:
                    // 2 sources

                    {
                        var7_7 = CFG.langManager.get("Undiscovered");
                    }
                }
                this.sDefenderName = var7_7;
                break block10;
            }
            this.iAggressor = var1_1;
            this.iDefender = var2_2;
            var7_7 = CFG.game.getWar(var3_3).getDefendersSize() == 1 ? CFG.game.getCiv(var2_2).getCivName() : CFG.game.getAlliance(CFG.game.getCiv(var2_2).getAllianceID()).getAllianceName();
            this.sDefenderName = var7_7;
        }
        this.iWarID = var3_3;
        var1_1 = CFG.game.getWar(this.iWarID).getCasualties_Aggressors() + CFG.game.getWar(this.iWarID).getCasualties_Defenders();
        var7_7 = var1_1 == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        this.oColorCasualtiesTotal = var7_7;
        this.sCasualtiesTotal = CFG.getNumber_SHORT(var1_1);
        this.sWarDate = Game_Calendar.getDate_ByTurnID(CFG.game.getWar(this.iWarID).getWarTurnID());
        CFG.glyphLayout.setText(CFG.fontMain, this.sWarDate);
        this.iWarDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.fAttackersPerc = 0.5f - (float)CFG.game.getWar(this.iWarID).getWarScore() / 100.0f * 0.5f;
        Button_Statistics_War.lTime = System.currentTimeMillis();
    }

    private final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    private final float getImageScale2(int n) {
        float f = (float)CFG.TEXT_HEIGHT * 0.7f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT * 0.7f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void buildElementHover() {
        int n;
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        if (CFG.FOG_OF_WAR == 2) {
            for (n = 0; n < CFG.game.getWar(this.iWarID).getAggressorsSize() && n < 6; ++n) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID())) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID(), 0, 0));
                    continue;
                }
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(-1, 0, 0));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, CFG.PADDING));
            for (n = 0; n < CFG.game.getWar(this.iWarID).getDefendersSize() && n < 6; ++n) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID())) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID(), 0, 0));
                    continue;
                }
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(-1, 0, 0));
            }
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        } else {
            for (n = 0; n < CFG.game.getWar(this.iWarID).getAggressorsSize() && n < 6; ++n) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID(), 0, 0));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, CFG.PADDING));
            for (n = 0; n < CFG.game.getWar(this.iWarID).getDefendersSize() && n < 6; ++n) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID(), 0, 0));
            }
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        n = CFG.game.getWar(this.iWarID).getWarScore();
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("Score"));
        ((StringBuilder)charSequence).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        if (n == 0) {
            charSequence = CFG.langManager.get("Balanced");
        } else {
            String string2;
            LanguageManager languageManager;
            if (n < 0) {
                languageManager = CFG.langManager;
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append(Math.abs(n));
                ((StringBuilder)charSequence).append("%");
                charSequence = ((StringBuilder)charSequence).toString();
                string2 = "XInFavorOfAggressors";
            } else {
                languageManager = CFG.langManager;
                charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append(Math.abs(n));
                ((StringBuilder)charSequence).append("%");
                charSequence = ((StringBuilder)charSequence).toString();
                string2 = "XInFavorOfDefenders";
            }
            charSequence = languageManager.get(string2, (String)charSequence);
        }
        stringBuilder.append((String)charSequence);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("Casualties"));
        ((StringBuilder)charSequence).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sCasualtiesTotal, this.oColorCasualtiesTotal));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.difficulty_hell, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.sWarDate, CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.25f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(Color.WHITE);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() * 3 / 5, false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 4 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), true, false);
        super.drawButtonBG(spriteBatch, n, n2, bl);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.45f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - 4, 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - 4, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Color color2;
        float f = this.fAttackersPerc;
        if (lTime + 375L > System.currentTimeMillis()) {
            f = 0.5f - (0.5f - this.fAttackersPerc) * (float)(System.currentTimeMillis() - lTime) / 375.0f;
            CFG.setRender_3(true);
        }
        ImageManager.getImage(Images.diplo_rivals).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.diplo_rivals).getHeight() * this.getImageScale(Images.diplo_rivals))) / 2 - ImageManager.getImage(Images.diplo_rivals).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)), (int)((float)ImageManager.getImage(Images.diplo_rivals).getHeight() * this.getImageScale(Images.diplo_rivals)));
        try {
            if (this.iAggressor >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iAggressor).getR() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getG() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getB() / 255.0f, 1.0f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 1.0f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 + n, this.getPosY() + CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        try {
            if (this.iDefender >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iDefender).getR() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getG() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getB() / 255.0f, 1.0f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + n, this.getPosY() + CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        if (CFG.FOG_OF_WAR == 2) {
            int n3;
            for (n3 = CFG.game.getWar(this.iWarID).getAggressorsSize() - 1; n3 >= 0; --n3) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getAggressorID(n3).getCivID())) {
                    CFG.game.getCiv(CFG.game.getWar(this.iWarID).getAggressorID(n3).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(CFG.game.getWar(this.iWarID).getAggressorID(n3).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                } else {
                    ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                }
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
            for (n3 = CFG.game.getWar(this.iWarID).getDefendersSize() - 1; n3 >= 0; --n3) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getDefenderID(n3).getCivID())) {
                    CFG.game.getCiv(CFG.game.getWar(this.iWarID).getDefenderID(n3).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(CFG.game.getWar(this.iWarID).getDefenderID(n3).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                } else {
                    ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                }
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n3 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
        } else {
            int n4;
            for (n4 = CFG.game.getWar(this.iWarID).getAggressorsSize() - 1; n4 >= 0; --n4) {
                CFG.game.getCiv(CFG.game.getWar(this.iWarID).getAggressorID(n4).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n4 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(CFG.game.getWar(this.iWarID).getAggressorID(n4).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n4 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
            for (n4 = CFG.game.getWar(this.iWarID).getDefendersSize() - 1; n4 >= 0; --n4) {
                CFG.game.getCiv(CFG.game.getWar(this.iWarID).getDefenderID(n4).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n4 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(CFG.game.getWar(this.iWarID).getDefenderID(n4).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * n4 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
            }
        }
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + this.getWidth() / 2 - (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 - CFG.PADDING * 2 - (int)((float)this.getTextWidth() * 0.7f) - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * (CFG.game.getWar(this.iWarID).getAggressorsSize() - 1) + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sDefenderName, this.getPosX() + this.getWidth() / 2 + (int)((float)ImageManager.getImage(Images.diplo_rivals).getWidth() * this.getImageScale(Images.diplo_rivals)) / 2 + CFG.PADDING * 2 + 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) * 3 / 4 * (CFG.game.getWar(this.iWarID).getDefendersSize() - 1) + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.7f) / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        CFG.fontMain.getData().setScale(0.6f);
        ImageManager.getImage(Images.difficulty_hell).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.difficulty_hell).getHeight() * this.getImageScale2(Images.difficulty_hell))) / 2 - ImageManager.getImage(Images.difficulty_hell).getHeight() + n2, (int)((float)ImageManager.getImage(Images.difficulty_hell).getWidth() * this.getImageScale2(Images.difficulty_hell)), (int)((float)ImageManager.getImage(Images.difficulty_hell).getHeight() * this.getImageScale2(Images.difficulty_hell)));
        CFG.drawTextWithShadow(spriteBatch, this.sCasualtiesTotal, this.getPosX() + (int)((float)ImageManager.getImage(Images.difficulty_hell).getWidth() * this.getImageScale2(Images.difficulty_hell)) + CFG.PADDING * 3 + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, this.oColorCasualtiesTotal);
        ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale2(Images.time)) + n, this.getPosY() + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale2(Images.time))) / 2 - ImageManager.getImage(Images.time).getHeight() + n2, (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale2(Images.time)), (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale2(Images.time)));
        CFG.drawTextWithShadow(spriteBatch, this.sWarDate, this.getPosX() + this.getWidth() - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale2(Images.time)) - CFG.PADDING * 3 - this.iWarDateWidth + n, this.getPosY() + CFG.PADDING * 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.6f) / 2.0f) + n2, CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, CFG.PADDING * 2, false, true);
        try {
            if (this.iAggressor >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iAggressor).getR() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getG() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getB() / 255.0f, 0.45f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 0.45f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 0.45f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, false, true);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING, false, true);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, true, true);
        try {
            if (this.iDefender >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iDefender).getR() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getG() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getB() / 255.0f, 0.45f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 0.45f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 0.45f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, false, true);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING, false, true);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.patt).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, false, true);
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), CFG.PADDING * 2, true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.785f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, CFG.PADDING * 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, CFG.PADDING * 2, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - CFG.PADDING - CFG.PADDING * 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2, 1);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iWarID;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

