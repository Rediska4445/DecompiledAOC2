/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import java.io.Serializable;

class Construction_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected ConstructionType constructionType = ConstructionType.PORT;
    protected int iNumOfTurnsLeft;
    protected int iProvinceID;

    protected Construction_GameData(int n, int n2) {
        this.iProvinceID = n;
        this.iNumOfTurnsLeft = n2;
    }

    protected void onConstructed(int n) {
        if (CFG.game.getProvince(this.iProvinceID).getCivID() == n) {
            BuildingsManager.buildPort(this.iProvinceID, n);
        }
    }
}

