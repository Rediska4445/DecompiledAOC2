/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AoCGame;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.util.ArrayList;

public class Button_Diplomacy_Flag
extends Button_Statistics {
    protected static final float FONT_SCALE = 0.75f;
    protected Image civFlag = null;
    protected int iCivID;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected Button_Diplomacy_Flag(int var1_1, int var2_2, int var3_3, int var4_4) {
        super(CFG.game.getCiv(var1_1).getCivName(), 0, var2_2, var3_3, var4_4, CFG.TEXT_HEIGHT * 2 + CFG.PADDING * 4);
        this.iCivID = var1_1;
        if (this.iCivID < 0) {
            this.civFlag = null;
            return;
        }
        try {
            try {
                var7_26 = Gdx.files;
                var8_33 = new StringBuilder();
                var8_33.append("game/flagsH/");
                var8_33.append(CFG.game.getCiv(this.iCivID).getCivTag());
                var8_33.append(".png");
                var6_12 = new Texture(var7_26.internal(var8_33.toString()));
                this.civFlag = var5_5 = new Image(var6_12, Texture.TextureFilter.Linear);
                return;
            }
            catch (GdxRuntimeException var6_13) {
                try {
                    var6_14 = Gdx.files;
                    var8_34 = new StringBuilder();
                    var8_34.append("game/flagsH/");
                    var8_34.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                    var8_34.append(".png");
                    var7_27 = new Texture(var6_14.internal(var8_34.toString()));
                    this.civFlag = var5_6 = new Image(var7_27, Texture.TextureFilter.Linear);
                    return;
                }
                catch (GdxRuntimeException var6_15) {
                    try {
                        var8_35 = Gdx.files;
                        var5_7 = new StringBuilder();
                        var5_7.append("game/flags/");
                        var5_7.append(CFG.game.getCiv(this.iCivID).getCivTag());
                        var5_7.append(".png");
                        var7_28 = new Texture(var8_35.internal(var5_7.toString()));
                        this.civFlag = var6_16 = new Image(var7_28, Texture.TextureFilter.Linear);
                        return;
                    }
                    catch (GdxRuntimeException var6_17) {
                        try {
                            var6_18 = Gdx.files;
                            var7_29 = new StringBuilder();
                            var7_29.append("game/flags/");
                            var7_29.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                            var7_29.append(".png");
                            var5_8 = new Texture(var6_18.internal(var7_29.toString()));
                            this.civFlag = var8_36 = new Image(var5_8, Texture.TextureFilter.Linear);
                            return;
                        }
                        catch (GdxRuntimeException var6_19) {
                            var9_40 = CFG.isAndroid();
                            if (!var9_40) ** GOTO lbl99
                            {
                                catch (GdxRuntimeException var6_25) {
                                    this.civFlag = null;
                                    return;
                                }
                            }
                            try {
                                var6_20 = Gdx.files;
                                var7_30 = new StringBuilder();
                                var7_30.append("game/civilizations_editor/");
                                var7_30.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var7_30.append("/");
                                var7_30.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var7_30.append("_FLH.png");
                                var8_37 = new Texture(var6_20.local(var7_30.toString()));
                                this.civFlag = var5_9 = new Image(var8_37, Texture.TextureFilter.Linear);
                                return;
                            }
                            catch (GdxRuntimeException var6_21) {
                                var8_38 = Gdx.files;
                                var6_22 = new StringBuilder();
                                var6_22.append("game/civilizations_editor/");
                                var6_22.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var6_22.append("/");
                                var6_22.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var6_22.append("_FLH.png");
                                var7_31 = new Texture(var8_38.internal(var6_22.toString()));
                                this.civFlag = var5_10 = new Image(var7_31, Texture.TextureFilter.Linear);
                                return;
lbl99:
                                // 1 sources

                                var8_39 = Gdx.files;
                                var7_32 = new StringBuilder();
                                var7_32.append("game/civilizations_editor/");
                                var7_32.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var7_32.append("/");
                                var7_32.append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(this.iCivID).getCivTag()));
                                var7_32.append("_FLH.png");
                                var6_23 = new Texture(var8_39.internal(var7_32.toString()));
                                this.civFlag = var5_11 = new Image(var6_23, Texture.TextureFilter.Linear);
                                return;
                            }
                        }
                    }
                }
            }
        }
        catch (OutOfMemoryError var6_24) {
            this.civFlag = null;
            return;
        }
    }

    private final void drawFlag(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
        if (this.civFlag != null) {
            try {
                Color color2 = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.slider_gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(1.0f, 1.0f, 1.0f, 0.1f);
                spriteBatch.setColor(color2);
                spriteBatch.setShader(AoCGame.shaderAlpha);
                ImageManager.getImage(Images.gradient).getTexture().bind(2);
                this.civFlag.getTexture().bind(1);
                Gdx.gl.glActiveTexture(33984);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
                spriteBatch.setShader(AoCGame.defaultShader);
                color2 = new Color(0.0f, 0.0f, 0.0f, 0.35f);
                spriteBatch.setColor(color2);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * 68.0f), this.getHeight(), false, false);
            }
            catch (NullPointerException nullPointerException) {
                spriteBatch.setShader(AoCGame.defaultShader);
            }
        } else {
            spriteBatch.setShader(AoCGame.defaultShader);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.825f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getHeight() / 44.0f * (float)CFG.PADDING), this.getHeight(), false, false);
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(this.getText(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.135f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.525f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        this.drawFlag(spriteBatch, n, n2, bl);
        spriteBatch.setColor(new Color(0.06f, 0.06f, 0.1f, 0.45f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.r, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.g, CFG.COLOR_CREATE_NEW_GAME_BOX_PLAYERS.b, 0.85f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            Color color2 = new Color((float)CFG.game.getCiv(this.iCivID).getR() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getG() / 255.0f, (float)CFG.game.getCiv(this.iCivID).getB() / 255.0f, 1.0f);
            spriteBatch.setColor(color2);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 1.0f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - ImageManager.getImage(Images.diplo_rivals).getWidth() / 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 2, (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        spriteBatch.setColor(Color.WHITE);
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - ImageManager.getImage(Images.diplo_rivals).getWidth() / 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - ImageManager.getImage(Images.diplo_rivals).getWidth() / 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - ImageManager.getImage(Images.diplo_rivals).getWidth() / 2 + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (CFG.TEXT_HEIGHT - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect))) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        CFG.fontMain.getData().setScale(0.75f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + this.getWidth() - CFG.PADDING - 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) - ImageManager.getImage(Images.diplo_rivals).getWidth() / 2 - (int)((float)this.getTextWidth() * 0.75f) - CFG.PADDING + n, this.getPosY() + CFG.PADDING + CFG.PADDING / 2 + (int)(((float)CFG.TEXT_HEIGHT - (float)CFG.TEXT_HEIGHT * 0.75f) / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }

    protected final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected void setVisible(boolean bl) {
        super.setVisible(bl);
    }
}

