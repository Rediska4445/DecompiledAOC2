/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.LanguageManager;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Statistics_WarDetails_WarResult
extends Button_Statistics {
    protected static final int ANIMATION_TIME = 375;
    private float fAttackersPerc;
    private int iAggressor;
    private int iDefender;
    private int iWarID = 0;
    private long lTime;

    protected Button_Statistics_WarDetails_WarResult(int n, int n2, int n3, int n4, int n5, int n6) {
        super(CFG.game.getCiv(n2).getCivName(), 0, n4, n5, n6, CFG.PADDING * 2);
        if (CFG.FOG_OF_WAR == 2) {
            this.iAggressor = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(n) ? n : -1;
            this.iDefender = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(n2) ? n2 : -1;
        } else {
            this.iAggressor = n;
            this.iDefender = n2;
        }
        this.iWarID = n3;
        this.fAttackersPerc = 0.5f - (float)CFG.game.getWar(this.iWarID).getWarScore() / 100.0f * 0.5f;
        if (this.fAttackersPerc != 0.5f) {
            this.lTime = System.currentTimeMillis();
        }
    }

    @Override
    protected void buildElementHover() {
        int n;
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        if (CFG.FOG_OF_WAR == 2) {
            for (n = 0; n < CFG.game.getWar(this.iWarID).getAggressorsSize() && n < 6; ++n) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID())) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID(), 0, 0));
                    continue;
                }
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(-1, 0, 0));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, CFG.PADDING));
            for (n = 0; n < CFG.game.getWar(this.iWarID).getDefendersSize() && n < 6; ++n) {
                if (CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID())) {
                    arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID(), 0, 0));
                    continue;
                }
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(-1, 0, 0));
            }
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        } else {
            for (n = 0; n < CFG.game.getWar(this.iWarID).getAggressorsSize() && n < 6; ++n) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getAggressorID(n).getCivID(), 0, 0));
            }
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, CFG.PADDING));
            for (n = 0; n < CFG.game.getWar(this.iWarID).getDefendersSize() && n < 6; ++n) {
                arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getWar(this.iWarID).getDefenderID(n).getCivID(), 0, 0));
            }
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        n = CFG.game.getWar(this.iWarID).getWarScore();
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Score"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        if (n == 0) {
            object = CFG.langManager.get("Balanced");
        } else {
            String string2;
            CharSequence charSequence;
            if (n < 0) {
                object = CFG.langManager;
                charSequence = new StringBuilder();
                charSequence.append(Math.abs(n));
                charSequence.append("%");
                charSequence = charSequence.toString();
                string2 = "XInFavorOfAggressors";
            } else {
                object = CFG.langManager;
                charSequence = new StringBuilder();
                charSequence.append(Math.abs(n));
                charSequence.append("%");
                charSequence = charSequence.toString();
                string2 = "XInFavorOfDefenders";
            }
            object = ((LanguageManager)object).get(string2, (String)charSequence);
        }
        stringBuilder.append((String)object);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.3f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Color color2;
        float f = this.fAttackersPerc;
        if (this.lTime + 375L > System.currentTimeMillis()) {
            f = 0.5f - (0.5f - this.fAttackersPerc) * (float)(System.currentTimeMillis() - this.lTime) / 375.0f;
            CFG.setRender_3(true);
        }
        try {
            if (this.iAggressor >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iAggressor).getR() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getG() / 255.0f, (float)CFG.game.getCiv(this.iAggressor).getB() / 255.0f, 0.45f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 0.45f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.getB(), 0.45f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, (int)((float)this.getWidth() * f), this.getHeight(), false, true);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)this.getWidth() * f), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, (int)((float)this.getWidth() * f), CFG.PADDING, false, true);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, (int)((float)this.getWidth() * f), this.getHeight(), true, true);
        try {
            if (this.iDefender >= 0) {
                color2 = new Color((float)CFG.game.getCiv(this.iDefender).getR() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getG() / 255.0f, (float)CFG.game.getCiv(this.iDefender).getB() / 255.0f, 0.45f);
                spriteBatch.setColor(color2);
            } else {
                color2 = new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 0.45f);
                spriteBatch.setColor(color2);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            spriteBatch.setColor(new Color(CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getR(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getG(), CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.getB(), 0.45f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth() - (int)((float)this.getWidth() * f), this.getHeight(), false, true);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - (int)((float)this.getWidth() * f), CFG.PADDING, false, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth() - (int)((float)this.getWidth() * f), CFG.PADDING, false, true);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() - (int)((float)this.getWidth() * f), this.getHeight(), false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, (int)((float)this.getWidth() * f), this.getHeight(), false, true);
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth() - (int)((float)this.getWidth() * f), this.getHeight(), true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.475f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - CFG.PADDING - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING, false, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.785f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected int getCurrent() {
        return this.iWarID;
    }
}

