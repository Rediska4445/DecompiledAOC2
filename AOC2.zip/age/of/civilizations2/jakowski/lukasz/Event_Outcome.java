/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Event_Outcome
implements Serializable {
    private static final long serialVersionUID = 0L;

    protected void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_CHANGE_OWNER);
    }

    protected int getCivID() {
        return -1;
    }

    protected int getCivID2() {
        return -1;
    }

    protected String getConditionText() {
        return "";
    }

    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        return new ArrayList<MenuElement_Hover_v2_Element2>();
    }

    protected List<Integer> getProvinces() {
        return new ArrayList<Integer>();
    }

    protected String getText() {
        return "";
    }

    protected int getValue() {
        return -1;
    }

    protected void outcomeAction() {
    }

    protected void setCivID(int n) {
    }

    protected void setCivID2(int n) {
    }

    protected void setProvinces(List<Integer> list) {
    }

    protected void setText(String string2) {
    }

    protected void setValue(int n) {
    }

    protected boolean updateCivIDAfterRemove(int n) {
        return false;
    }
}

