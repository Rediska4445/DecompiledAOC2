/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

class AI_RegoupArmyData {
    protected int iArmy;
    protected int iProvinceID;

    protected AI_RegoupArmyData(int n, int n2) {
        this.iProvinceID = n;
        this.iArmy = n2;
    }
}

