/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_View_Income
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.7f;
    private int iBalance;
    protected int iLevelWidth;
    private int iPopulationPercWidth;
    private int iPopulationWidth;
    private int iProvinceID;
    protected boolean isFestivalOrganized;
    private boolean row;
    protected String sLevel;
    private String sPopulation;

    protected Button_View_Income(int n, String charSequence, int n2, int n3, int n4, int n5, boolean bl) {
        boolean bl2 = false;
        this.row = false;
        this.iProvinceID = 0;
        this.iPopulationWidth = 0;
        this.iPopulationPercWidth = 0;
        this.isFestivalOrganized = false;
        this.sLevel = "";
        this.iLevelWidth = 0;
        super.init((String)charSequence, 0, n3, n4, n5, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        if (n % 2 == 0) {
            bl2 = true;
        }
        this.row = bl2;
        this.iProvinceID = n2;
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append((int)(CFG.game_NextTurnUpdate.getProvinceIncome_Taxation(n2) + CFG.game_NextTurnUpdate.getProvinceIncome_Production(n2)));
        this.sPopulation = ((StringBuilder)charSequence).toString();
        Object object = CFG.glyphLayout;
        Object object2 = CFG.fontMain;
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append(this.sPopulation);
        ((GlyphLayout)object).setText((BitmapFont)object2, ((StringBuilder)charSequence).toString());
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        this.iBalance = (int)CFG.game_NextTurnUpdate.getProvinceIncomeAndExpenses_Total(n2);
        object2 = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        object = new StringBuilder();
        charSequence = this.iBalance > 0 ? "+" : "";
        ((StringBuilder)object).append((String)charSequence);
        ((StringBuilder)object).append(this.iBalance);
        ((GlyphLayout)object2).setText(bitmapFont, ((StringBuilder)object).toString());
        this.iPopulationPercWidth = (int)(CFG.glyphLayout.width * 0.7f);
        this.isFestivalOrganized = bl;
        if (CFG.game.getProvince(n2).getLevelOfWorkshop() > 0) {
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("");
            ((StringBuilder)charSequence).append(CFG.game.getProvince(n2).getLevelOfWorkshop());
            this.sLevel = ((StringBuilder)charSequence).toString();
            CFG.glyphLayout.setText(CFG.fontMain, this.sLevel);
            this.iLevelWidth = (int)(CFG.glyphLayout.width * 0.7f);
        }
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.7f / (float)n;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()));
        Object object = CFG.game.getProvince(this.iProvinceID).getName().length() > 0 ? CFG.game.getProvince(this.iProvinceID).getName() : CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getCivName();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)object, CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Taxation"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        CharSequence charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append((int)CFG.game_NextTurnUpdate.getProvinceIncome_Taxation(this.iProvinceID));
        ((StringBuilder)object).append(CFG.getNumberWithSpaces(((StringBuilder)charSequence).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Production"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append((int)CFG.game_NextTurnUpdate.getProvinceIncome_Production(this.iProvinceID));
        ((StringBuilder)object).append(CFG.getNumberWithSpaces(((StringBuilder)charSequence).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("AdministrationCost"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append((int)CFG.game_NextTurnUpdate.getProvinceAdministration(this.iProvinceID, CFG.game_NextTurnUpdate.getAdministration_Capital(CFG.game.getProvince(this.iProvinceID).getCivID())));
        ((StringBuilder)charSequence).append(CFG.getNumberWithSpaces(((StringBuilder)object).toString()));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Balance"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        charSequence = new StringBuilder();
        object = this.iBalance > 0 ? "+" : "";
        ((StringBuilder)charSequence).append((String)object);
        ((StringBuilder)charSequence).append(this.iBalance);
        charSequence = ((StringBuilder)charSequence).toString();
        int n = this.iBalance;
        object = n > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (n == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text((String)charSequence, (Color)object));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_gold, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        if (this.isFestivalOrganized && CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).isInvestOrganized_TurnsLeft(this.iProvinceID) > 0) {
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Invest"), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID(), CFG.PADDING, CFG.PADDING));
            charSequence = new StringBuilder();
            ((StringBuilder)charSequence).append("+");
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).isInvestOrganized_EconomyLeft(this.iProvinceID));
            ((StringBuilder)charSequence).append(CFG.getNumberWithSpaces(((StringBuilder)object).toString()));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)charSequence).toString(), CFG.COLOR_TEXT_ECONOMY));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.economy, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID - 4 + CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).isInvestOrganized_TurnsLeft(this.iProvinceID))));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(" - ", CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).isInvestOrganized_TurnsLeft(this.iProvinceID))));
            object = new StringBuilder();
            ((StringBuilder)object).append(" [");
            ((StringBuilder)object).append(CFG.langManager.get("TurnsX", CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).isInvestOrganized_TurnsLeft(this.iProvinceID)));
            ((StringBuilder)object).append("]");
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL));
            arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0));
            arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
            arrayList2.clear();
        }
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.isFestivalOrganized) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop() > 0) {
            spriteBatch.setColor(Color.WHITE);
            ImageManager.getImage(Images.b_workshop).draw(spriteBatch, this.getPosX() + this.getWidth() - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) - CFG.PADDING * 3 - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.b_workshop).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_workshop).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_workshop).getHeight(), (int)((float)ImageManager.getImage(Images.b_workshop).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())), (int)((float)ImageManager.getImage(Images.b_workshop).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())));
            CFG.fontMain.getData().setScale(0.7f);
            CFG.drawTextWithShadow(spriteBatch, this.sLevel, this.getPosX() + this.getWidth() - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) - CFG.PADDING * 3 - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.b_workshop).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())) - CFG.PADDING - this.iLevelWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            CFG.fontMain.getData().setScale(1.0f);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING * 2 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        CharSequence charSequence = new StringBuilder();
        Object object = "";
        charSequence.append("");
        charSequence.append(this.sPopulation);
        CFG.drawText(spriteBatch, charSequence.toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationWidth - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE);
        ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())) / 2 + n2 - ImageManager.getImage(Images.top_gold).getHeight(), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_gold).getHeight())));
        CFG.fontMain.getData().setScale(0.7f);
        charSequence = new StringBuilder();
        if (this.iBalance > 0) {
            object = "+";
        }
        charSequence.append((String)object);
        charSequence.append(this.iBalance);
        charSequence = charSequence.toString();
        int n3 = this.getPosX();
        int n4 = CFG.PADDING;
        int n5 = (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight()));
        int n6 = (int)((float)this.getTextWidth() * 0.65f);
        int n7 = this.getPosY();
        int n8 = this.getHeight() / 2;
        int n9 = (int)((float)this.getTextHeight() * 0.7f / 2.0f);
        int n10 = this.iBalance;
        object = n10 > 0 ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (n10 == 0 ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        CFG.drawText(spriteBatch, (String)charSequence, n3 + n4 * 2 + n5 + n6 + n, n7 + n8 - n9 + n2, (Color)object);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : (this.isFestivalOrganized ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_OPTIONS_NS)) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

