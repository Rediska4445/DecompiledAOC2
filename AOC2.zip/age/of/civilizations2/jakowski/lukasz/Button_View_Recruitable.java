/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_View_Recruitable
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.6f;
    protected Color cColorStability;
    private boolean drawSupply = false;
    private int iPopulationPercWidth = 0;
    private int iProvinceID = 0;
    protected boolean isAssimiliate = false;
    private boolean row = false;
    private String sPopulationPerc;

    /*
     * Enabled aggressive block sorting
     */
    protected Button_View_Recruitable(int n, String string2, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, 0, n3, n4, n5, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        boolean bl2 = n % 2 == 0;
        this.row = bl2;
        this.iProvinceID = n2;
        this.sPopulationPerc = "" + CFG.getNumberWithSpaces("" + CFG.gameAction.getRecruitableArmy(this.iProvinceID));
        CFG.glyphLayout.setText(CFG.fontMain, this.sPopulationPerc);
        this.iPopulationPercWidth = (int)(CFG.glyphLayout.width * 0.6f);
        this.cColorStability = CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE;
        bl2 = CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury() > 0;
        this.drawSupply = bl2;
        this.isAssimiliate = bl;
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object = new ArrayList();
            Object object2 = new StringBuilder();
            MenuElement_Hover_v2_Element_Type_Text menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("RecruitablePopulation")).append(": ").toString());
            object.add(menuElement_Hover_v2_Element_Type_Text);
            object2 = new StringBuilder();
            menuElement_Hover_v2_Element_Type_Text = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(this.sPopulationPerc).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            object.add(menuElement_Hover_v2_Element_Type_Text);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_army, CFG.PADDING, 0);
            object.add(object2);
            object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            object.clear();
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.isAssimiliate) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury() > 0) {
            spriteBatch.setColor(Color.WHITE);
            ImageManager.getImage(Images.b_armoury).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iPopulationPercWidth - (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_armoury).getHeight(), (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())), (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())));
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(CFG.game.getProvince(this.iProvinceID).getCivID()).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        if (this.drawSupply) {
            ImageManager.getImage(Images.b_armoury).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING - this.iPopulationPercWidth + n - (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale(ImageManager.getImage(Images.b_armoury).getHeight())) - CFG.PADDING, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale(ImageManager.getImage(Images.b_armoury).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_armoury).getHeight(), (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale(ImageManager.getImage(Images.b_armoury).getHeight())), (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale(ImageManager.getImage(Images.b_armoury).getHeight())));
        }
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sPopulationPerc, this.getPosX() + this.getWidth() - CFG.PADDING - this.iPopulationPercWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f / 2.0f) + n2, this.cColorStability);
        CFG.fontMain.getData().setScale(1.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Color getColor(boolean bl) {
        if (bl) {
            return CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE;
        }
        if (!this.getClickable()) return new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f);
        if (!this.getIsHovered()) return CFG.COLOR_TEXT_OPTIONS_NS;
        return CFG.COLOR_TEXT_OPTIONS_NS_HOVER;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

