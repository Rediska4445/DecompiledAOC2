/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

public class Button_NewGameStyle_Left
extends Button {
    protected Button_NewGameStyle_Left(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false);
    }

    protected Button_NewGameStyle_Left(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super.init(string2, n, n2, n3, n4, (int)((float)CFG.BUTTON_HEIGHT * 0.65f), bl, true, false, false);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box_hover).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight());
            ImageManager.getImage(Images.new_game_box_hover).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box_hover).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box_hover).getHeight(), false, true);
        } else {
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.new_game_box).getHeight() + n2, this.getWidth(), this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight());
            ImageManager.getImage(Images.new_game_box).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.new_game_box).getHeight() * 2 + n2, this.getWidth(), ImageManager.getImage(Images.new_game_box).getHeight(), false, true);
        }
        spriteBatch.setColor(CFG.COLOR_NEW_GAME_EDGE_LINE);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() + 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight() - 4);
        spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.215f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 4);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.325f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        Object object = new Rectangle(this.getPosX() + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth(), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        if (bl) {
            CFG.fontMain.getData().setScale(0.8f);
            object = this.getText();
            int n3 = this.getPosX();
            int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, (String)object, n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        } else {
            CFG.fontMain.getData().setScale(0.8f);
            object = this.getText();
            int n5 = this.getPosX();
            int n6 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, (String)object, n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        }
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }

    @Override
    protected Color getColor(boolean bl) {
        return CFG.getColor_CivInfo_Text(bl, this.getIsHovered());
    }
}

