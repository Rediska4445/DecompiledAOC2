/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

public enum CivArmyMission_Type {
    PREAPARE_FOR_WAR,
    REGRUOP_AFTER_RECRUIT,
    REV_RISK_CONTROL_PROVINCE,
    NAVAL_INVASION,
    COLONIZE_PROVINCE,
    EXPAND_NETURAL_PROVINCE;

}

