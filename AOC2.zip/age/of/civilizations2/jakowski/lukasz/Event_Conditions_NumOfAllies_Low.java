/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Conditions_NumOfAllies_Low
extends Event_Conditions {
    protected int iCivID = -1;
    protected int iValue = 0;

    Event_Conditions_NumOfAllies_Low() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_NUMOFALLIES_LOW);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("NumberOfAllies")).append(" < ").append(this.getValue()).append(", ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("NumberOfAllies");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        boolean bl;
        block3: {
            bl = true;
            try {
                if (CFG.game.getCiv(this.getCivID()).getAllianceID() <= 0) break block3;
                if (CFG.game.getAlliance(CFG.game.getCiv(this.getCivID()).getAllianceID()).getCivilizationsSize() >= this.getValue()) return false;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                return false;
            }
            return bl;
        }
        int n = this.getValue();
        if (n > 0) return bl;
        return false;
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

