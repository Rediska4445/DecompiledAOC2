/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Type;
import age.of.civilizations2.jakowski.lukasz.Menu;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Event_Conditions
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected Event_Type conditionType = Event_Type.AND;

    Event_Conditions() {
    }

    protected void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_CIVEXIST);
    }

    protected int getCivID() {
        return -1;
    }

    protected int getCivID2() {
        return -1;
    }

    protected String getConditionText() {
        return "";
    }

    protected List<Integer> getProvinces() {
        return new ArrayList<Integer>();
    }

    protected String getText() {
        return "";
    }

    protected int getValue() {
        return -1;
    }

    protected boolean outCondition() {
        return false;
    }

    protected void setCivID(int n) {
    }

    protected void setCivID2(int n) {
    }

    protected void setProvinces(List<Integer> list) {
    }

    protected void setText(String string2) {
    }

    protected void setValue(int n) {
    }

    protected boolean updateCivIDAfterRemove(int n) {
        return false;
    }
}

