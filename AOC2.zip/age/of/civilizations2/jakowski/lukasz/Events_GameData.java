/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Event_GameData;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Events_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iEventsSize = 0;
    protected List<Event_GameData> lEvents = new ArrayList<Event_GameData>();

    Events_GameData() {
    }
}

