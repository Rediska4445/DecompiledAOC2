/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_Remove
extends Button_Menu {
    protected Button_Menu_Remove(int n, int n2, int n3, int n4, boolean bl) {
        super("", 0, n, n2, n3, n4, bl);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_menu_1_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth());
        }
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(Color.WHITE);
        if (bl) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.45f));
            ImageManager.getImage(Images.btn_remove).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_remove).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_remove).getHeight() / 2 + n2, true);
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_remove).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_remove).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_remove).getHeight() / 2 + n2, true);
        }
    }
}

