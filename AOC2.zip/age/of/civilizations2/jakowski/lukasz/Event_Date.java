/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Event_Date
implements Serializable {
    protected static final int NOT_SET_UPED = 9999999;
    protected int iEventDay = 1;
    protected int iEventMonth = 1;
    protected int iEventYear = 9999999;

    Event_Date() {
    }
}

