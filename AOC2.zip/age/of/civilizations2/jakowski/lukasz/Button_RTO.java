/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_RTO
extends Button_Menu {
    protected int iCivID;

    protected Button_RTO(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        String string2;
        StringBuilder stringBuilder;
        if (n2 > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            stringBuilder.append(". ");
            string2 = CFG.game.getCiv(n2).getCivName();
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            stringBuilder.append(". ");
            string2 = CFG.langManager.get("Undiscovered");
        }
        stringBuilder.append(string2);
        super(stringBuilder.toString(), CFG.PADDING + CFG.PADDING / 2, n3 + 2, n4, n5 - 2, n6, bl);
        this.iCivID = n2;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (!bl && !this.getIsHovered()) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        } else {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        }
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, 0.1f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() * 2 + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, 0.45f));
        ImageManager.getImage(Images.line_32).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.line_32).getHeight() * 2 + n2, this.getWidth(), 1);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() - CFG.CIV_FLAG_HEIGHT / 2 + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getTextPos() + this.getPosX() + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawText(spriteBatch, this.getText(), this.getTextPos() + this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT : CFG.COLOR_BUTTON_GAME_TEXT_HOVERED) : CFG.COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }
}

