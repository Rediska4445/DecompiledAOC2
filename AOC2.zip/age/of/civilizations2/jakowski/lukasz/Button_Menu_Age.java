/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_Age
extends Button_Menu {
    protected Button_Menu_Age(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_Age(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            spriteBatch.setColor(0.981f, 0.981f, 0.981f, 0.75f);
        } else {
            spriteBatch.setColor(0.019f, 0.024f, 0.03f, 0.75f);
        }
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight(), false, false);
        if (bl) {
            spriteBatch.setColor(0.0f, 0.0f, 0.0f, 1.0f);
        } else {
            spriteBatch.setColor(CFG.COLOR_MINIMAP_BORDER);
        }
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(Color.WHITE);
    }
}

