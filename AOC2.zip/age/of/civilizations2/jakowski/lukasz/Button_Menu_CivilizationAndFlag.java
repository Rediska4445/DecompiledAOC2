/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_CivilizationAndFlag
extends Button_Menu {
    private int iCivID;

    protected Button_Menu_CivilizationAndFlag(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super(CFG.game.getCiv(n).getCivName(), n2, n3, n4, n5, n6, bl);
        this.iCivID = n;
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getTextPos() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
    }

    @Override
    protected int getCurrent() {
        return this.iCivID;
    }
}

