/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization_GameData3;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Event_Outcome_FormCivilization
extends Event_Outcome {
    protected int iCivID = -1;
    protected String sTag = "";

    Event_Outcome_FormCivilization() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected boolean canMakeAction() {
        boolean bl = false;
        int n = 0;
        while (true) {
            block5: {
                if (n >= CFG.game.getCivsSize()) break;
                if (!CFG.game.getCiv(n).getCivTag().equals(this.sTag)) break block5;
                if (CFG.game.getCiv(n).getNumOfProvinces() <= 0) break;
                return bl;
            }
            ++n;
        }
        boolean bl2 = bl;
        try {
            if (this.getCivID() < 0) return bl2;
            bl2 = bl;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
        if (this.getCivID() >= CFG.game.getCivsSize()) return bl2;
        boolean bl3 = this.sTag.equals("");
        bl2 = bl;
        if (bl3) return bl2;
        return true;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_FORM_CIV);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("FormCivilization")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(" -> ").append(CFG.langManager.getCiv(this.getText())).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("FormCivilization");
            return var1_3;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected List<MenuElement_Hover_v2_Element2> getHoverText() {
        ArrayList arrayList = new ArrayList();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        ArrayList arrayList3 = arrayList;
        try {
            if (!this.canMakeAction()) return arrayList3;
            StringBuilder stringBuilder = new StringBuilder();
            arrayList3 = new ArrayList(stringBuilder.append(CFG.langManager.get("FormCivilization")).append(": ").toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(this.getCivID(), 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.game.getCiv(this.getCivID()).getCivName());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(" -> ", CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(CFG.langManager.getCiv(this.getText()));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)((Object)arrayList3));
            arrayList3 = new ArrayList(arrayList2);
            arrayList.add(arrayList3);
            arrayList2.clear();
            return arrayList;
        }
        catch (NullPointerException nullPointerException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return new ArrayList<MenuElement_Hover_v2_Element2>();
        }
    }

    @Override
    protected String getText() {
        return this.sTag;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    protected void outcomeAction() {
        int n;
        block29: {
            Object object;
            Object object2;
            int n2;
            if (!this.canMakeAction()) return;
            int n3 = -1;
            n = 0;
            while (true) {
                n2 = n3;
                if (n >= CFG.game.getCivsSize()) break;
                if (CFG.game.getCiv(n).getCivTag().equals(this.sTag)) {
                    n3 = n;
                    if (CFG.game.getCiv(n).getNumOfProvinces() > 0) return;
                    n2 = n3;
                    if (n3 != this.getCivID()) break;
                    return;
                }
                ++n;
            }
            if (n2 > 0) {
                String string2 = CFG.game.getCiv(this.getCivID()).getCivTag();
                CFG.game.getCiv(this.getCivID()).setCivTag(CFG.game.getCiv(n2).getCivTag());
                CFG.game.getCiv(n2).setCivTag(string2);
                CFG.game.getCiv(this.getCivID()).loadFlag();
                CFG.game.getCiv(n2).loadFlag();
                for (n = 0; n < CFG.game.getCiv(this.getCivID()).getCivRegionsSize(); ++n) {
                    CFG.game.getCiv(this.getCivID()).getCivRegion(n).buildScaleOfText();
                }
                for (n = 0; n < CFG.game.getCiv(n2).getCivRegionsSize(); ++n) {
                    CFG.game.getCiv(n2).getCivRegion(n).buildScaleOfText();
                }
                n = CFG.game.getCiv(this.getCivID()).getR();
                CFG.game.getCiv(this.getCivID()).setR(CFG.game.getCiv(n2).getR());
                CFG.game.getCiv(n2).setR(n);
                n = CFG.game.getCiv(this.getCivID()).getG();
                CFG.game.getCiv(this.getCivID()).setG(CFG.game.getCiv(n2).getG());
                CFG.game.getCiv(n2).setG(n);
                n = CFG.game.getCiv(this.getCivID()).getB();
                CFG.game.getCiv(this.getCivID()).setB(CFG.game.getCiv(n2).getB());
                CFG.game.getCiv(n2).setB(n);
                CFG.game.getCiv(this.getCivID()).updateCivilizationIdeology();
                CFG.game.getCiv(n2).updateCivilizationIdeology();
                CFG.gameNewGame.updateFormableCivilizations(this.getCivID());
                CFG.gameNewGame.updateFormableCivilizations(n2);
                for (n = 0; n < CFG.game.getCiv(this.getCivID()).getNumOfProvinces(); ++n) {
                    CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n)).setFromCivID(0);
                }
                for (n = 0; n < CFG.game.getCiv(n2).getNumOfProvinces(); ++n) {
                    CFG.game.getProvince(CFG.game.getCiv(n2).getProvinceID(n)).setFromCivID(0);
                }
                n = 0;
                while (true) {
                    if (n >= CFG.game.getPlayersSize()) {
                        CFG.eventsManager.swapIDsOfCivs(this.getCivID(), n2);
                        if (CFG.game.getActiveProvinceID() < 0) return;
                        n = CFG.game.getActiveProvinceID();
                        CFG.game.setActiveProvinceID(-1);
                        CFG.game.setActiveProvinceID(n);
                        return;
                    }
                    if (CFG.game.getPlayer(n).getCivID() == this.getCivID() || CFG.game.getPlayer(n).getCivID() == n2) {
                        CFG.game.getPlayer(n).loadPlayersFlag();
                    }
                    ++n;
                }
            }
            CFG.game.getCiv(this.getCivID()).setCivTag(this.getText());
            CFG.game.getCiv(this.getCivID()).setCivName(CFG.langManager.getCiv(CFG.game.getCiv(this.getCivID()).getCivTag()));
            CFG.game.getCiv(this.getCivID()).loadFlag();
            for (n = 0; n < CFG.game.getCiv(this.getCivID()).getCivRegionsSize(); ++n) {
                CFG.game.getCiv(this.getCivID()).getCivRegion(n).buildScaleOfText();
            }
            CFG.game.getCiv(this.getCivID()).updateCivilizationIdeology();
            try {
                object2 = Gdx.files;
                object = new StringBuilder();
                object = (Civilization_GameData3)CFG.deserialize(object2.internal(((StringBuilder)object).append("game/civilizations/").append(this.getText()).toString()).readBytes());
                CFG.game.getCiv(this.getCivID()).setR(((Civilization_GameData3)object).getR());
                CFG.game.getCiv(this.getCivID()).setG(((Civilization_GameData3)object).getG());
                CFG.game.getCiv(this.getCivID()).setB(((Civilization_GameData3)object).getB());
            }
            catch (GdxRuntimeException gdxRuntimeException) {
                try {
                    try {
                        object = Gdx.files;
                        object2 = new StringBuilder();
                        object2 = (Civilization_GameData3)CFG.deserialize(object.internal(((StringBuilder)object2).append("game/civilizations/").append(CFG.ideologiesManager.getRealTag(this.getText())).toString()).readBytes());
                        n = CFG.ideologiesManager.getIdeologyID(this.getText());
                        object = new Color((float)((Civilization_GameData3)object2).getR() / 255.0f, (float)((Civilization_GameData3)object2).getG() / 255.0f, (float)((Civilization_GameData3)object2).getB() / 255.0f, 0.775f);
                        object2 = new Color(CFG.ideologiesManager.getIdeology((int)n).getColor().r, CFG.ideologiesManager.getIdeology((int)n).getColor().g, CFG.ideologiesManager.getIdeology((int)n).getColor().b, 0.225f);
                        object = CFG.getColorMixed((Color)object, (Color)object2);
                        CFG.game.getCiv(this.getCivID()).setR((int)(((Color)object).r * 255.0f));
                        CFG.game.getCiv(this.getCivID()).setG((int)(((Color)object).g * 255.0f));
                        CFG.game.getCiv(this.getCivID()).setB((int)(((Color)object).b * 255.0f));
                    }
                    catch (GdxRuntimeException gdxRuntimeException2) {
                        try {
                            object = Gdx.files;
                            object2 = new StringBuilder();
                            object = (Civilization_GameData3)CFG.deserialize(object.local(((StringBuilder)object2).append("game/civilizations/").append(this.getText()).toString()).readBytes());
                            CFG.game.getCiv(this.getCivID()).setR(((Civilization_GameData3)object).getR());
                            CFG.game.getCiv(this.getCivID()).setG(((Civilization_GameData3)object).getG());
                            CFG.game.getCiv(this.getCivID()).setB(((Civilization_GameData3)object).getB());
                        }
                        catch (GdxRuntimeException gdxRuntimeException3) {
                            try {
                                object2 = Gdx.files;
                                object = new StringBuilder();
                                object2 = (Civilization_GameData3)CFG.deserialize(object2.local(((StringBuilder)object).append("game/civilizations/").append(CFG.ideologiesManager.getRealTag(this.getText())).toString()).readBytes());
                                n = CFG.ideologiesManager.getIdeologyID(this.getText());
                                object = new Color((float)((Civilization_GameData3)object2).getR() / 255.0f, (float)((Civilization_GameData3)object2).getG() / 255.0f, (float)((Civilization_GameData3)object2).getB() / 255.0f, 0.775f);
                                object2 = new Color(CFG.ideologiesManager.getIdeology((int)n).getColor().r, CFG.ideologiesManager.getIdeology((int)n).getColor().g, CFG.ideologiesManager.getIdeology((int)n).getColor().b, 0.225f);
                                object = CFG.getColorMixed((Color)object, (Color)object2);
                                CFG.game.getCiv(this.getCivID()).setR((int)(((Color)object).r * 255.0f));
                                CFG.game.getCiv(this.getCivID()).setG((int)(((Color)object).g * 255.0f));
                                CFG.game.getCiv(this.getCivID()).setB((int)(((Color)object).b * 255.0f));
                            }
                            catch (GdxRuntimeException gdxRuntimeException4) {
                                block30: {
                                    boolean bl = CFG.isAndroid();
                                    if (!bl) break block30;
                                    {
                                        catch (GdxRuntimeException gdxRuntimeException5) {}
                                    }
                                    try {
                                        object = Gdx.files;
                                        object2 = new StringBuilder();
                                        object = (Civilization_GameData3)CFG.deserialize(object.local(((StringBuilder)object2).append("game/civilizations_editor/").append(CFG.ideologiesManager.getRealTag(this.getText())).append("/").append(CFG.ideologiesManager.getRealTag(this.getText())).toString()).readBytes());
                                        CFG.game.getCiv(this.getCivID()).setR(((Civilization_GameData3)object).getR());
                                        CFG.game.getCiv(this.getCivID()).setG(((Civilization_GameData3)object).getG());
                                        CFG.game.getCiv(this.getCivID()).setB(((Civilization_GameData3)object).getB());
                                    }
                                    catch (GdxRuntimeException gdxRuntimeException6) {
                                        object2 = Gdx.files;
                                        object = new StringBuilder();
                                        object = (Civilization_GameData3)CFG.deserialize(object2.internal(((StringBuilder)object).append("game/civilizations_editor/").append(CFG.ideologiesManager.getRealTag(this.getText())).append("/").append(CFG.ideologiesManager.getRealTag(this.getText())).toString()).readBytes());
                                        CFG.game.getCiv(this.getCivID()).setR(((Civilization_GameData3)object).getR());
                                        CFG.game.getCiv(this.getCivID()).setG(((Civilization_GameData3)object).getG());
                                        CFG.game.getCiv(this.getCivID()).setB(((Civilization_GameData3)object).getB());
                                        break block29;
                                    }
                                    break block29;
                                }
                                object = Gdx.files;
                                object2 = new StringBuilder();
                                object = (Civilization_GameData3)CFG.deserialize(object.internal(((StringBuilder)object2).append("game/civilizations_editor/").append(CFG.ideologiesManager.getRealTag(this.getText())).append("/").append(CFG.ideologiesManager.getRealTag(this.getText())).toString()).readBytes());
                                CFG.game.getCiv(this.getCivID()).setR(((Civilization_GameData3)object).getR());
                                CFG.game.getCiv(this.getCivID()).setG(((Civilization_GameData3)object).getG());
                                CFG.game.getCiv(this.getCivID()).setB(((Civilization_GameData3)object).getB());
                            }
                        }
                    }
                }
                catch (ClassNotFoundException classNotFoundException) {
                }
                catch (IOException iOException) {}
            }
        }
        CFG.gameNewGame.updateFormableCivilizations(this.getCivID());
        n = 0;
        while (true) {
            if (n >= CFG.game.getCiv(this.getCivID()).getNumOfProvinces()) {
                if (CFG.game.getActiveProvinceID() < 0) return;
                n = CFG.game.getActiveProvinceID();
                CFG.game.setActiveProvinceID(-1);
                CFG.game.setActiveProvinceID(n);
                return;
            }
            CFG.game.getProvince(CFG.game.getCiv(this.getCivID()).getProvinceID(n)).setFromCivID(0);
            ++n;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setText(String string2) {
        this.sTag = string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

