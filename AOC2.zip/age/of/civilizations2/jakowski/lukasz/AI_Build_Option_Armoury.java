/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Armoury;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Option;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option_Armoury
extends AI_Build_Option {
    AI_Build_Option_Armoury() {
    }

    @Override
    protected AI_Build getData(int n) {
        return new AI_Build_Armoury(n, this.getMoney(n));
    }

    @Override
    protected float getScore(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_ARMOURY * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Armories / Math.max(CFG.game.getCiv(n).getNumOfProvinces() * BuildingsManager.getArmoury_MaxLevel(), 1)));
    }
}

