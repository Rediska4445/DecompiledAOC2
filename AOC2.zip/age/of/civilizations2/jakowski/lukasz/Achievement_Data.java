/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civilization_GameData3;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.GdxRuntimeException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Achievement_Data {
    protected static final float FONT_SCALE = 0.8f;
    private int TIME_IN_VIEW;
    private int TIME_IN_VIEW_HIDE_ANIMATION;
    private int iCivID;
    private int iLevelID;
    private int iSRID;
    private int iSROverID;
    private int iTextNumWidth;
    private int iTextWidth;
    private List<Color> lColors;
    private long lTime;
    private String sText;
    private String sTextNum;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected Achievement_Data(int n, String object, String string2, String object2, int n2) {
        block18: {
            block20: {
                ClassNotFoundException classNotFoundException2;
                block19: {
                    this.iTextWidth = -1;
                    this.iTextNumWidth = -1;
                    int n3 = 0;
                    this.iSROverID = 0;
                    this.TIME_IN_VIEW = 4500;
                    this.TIME_IN_VIEW_HIDE_ANIMATION = 500;
                    this.iSRID = 0;
                    this.iLevelID = 0;
                    this.iCivID = n;
                    this.sText = string2;
                    this.sTextNum = object2;
                    this.iLevelID = n2;
                    CFG.glyphLayout.setText(CFG.fontMain, this.sText);
                    this.iTextWidth = (int)(CFG.glyphLayout.width * 0.8f);
                    CFG.glyphLayout.setText(CFG.fontMain, this.sTextNum);
                    this.iTextNumWidth = (int)(CFG.glyphLayout.width * 0.8f);
                    this.lColors = new ArrayList<Color>();
                    this.iSROverID = ((String)object).charAt(0) % CFG.serviceRibbon_Manager.getSROverlayImagesSize();
                    string2 = object;
                    if (((String)object).indexOf(";") > 0) {
                        string2 = ((String)object).split(";")[0];
                    }
                    try {
                        try {
                            object = Gdx.files;
                            ((StringBuilder)object2).append("game/civilizations/");
                            ((StringBuilder)object2).append(string2);
                            object = (Civilization_GameData3)CFG.deserialize(object.internal(((StringBuilder)object2).toString()).readBytes());
                        }
                        catch (GdxRuntimeException gdxRuntimeException) {
                            try {
                                object = Gdx.files;
                                super();
                                ((StringBuilder)object2).append("game/civilizations/");
                                ((StringBuilder)object2).append(CFG.ideologiesManager.getRealTag(string2));
                                object = (Civilization_GameData3)CFG.deserialize(object.internal(((StringBuilder)object2).toString()).readBytes());
                                break block18;
                            }
                            catch (GdxRuntimeException gdxRuntimeException2) {
                                try {
                                    object2 = Gdx.files;
                                    object = new StringBuilder();
                                    ((StringBuilder)object).append("game/civilizations_editor/");
                                    ((StringBuilder)object).append(string2);
                                    ((StringBuilder)object).append("/");
                                    ((StringBuilder)object).append(string2);
                                    object = (Civilization_GameData3)CFG.deserialize(object2.local(((StringBuilder)object).toString()).readBytes());
                                    break block18;
                                }
                                catch (GdxRuntimeException gdxRuntimeException3) {
                                    try {
                                        object2 = Gdx.files;
                                        object = new StringBuilder();
                                        ((StringBuilder)object).append("game/civilizations_editor/");
                                        ((StringBuilder)object).append(string2);
                                        ((StringBuilder)object).append("/");
                                        ((StringBuilder)object).append(string2);
                                        object = (Civilization_GameData3)CFG.deserialize(object2.internal(((StringBuilder)object).toString()).readBytes());
                                        break block18;
                                    }
                                    catch (GdxRuntimeException gdxRuntimeException4) {
                                        try {
                                            object2 = Gdx.files;
                                            object = new StringBuilder();
                                            ((StringBuilder)object).append("game/civilizations_editor/");
                                            ((StringBuilder)object).append(CFG.ideologiesManager.getRealTag(string2));
                                            ((StringBuilder)object).append("/");
                                            ((StringBuilder)object).append(CFG.ideologiesManager.getRealTag(string2));
                                            object = (Civilization_GameData3)CFG.deserialize(object2.local(((StringBuilder)object).toString()).readBytes());
                                            break block18;
                                        }
                                        catch (GdxRuntimeException gdxRuntimeException5) {
                                            object2 = Gdx.files;
                                            object = new StringBuilder();
                                            ((StringBuilder)object).append("game/civilizations_editor/");
                                            ((StringBuilder)object).append(CFG.ideologiesManager.getRealTag(string2));
                                            ((StringBuilder)object).append("/");
                                            ((StringBuilder)object).append(CFG.ideologiesManager.getRealTag(string2));
                                            object = (Civilization_GameData3)CFG.deserialize(object2.internal(((StringBuilder)object).toString()).readBytes());
                                        }
                                    }
                                }
                            }
                        }
                        break block18;
                    }
                    catch (IOException iOException) {
                    }
                    catch (ClassNotFoundException classNotFoundException2) {
                        break block19;
                    }
                    if (CFG.LOGS) {
                        CFG.exceptionStack(iOException);
                    }
                    break block20;
                }
                if (CFG.LOGS) {
                    CFG.exceptionStack(classNotFoundException2);
                }
            }
            object = null;
        }
        if (((Civilization_GameData3)object).sr_GameData != null) {
            this.iSRID = CFG.serviceRibbon_Manager.getSRID(((Civilization_GameData3)object).sr_GameData.getSRTAG());
            for (n = n3; n < ((Civilization_GameData3)object).sr_GameData.getColors().size(); ++n) {
                this.lColors.add(new Color(((Civilization_GameData3)object).sr_GameData.getColor(n).getR(), ((Civilization_GameData3)object).sr_GameData.getColor(n).getG(), ((Civilization_GameData3)object).sr_GameData.getColor(n).getB(), 1.0f));
            }
            this.lTime = System.currentTimeMillis();
        }
    }

    private final float getAlpha() {
        if (System.currentTimeMillis() > this.lTime + (long)this.TIME_IN_VIEW - (long)this.TIME_IN_VIEW_HIDE_ANIMATION) {
            long l = System.currentTimeMillis();
            long l2 = this.lTime;
            long l3 = this.TIME_IN_VIEW;
            int n = this.TIME_IN_VIEW_HIDE_ANIMATION;
            return Math.max(0.0f, 1.0f - (float)(l - (l2 + l3 - (long)n)) / (float)n);
        }
        return 1.0f;
    }

    private final int getHeight() {
        return CFG.TEXT_HEIGHT + CFG.PADDING * 2 + CFG.SERVICE_RIBBON_HEIGHT + CFG.PADDING * 2 + CFG.PADDING * 2;
    }

    private final int getPosX() {
        return CFG.GAME_WIDTH / 2 - this.getWidth() / 2;
    }

    private final int getPosY() {
        return CFG.BUTTON_HEIGHT * 3 / 4;
    }

    private final int getWidth() {
        return Math.max(this.iTextWidth + this.iTextNumWidth + CFG.PADDING * 10, CFG.SERVICE_RIBBON_WIDTH * (this.iLevelID + 1) + CFG.PADDING * this.iLevelID + CFG.PADDING * 10);
    }

    protected final boolean canBeDisposed() {
        boolean bl = System.currentTimeMillis() > this.lTime + (long)this.TIME_IN_VIEW;
        return bl;
    }

    protected final void draw(SpriteBatch spriteBatch, int n, int n2) {
        float f = this.getAlpha();
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, CFG.COLOR_GRADIENT_DARK_BLUE.a * f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, f * 1.0f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - 2 + this.getHeight() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f * f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - 1 + this.getHeight() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f * f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING * 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), CFG.SERVICE_RIBBON_HEIGHT);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f * f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - 1 + CFG.PADDING * 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.SERVICE_RIBBON_HEIGHT + CFG.PADDING * 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(Color.WHITE);
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sText, this.getPosX() + this.getWidth() / 2 - (this.iTextWidth + this.iTextNumWidth) / 2 + n, this.getPosY() + CFG.SERVICE_RIBBON_HEIGHT + CFG.PADDING * 4 + n2, new Color(CFG.COLOR_TEXT_MODIFIER_NEUTRAL.r, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.g, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.b, CFG.COLOR_TEXT_MODIFIER_NEUTRAL.a * f));
        String string2 = this.sTextNum;
        int n3 = this.getPosX();
        int n4 = this.getWidth() / 2;
        int n5 = this.iTextWidth;
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 - (this.iTextNumWidth + n5) / 2 + n5 + n, this.getPosY() + CFG.SERVICE_RIBBON_HEIGHT + CFG.PADDING * 4 + n2, new Color(CFG.COLOR_TEXT_NUM_OF_PROVINCES.r, CFG.COLOR_TEXT_NUM_OF_PROVINCES.g, CFG.COLOR_TEXT_NUM_OF_PROVINCES.b, CFG.COLOR_TEXT_NUM_OF_PROVINCES.a * f));
        CFG.fontMain.getData().setScale(1.0f);
        for (n3 = 0; n3 < this.iLevelID + 1; ++n3) {
            CFG.serviceRibbon_Manager.drawSRLevel(spriteBatch, this.getPosX() + this.getWidth() / 2 - (CFG.SERVICE_RIBBON_WIDTH * (this.iLevelID + 1) + CFG.PADDING * this.iLevelID) / 2 + CFG.SERVICE_RIBBON_WIDTH * n3 + CFG.PADDING * n3 + n, this.getPosY() + CFG.PADDING * 2 + n2, n3, 0, this.iSROverID, this.iSRID, this.lColors);
        }
        CFG.setRender_3(true);
    }
}

