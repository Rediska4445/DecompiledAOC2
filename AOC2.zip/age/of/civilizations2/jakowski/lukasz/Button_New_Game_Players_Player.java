/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_New_Game_Players;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

class Button_New_Game_Players_Player
extends Button_New_Game_Players {
    protected static final int ANIMATION_T = 1000;
    private int animationState = 0;
    private boolean backAnimation = false;
    private float fAlphaMod = 0.0f;
    private long lTime = 0L;
    private long lTimeAnimation = 0L;

    protected Button_New_Game_Players_Player(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (this.lTime < System.currentTimeMillis() - 26L) {
            if (this.backAnimation) {
                this.fAlphaMod -= 0.02f;
                if (this.fAlphaMod < 0.0f) {
                    this.backAnimation = false;
                }
            } else {
                this.fAlphaMod += 0.02f;
                if (this.fAlphaMod > 0.4f) {
                    this.backAnimation = true;
                }
            }
            this.lTime = System.currentTimeMillis();
        }
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.325f - this.fAlphaMod));
        CFG.setRender_3(true);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        int n3 = this.animationState;
        if (n3 >= 0) {
            float f = 0.425f;
            if (n3 == 0) {
                float f2 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 1000.0f, 1.0f);
                float f3 = CFG.COLOR_FLAG_FRAME.r;
                float f4 = CFG.COLOR_FLAG_FRAME.g;
                float f5 = CFG.COLOR_FLAG_FRAME.b;
                if (!this.getIsHovered()) {
                    f = 0.325f;
                }
                spriteBatch.setColor(new Color(f3, f4, f5, f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f2), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 1000L) {
                    ++this.animationState;
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f6 = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 1000.0f, 1.0f);
                float f7 = CFG.COLOR_FLAG_FRAME.r;
                float f8 = CFG.COLOR_FLAG_FRAME.g;
                float f9 = CFG.COLOR_FLAG_FRAME.b;
                if (!this.getIsHovered()) {
                    f = 0.325f;
                }
                spriteBatch.setColor(new Color(f7, f8, f9, f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f6), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 1000L) {
                    this.animationState = 0;
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (CFG.game.getPlayer(0).getCivID() < 0) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        } else {
            CFG.game.getCiv(CFG.game.getPlayer(0).getCivID()).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(CFG.game.getPlayer(0).getCivID()).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2);
        Object object = new Rectangle(this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 3 + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - (CFG.CIV_FLAG_WIDTH + CFG.PADDING * 4), -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object);
        CFG.fontMain.getData().setScale(0.8f);
        object = CFG.game.getPlayer(0).getCivID() < 0 ? CFG.RANDOM_CIVILIZATION : CFG.game.getCiv(CFG.game.getPlayer(0).getCivID()).getCivName();
        CFG.drawText(spriteBatch, (String)object, this.getPosX() + CFG.CIV_FLAG_WIDTH + CFG.PADDING * 3 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException | IndexOutOfBoundsException | NullPointerException runtimeException) {
            return;
        }
    }
}

