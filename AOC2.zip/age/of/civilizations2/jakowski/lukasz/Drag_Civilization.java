/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Drag_Civilization {
    private int iCivID = 0;
    private int iPosX;
    private int iPosY;
    private boolean visible = false;

    Drag_Civilization() {
    }

    protected final void draw(SpriteBatch spriteBatch, int n) {
        if (this.visible) {
            int n2 = (int)((float)CFG.game.getCiv(this.iCivID).getCivNameHeight() * 100.0f / (float)CFG.CIV_FLAG_HEIGHT * (float)CFG.CIV_FLAG_WIDTH / 100.0f);
            int n3 = (int)((float)(CFG.CIV_FLAG_HEIGHT * CFG.game.getCiv(this.iCivID).getCivNameHeight()) * 100.0f / (float)CFG.CIV_FLAG_HEIGHT / 100.0f);
            spriteBatch.setColor(new Color(0.015686275f, 0.015686275f, 0.015686275f, 1.0f));
            Game game = CFG.game;
            int n4 = this.iPosX;
            int n5 = CFG.game.getCiv(this.iCivID).getCivNameWidth() / 2;
            int n6 = CFG.CIV_COLOR_WIDTH;
            int n7 = n2 / 2;
            game.drawCivNameBG(spriteBatch, n4 - n5 - n6 - n7 - CFG.CIV_NAME_BG_EXTRA_WIDTH + n, this.iPosY - CFG.game.getCiv(this.iCivID).getCivNameHeight() / 2 - CFG.CIV_NAME_BG_EXTRA_HEIGHT, CFG.game.getCiv(this.iCivID).getCivNameWidth() + CFG.CIV_NAME_BG_EXTRA_WIDTH * 2 + n2 + CFG.CIV_COLOR_WIDTH, CFG.game.getCiv(this.iCivID).getCivNameHeight() + CFG.CIV_NAME_BG_EXTRA_HEIGHT * 2);
            CFG.drawText(spriteBatch, CFG.game.getCiv(this.iCivID).getCivName(), this.iPosX - CFG.game.getCiv(this.iCivID).getCivNameWidth() / 2 + n7 + n, this.iPosY - CFG.game.getCiv(this.iCivID).getCivNameHeight() / 2, new Color(0.9843137f, 0.9843137f, 0.9843137f, 1.0f));
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.iPosX - CFG.game.getCiv(this.iCivID).getCivNameWidth() / 2 - n7 - CFG.CIV_COLOR_WIDTH + n, this.iPosY - CFG.game.getCiv(this.iCivID).getCivNameHeight() / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight(), n2, n3);
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.iPosX - CFG.game.getCiv(this.iCivID).getCivNameWidth() / 2 - n7 - CFG.CIV_COLOR_WIDTH + n, this.iPosY - CFG.game.getCiv(this.iCivID).getCivNameHeight() / 2 - ImageManager.getImage(Images.flag_rect).getHeight(), n2, n3);
        }
    }

    protected final int getCivID() {
        return this.iCivID;
    }

    protected final int getPosX() {
        return this.iPosX;
    }

    protected final int getPosY() {
        return this.iPosY;
    }

    protected final boolean getVisible() {
        return this.visible;
    }

    protected final void setCivID(int n) {
        this.iCivID = n;
    }

    protected final void setPosX(int n) {
        this.iPosX = n;
        CFG.setRender_3(true);
    }

    protected final void setPosY(int n) {
        this.iPosY = n;
    }

    protected final void setVisible(boolean bl) {
        this.visible = bl;
    }
}

