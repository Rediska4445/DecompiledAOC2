/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Menu_Descripted
extends Button_Menu {
    private String sDesc;

    protected Button_Menu_Descripted(String string2, String string3, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string3, n, n2, n3, n4, n5, bl);
        this.sDesc = string2;
    }

    protected Button_Menu_Descripted(String string2, String string3, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string3, n, n2, n3, n4, n5, bl, bl2);
        this.sDesc = string2;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.9f);
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = this.getTextPos();
        int n5 = this.getPosY();
        int n6 = this.getHeight() / 2;
        int n7 = (int)((float)CFG.TEXT_HEIGHT * 0.9f + (float)CFG.PADDING + (float)CFG.TEXT_HEIGHT * 0.7f) / 2;
        Color color2 = this.getIsHovered() ? CFG.COLOR_TEXT_CNG_TOP_SCENARIO_NAME_HOVER : CFG.COLOR_TEXT_CNG_TOP_SCENARIO_NAME;
        CFG.drawText(spriteBatch, string2, n3 + n4 + n, n5 + n6 - n7 + n2, color2);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.sDesc, this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.9f + (float)CFG.PADDING + (float)CFG.TEXT_HEIGHT * 0.7f) / 2 + CFG.PADDING + (int)((float)CFG.TEXT_HEIGHT * 0.9f) + n2, new Color(0.58f, 0.58f, 0.58f, 1.0f));
        CFG.fontMain.getData().setScale(1.0f);
    }
}

