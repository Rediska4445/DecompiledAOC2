/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.util.ArrayList;
import java.util.List;

class AI_ReleaseVassal {
    protected int iCivID;
    protected List<Integer> lProvinces = new ArrayList<Integer>();

    protected AI_ReleaseVassal(int n, int n2) {
        this.iCivID = n;
        this.addProvince(n2);
    }

    protected final void addProvince(int n) {
        this.lProvinces.add(n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean haveProvince(int n) {
        int n2 = this.lProvinces.size() - 1;
        while (n2 >= 0) {
            if (this.lProvinces.get(n2) == n) {
                return true;
            }
            --n2;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean removeProvinceID(int n) {
        int n2 = this.lProvinces.size() - 1;
        while (n2 >= 0) {
            if (this.lProvinces.get(n2) == n) {
                this.lProvinces.remove(n2);
                return true;
            }
            --n2;
        }
        return false;
    }
}

