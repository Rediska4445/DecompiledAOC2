/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

enum Editors {
    eTERRAINS,
    eSHIFT_ARMY,
    eSHIFT_PORT,
    eLEVEL_OF_PORT,
    ePROVINCE_TEXTURE,
    ePROVINCE_CONTINENTS,
    ePROVINCE_REGIONS,
    ePROVINCE_MAP_REGIONS,
    eNEIGHBORING_PROVINCES,
    eGROWTH_RATE;

}

