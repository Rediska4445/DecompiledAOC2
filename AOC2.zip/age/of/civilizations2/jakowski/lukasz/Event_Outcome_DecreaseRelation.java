/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Outcome_DecreaseRelation
extends Event_Outcome {
    protected int iCivID = -1;
    protected int iCivID2 = -1;
    protected int iValue = 0;

    Event_Outcome_DecreaseRelation() {
    }

    protected boolean canMakeAction() {
        return false;
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_OUT_DECRELATION);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    @Override
    protected int getCivID2() {
        return this.iCivID2;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("DecreaseRelation")).append(": ").append(CFG.game.getCiv(this.getCivID()).getCivName()).append(", ").append(CFG.game.getCiv(this.getCivID2()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("DecreaseRelation");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    @Override
    protected void outcomeAction() {
        if (this.getCivID() < 0 || this.getCivID() >= CFG.game.getCivsSize() || this.getCivID2() < 0 || this.getCivID2() < CFG.game.getCivsSize()) {
            // empty if block
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setCivID2(int n) {
        this.iCivID2 = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        boolean bl;
        boolean bl2 = false;
        if (this.iCivID == n) {
            this.iCivID = -1;
            bl = true;
        } else {
            bl = bl2;
            if (n < this.iCivID) {
                --this.iCivID;
                bl = bl2;
            }
        }
        if (this.iCivID2 == n) {
            this.iCivID2 = -1;
            return true;
        }
        bl2 = bl;
        if (n >= this.iCivID2) return bl2;
        --this.iCivID2;
        return bl;
    }
}

