/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.LanguageManager;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_Likelihood
extends Button {
    protected static final int ANIMATION_TIME = 375;
    protected static final float FONT_SIZE = 0.55f;
    private float fPerc = 1.0f;
    private int iLikelihoodwidth;
    private int iResWidth;
    private long lTime;
    private String sLikelihood;
    private String sRes;

    protected Button_Likelihood(float f, int n, int n2, int n3) {
        String string2;
        super.init("", 0, n, n2, n3, (int)((float)CFG.TEXT_HEIGHT * 0.95f + (float)(CFG.PADDING * 2)), true, true, false, false, null);
        this.fPerc = f;
        this.lTime = System.currentTimeMillis();
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("LikelihoodOfSuccess"));
        ((StringBuilder)object).append(": ");
        this.sLikelihood = ((StringBuilder)object).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sLikelihood);
        this.iLikelihoodwidth = (int)(CFG.glyphLayout.width * 0.55f);
        if (f > 0.5f) {
            object = CFG.langManager;
            string2 = "High";
        } else {
            object = CFG.langManager;
            string2 = "Low";
        }
        this.sRes = ((LanguageManager)object).get(string2);
        CFG.glyphLayout.setText(CFG.fontMain, this.sRes);
        this.iResWidth = (int)(CFG.glyphLayout.width * 0.55f);
    }

    @Override
    protected void buildElementHover() {
        String string2;
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("LikelihoodOfSuccess"));
        ((StringBuilder)object).append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString()));
        if ((float)this.getCurrent() / 100.0f >= 0.5f) {
            object = CFG.langManager;
            string2 = "High";
        } else {
            object = CFG.langManager;
            string2 = "Low";
        }
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(((LanguageManager)object).get(string2), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f = this.fPerc;
        if (this.lTime + 375L > System.currentTimeMillis()) {
            f = this.fPerc * (float)(System.currentTimeMillis() - this.lTime) / 375.0f;
            CFG.setRender_3(true);
        }
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.25f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(Color.WHITE);
        spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.2f));
        ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.175f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.375f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() * 4 / 5);
        float f2 = CFG.COLOR_TEXT_MODIFIER_POSITIVE.r;
        float f3 = CFG.COLOR_TEXT_MODIFIER_POSITIVE.g;
        float f4 = CFG.COLOR_TEXT_MODIFIER_POSITIVE.b;
        float f5 = !this.getIsHovered() && !bl ? 0.475f : 0.4f;
        spriteBatch.setColor(new Color(f2, f3, f4, f5));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, (int)((float)this.getWidth() * f), this.getHeight());
        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_POSITIVE.r, CFG.COLOR_TEXT_MODIFIER_POSITIVE.g, CFG.COLOR_TEXT_MODIFIER_POSITIVE.b, 0.8f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + (int)((float)this.getWidth() * f) + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.275f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - this.getWidth() / 10 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 10, this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + 1 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 10, this.getHeight(), false, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.625f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.375f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        CFG.fontMain.getData().setScale(0.55f);
        CFG.drawText(spriteBatch, this.sLikelihood, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iLikelihoodwidth - this.iResWidth + n, this.getPosY() + (int)(((float)this.getHeight() - (float)CFG.TEXT_HEIGHT * 0.55f) / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
        f = !this.getIsHovered() && !bl ? 0.7f : 0.85f;
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() * 3 / 5, false, false);
        f = !this.getIsHovered() && !bl ? 0.325f : 0.425f;
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 4 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 4, this.getHeight(), true, false);
        f3 = CFG.COLOR_FLAG_FRAME.r;
        f5 = CFG.COLOR_FLAG_FRAME.g;
        f2 = CFG.COLOR_FLAG_FRAME.b;
        f = !this.getIsHovered() && !bl ? 0.425f : 0.55f;
        spriteBatch.setColor(new Color(f3, f5, f2, f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.375f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() + 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, 1, this.getHeight() - 2);
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight() - 2);
        CFG.fontMain.getData().setScale(0.55f);
        String string2 = this.sRes;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = CFG.PADDING;
        int n6 = this.iResWidth;
        int n7 = this.getPosY();
        int n8 = (int)(((float)this.getHeight() - (float)CFG.TEXT_HEIGHT * 0.55f) / 2.0f);
        Color color2 = this.fPerc > 0.5f ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 - n5 * 2 - n6 + n, n7 + n8 + n2, color2);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : new Color(CFG.COLOR_BUTTON_MENU_TEXT.r, CFG.COLOR_BUTTON_MENU_TEXT.g, CFG.COLOR_BUTTON_MENU_TEXT.b, 0.75f)) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return (int)(this.fPerc * 100.0f);
    }
}

