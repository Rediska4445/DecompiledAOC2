/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import age.of.civilizations2.jakowski.lukasz.Menu_InGame_View_Army;
import age.of.civilizations2.jakowski.lukasz.Shaft;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_View_Buildings
extends Button {
    protected static final float FONT_SIZE = 0.65f;
    protected static final float FONT_SIZE2 = 0.6f;
    private int iLargestNationality = 0;
    private int iPopulationWidth = 0;
    private int iProvinceID = 0;
    protected boolean isAssimiliate = false;
    private boolean row = false;
    private String sPopulation;

    /*
     * Enabled aggressive block sorting
     */
    protected Button_View_Buildings(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super.init(string2, 0, n4, n5, n6, Menu_InGame_View_Army.getButtonHeight(), true, true, false, false);
        boolean bl2 = n % 2 == 0;
        this.row = bl2;
        this.iProvinceID = n2;
        this.iLargestNationality = CFG.game.getProvince(this.iProvinceID).getCivID();
        this.sPopulation = "" + n3;
        CFG.glyphLayout.setText(CFG.fontMain, "" + this.sPopulation);
        this.iPopulationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        this.isAssimiliate = bl;
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    private final float getImageScale2(int n) {
        return (float)CFG.TEXT_HEIGHT / (float)n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void buildElementHover() {
        try {
            Object object;
            Object object2;
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            Object object3 = new ArrayList();
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfFort() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getFort_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfFort())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_fort, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfFort()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("HidesTheArmyFromTheSightOfViewOfWatchTower"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("DefenseBonus")).append(": ").toString());
                ((ArrayList)object3).add(object);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("+").append(BuildingsManager.getFort_DefenseBonus(CFG.game.getProvince(this.iProvinceID).getLevelOfFort())).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfWatchTower() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getTower_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfWatchTower())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_tower, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfWatchTower()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AllowsToSeeTheArmyInNeighboringProvinces"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("DefenseBonus")).append(": ").toString());
                ((ArrayList)object3).add(object);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("+").append(BuildingsManager.getTower_DefenseBonus(CFG.game.getProvince(this.iProvinceID).getLevelOfWatchTower())).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfPort() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getPort_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfPort())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_port, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfPort()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AllowsYourArmyGoToTheSea"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.icon_move_sea, CFG.PADDING, 0);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("IncomeProduction")).append(": ").toString());
                ((ArrayList)object3).add(object);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("+").append((int)(BuildingsManager.getPort_IncomeProduction(CFG.game.getProvince(this.iProvinceID).getLevelOfPort()) * 100.0f)).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.economy, CFG.PADDING, 0);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getLibrary_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_library, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("+1"), CFG.COLOR_TEXT_RESEARCH);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.research, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ResearchPerTurnForEveryXPeopleInProvince", BuildingsManager.getLibrary_ResearchPerPopulation(CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary())), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfShaft() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(Shaft.getShaft_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfShaft())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_shaft, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfShaft()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfFarm() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getFarm_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfFarm())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_farm, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfFarm()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("GrowthRate")).append(": ").toString());
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("+").append((int)(BuildingsManager.getFarm_GrowthRateBonus(CFG.game.getProvince(this.iProvinceID).getLevelOfFarm()) * 100.0f)).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.population_growth, CFG.PADDING, 0);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getWorkshop_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_workshop, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("IncomeProduction")).append(": ").toString());
                ((ArrayList)object3).add(object);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("+").append((int)(BuildingsManager.getWorkshop_IncomeProduction(CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop()) * 100.0f)).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.population_growth, CFG.PADDING, 0);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getArmoury_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_armoury, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ReducesTheCostOfRecruitmentPerUnitByOneGold"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfSupply() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getSupply_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfSupply())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.b_supply, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfSupply()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(" - ");
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("MilitaryUpkeep")).append(": ").toString());
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append("-").append((int)(BuildingsManager.getSupply_Bonus(CFG.game.getProvince(this.iProvinceID).getLevelOfSupply()) * 100.0f)).append("%").toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                ((ArrayList)object3).add(object);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfNuclearReactor() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getNuclearReactor_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfNuclearReactor())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.top_nuclear_weapons, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object2 = new StringBuilder();
                object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfSupply()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            if (CFG.game.getProvince(this.iProvinceID).getLevelOfBunker() > 0) {
                object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(BuildingsManager.getBunker_Name(CFG.game.getProvince(this.iProvinceID).getLevelOfBunker())), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.bBunker, CFG.PADDING, CFG.PADDING);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append(CFG.langManager.get("Level")).append(": ").toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                ((ArrayList)object3).add(object2);
                object = new StringBuilder();
                object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).append("").append(CFG.game.getProvince(this.iProvinceID).getLevelOfSupply()).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                ((ArrayList)object3).add(object2);
                object2 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)object3);
                arrayList.add((MenuElement_Hover_v2_Element2)object2);
                ((ArrayList)object3).clear();
            }
            this.menuElementHover = object3 = new MenuElement_Hover_v2(arrayList);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        int n4;
        int n5;
        Image image;
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.275f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.4f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
        }
        if (this.isAssimiliate) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        if (this.iProvinceID == CFG.game.getActiveProvinceID()) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.825f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight());
        }
        spriteBatch.setColor(Color.WHITE);
        int n6 = 0;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfFort() > 0) {
            image = ImageManager.getImage(Images.b_fort);
            n5 = this.getPosX();
            n4 = this.getWidth();
            n6 = 0 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_fort).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_fort).getHeight())));
            image.draw(spriteBatch, n5 + n4 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_fort).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_fort).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_fort).getHeight(), (int)((float)ImageManager.getImage(Images.b_fort).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_fort).getHeight())), (int)((float)ImageManager.getImage(Images.b_fort).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_fort).getHeight())));
        }
        n4 = n6;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfNuclearReactor() > 0) {
            image = ImageManager.getImage(Images.top_nuclear_weapons);
            n3 = this.getPosX();
            n5 = this.getWidth();
            n4 = n6 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.top_nuclear_weapons).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_nuclear_weapons).getHeight())));
            image.draw(spriteBatch, n3 + n5 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_nuclear_weapons).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_nuclear_weapons).getHeight())) / 2 + n2 - ImageManager.getImage(Images.top_nuclear_weapons).getHeight(), (int)((float)ImageManager.getImage(Images.top_nuclear_weapons).getWidth() * this.getImageScale2(ImageManager.getImage(Images.top_nuclear_weapons).getHeight())), (int)((float)ImageManager.getImage(Images.top_nuclear_weapons).getHeight() * this.getImageScale2(ImageManager.getImage(Images.top_nuclear_weapons).getHeight())));
        }
        n6 = n4;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfBunker() > 0) {
            image = ImageManager.getImage(Images.bBunker);
            n3 = this.getPosX();
            n5 = this.getWidth();
            n6 = n4 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.bBunker).getWidth() * this.getImageScale2(ImageManager.getImage(Images.bBunker).getHeight())));
            image.draw(spriteBatch, n3 + n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.bBunker).getHeight() * this.getImageScale2(ImageManager.getImage(Images.bBunker).getHeight())) / 2 + n2 - ImageManager.getImage(Images.bBunker).getHeight(), (int)((float)ImageManager.getImage(Images.bBunker).getWidth() * this.getImageScale2(ImageManager.getImage(Images.bBunker).getHeight())), (int)((float)ImageManager.getImage(Images.bBunker).getHeight() * this.getImageScale2(ImageManager.getImage(Images.bBunker).getHeight())));
        }
        n4 = n6;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfShaft() > 0) {
            image = ImageManager.getImage(Images.b_shaft);
            n3 = this.getPosX();
            n5 = this.getWidth();
            n4 = n6 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_shaft).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_shaft).getHeight())));
            image.draw(spriteBatch, n3 + n5 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_shaft).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_shaft).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_shaft).getHeight(), (int)((float)ImageManager.getImage(Images.b_shaft).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_shaft).getHeight())), (int)((float)ImageManager.getImage(Images.b_shaft).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_shaft).getHeight())));
        }
        n6 = n4;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfWatchTower() > 0) {
            image = ImageManager.getImage(Images.b_tower);
            n5 = this.getPosX();
            n3 = this.getWidth();
            n6 = n4 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_tower).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_tower).getHeight())));
            image.draw(spriteBatch, n5 + n3 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_tower).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_tower).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_tower).getHeight(), (int)((float)ImageManager.getImage(Images.b_tower).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_tower).getHeight())), (int)((float)ImageManager.getImage(Images.b_tower).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_tower).getHeight())));
        }
        n4 = n6;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfPort() > 0) {
            image = ImageManager.getImage(Images.b_port);
            n5 = this.getPosX();
            n3 = this.getWidth();
            n4 = n6 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_port).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_port).getHeight())));
            image.draw(spriteBatch, n5 + n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_port).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_port).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_port).getHeight(), (int)((float)ImageManager.getImage(Images.b_port).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_port).getHeight())), (int)((float)ImageManager.getImage(Images.b_port).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_port).getHeight())));
        }
        n5 = n4;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfFarm() > 0) {
            image = ImageManager.getImage(Images.b_farm);
            n3 = this.getPosX();
            n6 = this.getWidth();
            n5 = n4 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_farm).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())));
            image.draw(spriteBatch, n3 + n6 + n5 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_farm).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_farm).getHeight(), (int)((float)ImageManager.getImage(Images.b_farm).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())), (int)((float)ImageManager.getImage(Images.b_farm).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_farm).getHeight())));
        }
        n6 = n5;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfWorkshop() > 0) {
            image = ImageManager.getImage(Images.b_workshop);
            n4 = this.getPosX();
            n3 = this.getWidth();
            n6 = n5 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_workshop).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())));
            image.draw(spriteBatch, n4 + n3 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_workshop).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_workshop).getHeight(), (int)((float)ImageManager.getImage(Images.b_workshop).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())), (int)((float)ImageManager.getImage(Images.b_workshop).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_workshop).getHeight())));
        }
        n4 = n6;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfLibrary() > 0) {
            image = ImageManager.getImage(Images.b_library);
            n5 = this.getPosX();
            n3 = this.getWidth();
            n4 = n6 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_library).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())));
            image.draw(spriteBatch, n5 + n3 + n4 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_library).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_library).getHeight(), (int)((float)ImageManager.getImage(Images.b_library).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())), (int)((float)ImageManager.getImage(Images.b_library).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_library).getHeight())));
        }
        n6 = n4;
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfArmoury() > 0) {
            image = ImageManager.getImage(Images.b_armoury);
            n3 = this.getPosX();
            n5 = this.getWidth();
            n6 = n4 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())));
            image.draw(spriteBatch, n3 + n5 + n6 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_armoury).getHeight(), (int)((float)ImageManager.getImage(Images.b_armoury).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())), (int)((float)ImageManager.getImage(Images.b_armoury).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_armoury).getHeight())));
        }
        if (CFG.game.getProvince(this.iProvinceID).getLevelOfSupply() > 0) {
            ImageManager.getImage(Images.b_supply).draw(spriteBatch, this.getPosX() + this.getWidth() + (n6 - (CFG.PADDING + (int)((float)ImageManager.getImage(Images.b_supply).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_supply).getHeight())))) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.b_supply).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_supply).getHeight())) / 2 + n2 - ImageManager.getImage(Images.b_supply).getHeight(), (int)((float)ImageManager.getImage(Images.b_supply).getWidth() * this.getImageScale2(ImageManager.getImage(Images.b_supply).getHeight())), (int)((float)ImageManager.getImage(Images.b_supply).getHeight() * this.getImageScale2(ImageManager.getImage(Images.b_supply).getHeight())));
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iLargestNationality).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 - CFG.game.getCiv(this.iLargestNationality).getFlag().getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        CFG.drawText(spriteBatch, "" + this.sPopulation, this.getPosX() + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(ImageManager.getImage(Images.flag_rect).getHeight())) + CFG.PADDING * 2 + (int)((float)this.getTextWidth() * 0.65f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        CFG.fontMain.getData().setScale(1.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Color getColor(boolean bl) {
        if (bl) {
            return CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE;
        }
        if (!this.getClickable()) return new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.6f);
        if (!this.getIsHovered()) return CFG.COLOR_TEXT_OPTIONS_NS;
        return CFG.COLOR_TEXT_OPTIONS_NS_HOVER;
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }
}

