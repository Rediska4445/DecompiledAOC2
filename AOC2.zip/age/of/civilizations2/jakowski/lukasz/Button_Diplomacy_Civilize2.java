/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Ideology;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;

class Button_Diplomacy_Civilize2
extends Button {
    private int iCivID = 0;
    private int iTextCostDiplomacyWidth;
    private int iTextCostGoldWidth;
    private boolean row = false;
    private String sTextCostDiplomacy;
    private String sTextCostGold;

    protected Button_Diplomacy_Civilize2(int n, int n2, int n3, int n4, boolean bl, boolean bl2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("ChangeTypeOfGovernmentTo"));
        stringBuilder.append(": ");
        super.init(stringBuilder.toString(), 0, n2, n3, n4, Math.max(Math.max(CFG.TEXT_HEIGHT, CFG.CIV_FLAG_HEIGHT) + CFG.PADDING * 4, (int)((float)CFG.BUTTON_HEIGHT * 0.6f)), bl, true, true, bl2);
        this.iCivID = n;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((float)((int)(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)n).getIdeologyID()).CIVILIZE_TECH_LEVEL * 100.0f)) / 100.0f);
        this.sTextCostGold = stringBuilder.toString();
        this.sTextCostDiplomacy = "1.0";
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostGold);
        this.iTextCostGoldWidth = (int)(CFG.glyphLayout.width * 0.6f);
        CFG.glyphLayout.setText(CFG.fontMain, this.sTextCostDiplomacy);
        this.iTextCostDiplomacyWidth = (int)(CFG.glyphLayout.width * 0.6f);
    }

    private final float getImageScale(int n) {
        float f = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 0.6f / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Diplomacy_Civilize2.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.3f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.3f));
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Diplomacy_Civilize2.this.getPosX() + n, Button_Diplomacy_Civilize2.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_Diplomacy_Civilize2.this.getWidth() / 6, Button_Diplomacy_Civilize2.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.2f));
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Diplomacy_Civilize2.this.getPosX() + n, Button_Diplomacy_Civilize2.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + 1 + n2, Button_Diplomacy_Civilize2.this.getWidth() / 10, Button_Diplomacy_Civilize2.this.getHeight() - 2, false, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.5f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_Civilize2.this.getPosX() + n, Button_Diplomacy_Civilize2.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy_Civilize2.this.getWidth(), CFG.PADDING, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_Civilize2.this.getPosX() + n, Button_Diplomacy_Civilize2.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Diplomacy_Civilize2.this.getHeight() - 1 + n2 - CFG.PADDING, Button_Diplomacy_Civilize2.this.getWidth(), CFG.PADDING, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        try {
            ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
            ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
            Object object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("ChangeTypeOfGovernmentTo"));
            ((StringBuilder)object).append("..?");
            Object object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("WhatIsAGovernmentAnyway"));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("ChangeTypeOfGovernmentTo"));
            ((StringBuilder)object).append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text(CFG.ideologiesManager.getIdeology(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getName(), CFG.ideologiesManager.getIdeology(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getColor());
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Ideology(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            object2 = new MenuElement_Hover_v2_Element_Type_Space();
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("RequiredTechnologyLevel"));
            ((StringBuilder)object).append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("");
            ((StringBuilder)object2).append((float)((int)(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL * 100.0f)) / 100.0f);
            object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_TEXT_TECHNOLOGY);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.technology, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            int n = CFG.game.getCiv(this.iCivID).getTechnologyLevel() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL ? Images.icon_check_true : Images.icon_check_false;
            object2 = new MenuElement_Hover_v2_Element_Type_Image(n, CFG.PADDING, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = CFG.game.getCiv(this.iCivID).getTechnologyLevel() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            object = new MenuElement_Hover_v2_Element_Type_Text("[", (Color)object2);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object2 = new MenuElement_Hover_v2_Element_Type_Flag(this.iCivID, 0, CFG.PADDING);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("");
            ((StringBuilder)object2).append((float)((int)(CFG.game.getCiv(this.iCivID).getTechnologyLevel() * 100.0f)) / 100.0f);
            String string2 = ((StringBuilder)object2).toString();
            object2 = CFG.game.getCiv(this.iCivID).getTechnologyLevel() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            object = new MenuElement_Hover_v2_Element_Type_Text(string2, (Color)object2);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.technology, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = CFG.game.getCiv(this.iCivID).getTechnologyLevel() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            object = new MenuElement_Hover_v2_Element_Type_Text("]", (Color)object2);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            object = new StringBuilder();
            ((StringBuilder)object).append(CFG.langManager.get("DiplomacyPoints"));
            ((StringBuilder)object).append(": ");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Text("1.0");
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element_Type_Image(Images.top_diplomacy_points, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            n = CFG.game.getCiv(this.iCivID).getDiplomacyPoints() >= 10 ? Images.icon_check_true : Images.icon_check_false;
            object2 = new MenuElement_Hover_v2_Element_Type_Image(n, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object2 = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object2);
            arrayList2.clear();
            this.menuElementHover = object2 = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        try {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        catch (NullPointerException nullPointerException) {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + (Button_Diplomacy.iDiploWidth - ImageManager.getImage(Images.flag_rect).getWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        ImageManager.getImage(Images.technology).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology)) + n, this.getPosY() + CFG.PADDING / 2 + this.getHeight() / 2 - this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology) / 2.0f) - ImageManager.getImage(Images.technology).getHeight() + n2, (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology)), (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology)));
        ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)) + n, this.getPosY() - CFG.PADDING / 2 + this.getHeight() / 2 + this.getHeight() / 4 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points) / 2.0f) - ImageManager.getImage(Images.top_diplomacy_points).getHeight() + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points)));
        CFG.fontMain.getData().setScale(0.6f);
        Object object = this.sTextCostGold;
        int n3 = this.getPosX();
        int n4 = this.getWidth();
        int n5 = this.iTextCostGoldWidth;
        int n6 = CFG.PADDING;
        int n7 = (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology));
        int n8 = this.getPosY();
        int n9 = CFG.PADDING / 2;
        int n10 = this.getHeight() / 2;
        int n11 = this.getHeight() / 4;
        int n12 = (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f);
        Object object2 = CFG.game.getCiv(this.iCivID).getTechnologyLevel() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CIVILIZE_TECH_LEVEL ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawText(spriteBatch, (String)object, n3 + n4 - n5 - n6 * 3 - n7 + n, n8 + n9 + n10 - n11 - n12 + n2, (Color)object2);
        object = this.sTextCostDiplomacy;
        n10 = this.getPosX();
        n11 = this.getWidth();
        n4 = this.iTextCostDiplomacyWidth;
        n9 = CFG.PADDING;
        n12 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points));
        n8 = this.getPosY();
        n3 = CFG.PADDING / 2;
        n6 = this.getHeight() / 2;
        n5 = this.getHeight() / 4;
        n7 = (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f);
        object2 = CFG.game.getCiv(this.iCivID).getDiplomacyPoints() >= 10 ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
        CFG.drawText(spriteBatch, (String)object, n10 + n11 - n4 - n9 * 3 - n12 + n, n8 - n3 + n6 + n5 - n7 + n2, (Color)object2);
        object2 = new Rectangle(this.getPosX() + Button_Diplomacy.iDiploWidth + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - this.getRightWidth() - Button_Diplomacy.iDiploWidth, -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors((Rectangle)object2);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawText(spriteBatch, this.getText(), this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        try {
            object2 = CFG.ideologiesManager.getIdeology(CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getName();
            n3 = this.getPosX();
            n4 = Button_Diplomacy.iDiploWidth;
            n6 = (int)((float)this.getTextWidth() * 0.7f);
            n8 = this.getPosY();
            n9 = this.getHeight() / 2;
            n11 = (int)((float)this.getTextHeight() * 0.7f / 2.0f);
            object = new Color(CFG.ideologiesManager.getIdeology((int)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getColor().r, CFG.ideologiesManager.getIdeology((int)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getColor().g, CFG.ideologiesManager.getIdeology((int)CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)this.iCivID).getIdeologyID()).CAN_BECOME_CIVILIZED).getColor().b, 1.0f);
            CFG.drawText(spriteBatch, (String)object2, n3 + n4 + n6 + n, n8 + n9 - n11 + n2, (Color)object);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
        }
        catch (IllegalStateException illegalStateException) {}
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }

    protected final int getRightWidth() {
        return Math.max(this.iTextCostGoldWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology)), this.iTextCostDiplomacyWidth + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.top_diplomacy_points)));
    }

    @Override
    protected void setMax(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }

    @Override
    protected void setVisible(boolean bl) {
        super.setVisible(bl);
    }
}

