/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data_PortToBuild;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;

class CivArmyMission_Expand_BuildPort
extends CivArmyMission {
    protected int iBuildPortInProvinceID = -1;

    protected CivArmyMission_Expand_BuildPort(int n, int n2, int n3, int n4) {
        this.iArmy = n4;
        this.iProvinceID = n2;
        this.iBuildPortInProvinceID = n2;
        this.toProvinceID = n3;
        this.MISSION_ID = -1;
        this.MISSION_TYPE = CivArmyMission_Type.EXPAND_NETURAL_PROVINCE;
        RegroupArmy_Data_PortToBuild regroupArmy_Data_PortToBuild = new RegroupArmy_Data_PortToBuild(n, this.iProvinceID, n3);
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = regroupArmy_Data_PortToBuild.getRouteSize() + 6;
    }

    @Override
    protected boolean action(int n) {
        if (this.iProvinceID != this.toProvinceID && CFG.game.getProvince(this.toProvinceID).getCivID() == 0) {
            RegroupArmy_Data_PortToBuild regroupArmy_Data_PortToBuild = new RegroupArmy_Data_PortToBuild(n, this.iProvinceID, this.toProvinceID);
            if (CFG.game.getProvince(this.iBuildPortInProvinceID).getCivID() == n && this.action_BuildPort(n, this.iBuildPortInProvinceID) && regroupArmy_Data_PortToBuild.getRouteSize() > 0) {
                if (regroupArmy_Data_PortToBuild.getRouteSize() == 1) {
                    return CFG.gameAction.moveArmy(this.iProvinceID, this.toProvinceID, this.iArmy, n, true, false);
                }
                if (CFG.gameAction.moveArmy(this.iProvinceID, regroupArmy_Data_PortToBuild.getRoute(0), this.iArmy, n, true, false)) {
                    regroupArmy_Data_PortToBuild.setFromProvinceID(regroupArmy_Data_PortToBuild.getRoute(0));
                    regroupArmy_Data_PortToBuild.removeRoute(0);
                    regroupArmy_Data_PortToBuild.setNumOfUnits(this.iArmy);
                    CFG.game.getCiv(n).addRegroupArmy(regroupArmy_Data_PortToBuild);
                    return true;
                }
                return false;
            }
        }
        return true;
    }

    protected final boolean action_BuildPort(int n, int n2) {
        if (CFG.game.getProvince(n2).getLevelOfPort() == 0) {
            if (CFG.game.getProvince(n2).getCivID() == n && CFG.game.getCiv(n).isInConstruction(n2, ConstructionType.PORT) == 0) {
                Application application = Gdx.app;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("move: ");
                stringBuilder.append(CFG.game.getCiv(n).getMovePoints());
                application.log("AoC", stringBuilder.toString());
                if (BuildingsManager.constructPort(n2, n)) {
                    ++this.iObsolate;
                    return false;
                }
                this.lockTreasury_Port(n, n2);
            }
            return false;
        }
        return true;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        boolean bl = Game_Calendar.TURN_ID != this.TURN_ID;
        return bl;
    }

    protected final void lockTreasury_Port(int n, int n2) {
        n2 = (int)((float)BuildingsManager.getPort_BuildCost(CFG.game.getProvince(n2).getLevelOfPort() + 1, n2) * 1.05f);
        CFG.game.getCiv((int)n).civGameData.iLockTreasury = Math.max(CFG.game.getCiv((int)n).civGameData.iLockTreasury, n2);
        if (CFG.game.getCiv((int)n).iBudget > 0) {
            this.iObsolate = CFG.game.getCiv(n).getMoney() > 0L && CFG.game.getCiv(n).getMoney() < (long)n2 ? Math.max(this.iObsolate, Math.max(2, (int)Math.ceil((float)CFG.game.getCiv(n).getMoney() / (float)n2))) : Math.max(2, this.iObsolate);
        }
    }
}

