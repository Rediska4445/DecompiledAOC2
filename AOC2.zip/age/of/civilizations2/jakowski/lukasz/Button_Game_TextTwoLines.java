/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Game_TextTwoLines
extends Button_Game {
    private int iTextBotWidth = 0;
    private String sTextBot;

    protected Button_Game_TextTwoLines(String string2, String string3, int n, int n2, int n3, int n4, boolean bl) {
        super(string2, n, n2, n3, n4, bl);
        this.sTextBot = string3;
        CFG.fontMain.getData().setScale(0.8f);
        CFG.glyphLayout.setText(CFG.fontMain, string3);
        this.iTextBotWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + (this.getWidth() - super.getTextWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.PADDING / 2 - this.iTextHeight + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + (this.getWidth() - super.getTextWidth()) / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.PADDING / 2 - this.iTextHeight + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(0.8f);
        CFG.drawTextWithShadow(spriteBatch, this.sTextBot, this.getPosX() + (this.getWidth() - this.iTextBotWidth) / 2 + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING + (CFG.TEXT_HEIGHT - CFG.TEXT_HEIGHT) / 2 + n2, new Color(0.46f, 0.46f, 0.46f, 1.0f));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : CFG.COLOR_BUTTON_GAME_TEXT) : CFG.COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getTextPos() {
        return super.getTextWidth();
    }

    @Override
    protected int getTextWidth() {
        int n;
        int n2 = super.getTextWidth();
        int n3 = n = this.iTextBotWidth;
        if (n2 > n) {
            n3 = super.getTextWidth();
        }
        return n3;
    }
}

