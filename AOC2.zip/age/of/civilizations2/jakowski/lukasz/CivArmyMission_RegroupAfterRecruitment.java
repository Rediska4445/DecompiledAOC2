/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.RegroupArmy_Data;

class CivArmyMission_RegroupAfterRecruitment
extends CivArmyMission {
    protected int iTurnsRequiredToMoveToFrontLine = 1;

    protected CivArmyMission_RegroupAfterRecruitment(int n, int n2, int n3, int n4) {
        this.iArmy = n4;
        this.iProvinceID = n2;
        this.toProvinceID = n3;
        this.MISSION_ID = -1;
        this.iTurnsRequiredToMoveToFrontLine = new RegroupArmy_Data(n, this.iProvinceID, n3).getRouteSize();
        this.MISSION_TYPE = CivArmyMission_Type.REGRUOP_AFTER_RECRUIT;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = 15;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean action(int n) {
        boolean bl;
        boolean bl2 = bl = true;
        if (this.iProvinceID == this.toProvinceID) return bl2;
        RegroupArmy_Data regroupArmy_Data = new RegroupArmy_Data(n, this.iProvinceID, this.toProvinceID);
        bl2 = bl;
        if (regroupArmy_Data.getRouteSize() <= 0) return bl2;
        if (regroupArmy_Data.getRouteSize() == 1) {
            return CFG.gameAction.moveArmy(this.iProvinceID, this.toProvinceID, this.iArmy, n, true, false);
        }
        if (!CFG.gameAction.moveArmy(this.iProvinceID, regroupArmy_Data.getRoute(0), this.iArmy, n, true, false)) return false;
        regroupArmy_Data.setFromProvinceID(regroupArmy_Data.getRoute(0));
        regroupArmy_Data.removeRoute(0);
        regroupArmy_Data.setNumOfUnits(this.iArmy);
        CFG.game.getCiv(n).addRegroupArmy(regroupArmy_Data);
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean canMakeAction(int n, int n2) {
        if (Game_Calendar.TURN_ID == this.TURN_ID) return false;
        return true;
    }
}

