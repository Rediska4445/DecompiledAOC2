/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;

class Editor_Wasteland
extends Editor {
    Editor_Wasteland() {
    }

    protected static final void actionSave() {
        char c;
        Object object = Gdx.files;
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("map/");
        ((StringBuilder)object2).append(CFG.map.getFile_ActiveMap_Path());
        ((StringBuilder)object2).append("wasteland_maps/");
        ((StringBuilder)object2).append("temp");
        object2 = object.local(((StringBuilder)object2).toString());
        object = new StringBuilder();
        ((StringBuilder)object).append("");
        char c2 = CFG.game.getProvince(0).getWasteland() >= 0 ? (c = '1') : (c = '0');
        ((StringBuilder)object).append(c2);
        ((StringBuilder)object).append(";");
        ((FileHandle)object2).writeString(((StringBuilder)object).toString(), false);
        for (c = '\u0001'; c < CFG.game.getProvincesSize(); ++c) {
            char c3;
            if (CFG.game.getProvince(c).getSeaProvince()) continue;
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            c2 = CFG.game.getProvince(c).getWasteland() >= 0 ? (c3 = '1') : (c3 = '0');
            ((StringBuilder)object).append(c2);
            ((StringBuilder)object).append(";");
            ((FileHandle)object2).writeString(((StringBuilder)object).toString(), true);
        }
    }

    @Override
    protected void keyDown(int n) {
        boolean bl = Gdx.input.isKeyPressed(21);
        n = 1;
        if (bl || Gdx.input.isKeyPressed(22)) {
            CFG.bSetWasteland_AvailableProvinces ^= true;
        }
        if (Gdx.input.isKeyPressed(62) && CFG.game.getActiveProvinceID() >= 0 && !CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince()) {
            CFG.game.setWasteland(CFG.game.getActiveProvinceID(), CFG.bSetWasteland_AvailableProvinces);
        }
        if (Gdx.input.isKeyPressed(67)) {
            while (n < CFG.game.getProvincesSize()) {
                if (!CFG.game.getProvince(n).getSeaProvince()) {
                    CFG.game.getProvince(n).setWasteland(0);
                }
                ++n;
            }
        }
        if (Gdx.input.isKeyPressed(66)) {
            Editor_Wasteland.actionSave();
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WASTELAND: ");
        stringBuilder.append(CFG.bSetWasteland_AvailableProvinces);
        return stringBuilder.toString();
    }
}

