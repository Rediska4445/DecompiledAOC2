/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Build
extends Button {
    protected static final float FONTSIZE = 0.7f;
    protected static final float TEXT_COST_SCALE = 0.6f;
    protected static final float TEXT_MOVEMENT_COST_SCALE = 0.6f;
    protected boolean backAnimation;
    protected boolean canBuild_MoneyCost;
    protected boolean canBuild_Movement;
    protected float fAlphaMod = 0.0f;
    protected int iConstructionWidth;
    protected int iCostWidth;
    protected int iImageID;
    protected int iMovementCostWidth;
    protected int iTechWidth;
    protected boolean inConstruction;
    protected long lTime = 0L;
    protected boolean row;
    protected String sConstruction;
    protected String sCost;
    protected String sMovementCost;
    protected String sTech;

    protected Button_Build(String object, int n, int n2, int n3, int n4, int n5, int n6, boolean bl, boolean bl2, int n7, float f) {
        Object object2;
        Object object3;
        boolean bl3 = false;
        this.backAnimation = false;
        this.row = false;
        this.iConstructionWidth = 0;
        this.iTechWidth = 0;
        super.init(CFG.langManager.get((String)object), 0, n4, n5, n6, CFG.BUTTON_HEIGHT * 4 / 5, bl, true, true, bl2);
        this.iImageID = n;
        bl = n7 > 0;
        this.inConstruction = bl;
        if (n7 > 0) {
            this.sConstruction = CFG.langManager.get("TurnsX", n7);
            object3 = CFG.glyphLayout;
            object2 = CFG.fontMain;
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(this.sConstruction);
            ((GlyphLayout)object3).setText((BitmapFont)object2, ((StringBuilder)object).toString());
            this.iConstructionWidth = (int)(CFG.glyphLayout.width * 0.6f);
        }
        bl = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney() >= (long)n2;
        this.canBuild_MoneyCost = bl;
        if (n2 > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(n2);
            this.sCost = ((StringBuilder)object).toString();
        } else {
            this.sCost = "";
        }
        bl = bl3;
        if (CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMovePoints() >= n3) {
            bl = true;
        }
        this.canBuild_Movement = bl;
        if (n3 > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append((float)n3 / 10.0f);
            this.sMovementCost = ((StringBuilder)object).toString();
        } else {
            this.sMovementCost = "";
        }
        CFG.fontMain.getData().setScale(0.6f);
        object = CFG.glyphLayout;
        object2 = CFG.fontMain;
        object3 = new StringBuilder();
        ((StringBuilder)object3).append("");
        ((StringBuilder)object3).append(this.sCost);
        ((GlyphLayout)object).setText((BitmapFont)object2, ((StringBuilder)object3).toString());
        this.iCostWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(0.6f);
        object3 = CFG.glyphLayout;
        object = CFG.fontMain;
        object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        ((StringBuilder)object2).append(this.sMovementCost);
        ((GlyphLayout)object3).setText((BitmapFont)object, ((StringBuilder)object2).toString());
        this.iMovementCostWidth = (int)CFG.glyphLayout.width;
        if (CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getTechnologyLevel() < f) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append((float)((int)(f * 100.0f)) / 100.0f);
            this.sTech = ((StringBuilder)object).toString();
            object2 = CFG.glyphLayout;
            object3 = CFG.fontMain;
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(this.sTech);
            ((GlyphLayout)object2).setText((BitmapFont)object3, ((StringBuilder)object).toString());
            this.iTechWidth = (int)CFG.glyphLayout.width;
        }
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Build.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_POSITIVE.r, CFG.COLOR_TEXT_MODIFIER_POSITIVE.g, CFG.COLOR_TEXT_MODIFIER_POSITIVE.b, 0.2f));
                        ImageManager.getImage(Images.patt_square).draw2(spriteBatch, Button_Build.this.getPosX() + n, Button_Build.this.getPosY() - ImageManager.getImage(Images.patt_square).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_Build.this.getHeight() - 2, true, false);
                        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Build.this.getPosX() + n, Button_Build.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_Build.this.getHeight() / 4, false, false);
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Build.this.getPosX() + n, Button_Build.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Build.this.getHeight() - 1 + n2 - Button_Build.this.getHeight() / 4, Button_Diplomacy.iDiploWidth, Button_Build.this.getHeight() / 4, false, true);
                        spriteBatch.setColor(Color.WHITE);
                    }
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth - CFG.PADDING * 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.35f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        if (this.inConstruction) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.525f));
            ImageManager.getImage(Images.patt).draw2(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() - ImageManager.getImage(Images.patt).getHeight() + n2, this.getWidth() - Button_Diplomacy.iDiploWidth, this.getHeight());
        }
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.getIsHovered()) {
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
        } else {
            this.backAnimation = false;
            this.fAlphaMod = 0.0f;
            this.lTime = System.currentTimeMillis();
        }
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        spriteBatch.setColor(Color.WHITE);
        if (!this.inConstruction) {
            if (this.iTechWidth > 0) {
                ImageManager.getImage(Images.technology).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.technology).getHeight() - (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology, 0.6f)), (int)((float)ImageManager.getImage(Images.technology).getHeight() * this.getImageScale(Images.technology, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                CFG.drawTextWithShadow(spriteBatch, this.sTech, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iTechWidth - (int)((float)ImageManager.getImage(Images.technology).getWidth() * this.getImageScale(Images.technology, 0.6f)) - CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f) / 2 + n2, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
            } else if (this.sCost.length() > 0 && this.sMovementCost.length() > 0) {
                Color color2;
                int n3;
                int n4;
                int n5;
                int n6;
                int n7;
                int n8;
                int n9;
                int n10;
                int n11;
                String string2;
                if (this.sCost.length() > 0) {
                    ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)) - ImageManager.getImage(Images.top_gold).getHeight() - CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)));
                    CFG.fontMain.getData().setScale(0.6f);
                    string2 = this.sCost;
                    n11 = this.getPosX();
                    n10 = this.getWidth();
                    n9 = CFG.PADDING;
                    int n12 = Math.max((int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)));
                    n8 = CFG.PADDING;
                    n7 = this.iCostWidth;
                    n6 = this.getPosY();
                    n5 = this.getHeight() / 2;
                    n4 = CFG.PADDING / 2;
                    n3 = (int)((float)this.getTextHeight() * 0.6f);
                    color2 = this.canBuild_MoneyCost ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                    CFG.drawTextWithShadow(spriteBatch, string2, n11 + n10 - n9 * 2 - n12 - n8 - n7 + n, n6 + n5 - n4 - n3 + n2, color2);
                }
                if (this.sMovementCost.length() > 0) {
                    ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_movement_points).getHeight() + CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)));
                    CFG.fontMain.getData().setScale(0.6f);
                    string2 = this.sMovementCost;
                    n6 = this.getPosX();
                    n8 = this.getWidth();
                    n10 = CFG.PADDING;
                    n11 = this.iMovementCostWidth;
                    n9 = Math.max((int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)));
                    n3 = CFG.PADDING;
                    n4 = this.getPosY();
                    n7 = this.getHeight() / 2;
                    n5 = CFG.PADDING / 2;
                    color2 = this.canBuild_Movement ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                    CFG.drawTextWithShadow(spriteBatch, string2, n6 + n8 - n10 * 2 - n11 - n9 - n3 + n, n4 + n7 + n5 + n2, color2);
                }
            } else if (this.sMovementCost.length() > 0) {
                ImageManager.getImage(Images.top_movement_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_movement_points).getHeight() - (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_movement_points).getHeight() * this.getImageScale(Images.top_movement_points, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                String string3 = this.sMovementCost;
                int n13 = this.getPosX();
                int n14 = this.getWidth();
                int n15 = CFG.PADDING;
                int n16 = this.iMovementCostWidth;
                int n17 = (int)((float)ImageManager.getImage(Images.top_movement_points).getWidth() * this.getImageScale(Images.top_movement_points, 0.6f));
                int n18 = CFG.PADDING;
                int n19 = this.getPosY();
                int n20 = this.getHeight() / 2;
                int n21 = (int)((float)this.getTextHeight() * 0.6f) / 2;
                Color color3 = this.canBuild_Movement ? CFG.COLOR_INGAME_MOVEMENT : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                CFG.drawTextWithShadow(spriteBatch, string3, n13 + n14 - n15 * 2 - n16 - n17 - n18 + n, n19 + n20 - n21 + n2, color3);
            } else if (this.getCheckboxState()) {
                ImageManager.getImage(Images.icon_check_true).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.icon_check_true).getWidth() * this.getImageScale(Images.icon_check_true, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.icon_check_true).getHeight() - (int)((float)ImageManager.getImage(Images.icon_check_true).getHeight() * this.getImageScale(Images.icon_check_true, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.icon_check_true).getWidth() * this.getImageScale(Images.icon_check_true, 0.6f)), (int)((float)ImageManager.getImage(Images.icon_check_true).getHeight() * this.getImageScale(Images.icon_check_true, 0.6f)));
            }
        } else {
            ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.time).getHeight() - (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time, 0.6f)), (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time, 0.6f)));
            CFG.fontMain.getData().setScale(0.6f);
            CFG.drawTextWithShadow(spriteBatch, this.sConstruction, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - this.iConstructionWidth - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time, 0.6f)) - CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.6f) / 2 + n2, CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
        }
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f / 2.0f) + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.525f));
        return color2;
    }

    protected float getImageScale(int n, float f) {
        return (float)CFG.TEXT_HEIGHT * f / (float)ImageManager.getImage(n).getHeight();
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

