/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;

class Button_NS_Opinion
extends Button {
    protected static final float FONTSIZE = 0.7f;
    protected static final float FONTSIZE2 = 0.65f;
    protected static final float TEXT_COST_SCALE = 0.7f;
    protected static final float TEXT_MOVEMENT_COST_SCALE = 0.7f;
    protected boolean backAnimation = false;
    protected boolean canBuild_MoneyCost;
    protected boolean canBuild_Movement;
    protected float fAlphaMod = 0.0f;
    private int iCivA;
    private int iCivB;
    protected int iCostWidth;
    private int iCurrentRelationWidth = 0;
    protected int iImageID;
    protected int iMovementCostWidth;
    protected long lTime = 0L;
    private Color relationColor;
    protected boolean row = false;
    private String sCivBName;
    protected String sCost;
    private String sCurrentRelation;
    protected String sMovementCost;

    protected Button_NS_Opinion(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        Object object = new StringBuilder();
        ((StringBuilder)object).append(CFG.langManager.get("Opinion"));
        ((StringBuilder)object).append(": ");
        super.init(((StringBuilder)object).toString(), 0, n6, n7, n8, CFG.BUTTON_HEIGHT * 4 / 5, true, true, false, false);
        this.iCivA = n;
        this.iCivB = n2;
        this.iImageID = n3;
        this.sCivBName = CFG.game.getCiv(n2).getCivName();
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append("");
        object = CFG.game.getCivRelation_OfCivB(n2, n) > 0.0f ? "+" : "";
        ((StringBuilder)object2).append((String)object);
        ((StringBuilder)object2).append((float)((int)(CFG.game.getCivRelation_OfCivB(n2, n) * 10.0f)) / 10.0f);
        ((StringBuilder)object2).append(" ");
        this.sCurrentRelation = ((StringBuilder)object2).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sCurrentRelation);
        this.iCurrentRelationWidth = (int)(CFG.glyphLayout.width * 0.65f);
        object = CFG.game.getCivRelation_OfCivB(n2, n) > 0.0f ? CFG.COLOR_TEXT_MODIFIER_POSITIVE : (CFG.game.getCivRelation_OfCivB(n2, n) == 0.0f ? CFG.COLOR_TEXT_MODIFIER_NEUTRAL2 : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
        this.relationColor = object;
        long l = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney();
        long l2 = n4;
        boolean bl = true;
        boolean bl2 = l >= l2;
        this.canBuild_MoneyCost = bl2;
        if (n4 > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append(n4);
            this.sCost = ((StringBuilder)object).toString();
        } else {
            this.sCost = "";
        }
        bl2 = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= n5 ? bl : false;
        this.canBuild_Movement = bl2;
        if (n5 > 0) {
            object = new StringBuilder();
            ((StringBuilder)object).append("");
            ((StringBuilder)object).append((float)n5 / 10.0f);
            this.sMovementCost = ((StringBuilder)object).toString();
        } else {
            this.sMovementCost = "";
        }
        CFG.fontMain.getData().setScale(0.7f);
        object = CFG.glyphLayout;
        object2 = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sCost);
        ((GlyphLayout)object).setText((BitmapFont)object2, stringBuilder.toString());
        this.iCostWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(0.7f);
        object2 = CFG.glyphLayout;
        object = CFG.fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sMovementCost);
        ((GlyphLayout)object2).setText((BitmapFont)object, stringBuilder.toString());
        this.iMovementCostWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(1.0f);
    }

    private final float getImageScale(int n) {
        return (float)CFG.TEXT_HEIGHT * 0.8f / (float)ImageManager.getImage(n).getHeight();
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_NS_Opinion.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_POSITIVE.r, CFG.COLOR_TEXT_MODIFIER_POSITIVE.g, CFG.COLOR_TEXT_MODIFIER_POSITIVE.b, 0.2f));
                        ImageManager.getImage(Images.patt_square).draw2(spriteBatch, Button_NS_Opinion.this.getPosX() + n, Button_NS_Opinion.this.getPosY() - ImageManager.getImage(Images.patt_square).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_NS_Opinion.this.getHeight() - 2, true, false);
                        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_NS_Opinion.this.getPosX() + n, Button_NS_Opinion.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_NS_Opinion.this.getHeight() / 4, false, false);
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_NS_Opinion.this.getPosX() + n, Button_NS_Opinion.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_NS_Opinion.this.getHeight() - 1 + n2 - Button_NS_Opinion.this.getHeight() / 4, Button_Diplomacy.iDiploWidth, Button_NS_Opinion.this.getHeight() / 4, false, true);
                        spriteBatch.setColor(Color.WHITE);
                    }
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivA, 0, CFG.PADDING));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivA).getCivName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(" - ", CFG.COLOR_TEXT_MODIFIER_NEUTRAL2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.iCivB).getCivName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Flag(this.iCivB, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Space());
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CFG.langManager.get("DiplomacyPoints"));
        stringBuilder.append(": ");
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("-");
        stringBuilder.append(this.sMovementCost);
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Text(stringBuilder.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2));
        arrayList2.add(new MenuElement_Hover_v2_Element_Type_Image(Images.top_diplomacy_points, CFG.PADDING, 0));
        arrayList.add(new MenuElement_Hover_v2_Element2(arrayList2));
        arrayList2.clear();
        this.menuElementHover = new MenuElement_Hover_v2(arrayList);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth - CFG.PADDING * 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.35f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.getIsHovered()) {
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
        } else {
            this.backAnimation = false;
            this.fAlphaMod = 0.0f;
            this.lTime = System.currentTimeMillis();
        }
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        spriteBatch.setColor(Color.WHITE);
        if (this.sCost.length() > 0 && this.sMovementCost.length() > 0) {
            Color color2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            int n9;
            int n10;
            int n11;
            String string2;
            if (this.sCost.length() > 0) {
                ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.7f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.7f)) - ImageManager.getImage(Images.top_gold).getHeight() - CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.7f)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.7f)));
                CFG.fontMain.getData().setScale(0.7f);
                string2 = this.sCost;
                n11 = this.getPosX();
                n10 = this.getWidth();
                n9 = CFG.PADDING;
                n8 = Math.max((int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.7f)));
                int n12 = CFG.PADDING;
                n7 = this.iCostWidth;
                n6 = this.getPosY();
                n5 = this.getHeight() / 2;
                n4 = CFG.PADDING / 2;
                n3 = (int)((float)this.getTextHeight() * 0.7f);
                color2 = this.canBuild_MoneyCost ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                CFG.drawTextWithShadow(spriteBatch, string2, n11 + n10 - n9 * 2 - n8 - n12 - n7 + n, n6 + n5 - n4 - n3 + n2, color2);
            }
            if (this.sMovementCost.length() > 0) {
                ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_diplomacy_points).getHeight() + CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.7f)));
                CFG.fontMain.getData().setScale(0.7f);
                string2 = this.sMovementCost;
                n6 = this.getPosX();
                n5 = this.getWidth();
                n7 = CFG.PADDING;
                n4 = this.iMovementCostWidth;
                n8 = Math.max((int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)), (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.7f)));
                n3 = CFG.PADDING;
                n10 = this.getPosY();
                n9 = this.getHeight() / 2;
                n11 = CFG.PADDING / 2;
                color2 = this.canBuild_Movement ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                CFG.drawTextWithShadow(spriteBatch, string2, n6 + n5 - n7 * 2 - n4 - n8 - n3 + n, n10 + n9 + n11 + n2, color2);
            }
        } else if (this.sMovementCost.length() > 0) {
            ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_diplomacy_points).getHeight() - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.7f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.7f)));
            CFG.fontMain.getData().setScale(0.7f);
            String string3 = this.sMovementCost;
            int n13 = this.getPosX();
            int n14 = this.getWidth();
            int n15 = CFG.PADDING;
            int n16 = this.iMovementCostWidth;
            int n17 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.7f));
            int n18 = CFG.PADDING;
            int n19 = this.getPosY();
            int n20 = this.getHeight() / 2;
            int n21 = (int)((float)this.getTextHeight() * 0.7f) / 2;
            Color color3 = this.canBuild_Movement ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
            CFG.drawTextWithShadow(spriteBatch, string3, n13 + n14 - n15 * 2 - n16 - n17 - n18 + n, n19 + n20 - n21 + n2, color3);
        }
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(Images.diplo_relations).draw(spriteBatch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iCurrentRelationWidth + CFG.PADDING * 3 / 4 + (int)((float)this.getTextWidth() * 0.65f) + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + (int)((float)this.getTextHeight() * 0.65f) / 2 - (int)((float)ImageManager.getImage(Images.diplo_relations).getHeight() * this.getImageScale(Images.diplo_relations, 0.65f)) / 2 - ImageManager.getImage(Images.diplo_relations).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_relations).getWidth() * this.getImageScale(Images.diplo_relations, 0.65f)), (int)((float)ImageManager.getImage(Images.diplo_relations).getHeight() * this.getImageScale(Images.diplo_relations, 0.65f)));
        CFG.game.getCiv(this.iCivB).getFlag().draw(spriteBatch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivB).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.sCivBName, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sCurrentRelation, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.65f) + CFG.CIV_FLAG_WIDTH + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, this.relationColor);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.525f));
        return color2;
    }

    protected float getImageScale(int n, float f) {
        return (float)CFG.TEXT_HEIGHT * f / (float)ImageManager.getImage(n).getHeight();
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

