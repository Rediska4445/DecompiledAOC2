/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_View
extends Button {
    protected Button_View(String string2, int n, int n2, int n3, int n4, boolean bl) {
        super.init(string2, -1, n, n2, n3, n4, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        n2 = bl ? Images.top_view_right_h : Images.top_view_right;
        ImageManager.getImage(n2).draw2(spriteBatch, this.getPosX() + n, this.getHeight() - ImageManager.getImage(Images.top_view_right).getHeight() * 2, this.getWidth(), ImageManager.getImage(Images.top_view_right).getHeight(), true);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            CFG.fontMain.getData().setScale(0.6f);
            String string2 = this.getText();
            int n3 = this.getPosX();
            int n4 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.6f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, string2, n3 + n4 + n, this.getPosY() + ImageManager.getImage(Images.top_left2).getHeight() + (this.getHeight() - ImageManager.getImage(Images.top_left2).getHeight() - 2) / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        } else {
            CFG.fontMain.getData().setScale(0.6f);
            String string3 = this.getText();
            int n5 = this.getPosX();
            int n6 = this.getTextPos() < 0 ? this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.6f / 2.0f) : this.getTextPos();
            CFG.drawText(spriteBatch, string3, n5 + n6 + n, this.getPosY() + ImageManager.getImage(Images.top_left2).getHeight() + (this.getHeight() - ImageManager.getImage(Images.top_left2).getHeight() - 2) / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, this.getColor(bl));
            CFG.fontMain.getData().setScale(1.0f);
        }
    }

    @Override
    protected final Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_TOP_VIEWS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_TOP_VIEWS_HOVER : CFG.COLOR_TEXT_TOP_VIEWS) : CFG.COLOR_TEXT_TOP_VIEWS_NOT_CLICKABLE);
        return color2;
    }
}

