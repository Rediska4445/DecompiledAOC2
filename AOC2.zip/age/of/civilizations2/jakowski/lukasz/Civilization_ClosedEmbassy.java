/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Civilization_ClosedEmbassy
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iCivID = 0;
    protected int iNumOfTurns = 0;

    protected Civilization_ClosedEmbassy(int n, int n2) {
        this.iCivID = n;
        this.iNumOfTurns = n2;
    }
}

