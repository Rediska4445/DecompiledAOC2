/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Build;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Build_Assimilate
extends Button_Build {
    protected static final float FONT_SIZE_SCALE = 0.6f;
    protected Color cColorAssimilate = Color.WHITE;
    protected int iDateWidth;
    protected String sDate;
    protected String sProvinceName;
    protected String sStability;

    protected Button_Build_Assimilate(int n, String charSequence, String string2, String string3, int n2, int n3, int n4, int n5, int n6, int n7) {
        super((String)charSequence, n2, n3, n4, n5, n6, n7, true, false, 0, 0.0f);
        this.sProvinceName = string2;
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.langManager.get("Stability"));
        ((StringBuilder)charSequence).append(": ");
        this.sDate = ((StringBuilder)charSequence).toString();
        CFG.glyphLayout.setText(CFG.fontMain, this.sDate);
        this.iDateWidth = (int)(CFG.glyphLayout.width * 0.6f);
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("");
        ((StringBuilder)charSequence).append((int)(CFG.game.getProvince(n).getProvinceStability() * 100.0f));
        ((StringBuilder)charSequence).append("%");
        this.sStability = ((StringBuilder)charSequence).toString();
        this.cColorAssimilate = CFG.getColorStep(CFG.COLOR_TEXT_PROVINCE_STABILITY_MIN, CFG.COLOR_TEXT_PROVINCE_STABILITY_MAX, (int)(CFG.game.getProvince(n).getProvinceStability() * 100.0f), 75, 1.0f);
        boolean bl = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getDiplomacyPoints() >= n4;
        this.canBuild_Movement = bl;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        if (this.sCost.length() > 0 && this.sMovementCost.length() > 0) {
            Color color2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            int n9;
            int n10;
            int n11;
            String string2;
            if (this.sCost.length() > 0) {
                ImageManager.getImage(Images.top_gold).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)) - ImageManager.getImage(Images.top_gold).getHeight() - CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f)), (int)((float)ImageManager.getImage(Images.top_gold).getHeight() * this.getImageScale(Images.top_gold, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                string2 = this.sCost;
                n11 = this.getPosX();
                n10 = this.getWidth();
                n9 = CFG.PADDING;
                int n12 = (int)((float)ImageManager.getImage(Images.top_gold).getWidth() * this.getImageScale(Images.top_gold, 0.6f));
                n8 = CFG.PADDING;
                n7 = this.iCostWidth;
                n6 = this.getPosY();
                n5 = this.getHeight() / 2;
                n4 = CFG.PADDING / 2;
                n3 = (int)((float)this.getTextHeight() * 0.6f);
                color2 = this.canBuild_MoneyCost ? CFG.COLOR_INGAME_GOLD : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2;
                CFG.drawTextWithShadow(spriteBatch, string2, n11 + n10 - n9 * 2 - n12 - n8 - n7 + n, n6 + n5 - n4 - n3 + n2, color2);
            }
            if (this.sMovementCost.length() > 0) {
                ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_diplomacy_points).getHeight() + CFG.PADDING / 2 + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.6f)));
                CFG.fontMain.getData().setScale(0.6f);
                string2 = this.sMovementCost;
                n4 = this.getPosX();
                n3 = this.getWidth();
                n8 = CFG.PADDING;
                n11 = this.iMovementCostWidth;
                n9 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f));
                n6 = CFG.PADDING;
                n7 = this.getPosY();
                n10 = this.getHeight() / 2;
                n5 = CFG.PADDING / 2;
                color2 = this.canBuild_Movement ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE;
                CFG.drawTextWithShadow(spriteBatch, string2, n4 + n3 - n8 * 2 - n11 - n9 - n6 + n, n7 + n10 + n5 + n2, color2);
            }
        } else if (this.sMovementCost.length() > 0) {
            ImageManager.getImage(Images.top_diplomacy_points).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f)) + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.top_diplomacy_points).getHeight() - (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.6f)) / 2 + n2, (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f)), (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getHeight() * this.getImageScale(Images.top_diplomacy_points, 0.6f)));
            CFG.fontMain.getData().setScale(0.6f);
            String string3 = this.sMovementCost;
            int n13 = this.getPosX();
            int n14 = this.getWidth();
            int n15 = CFG.PADDING;
            int n16 = this.iMovementCostWidth;
            int n17 = (int)((float)ImageManager.getImage(Images.top_diplomacy_points).getWidth() * this.getImageScale(Images.top_diplomacy_points, 0.6f));
            int n18 = CFG.PADDING;
            int n19 = this.getPosY();
            int n20 = this.getHeight() / 2;
            int n21 = (int)((float)this.getTextHeight() * 0.6f) / 2;
            Color color3 = this.canBuild_Movement ? CFG.COLOR_INGAME_DIPLOMACY_POINTS : CFG.COLOR_TEXT_MODIFIER_NEGATIVE;
            CFG.drawTextWithShadow(spriteBatch, string3, n13 + n14 - n15 * 2 - n16 - n17 - n18 + n, n19 + n20 - n21 + n2, color3);
        }
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sProvinceName, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        CFG.fontMain.getData().setScale(0.6f);
        CFG.drawTextWithShadow(spriteBatch, this.sDate, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sStability, this.getPosX() + CFG.PADDING + this.iDateWidth + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, this.cColorAssimilate);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected void setCurrent(int n) {
        StringBuilder stringBuilder;
        boolean bl = CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMoney() >= (long)n;
        this.canBuild_MoneyCost = bl;
        if (n > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            this.sCost = stringBuilder.toString();
        } else {
            this.sCost = "";
        }
        CFG.fontMain.getData().setScale(0.6f);
        GlyphLayout glyphLayout = CFG.glyphLayout;
        BitmapFont bitmapFont = CFG.fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.sCost);
        glyphLayout.setText(bitmapFont, stringBuilder.toString());
        this.iCostWidth = (int)CFG.glyphLayout.width;
        CFG.fontMain.getData().setScale(1.0f);
    }
}

