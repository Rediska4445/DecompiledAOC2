/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Game;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Game_ArrowUp
extends Button_Game {
    protected Button_Game_ArrowUp(int n, int n2, boolean bl) {
        super("", 0, n, n2, bl);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.arrow_active).draw(spriteBatch, this.getPosX() + ImageManager.getImage(Images.arrow_active).getHeight() / 2 + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.arrow_active).getWidth() / 2 - ImageManager.getImage(Images.arrow_active).getHeight() + n2, ImageManager.getImage(Images.arrow_active).getWidth(), ImageManager.getImage(Images.arrow_active).getHeight(), 270.0f);
        } else {
            ImageManager.getImage(Images.arrow).draw(spriteBatch, this.getPosX() + ImageManager.getImage(Images.arrow).getHeight() / 2 + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.arrow).getWidth() / 2 - ImageManager.getImage(Images.arrow).getHeight() + n2, ImageManager.getImage(Images.arrow).getWidth(), ImageManager.getImage(Images.arrow).getHeight(), 270.0f);
        }
    }
}

