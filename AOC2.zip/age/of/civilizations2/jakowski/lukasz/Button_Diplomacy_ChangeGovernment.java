/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Ideologies_Manager;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.GdxRuntimeException;

class Button_Diplomacy_ChangeGovernment
extends Button_Statistics {
    private static final float FONT_SCALE = 0.7f;
    private static final float FONT_SCALE2 = 0.6f;
    private Image civFlag;
    private int iAgeNameWidth;
    private int iIdeologyID;
    private String sAgeName;

    protected Button_Diplomacy_ChangeGovernment(int n, int n2, int n3, int n4, int n5, int n6) {
        CharSequence charSequence = CFG.ideologiesManager.getIdeology(n3).getName();
        int n7 = CFG.isAndroid() ? (int)Math.max((float)CFG.BUTTON_HEIGHT * 0.6f, (float)(CFG.TEXT_HEIGHT + CFG.PADDING * 6)) : CFG.TEXT_HEIGHT + CFG.PADDING * 4;
        super((String)charSequence, 0, n4, n5, n6, n7, false);
        this.iIdeologyID = n3;
        boolean bl = n % 2 == 0;
        this.row = bl;
        this.sAgeName = CFG.gameAges.getAge(CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).AVAILABLE_SINCE_AGE_ID).getName();
        CFG.glyphLayout.setText(CFG.fontMain, this.sAgeName);
        this.iAgeNameWidth = (int)(CFG.glyphLayout.width * 0.6f);
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append(CFG.ideologiesManager.getRealTag(CFG.game.getCiv(n2).getCivTag()));
        ((StringBuilder)charSequence).append(CFG.ideologiesManager.getIdeology(n3).getExtraTag());
        this.loadFlag(((StringBuilder)charSequence).toString());
    }

    private final float getImageScale(int n) {
        float f = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)ImageManager.getImage(n).getHeight();
        }
        return f2;
    }

    private final float getImageScale_Ideology() {
        float f = (float)CFG.TEXT_HEIGHT / (float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getHeight();
        float f2 = 1.0f;
        if (f < 1.0f) {
            f2 = (float)CFG.TEXT_HEIGHT / (float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getHeight();
        }
        return f2;
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Diplomacy_ChangeGovernment.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(0.55f, 0.8f, 0.0f, 0.2f));
                    } else {
                        spriteBatch.setColor(new Color(0.8f, 0.137f, 0.0f, 0.15f));
                    }
                    ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, Button_Diplomacy_ChangeGovernment.this.getPosX() + n, Button_Diplomacy_ChangeGovernment.this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + 1 + n2, Button_Diplomacy_ChangeGovernment.this.getWidth(), Button_Diplomacy_ChangeGovernment.this.getHeight() - 2, true, false);
                    spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_ChangeGovernment.this.getPosX() + n, Button_Diplomacy_ChangeGovernment.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy_ChangeGovernment.this.getWidth(), Button_Diplomacy_ChangeGovernment.this.getHeight() / 4, false, false);
                    ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_Diplomacy_ChangeGovernment.this.getPosX() + n, Button_Diplomacy_ChangeGovernment.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_Diplomacy_ChangeGovernment.this.getHeight() - 1 + n2 - Button_Diplomacy_ChangeGovernment.this.getHeight() / 4, Button_Diplomacy_ChangeGovernment.this.getWidth(), Button_Diplomacy_ChangeGovernment.this.getHeight() / 4, false, true);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void buildElementHover() {
        this.menuElementHover = CFG.ideologiesManager.getIdeologyHover_Just(this.iIdeologyID);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.15f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.35f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.05f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight());
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 6 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 6, this.getHeight(), true, false);
        }
        if (bl || this.getIsHovered()) {
            float f = CFG.COLOR_GRADIENT_DIPLOMACY.r;
            float f2 = CFG.COLOR_GRADIENT_DIPLOMACY.g;
            float f3 = CFG.COLOR_GRADIENT_DIPLOMACY.b;
            float f4 = bl ? 0.345f : 0.265f;
            spriteBatch.setColor(new Color(f, f2, f3, f4));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
        }
        if (this.row) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.625f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.375f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth());
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        this.civFlag.draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - this.civFlag.getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + CFG.PADDING * 2 + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)) / 2 - ImageManager.getImage(Images.flag_rect).getHeight() + n2, (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)), (int)((float)ImageManager.getImage(Images.flag_rect).getHeight() * this.getImageScale(Images.flag_rect)));
        if (!this.getClickable()) {
            spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.675f));
        }
        ImageManager.getImage(Images.time).draw(spriteBatch, this.getPosX() + this.getWidth() - CFG.PADDING * 2 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time)) / 2 - ImageManager.getImage(Images.time).getHeight() + n2, (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)), (int)((float)ImageManager.getImage(Images.time).getHeight() * this.getImageScale(Images.time)));
        spriteBatch.setColor(Color.WHITE);
        if (!this.getClickable()) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.65f));
        }
        CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().draw(spriteBatch, this.getPosX() + (Ideologies_Manager.MAX_CROWN_WIDTH + CFG.PADDING * 2) / 2 - (int)((float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getWidth() * this.getImageScale_Ideology()) / 2 + CFG.PADDING * 3 + (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect)) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getHeight() * this.getImageScale_Ideology()) / 2 - CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getHeight() + n2, (int)((float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getWidth() * this.getImageScale_Ideology()), (int)((float)CFG.ideologiesManager.getIdeology(this.iIdeologyID).getCrownImageScaled().getHeight() * this.getImageScale_Ideology()));
        spriteBatch.setColor(Color.WHITE);
        CFG.fontMain.getData().setScale(0.6f);
        Object object = new StringBuilder();
        ((StringBuilder)object).append("");
        ((StringBuilder)object).append(this.sAgeName);
        CFG.drawTextWithShadow(spriteBatch, ((StringBuilder)object).toString(), this.getPosX() + this.getWidth() - CFG.PADDING * 3 - (int)((float)ImageManager.getImage(Images.time).getWidth() * this.getImageScale(Images.time)) - this.iAgeNameWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.6f / 2.0f) + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.fontMain.getData().setScale(0.7f);
        String string2 = this.getText();
        int n3 = this.getPosX();
        int n4 = CFG.PADDING;
        int n5 = (int)((float)ImageManager.getImage(Images.flag_rect).getWidth() * this.getImageScale(Images.flag_rect));
        int n6 = Ideologies_Manager.MAX_CROWN_WIDTH;
        int n7 = CFG.PADDING;
        int n8 = this.getPosY();
        int n9 = this.getHeight() / 2;
        int n10 = (int)((float)CFG.TEXT_HEIGHT * 0.7f / 2.0f);
        object = this.getClickable() ? new Color(CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).getColor().r, CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).getColor().g, CFG.ideologiesManager.getIdeology((int)this.iIdeologyID).getColor().b, 1.0f) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.35f);
        CFG.drawTextWithShadow(spriteBatch, string2, n3 + n4 * 4 + n5 + n6 + n7 * 2 + n, n8 + n9 - n10 + n2, (Color)object);
        CFG.fontMain.getData().setScale(1.0f);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iIdeologyID;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected final void loadFlag(String var1_1) {
        try {
            var4_16 = Gdx.files;
            var5_21 = new StringBuilder();
            var5_21.append("game/flags/");
            var5_21.append(var1_1);
            var5_21.append(".png");
            var3_11 = new Texture(var4_16.internal(var5_21.toString()));
            this.civFlag = var2_3 = new Image(var3_11, Texture.TextureFilter.Nearest);
            return;
        }
        catch (GdxRuntimeException var2_4) {
            try {
                var2_5 = Gdx.files;
                var4_17 = new StringBuilder();
                var4_17.append("game/flags/");
                var4_17.append(CFG.ideologiesManager.getRealTag(var1_1));
                var4_17.append(".png");
                var5_22 = new Texture(var2_5.internal(var4_17.toString()));
                this.civFlag = var3_12 = new Image(var5_22, Texture.TextureFilter.Nearest);
                return;
            }
            catch (GdxRuntimeException var2_6) {
                var6_26 = CFG.isAndroid();
                if (!var6_26) ** GOTO lbl63
                try {
                    var3_13 = Gdx.files;
                    var4_18 = new StringBuilder();
                    var4_18.append("game/civilizations_editor/");
                    var4_18.append(CFG.ideologiesManager.getRealTag(var1_1));
                    var4_18.append("/");
                    var4_18.append(CFG.ideologiesManager.getRealTag(var1_1));
                    var4_18.append("_FL.png");
                    var5_23 = new Texture(var3_13.local(var4_18.toString()));
                    this.civFlag = var2_7 = new Image(var5_23, Texture.TextureFilter.Nearest);
                    return;
                }
                catch (GdxRuntimeException var2_8) {
                    try {
                        var5_24 = Gdx.files;
                        var4_19 = new StringBuilder();
                        var4_19.append("game/civilizations_editor/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(var1_1));
                        var4_19.append("/");
                        var4_19.append(CFG.ideologiesManager.getRealTag(var1_1));
                        var4_19.append("_FL.png");
                        var3_14 = new Texture(var5_24.internal(var4_19.toString()));
                        this.civFlag = var2_9 = new Image(var3_14, Texture.TextureFilter.Nearest);
                        return;
lbl63:
                        // 1 sources

                        var2_10 = Gdx.files;
                        var3_15 = new StringBuilder();
                        var3_15.append("game/civilizations_editor/");
                        var3_15.append(CFG.ideologiesManager.getRealTag(var1_1));
                        var3_15.append("/");
                        var3_15.append(CFG.ideologiesManager.getRealTag(var1_1));
                        var3_15.append("_FL.png");
                        var4_20 = new Texture(var2_10.internal(var3_15.toString()));
                        this.civFlag = var5_25 = new Image(var4_20, Texture.TextureFilter.Nearest);
                        return;
                    }
                    catch (GdxRuntimeException var1_2) {
                        this.civFlag = new Image(new Texture(Gdx.files.internal("game/flags/ran.png")), Texture.TextureFilter.Nearest);
                    }
                }
            }
        }
    }

    @Override
    protected void setVisible(boolean bl) {
        Image image;
        super.setVisible(bl);
        if (!bl && (image = this.civFlag) != null) {
            image.getTexture().dispose();
            this.civFlag = null;
        }
    }
}

