/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Civ_Mission_ChangeTypeOfGoverment;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import java.util.ArrayList;
import java.util.List;

class AI_Style_CityState
extends AI_Style {
    protected AI_Style_CityState() {
        this.TAG = "CITYSTATE";
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_DEFAULT = 0.05f;
        this.PERSONALITY_MIN_MILITARY_SPENDINGS_RANDOM = 19;
        this.PERSONALITY_MIN_HAPPINESS_DEFAULT = 77;
        this.PERSONALITY_MIN_HAPPINESS_RANDOM = 20;
        this.PERSONALITY_FORGIVNESS_DEFAULT = 0.4f;
        this.PERSONALITY_FORGIVNESS_RANDOM = 10;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void buildStartingBuildings(int n) {
        super.buildStartingBuildings(n);
        try {
            if (CFG.game.getCiv(n).getCapitalProvinceID() < 0) return;
            if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFarm_TechLevel(1) * 0.92f) {
                CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfFarm(Math.max(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getLevelOfFarm(), 1));
            }
            if (CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getLibrary_TechLevel(1) * 1.08f) {
                CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfLibrary(Math.max(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getLevelOfLibrary(), 1));
            }
            if (!(CFG.game.getCiv(n).getTechnologyLevel() >= BuildingsManager.getFort_TechLevel(2) * 1.08f)) return;
            CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).setLevelOfLibrary(Math.max(CFG.game.getProvince(CFG.game.getCiv(n).getCapitalProvinceID()).getLevelOfFort(), 2));
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void sendGiftToFriendlyCiv(int n) {
        block7: {
            block6: {
                if (Game_Calendar.TURN_ID < CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID) break block6;
                if (!CFG.game.getCiv(n).isAtWar()) break block7;
                CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 10 + CFG.oR.nextInt(15);
            }
            return;
        }
        if (CFG.game.getCiv(n).getMoney() > 0L && CFG.game.getCiv((int)n).iBudget > 0) {
            if (CFG.game.getCiv(n).getFriendlyCivsSize() > 0) {
                DiplomacyManager.sendGift(CFG.game.getCiv((int)n).getFriendlyCiv((int)CFG.oR.nextInt((int)CFG.game.getCiv((int)n).getFriendlyCivsSize())).iCivID, n, (int)Math.ceil((float)CFG.game.getCiv((int)n).iBudget * (0.05f + (float)CFG.oR.nextInt(75) / 1000.0f)));
                CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 5 + CFG.oR.nextInt(8);
                return;
            }
            CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 10 + CFG.oR.nextInt(10);
            return;
        }
        CFG.game.getCiv((int)n).civGameData.iSendGift_LastTurnID = Game_Calendar.TURN_ID + 6 + CFG.oR.nextInt(8);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void shouldChangeTypeOfGoverment(int n) {
        if (CFG.game.getCiv(n).getHappiness() > 85 && CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment == null) {
            List<Boolean> list = CFG.ideologiesManager.canChangeToIdeology(n);
            ArrayList<Integer> arrayList = new ArrayList<Integer>();
            for (int i = 0; i < list.size(); ++i) {
                if (!list.get(i).booleanValue()) continue;
                arrayList.add(i);
            }
            if (arrayList.size() > 0) {
                CFG.game.getCiv((int)n).civGameData.changeTypeOfGoverment = new Civ_Mission_ChangeTypeOfGoverment((Integer)arrayList.get(CFG.oR.nextInt(arrayList.size())), n);
            }
            return;
        }
        this.sendGiftToFriendlyCiv(n);
    }

    @Override
    protected void turnOrders(int n) {
        this.shouldChangeTypeOfGoverment(n);
        this.checkBalanceOfProvinces_Tribal(n);
        super.turnOrders(n);
    }
}

