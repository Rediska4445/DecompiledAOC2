/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class Continent_GameData
implements Serializable {
    private static final long serialVersionUID = 0L;
    private float fB;
    private float fG;
    private float fR;
    private String sName = "";

    protected Continent_GameData() {
    }

    protected final float getB() {
        return this.fB;
    }

    protected final float getG() {
        return this.fG;
    }

    protected final String getName() {
        return this.sName;
    }

    protected final float getR() {
        return this.fR;
    }

    protected final void setB(float f) {
        this.fB = f;
    }

    protected final void setG(float f) {
        this.fG = f;
    }

    protected final void setName(String string2) {
        this.sName = string2;
    }

    protected final void setR(float f) {
        this.fR = f;
    }
}

