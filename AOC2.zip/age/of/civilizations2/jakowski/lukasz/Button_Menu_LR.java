/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Menu_LR
extends Button_Menu {
    protected Button_Menu_LR(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Menu_LR(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (bl) {
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btnh_menu_h).getWidth());
            ImageManager.getImage(Images.btnh_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btnh_menu_h).getWidth() + n, this.getPosY() + n2, true);
        } else if (this.getIsHovered() && this.getClickable()) {
            spriteBatch.setColor(CFG.COLOR_BUTTON_MENU_HOVER_BG);
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth());
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth() + n, this.getPosY() + n2, true);
            spriteBatch.setColor(Color.WHITE);
        } else {
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth());
            ImageManager.getImage(Images.btn_menu_h).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_menu_h).getWidth() + n, this.getPosY() + n2, true);
        }
        if (this.getClickable() && this.getIsHovered() && !bl && animationState >= 0) {
            if (animationState == 0) {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu_LR.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    ++animationState;
                    lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f = Math.min((float)(System.currentTimeMillis() - lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(Button_Menu_LR.getColorLine());
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (lTimeAnimation < System.currentTimeMillis() - 750L) {
                    animationState = 0;
                    lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
            spriteBatch.setColor(Color.WHITE);
        }
    }
}

