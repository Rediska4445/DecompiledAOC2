/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Options_NS_MapModes;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Options_NS_MapModes2
extends Button_Options_NS_MapModes {
    protected Button_Options_NS_MapModes2(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        super(n, string2, n2, n3, n4, n5, n6, bl);
    }

    protected Button_Options_NS_MapModes2(int n, String string2, int n2, int n3, int n4, int n5, int n6, boolean bl, boolean bl2) {
        super(n, string2, n2, n3, n4, n5, n6, bl, bl2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f;
        float f2;
        float f3;
        float f4;
        block3: {
            block2: {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
                ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), this.getWidth(), this.getHeight() - CFG.PADDING);
                f4 = CFG.COLOR_INFO_BOX_GRADIENT.r;
                f3 = CFG.COLOR_INFO_BOX_GRADIENT.g;
                f2 = CFG.COLOR_INFO_BOX_GRADIENT.b;
                float f5 = 0.225f;
                f = !bl && this.getIsHovered() ? 0.175f : 0.225f;
                spriteBatch.setColor(new Color(f4, f3, f2, f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight() - CFG.PADDING, false, false);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n + this.getWidth() - this.getWidth() / 2, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight() - CFG.PADDING, true, false);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), (this.getHeight() - CFG.PADDING) / 5);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - (this.getHeight() - CFG.PADDING) / 5 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), (this.getHeight() - CFG.PADDING) / 5, false, true);
                f4 = CFG.COLOR_FLAG_FRAME.r;
                f3 = CFG.COLOR_FLAG_FRAME.g;
                f2 = CFG.COLOR_FLAG_FRAME.b;
                if (bl) break block2;
                f = f5;
                if (!this.getIsHovered()) break block3;
            }
            f = 0.325f;
        }
        spriteBatch.setColor(new Color(f4, f3, f2, f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1, true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + CFG.PADDING / 2 + n2 + (this.getHeight() - CFG.PADDING) - 1 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth(), 1, true, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        CFG.drawRect(spriteBatch, this.getPosX() + n - 1, this.getPosY() + CFG.PADDING / 2 + n2 - 2, this.getWidth() + 2, this.getHeight() - CFG.PADDING + 2);
        spriteBatch.setColor(Color.WHITE);
    }
}

