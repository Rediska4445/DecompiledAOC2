/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ConfigINI;
import age.of.civilizations2.jakowski.lukasz.Game_Action;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.Game_Render;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.InitGame;
import age.of.civilizations2.jakowski.lukasz.LinkHandler;
import age.of.civilizations2.jakowski.lukasz.MenuManager;
import age.of.civilizations2.jakowski.lukasz.SettingsManager;
import age.of.civilizations2.jakowski.lukasz.Shaft;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import age.of.civilizations2.jakowski.lukasz.Steam_Game;
import age.of.civilizations2.jakowski.lukasz.Touch;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.utils.GdxRuntimeException;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import java.util.concurrent.TimeUnit;

public class AoCGame
extends ApplicationAdapter
implements InputProcessor {
    private static final int DEFAULT_SCROLL = 15;
    private static final int DEFAULT_SCROLL_MAP = 12;
    protected static int FPS_LIMIT = 0;
    public static int LEFT = 0;
    public static int RIGHT = 0;
    public static final boolean STEAM_BUILD = false;
    public static int TOP = 0;
    protected static int TYPE_NUMBER = 0;
    protected static final int TYPE_NUMBER_RESET_TIME = 625;
    protected static long TYPE_NUMER_TIME;
    protected static ShaderProgram blackWhiteShader;
    protected static OrthographicCamera camera;
    protected static ShaderProgram defaultShader;
    protected static boolean drawFPS;
    protected static LinkHandler mLinkHandler;
    protected static ShaderProgram nextPlayerTurnShader;
    public static boolean screenShotMode;
    protected static ShaderProgram shaderAlpha;
    protected static ShaderProgram shaderAlpha2;
    protected static Steam_Game steamGame;
    protected static Viewport viewport;
    private boolean MAP_MOVE_BOT = false;
    private boolean MAP_MOVE_LEFT = false;
    private boolean MAP_MOVE_RIGHT = false;
    private boolean MAP_MOVE_TOP = false;
    private final String VERTEX;
    private String fragmentShader;
    private int iNumOfFPS = 0;
    private int iScroll = 15;
    private float iScroll_MAP = 12.0f;
    private float iScroll_MAPY = 12.0f;
    private long lScrollTime = 0L;
    private long lScrollTime_MAP = 0L;
    private long lScrollTime_MAPY = 0L;
    private long lTimeFPS;
    private SpriteBatch oSB;
    private long renderStart;
    private RequestRendering requestRendering;
    private Touch touch = new Touch();
    private String vertexShader;

    static {
        screenShotMode = false;
        drawFPS = false;
        FPS_LIMIT = 60;
        TYPE_NUMER_TIME = 0L;
        TYPE_NUMBER = 0;
    }

    public AoCGame(LinkHandler linkHandler) {
        this.VERTEX = "attribute vec4 a_position;attribute vec4 a_color;attribute vec2 a_texCoord0;uniform mat4 u_projTrans;varying vec4 vColor;varying vec2 vTexCoord;void main() {\tvColor = a_color;\tvTexCoord = a_texCoord0;\tgl_Position =  u_projTrans * a_position;}";
        mLinkHandler = linkHandler;
    }

    private void countFPS() {
        ++this.iNumOfFPS;
        if (System.currentTimeMillis() > this.lTimeFPS + 1000L) {
            this.lTimeFPS = System.currentTimeMillis();
            CFG.iNumOfFPS = this.iNumOfFPS;
            this.iNumOfFPS = 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected static final void loadCursor(boolean bl) {
        if (!CFG.settingsManager.loadCursor) {
            if (bl) return;
            Gdx.graphics.setSystemCursor(Cursor.SystemCursor.Arrow);
            return;
        }
        try {
            Pixmap pixmap = new Pixmap(Gdx.files.internal("UI/icons/cursor.png"));
            Cursor cursor = Gdx.graphics.newCursor(pixmap, 0, 0);
            Gdx.graphics.setCursor(cursor);
            pixmap.dispose();
            return;
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            return;
        }
    }

    protected static final void resetTypeNumber() {
        TYPE_NUMER_TIME = 0L;
        TYPE_NUMBER = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected static final void updateArmyFontSize() {
        if (CFG.settingsManager.FONT_ARMY_SIZE < 0) {
            SettingsManager settingsManager = CFG.settingsManager;
            int n = CFG.XXXHDPI || CFG.XXXXHDPI || CFG.XXHDPI ? 18 : 16;
            settingsManager.FONT_ARMY_SIZE = n;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void updateMoveMap() {
        try {
            if (this.MAP_MOVE_LEFT) {
                this.updateScroll_Map();
                CFG.map.getMapCoordinates().setNewPosX(CFG.map.getMapCoordinates().getPosX() + (int)this.iScroll_MAP);
            } else if (this.MAP_MOVE_RIGHT) {
                this.updateScroll_Map();
                CFG.map.getMapCoordinates().setNewPosX(CFG.map.getMapCoordinates().getPosX() - (int)this.iScroll_MAP);
            }
            if (this.MAP_MOVE_TOP) {
                this.updateScroll_MapY();
                CFG.map.getMapCoordinates().setNewPosY(CFG.map.getMapCoordinates().getPosY() + (int)this.iScroll_MAPY);
                return;
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        catch (NullPointerException nullPointerException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(nullPointerException);
            return;
        }
        catch (ArithmeticException arithmeticException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(arithmeticException);
            return;
        }
        {
            if (!this.MAP_MOVE_BOT) return;
            this.updateScroll_MapY();
            CFG.map.getMapCoordinates().setNewPosY(CFG.map.getMapCoordinates().getPosY() - (int)this.iScroll_MAPY);
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final void updateRequestRendering(boolean bl) {
        if (bl) {
            this.requestRendering = new RequestRendering(){

                @Override
                public void update() {
                }
            };
            CFG.setRender_3(true);
            return;
        }
        this.requestRendering = new RequestRendering(){

            @Override
            public void update() {
            }
        };
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final void updateScroll() {
        if (this.lScrollTime + 50L > System.currentTimeMillis()) {
            this.lScrollTime = System.currentTimeMillis();
            this.iScroll += (int)((float)this.iScroll * 1.2f);
            if (this.iScroll > 75) {
                this.iScroll = 75;
            }
            return;
        }
        this.lScrollTime = System.currentTimeMillis();
        this.iScroll = 15;
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void updateScroll_Map() {
        float f = 1.0f;
        if (this.lScrollTime_MAP + 150L >= System.currentTimeMillis()) return;
        this.lScrollTime_MAP = System.currentTimeMillis();
        this.iScroll_MAP += this.iScroll_MAP * 0.475f;
        float f2 = CFG.map.getMapScale().getCurrentScale() < 1.0f ? 1.0f + (1.0f - CFG.map.getMapScale().getCurrentScale()) : 1.0f;
        if (this.iScroll_MAP > 35.0f * f2) {
            f2 = f;
            if (CFG.map.getMapScale().getCurrentScale() < 1.0f) {
                f2 = 1.0f + (1.0f - CFG.map.getMapScale().getCurrentScale());
            }
            this.iScroll_MAP = f2 * 35.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private final void updateScroll_MapY() {
        float f = 1.0f;
        if (this.lScrollTime_MAPY + 150L >= System.currentTimeMillis()) return;
        this.lScrollTime_MAPY = System.currentTimeMillis();
        this.iScroll_MAPY += this.iScroll_MAPY * 0.475f;
        float f2 = CFG.map.getMapScale().getCurrentScale() < 1.0f ? 1.0f + (1.0f - CFG.map.getMapScale().getCurrentScale()) : 1.0f;
        if (this.iScroll_MAPY > 35.0f * f2) {
            f2 = f;
            if (CFG.map.getMapScale().getCurrentScale() < 1.0f) {
                f2 = 1.0f + (1.0f - CFG.map.getMapScale().getCurrentScale());
            }
            this.iScroll_MAPY = f2 * 35.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void create() {
        ConfigINI.readConfig();
        CFG.LANDSCAPE = ConfigINI.landscape;
        if (CFG.isAndroid()) {
            if (CFG.LANDSCAPE) {
                CFG.GAME_WIDTH = Gdx.graphics.getWidth();
                CFG.GAME_HEIGHT = Gdx.graphics.getHeight();
            } else if (Gdx.graphics.getHeight() < Gdx.graphics.getWidth()) {
                CFG.GAME_WIDTH = Gdx.graphics.getHeight();
                CFG.GAME_HEIGHT = Gdx.graphics.getWidth();
            } else {
                CFG.GAME_WIDTH = Gdx.graphics.getWidth();
                CFG.GAME_HEIGHT = Gdx.graphics.getHeight();
            }
        } else {
            CFG.GAME_WIDTH = Gdx.graphics.getWidth();
            CFG.GAME_HEIGHT = Gdx.graphics.getHeight();
        }
        camera = new OrthographicCamera(CFG.GAME_WIDTH, CFG.GAME_HEIGHT);
        camera.setToOrtho(false, CFG.GAME_WIDTH, -CFG.GAME_HEIGHT);
        viewport = new FitViewport(CFG.GAME_WIDTH, (float)CFG.GAME_HEIGHT, camera);
        CFG.updateRender(true);
        this.updateRequestRendering(true);
        CFG.loadSettings();
        CFG.DENSITY = Gdx.graphics.getDensity();
        if (CFG.DENSITY < 1.0f) {
            CFG.DENSITY = 1.0f;
        }
        if (ConfigINI.iUIScale <= 0) {
            if (CFG.isAndroid()) {
                boolean bl = Gdx.graphics.getPpiX() >= 300.0f || CFG.GAME_WIDTH >= 1200 || CFG.GAME_HEIGHT >= 1200;
                CFG.XHDPI = bl;
                bl = Gdx.graphics.getPpiX() >= 380.0f || CFG.GAME_WIDTH >= 1800 || CFG.GAME_HEIGHT >= 1800;
                CFG.XXHDPI = bl;
            } else if (CFG.isDesktop()) {
                boolean bl = CFG.GAME_WIDTH >= 2400;
                CFG.XHDPI = bl;
            }
        } else if (ConfigINI.iUIScale == 1) {
            CFG.XHDPI = false;
            CFG.XXHDPI = false;
            CFG.XXXHDPI = false;
            CFG.XXXXHDPI = false;
        } else if (ConfigINI.iUIScale == 2) {
            CFG.XHDPI = true;
            CFG.XXHDPI = false;
            CFG.XXXHDPI = false;
            CFG.XXXXHDPI = false;
        } else if (ConfigINI.iUIScale == 3) {
            CFG.XHDPI = true;
            CFG.XXHDPI = true;
            CFG.XXXHDPI = false;
            CFG.XXXXHDPI = false;
        } else if (ConfigINI.iUIScale == 4) {
            CFG.XHDPI = true;
            CFG.XXHDPI = true;
            CFG.XXXHDPI = true;
            CFG.XXXXHDPI = false;
        } else if (ConfigINI.iUIScale == 5) {
            CFG.XHDPI = true;
            CFG.XXHDPI = true;
            CFG.XXXHDPI = true;
            CFG.XXXXHDPI = true;
        }
        this.oSB = new SpriteBatch();
        Gdx.input.setInputProcessor(this);
        Gdx.input.setCatchBackKey(true);
        Images.btn_menu_h = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "buttons/menu.png");
        Images.btn_clear = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "buttons/clear.png");
        Images.btn_close = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "buttons/close.png");
        Images.line_32_off1 = ImageManager.addImage("UI/lines/line_32_off1.png", Pixmap.Format.RGBA8888, Texture.TextureFilter.Linear, Texture.TextureWrap.Repeat);
        Images.gradient = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "gradient.png");
        Images.feather = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "icons/feather.png");
        Images.top_nuclear_weapons = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "icons/nuclear_weapons.png");
        Images.loading_rect_edge = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "loading/loading_edge.png", Pixmap.Format.RGBA8888, Texture.TextureFilter.Nearest, Texture.TextureWrap.ClampToEdge);
        Images.pix255_255_255 = ImageManager.addImage("UI/pix", Pixmap.Format.RGBA8888, Texture.TextureFilter.Linear, Texture.TextureWrap.Repeat);
        CFG.BUTTON_HEIGHT = ImageManager.getImage(Images.btn_menu_h).getHeight();
        int n = CFG.XXXXHDPI ? 212 : (CFG.XXXHDPI ? 180 : (CFG.XXHDPI ? 160 : (CFG.XHDPI ? 120 : 90)));
        CFG.BUTTON_WIDTH = n;
        CFG.GUI_SCALE = 100.0f * (float)CFG.BUTTON_HEIGHT / 68.0f / 100.0f;
        CFG.PADDING = (int)(5.0f * CFG.GUI_SCALE);
        CFG.CIV_INFO_MENU_WIDTH = (int)((float)CFG.CIV_INFO_MENU_WIDTH * CFG.GUI_SCALE);
        CFG.CIV_COLOR_WIDTH = (int)((float)CFG.CIV_COLOR_WIDTH * CFG.GUI_SCALE);
        CFG.SERVICE_RIBBON_WIDTH = (int)((float)CFG.SERVICE_RIBBON_WIDTH * CFG.GUI_SCALE);
        CFG.SERVICE_RIBBON_HEIGHT = (int)((float)CFG.SERVICE_RIBBON_HEIGHT * CFG.GUI_SCALE);
        if (CFG.settingsManager.FONT_MAIN_SIZE < 0) {
            CFG.settingsManager.FONT_MAIN_SIZE = (int)(18.0f * CFG.GUI_SCALE);
        }
        AoCGame.updateArmyFontSize();
        Images.gameLogo = ImageManager.addImage("UI/" + CFG.getRescouresPath() + "game_logo.png");
        CFG.menuManager = new MenuManager();
        Game_Render.updateRenderer();
        Game_Render.updateDrawMoveUnits();
        CFG.soundsManager = new SoundsManager();
        new InitGame();
        ShaderProgram.pedantic = false;
        String string2 = Gdx.files.internal("game/shader/default_vertex.glsl").readString();
        String string3 = Gdx.files.internal("game/shader/flag_fragment.glsl").readString();
        String string4 = Gdx.files.internal("game/shader/nextPlayerTurn_vertex.glsl").readString();
        shaderAlpha = new ShaderProgram("attribute vec4 a_position;attribute vec4 a_color;attribute vec2 a_texCoord0;uniform mat4 u_projTrans;varying vec4 vColor;varying vec2 vTexCoord;void main() {\tvColor = a_color;\tvTexCoord = a_texCoord0;\tgl_Position =  u_projTrans * a_position;}", string3);
        shaderAlpha.begin();
        shaderAlpha.setUniformi("u_texture1", 1);
        shaderAlpha.setUniformi("u_mask", 2);
        shaderAlpha.end();
        this.vertexShader = "attribute vec4 a_position;\nattribute vec4 a_color;\nattribute vec2 a_texCoord0;\nuniform mat4 u_projTrans;\nvarying vec4 v_color;\nvarying vec2 v_texCoords;\n\nvoid main()\n{\n   v_color = a_color;\n   v_color.a = v_color.a * (255.0/254.0);\n   v_texCoords = a_texCoord0;\n   gl_Position =  u_projTrans * a_position;\n}\n";
        this.fragmentShader = "#ifdef GL_ES\nprecision mediump float;\n#endif\nvarying vec4 v_color;\nvarying vec2 v_texCoords;\nuniform sampler2D u_texture;\nuniform sampler2D u_texture2;\nuniform float u_maskScale;\nuniform float u_useMask;\nuniform vec2 u_maskOffset;\nvoid main()                                  \n{                                            \n vec2 newCoords = -1.0 * (u_maskScale - 1.0)/2.0 + (u_maskScale * v_texCoords) + u_maskOffset;\n vec4 mask = vec4(1.0, 1.0, 1.0, 1.0); \nif(u_useMask > 0.5) \n\tmask = texture2D(u_texture2, v_texCoords);\n vec4 color = v_color * texture2D(u_texture, newCoords);\n  gl_FragColor = vec4(color.rgb, color.a * mask.r);\n}";
        shaderAlpha2 = new ShaderProgram(this.vertexShader, this.fragmentShader);
        shaderAlpha2.begin();
        shaderAlpha2.setUniformi("u_texture", 0);
        shaderAlpha2.setUniformi("u_texture2", 1);
        shaderAlpha2.setUniformf("u_useMask", 1.0f);
        shaderAlpha2.setUniformf("u_maskScale", 20.0f);
        shaderAlpha2.setUniformf("u_maskOffset", 0.0f, 0.0f);
        String string5 = Gdx.files.internal("game/shader/default_fragment.glsl").readString();
        String string6 = Gdx.files.internal("game/shader/blackWhite_fragment.glsl").readString();
        string3 = Gdx.files.internal("game/shader/nextPlayerTurn_fragment.glsl").readString();
        defaultShader = new ShaderProgram(string2, string5);
        blackWhiteShader = new ShaderProgram(string2, string6);
        nextPlayerTurnShader = new ShaderProgram(string4, string3);
        long l = System.currentTimeMillis();
        AoCGame.loadCursor(true);
        Gdx.app.log("AoC", "LOAD TIME: " + (System.currentTimeMillis() - l));
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                int n = 0;
                Gdx.app.log("BEII", "TurnListener started!");
                block2: while (true) {
                    int n2;
                    try {
                        do {
                            TimeUnit.SECONDS.sleep(1L);
                        } while (n == Game_Calendar.TURN_ID);
                    }
                    catch (InterruptedException interruptedException) {
                        throw new RuntimeException(interruptedException);
                    }
                    for (n = 1; n < CFG.game.getCivsSize(); ++n) {
                        float f = 0.0f;
                        for (n2 = 0; n2 < CFG.game.getCiv(n).getNumOfProvinces(); ++n2) {
                            float f2 = f;
                            if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getLevelOfShaft() > 0) {
                                f2 = f + Shaft.getShaft_Bonus(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n2)).getLevelOfShaft());
                            }
                            f = f2;
                        }
                        Gdx.app.log("BEII", "RESLOG: " + f + " (" + (int)(f * 12.0f) + ")");
                        CFG.game.getCiv(n).setManPower(CFG.game.getCiv(n).getManPower() + (int)(f * 12.0f));
                    }
                    int n3 = Game_Calendar.TURN_ID;
                    Gdx.app.log("BEII", "RPT: 0 (TIME NOT TESTED");
                    n2 = 0;
                    while (true) {
                        n = n3;
                        if (n2 >= CFG.game.getProvincesSize()) continue block2;
                        if (CFG.game.getProvince(n2).getDrawNuclearExplosion()) {
                            CFG.game.getProvince(n2).setDrawNuclearExplosion(false);
                        }
                        ++n2;
                    }
                    break;
                }
            }
        }).start();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void dispose() {
        try {
            Gdx.app.log("AoC", "dispose");
            if (CFG.isDesktop()) {
                // empty if block
            }
            this.oSB.dispose();
            CFG.fontMain.dispose();
            CFG.fontBorder.dispose();
            for (int i = 0; i < ImageManager.getImagesSize(); ++i) {
                ImageManager.getImage(i).getTexture().dispose();
            }
        }
        catch (GdxRuntimeException gdxRuntimeException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(gdxRuntimeException);
            return;
        }
        catch (NullPointerException nullPointerException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(nullPointerException);
            return;
        }
        {
            CFG.map.getMapBG().disposeGameMap();
            CFG.soundsManager.dispose();
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected float getScrolled_ScaleUpdate() {
        if (!(CFG.map.getMapScale().getCurrentScale() <= 1.0f)) return 0.1f;
        if (CFG.map.getMapScale().getCurrentScale() >= 0.65f) {
            return 0.05f;
        }
        if (!(CFG.map.getMapScale().getCurrentScale() >= 0.4f)) return 0.01f;
        return 0.02f;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean keyDown(int n) {
        boolean bl = false;
        try {
            CFG.setRender_3(true);
            if (CFG.menuManager.getKeyboard().getVisible()) return true;
            if (CFG.editorManager.keyDown(n)) {
                return true;
            }
            if (n == 21) {
                this.MAP_MOVE_LEFT = true;
                this.MAP_MOVE_RIGHT = false;
                this.lScrollTime_MAP = System.currentTimeMillis();
                this.iScroll_MAP = 15.0f;
            }
            if (n == 22) {
                this.MAP_MOVE_RIGHT = true;
                this.MAP_MOVE_LEFT = false;
                this.lScrollTime_MAP = System.currentTimeMillis();
                this.iScroll_MAP = 15.0f;
            }
            if (n == 19) {
                this.MAP_MOVE_TOP = true;
                this.MAP_MOVE_BOT = false;
                this.lScrollTime_MAPY = System.currentTimeMillis();
                this.iScroll_MAPY = 15.0f;
            }
            if (n == 20) {
                this.MAP_MOVE_BOT = true;
                this.MAP_MOVE_TOP = false;
                this.lScrollTime_MAPY = System.currentTimeMillis();
                this.iScroll_MAPY = 15.0f;
            }
            if (n != 49) return true;
            if (!screenShotMode) {
                bl = true;
            }
            screenShotMode = bl;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return true;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return true;
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
            return true;
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean keyTyped(char c) {
        CFG.setRender_3(true);
        Gdx.app.log("AoC", "" + c + " character: " + c);
        try {
            if (CFG.menuManager.getKeyboard().getVisible() && c > '\u0000') {
                if (c == '\u0012' || c == '\b') {
                    CFG.keyboardDelete.action();
                    CFG.menuManager.getKeyboard().onMenuPressed();
                } else if (c != '\r' && c != ';' && c != '<') {
                    CFG.Keyboard_Action_Write keyboard_Action_Write = CFG.keyboardWrite;
                    StringBuilder stringBuilder = new StringBuilder();
                    keyboard_Action_Write.action(stringBuilder.append("").append(c).toString());
                    CFG.menuManager.getKeyboard().onMenuPressed();
                }
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
        }
        try {
            CFG.soundsManager.playSound(SoundsManager.SOUND_CLICK, SoundsManager.PERC_VOLUME_KEYBOARD);
            return false;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return false;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return false;
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
            return false;
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
            return false;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public boolean keyUp(int var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:406)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:481)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean mouseMoved(int n, int n2) {
        try {
            Touch.setMousePosXY(n, n2);
            if (CFG.isDesktop()) {
                if (n < CFG.PADDING) {
                    if (!this.MAP_MOVE_LEFT) {
                        this.MAP_MOVE_LEFT = true;
                        this.MAP_MOVE_RIGHT = false;
                        this.lScrollTime_MAP = System.currentTimeMillis();
                        this.iScroll_MAP = 15.0f;
                    }
                } else {
                    this.MAP_MOVE_LEFT = false;
                }
                if (n > CFG.GAME_WIDTH - CFG.PADDING) {
                    if (!this.MAP_MOVE_RIGHT) {
                        this.MAP_MOVE_RIGHT = true;
                        this.MAP_MOVE_LEFT = false;
                        this.lScrollTime_MAP = System.currentTimeMillis();
                        this.iScroll_MAP = 15.0f;
                    }
                } else {
                    this.MAP_MOVE_RIGHT = false;
                }
                if (n2 < CFG.PADDING) {
                    if (!this.MAP_MOVE_TOP) {
                        this.MAP_MOVE_TOP = true;
                        this.MAP_MOVE_BOT = false;
                        this.lScrollTime_MAPY = System.currentTimeMillis();
                        this.iScroll_MAPY = 15.0f;
                    }
                } else {
                    this.MAP_MOVE_TOP = false;
                }
                if (n2 > CFG.GAME_HEIGHT - CFG.PADDING) {
                    if (!this.MAP_MOVE_BOT) {
                        this.MAP_MOVE_BOT = true;
                        this.MAP_MOVE_TOP = false;
                        this.lScrollTime_MAPY = System.currentTimeMillis();
                        this.iScroll_MAPY = 15.0f;
                    }
                } else {
                    this.MAP_MOVE_BOT = false;
                }
            }
            this.touch.actionMove_Hover(n, n2);
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return true;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return true;
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
            return true;
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
            return true;
        }
    }

    @Override
    public void pause() {
        this.updateRequestRendering(false);
        if (!CFG.menuManager.getInLoadMap() && !CFG.menuManager.getInInitMenu()) {
            CFG.updateRender(false);
        }
        CFG.setRender_3(true);
        super.pause();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public void render() {
        block38: {
            this.renderStart = System.currentTimeMillis();
            try {
                this.update();
                this.updateMoveMap();
            }
            catch (IndexOutOfBoundsException var2_2) {
                CFG.exceptionStack(var2_2);
            }
            catch (NullPointerException var2_3) {
                CFG.exceptionStack(var2_3);
            }
            catch (ArithmeticException var2_4) {
                CFG.exceptionStack(var2_4);
            }
            catch (StackOverflowError var2_5) {
                CFG.exceptionStack(var2_5);
            }
            catch (IllegalArgumentException var2_6) {
                CFG.exceptionStack(var2_6);
            }
            if (!CFG.RENDER && !CFG.settingsManager.CONTINUOUS_RENDERING) ** GOTO lbl73
            try {
                block37: {
                    if (CFG.RENDER3) {
                        CFG.RENDER3 = false;
                    } else if (CFG.RENDER2) {
                        CFG.RENDER2 = false;
                    } else {
                        CFG.RENDER = false;
                    }
                    Gdx.gl.glClearColor(CFG.BACKGROUND_COLOR.r, CFG.BACKGROUND_COLOR.g, CFG.BACKGROUND_COLOR.b, CFG.BACKGROUND_COLOR.a);
                    Gdx.gl.glClear(16640);
                    AoCGame.viewport.setWorldSize((float)CFG.GAME_WIDTH / CFG.map.getMapScale().getCurrentScale(), (float)CFG.GAME_HEIGHT / CFG.map.getMapScale().getCurrentScale());
                    AoCGame.viewport.apply();
                    AoCGame.camera.setToOrtho(true, (float)CFG.GAME_WIDTH / CFG.map.getMapScale().getCurrentScale(), (float)(-CFG.GAME_HEIGHT) / CFG.map.getMapScale().getCurrentScale());
                    this.oSB.setProjectionMatrix(AoCGame.camera.combined);
                    this.oSB.begin();
                    this.oSB.setShader(AoCGame.defaultShader);
                    Game_Render.draw(this.oSB);
                    this.oSB.end();
                    AoCGame.camera.setToOrtho(false, CFG.GAME_WIDTH, -CFG.GAME_HEIGHT);
                    AoCGame.viewport.setWorldSize(CFG.GAME_WIDTH, CFG.GAME_HEIGHT);
                    AoCGame.viewport.apply();
                    this.oSB.setProjectionMatrix(AoCGame.camera.combined);
                    this.oSB.begin();
                    Game_Render.drawWithoutScale(this.oSB);
                    this.oSB.end();
                    AoCGame.viewport.setWorldSize((float)CFG.GAME_WIDTH / CFG.map.getMapScale().getCurrentScale(), (float)CFG.GAME_HEIGHT / CFG.map.getMapScale().getCurrentScale());
                    AoCGame.viewport.apply();
                    AoCGame.camera.setToOrtho(true, (float)CFG.GAME_WIDTH / CFG.map.getMapScale().getCurrentScale(), (float)(-CFG.GAME_HEIGHT) / CFG.map.getMapScale().getCurrentScale());
                    this.oSB.setProjectionMatrix(AoCGame.camera.combined);
                    this.oSB.begin();
                    this.oSB.setShader(AoCGame.defaultShader);
                    Game_Render.drawMapDetails(this.oSB);
                    this.oSB.end();
                    AoCGame.camera.setToOrtho(false, CFG.GAME_WIDTH, -CFG.GAME_HEIGHT);
                    AoCGame.viewport.setWorldSize(CFG.GAME_WIDTH, CFG.GAME_HEIGHT);
                    AoCGame.viewport.apply();
                    this.oSB.setProjectionMatrix(AoCGame.camera.combined);
                    this.oSB.begin();
                    this.oSB.setColor(Color.WHITE);
                    if (!AoCGame.screenShotMode) {
                        CFG.menuManager.draw(this.oSB);
                        CFG.editorManager.draw(this.oSB);
                    }
                    if (!(var1_19 = AoCGame.drawFPS)) break block37;
                    CFG.fontMain.getData().setScale(0.8f);
                    var2_1 = this.oSB;
                    var3_20 = new StringBuilder();
                    CFG.drawTextWithShadow(var2_1, var3_20.append("FPS: ").append(CFG.iNumOfFPS).toString(), CFG.PADDING * 2, CFG.PADDING * 2, Color.WHITE);
                    CFG.fontMain.getData().setScale(1.0f);
                    break block37;
lbl73:
                    // 1 sources

                    try {
                        Thread.sleep((long)(1000.0f / (float)AoCGame.FPS_LIMIT - (float)(System.currentTimeMillis() - this.renderStart)));
                    }
                    catch (InterruptedException var2_14) {
                        if (CFG.LOGS) {
                            CFG.exceptionStack(var2_14);
                        }
                        break block38;
                    }
                    catch (IllegalArgumentException var2_15) {
                        if (CFG.LOGS) {
                            CFG.exceptionStack(var2_15);
                        }
                        break block38;
                    }
                    catch (NullPointerException var2_16) {
                        if (CFG.LOGS) {
                            CFG.exceptionStack(var2_16);
                        }
                        break block38;
                    }
                    catch (IllegalStateException var2_17) {
                        break block37;
                    }
                    catch (NullPointerException var2_18) {}
                }
                try {
                    this.oSB.setColor(Color.WHITE);
                    this.oSB.end();
                }
                catch (IllegalStateException var2_7) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(var2_7);
                    }
                    CFG.setRender_3(true);
                    try {
                        this.oSB.end();
                    }
                    catch (IllegalStateException var2_8) {}
                }
                catch (NullPointerException var2_9) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(var2_9);
                    }
                    CFG.setRender_3(true);
                }
            }
            catch (IndexOutOfBoundsException var2_10) {
                CFG.exceptionStack(var2_10);
                CFG.setRender_3(true);
            }
            catch (StackOverflowError var2_11) {
                CFG.exceptionStack(var2_11);
                CFG.setRender_3(true);
            }
            catch (ArithmeticException var2_12) {
                CFG.exceptionStack(var2_12);
                CFG.setRender_3(true);
            }
            catch (IllegalArgumentException var2_13) {
                CFG.exceptionStack(var2_13);
                CFG.setRender_3(true);
            }
        }
        if (CFG.isDesktop()) {
            // empty if block
        }
        this.requestRendering.update();
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void resize(int n, int n2) {
        if (CFG.isAndroid()) {
            if (CFG.LANDSCAPE) {
                viewport.update(n, n2, false);
            } else {
                viewport.update(-n2, -n, false);
            }
        } else {
            viewport.update(n, n2, false);
        }
        CFG.setRender_3(true);
    }

    @Override
    public void resume() {
        CFG.updateRender(true);
        this.updateRequestRendering(true);
        Gdx.graphics.requestRendering();
        CFG.setRender_3(true);
        super.resume();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean scrolled(int var1_1) {
        block19: {
            try {
                if (!CFG.menuManager.getIsScrollableY_MenuHovered()) ** GOTO lbl29
                this.updateScroll();
                var2_2 = CFG.menuManager;
                if (var1_1 == 1) {
                    var1_1 = -this.iScroll;
                }
                ** GOTO lbl-1000
            }
            catch (IndexOutOfBoundsException var2_3) {
                CFG.exceptionStack(var2_3);
            }
            catch (NullPointerException var2_4) {
                CFG.exceptionStack(var2_4);
            }
            catch (StackOverflowError var2_5) {
                CFG.exceptionStack(var2_5);
            }
            catch (ArithmeticException var2_6) {
                CFG.exceptionStack(var2_6);
            }
lbl21:
            // 2 sources

            while (true) {
                var2_2.scrollHoveredMenu_Y(var1_1);
lbl23:
                // 10 sources

                while (true) {
                    CFG.soundsManager.playSound(SoundsManager.SOUND_CLICK, SoundsManager.PERC_VOLUME_KEYBOARD);
                    return true;
                    break;
                }
                break;
            }
lbl-1000:
            // 1 sources

            {
                var1_1 = this.iScroll;
                ** continue;
lbl29:
                // 1 sources

                if (!CFG.menuManager.getIsScrollableX_MenuHovered()) ** GOTO lbl39
                this.updateScroll();
                var2_2 = CFG.menuManager;
                if (var1_1 != 1) ** GOTO lbl-1000
                var1_1 = -this.iScroll;
lbl34:
                // 2 sources

                while (true) {
                    var2_2.scrollHoveredMenu_X(var1_1);
                    break;
                }
            }
lbl-1000:
            // 1 sources

            {
                var1_1 = this.iScroll;
                ** continue;
lbl39:
                // 1 sources

                if (!CFG.menuManager.getIsScrollable_Hovered_MenuElement()) ** GOTO lbl49
                this.updateScroll();
                var2_2 = CFG.menuManager;
                if (var1_1 != 1) ** GOTO lbl-1000
                var1_1 = -this.iScroll;
lbl44:
                // 2 sources

                while (true) {
                    var2_2.scrollHoveredMenuElement(var1_1);
                    ** GOTO lbl23
                    break;
                }
            }
lbl-1000:
            // 1 sources

            {
                var1_1 = this.iScroll;
                ** continue;
lbl49:
                // 1 sources

                if (var1_1 != 1) break block19;
                CFG.map.getMapScale().setNewCurrentScaleByButton2(-this.getScrolled_ScaleUpdate());
                ** GOTO lbl23
            }
        }
        if (var1_1 != -1) ** GOTO lbl23
        {
            CFG.map.getMapScale().setNewCurrentScaleByButton2(this.getScrolled_ScaleUpdate());
            ** continue;
        }
        catch (IndexOutOfBoundsException var2_7) {
            CFG.exceptionStack(var2_7);
            return true;
        }
        catch (NullPointerException var2_8) {
            CFG.exceptionStack(var2_8);
            return true;
        }
        catch (StackOverflowError var2_9) {
            CFG.exceptionStack(var2_9);
            return true;
        }
        catch (ArithmeticException var2_10) {
            CFG.exceptionStack(var2_10);
            return true;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean touchDown(int n, int n2, int n3, int n4) {
        try {
            Touch.setMousePosXY(n, n2);
            CFG.setRender_3(true);
            this.touch.actionDown(n, n2, n3);
            CFG.editorManager.touchDown(n, n2, n3, n4);
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return true;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return true;
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
            return true;
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean touchDragged(int n, int n2, int n3) {
        try {
            Touch.setMousePosXY(n, n2);
            if (Gdx.input.isTouched(1) && n3 == 0) {
                this.touch.actionMove(Gdx.input.getX(0), Gdx.input.getY(0), Gdx.input.getX(1), Gdx.input.getY(1));
            } else {
                this.touch.actionMove(n, n2, n3);
            }
            CFG.editorManager.touchDragged(n, n2, n3);
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return true;
        }
        catch (NullPointerException nullPointerException) {
            CFG.exceptionStack(nullPointerException);
            return true;
        }
        catch (StackOverflowError stackOverflowError) {
            CFG.exceptionStack(stackOverflowError);
            return true;
        }
        catch (ArithmeticException arithmeticException) {
            CFG.exceptionStack(arithmeticException);
            return true;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public boolean touchUp(int var1_1, int var2_2, int var3_3, int var4_4) {
        try {
            block21: {
                Touch.setMousePosXY(var1_1, var2_2);
                CFG.setRender_3(true);
                if (!CFG.isDesktop()) break block21;
                if (CFG.menuManager.getInGameView() && CFG.map.getMapScale().getCurrentScale() >= 1.0f) {
                    if (var4_4 == 1 && !CFG.SPECTATOR_MODE && CFG.gameAction.getActiveTurnState() == Game_Action.TurnStates.INPUT_ORDERS && CFG.game.getCiv(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()).getMovePoints() >= CFG.ideologiesManager.getIdeology((int)CFG.game.getCiv((int)CFG.game.getPlayer((int)CFG.PLAYER_TURNID).getCivID()).getIdeologyID()).COST_OF_MOVE_OWN_PROVINCE && CFG.game.getActiveProvinceID() >= 0 && CFG.gameAction.controlsArmyInProvince(CFG.game.getActiveProvinceID(), CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID()) && !CFG.menuManager.getVisible_InGame_FlagAction()) {
                        CFG.game.setProvinceID_PPM(var1_1, var2_2);
                    } else {
                        this.touch.actionUp(var1_1, var2_2, var3_3);
                    }
                } else {
                    this.touch.actionUp(var1_1, var2_2, var3_3);
                }
                ** GOTO lbl30
            }
            try {
                this.touch.actionUp(var1_1, var2_2, var3_3);
                ** GOTO lbl30
            }
            catch (NullPointerException var5_5) {
                this.touch.actionUp(var1_1, var2_2, var3_3);
                if (CFG.LOGS) {
                    CFG.exceptionStack(var5_5);
                }
                ** GOTO lbl30
                catch (IndexOutOfBoundsException var5_7) {
                    block22: {
                        this.touch.actionUp(var1_1, var2_2, var3_3);
                        if (!CFG.LOGS) break block22;
                        CFG.exceptionStack(var5_7);
                    }
                    try {
                        CFG.editorManager.touchUp(var1_1, var2_2, var3_3, var4_4);
                        return true;
                    }
                    catch (IndexOutOfBoundsException var5_6) {
                        CFG.exceptionStack(var5_6);
                        return true;
                    }
                    catch (NullPointerException var5_8) {
                        CFG.exceptionStack(var5_8);
                        return true;
                    }
                }
            }
        }
        catch (StackOverflowError var5_9) {
            CFG.exceptionStack(var5_9);
            return true;
        }
        catch (ArithmeticException var5_10) {
            CFG.exceptionStack(var5_10);
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void typeNumber(int n) {
        if (System.currentTimeMillis() - 625L > TYPE_NUMER_TIME) {
            TYPE_NUMBER = n;
        } else {
            TYPE_NUMBER *= 10;
            TYPE_NUMBER += n;
        }
        TYPE_NUMER_TIME = System.currentTimeMillis();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void update() {
        block22: {
            block21: {
                this.countFPS();
                try {
                    CFG.game.update();
                }
                catch (NullPointerException nullPointerException) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(nullPointerException);
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(indexOutOfBoundsException);
                    }
                }
                catch (StackOverflowError stackOverflowError) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(stackOverflowError);
                    }
                }
                catch (ArithmeticException arithmeticException) {
                    if (!CFG.LOGS) break block21;
                    CFG.exceptionStack(arithmeticException);
                }
            }
            try {
                CFG.map.update();
            }
            catch (NullPointerException nullPointerException) {
                if (CFG.LOGS) {
                    CFG.exceptionStack(nullPointerException);
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                if (CFG.LOGS) {
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
            catch (StackOverflowError stackOverflowError) {
                if (CFG.LOGS) {
                    CFG.exceptionStack(stackOverflowError);
                }
            }
            catch (ArithmeticException arithmeticException) {
                if (!CFG.LOGS) break block22;
                CFG.exceptionStack(arithmeticException);
            }
        }
        try {
            CFG.menuManager.update();
            return;
        }
        catch (NullPointerException nullPointerException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(nullPointerException);
            return;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        catch (StackOverflowError stackOverflowError) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(stackOverflowError);
            return;
        }
        catch (ArithmeticException arithmeticException) {
            if (!CFG.LOGS) return;
            CFG.exceptionStack(arithmeticException);
            return;
        }
    }

    static interface RequestRendering {
        public void update();
    }
}

