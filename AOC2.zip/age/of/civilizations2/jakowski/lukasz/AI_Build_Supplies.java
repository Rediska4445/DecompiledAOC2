/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ConstructionType;
import java.util.ArrayList;
import java.util.List;

class AI_Build_Supplies
extends AI_Build {
    private List<Integer> lBuildCost = new ArrayList<Integer>();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected AI_Build_Supplies(int n, long l) {
        super(n, l);
        int n2 = 0;
        int n3 = 0;
        try {
            while (n3 < BuildingsManager.getSupply_MaxLevel()) {
                ArrayList<Integer> arrayList = this.lBuildCost;
                arrayList.add(BuildingsManager.getSupply_BuildCost(++n3, CFG.game.getCiv(n).getProvinceID(0)));
                List list = this.lProvincesToBuild;
                arrayList = new ArrayList<Integer>();
                list.add(arrayList);
            }
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            CFG.exceptionStack(indexOutOfBoundsException);
            return;
        }
        if (l < (long)this.lBuildCost.get(0).intValue()) return;
        for (n3 = n2; n3 < CFG.game.getCiv(n).getNumOfProvinces(); ++n3) {
            if (CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).isOccupied() || !(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getProvinceStability() > CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MIN_STABILITY) || !(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getRevolutionaryRisk() <= CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_MAX_REV_RISK) || !BuildingsManager.canBuildSupply(CFG.game.getCiv(n).getProvinceID(n3)) || (n2 = CFG.game.getCiv(n).isInConstruction(CFG.game.getCiv(n).getProvinceID(n3), ConstructionType.SUPPLY)) != 0) continue;
            try {
                if (l < (long)this.lBuildCost.get(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getLevelOfSupply()).intValue()) continue;
                ((List)this.lProvincesToBuild.get(CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getLevelOfSupply())).add(CFG.game.getCiv(n).getProvinceID(n3));
                ++this.iProvincesToBuild_NumOfElements;
                this.iMaxDangerLevel = Math.max(this.iMaxDangerLevel, CFG.game.getProvince(CFG.game.getCiv(n).getProvinceID(n3)).getDangerLevel());
                continue;
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        }
    }

    @Override
    protected boolean build(int n, int n2, boolean bl) {
        n2 = -1;
        float f = 0.0f;
        for (int i = this.lProvincesToBuild.size() - 1; i >= 0; --i) {
            for (int j = ((List)this.lProvincesToBuild.get(i)).size() - 1; j >= 0; --j) {
                float f2;
                if (n2 < 0) {
                    n2 = (Integer)((List)this.lProvincesToBuild.get(i)).get(j);
                    f2 = this.getProvinceBuildScore(n, n2);
                } else {
                    f2 = f;
                    if (this.getProvinceBuildScore(n, (Integer)((List)this.lProvincesToBuild.get(i)).get(j)) > f) {
                        n2 = (Integer)((List)this.lProvincesToBuild.get(i)).get(j);
                        f2 = this.getProvinceBuildScore(n, n2);
                    }
                }
                f = f2;
            }
        }
        boolean bl2 = bl;
        if (n2 >= 0) {
            bl2 = bl;
            if (BuildingsManager.constructSupply(n2, n)) {
                bl2 = true;
            }
        }
        return bl2;
    }

    @Override
    protected int getNumOfAlreadyBuilt(int n) {
        return CFG.game.getCiv((int)n).iNumOf_Libraries;
    }

    protected float getProvinceBuildScore(int n, int n2) {
        return (float)CFG.game.getProvince(n2).getPopulationData().getPopulation() * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE + CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_STABILITY_SCORE * CFG.game.getProvince(n2).getProvinceStability()) * (1.0f - CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_DANGER_SCORE * (float)CFG.game.getProvince(n2).getDangerLevel() / (float)this.iMaxDangerLevel) * (1.0f - CFG.game.getProvince(n2).getRevolutionaryRisk());
    }
}

