/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_CalendarDay
extends Button {
    private int iCurrent = 0;

    protected Button_CalendarDay(int n, int n2, int n3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n);
        super.init(stringBuilder.toString(), -1, n2, n3, CFG.BUTTON_HEIGHT * 2 / 3, CFG.BUTTON_HEIGHT / 2, true, true, false, false, null);
        this.iCurrent = n;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.475f));
        ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, 0.25f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), false, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5);
        spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 5, false, true);
        float f = this.getIsHovered() ? 0.95f : 0.745f;
        spriteBatch.setColor(new Color(0.20392157f, 0.23921569f, 0.26666668f, f));
        CFG.drawRect(spriteBatch, this.getPosX() + n, this.getPosY() + n2, this.getWidth(), this.getHeight());
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.7f));
        CFG.drawRect(spriteBatch, this.getPosX() - 1 + n, this.getPosY() - 1 + n2, this.getWidth() + 2, this.getHeight() + 2);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.65f));
        CFG.drawRect(spriteBatch, this.getPosX() + 1 + n, this.getPosY() + 1 + n2, this.getWidth() - 2, this.getHeight() - 2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        bl = bl || Game_Calendar.currentDay == this.iCurrent;
        return super.getColor(bl);
    }

    @Override
    protected int getCurrent() {
        return this.iCurrent;
    }
}

