/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import java.io.Serializable;

class CivInvest_Development
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected float iDevelopemntLeft;
    protected float iDevelopemntPerTurn;
    protected int iProvinceID;
    protected int iTurnsLeft;

    protected CivInvest_Development(int n, int n2, float f, float f2) {
        this.iProvinceID = n;
        this.iTurnsLeft = n2;
        this.iDevelopemntLeft = f;
        this.iDevelopemntPerTurn = f2;
    }
}

