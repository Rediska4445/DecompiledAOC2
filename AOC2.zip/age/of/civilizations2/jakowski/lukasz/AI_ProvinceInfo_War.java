/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import java.util.ArrayList;
import java.util.List;

class AI_ProvinceInfo_War {
    protected int iProvinceID;
    protected float iValue;
    protected List<Integer> lProvinces_Enemy = new ArrayList<Integer>();
    protected boolean ownFrontProvince = false;

    protected AI_ProvinceInfo_War(int n, int n2, boolean bl) {
        this.iProvinceID = n;
        this.iValue = n2;
        this.ownFrontProvince = bl;
    }

    protected final void buildEnemyProvinces(int n) {
        for (int i = 0; i < CFG.game.getProvince(this.iProvinceID).getNeighboringProvincesSize(); ++i) {
            if (!CFG.game.getCivsAtWar(n, CFG.game.getProvince(CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(i)).getCivID())) continue;
            this.lProvinces_Enemy.add(CFG.game.getProvince(this.iProvinceID).getNeighboringProvinces(i));
        }
    }

    protected final boolean enemyProvinceBordersWithOurTrueProvince(int n) {
        for (int i = 0; i < this.lProvinces_Enemy.size(); ++i) {
            for (int j = 0; j < CFG.game.getProvince(this.lProvinces_Enemy.get(i)).getNeighboringProvincesSize(); ++j) {
                if (CFG.game.getProvince(CFG.game.getProvince(this.lProvinces_Enemy.get(i)).getNeighboringProvinces(j)).getCivID() != n) continue;
                return true;
            }
        }
        return false;
    }

    protected final int getArmy(int n) {
        return CFG.game.getProvince(this.iProvinceID).getArmyCivID(n);
    }

    protected final int getRecruitableArmy(int n) {
        return CFG.gameAction.getRecruitableArmy(this.iProvinceID, n);
    }

    protected final int getRecruitableArmyAutoplan(int n) {
        return CFG.gameAction.getRecruitableArmyAutoplan(this.iProvinceID, n);
    }

    protected final boolean isOccupied() {
        return CFG.game.getProvince(this.iProvinceID).isOccupied();
    }
}

