/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Skills;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.SkillsManager;

class AI_Skills_Research
extends AI_Skills {
    protected AI_Skills_Research(int n, int n2) {
        super(n, n2);
    }

    @Override
    protected void addPoint_CivID(int n) {
        SkillsManager.add_Research(n);
        this.iPoints = CFG.game.getCiv((int)n).civGameData.skills.POINTS_RESEARCH;
    }

    @Override
    protected float getScore_Personality(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.TECH_RESEARCH;
    }
}

