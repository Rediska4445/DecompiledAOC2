/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_BotBar;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_BotBar_Disease
extends Button_BotBar {
    protected Button_BotBar_Disease(String string2, float f, int n, int n2, int n3, boolean bl, boolean bl2) {
        super(string2, f, n, n2, n3, bl, bl2);
        this.iTextPositionX = CFG.PADDING * 2 + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(CFG.COLOR_TEXT_MODIFIER_NEGATIVE);
        ImageManager.getImage(Images.bot_left_red).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.bot_left_red).getHeight() + n2, this.getWidth() + ImageManager.getImage(Images.bot_left_red).getWidth() / 2, this.getHeight(), true, true);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.disease).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() + (this.getHeight() - ImageManager.getImage(Images.disease).getHeight()) / 2 + n2);
        CFG.fontMain.getData().setScale(this.FONT_SCALE);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + CFG.PADDING + ImageManager.getImage(Images.disease).getWidth() + n, this.getPosY() + this.getHeight() / 2 - this.iTextHeight / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_MODIFIER_NEGATIVE_ACTTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_MODIFIER_NEGATIVE_HOVER : CFG.COLOR_TEXT_MODIFIER_NEGATIVE2) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }

    @Override
    protected int getWidth() {
        return this.iTextWidth + CFG.PADDING * 2 + 2 + ImageManager.getImage(Images.disease).getWidth() + CFG.PADDING * 2 + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    @Override
    public void setText(String string2) {
        block2: {
            this.sText = string2;
            this.setWidth(1);
            try {
                CFG.glyphLayout.setText(CFG.fontMain, string2);
                this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
                this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            }
            catch (NullPointerException nullPointerException) {
                if (!CFG.LOGS) break block2;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }
}

