/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Civilization_ServiceRibbon_GameData;
import java.io.Serializable;

class Civilization_GameData3
implements Serializable {
    private static final long serialVersionUID = 0L;
    private int iB;
    private int iG;
    private int iR;
    private String sCivTag;
    protected Civilization_ServiceRibbon_GameData sr_GameData = new Civilization_ServiceRibbon_GameData();

    protected Civilization_GameData3() {
        this.sCivTag = "";
    }

    protected Civilization_GameData3(String string2, int n, int n2, int n3) {
        this.sCivTag = string2;
        this.iR = n;
        this.iG = n2;
        this.iB = n3;
    }

    protected final int getB() {
        return this.iB;
    }

    protected final String getCivTag() {
        return this.sCivTag;
    }

    protected final int getG() {
        return this.iG;
    }

    protected final int getR() {
        return this.iR;
    }

    protected final void setB(int n) {
        this.iB = n;
    }

    protected final void setCivTag(String string2) {
        this.sCivTag = string2;
    }

    protected final void setG(int n) {
        this.iG = n;
    }

    protected final void setR(int n) {
        this.iR = n;
    }
}

