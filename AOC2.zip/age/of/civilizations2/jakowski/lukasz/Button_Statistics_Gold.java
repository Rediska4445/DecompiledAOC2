/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Statistics;
import age.of.civilizations2.jakowski.lukasz.CFG;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Statistics_Gold
extends Button_Statistics {
    private String sGold;

    protected Button_Statistics_Gold(String string2, String string3, int n, int n2, int n3, int n4, int n5) {
        super(string2, n, n2, n3, n4, n5);
        this.sGold = string3;
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.textPosition.getTextPosition() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, this.getColor(bl));
        CFG.drawTextWithShadow(spriteBatch, this.sGold, this.getPosX() + this.textPosition.getTextPosition() + (int)((float)this.getTextWidth() * 0.7f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.iTextHeight * 0.7f / 2.0f) + n2, CFG.COLOR_INGAME_GOLD);
        CFG.fontMain.getData().setScale(1.0f);
    }
}

