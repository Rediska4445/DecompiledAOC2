/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Event_Conditions;
import age.of.civilizations2.jakowski.lukasz.Menu;

class Event_Conditions_Ideology
extends Event_Conditions {
    protected int iCivID = -1;
    protected int iValue = 0;

    Event_Conditions_Ideology() {
    }

    @Override
    protected final void editViewID() {
        CFG.menuManager.setViewID(Menu.eCREATE_SCENARIO_EVENTS_COND_IDEOLOGY);
    }

    @Override
    protected int getCivID() {
        return this.iCivID;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected String getConditionText() {
        void var1_3;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = stringBuilder.append(CFG.langManager.get("Government")).append(": ").append(CFG.ideologiesManager.getIdeology(this.getValue()).getName()).append(", ").append(CFG.game.getCiv(this.getCivID()).getCivName()).toString();
            return var1_3;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            String string3 = CFG.langManager.get("Government");
            return var1_3;
        }
    }

    @Override
    protected int getValue() {
        return this.iValue;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean outCondition() {
        boolean bl = false;
        try {
            int n = CFG.game.getCiv(this.getCivID()).getIdeologyID();
            int n2 = this.getValue();
            if (n != n2) return bl;
            return true;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return bl;
        }
    }

    @Override
    protected void setCivID(int n) {
        this.iCivID = n;
    }

    @Override
    protected void setValue(int n) {
        this.iValue = n;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean updateCivIDAfterRemove(int n) {
        if (this.iCivID == n) {
            this.iCivID = -1;
            return true;
        }
        if (n >= this.iCivID) return false;
        --this.iCivID;
        return false;
    }
}

