/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Event_Outcome;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Event_Decision
implements Serializable {
    private static final long serialVersionUID = 0L;
    protected int iAIChance = 100;
    protected List<Event_Outcome> lOutcomes = new ArrayList<Event_Outcome>();
    protected String sTitle = "";

    protected final void executeDecision() {
        for (int i = 0; i < this.lOutcomes.size(); ++i) {
            this.lOutcomes.get(i).outcomeAction();
        }
    }
}

