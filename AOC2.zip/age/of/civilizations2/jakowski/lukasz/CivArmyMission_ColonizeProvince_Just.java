/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission;
import age.of.civilizations2.jakowski.lukasz.CivArmyMission_Type;
import age.of.civilizations2.jakowski.lukasz.DiplomacyManager;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;

class CivArmyMission_ColonizeProvince_Just
extends CivArmyMission {
    private int iCivID;
    private int iColonizeProvinceID;

    protected CivArmyMission_ColonizeProvince_Just(int n, int n2) {
        this.toProvinceID = n2;
        this.iColonizeProvinceID = n2;
        this.MISSION_ID = -1;
        this.iCivID = n;
        this.MISSION_TYPE = CivArmyMission_Type.COLONIZE_PROVINCE;
        this.TURN_ID = Game_Calendar.TURN_ID;
        this.iObsolate = (int)Math.max((float)CFG.game.getProvincesSize() * 0.01f, 30.0f);
        this.iArmy = 0;
        this.generateColonizeData();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean action(int n) {
        boolean bl = true;
        if (CFG.game.getProvince(this.iColonizeProvinceID).getCivID() != 0) {
            CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
            return bl;
        }
        if (DiplomacyManager.colonizeWastelandProvince(this.iColonizeProvinceID, this.iCivID)) {
            CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
            CFG.game.getCiv(this.iCivID).buildCivPersonality_Colonization();
            return bl;
        }
        this.lockTreasury();
        return false;
    }

    @Override
    protected boolean canMakeAction(int n, int n2) {
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final boolean generateColonizeData() {
        boolean bl = false;
        this.iProvinceID = -1;
        if (CFG.game.getCiv((int)this.iCivID).iBudget < 0) {
            this.iObsolate = 0;
            CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
            return bl;
        }
        int n = 0;
        while (true) {
            block7: {
                block6: {
                    if (n >= CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringProvincesSize()) break block6;
                    if (this.iCivID != CFG.game.getProvince(CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringProvinces(n)).getCivID()) break block7;
                    this.iProvinceID = CFG.game.getProvince(this.iColonizeProvinceID).getNeighboringProvinces(n);
                }
                this.lockTreasury();
                if (this.iProvinceID >= 0) return true;
                this.iObsolate = 0;
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = 1;
                return bl;
            }
            ++n;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    protected final void lockTreasury() {
        block4: {
            block3: {
                int n = (int)((float)DiplomacyManager.getColonizeCost(this.iColonizeProvinceID, this.iCivID) * 1.05f);
                CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury = Math.max(CFG.game.getCiv((int)this.iCivID).civGameData.iLockTreasury, n);
                if (CFG.game.getCiv((int)this.iCivID).iBudget <= 0) break block3;
                if (CFG.game.getCiv(this.iCivID).getMoney() <= 0L || CFG.game.getCiv(this.iCivID).getMoney() >= (long)n) break block4;
                this.iObsolate = Math.max(this.iObsolate, Math.max(2, (int)Math.ceil((float)CFG.game.getCiv(this.iCivID).getMoney() / (float)n)));
            }
            return;
        }
        this.iObsolate = Math.max(2, this.iObsolate);
    }
}

