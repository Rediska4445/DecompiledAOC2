/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Menu;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Options_NS
extends Button_Menu {
    protected Button_Options_NS(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    protected Button_Options_NS(String string2, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        super(string2, n, n2, n3, n4, n5, bl, bl2);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_Options_NS.this.getCheckboxState()) {
                        spriteBatch.setColor(CFG.COLOR_TEXT_CHECKBOX_TRUE);
                    } else {
                        spriteBatch.setColor(CFG.COLOR_TEXT_CHECKBOX_FALSE);
                    }
                    ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, Button_Options_NS.this.getPosX() + n, Button_Options_NS.this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2 + 1, Button_Options_NS.this.getWidth(), Button_Options_NS.this.getHeight() - 3);
                    spriteBatch.setColor(Color.WHITE);
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        float f;
        float f2;
        float f3;
        float f4;
        block5: {
            block4: {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.35f));
                ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + n2 - ImageManager.getImage(Images.pix255_255_255).getHeight(), this.getWidth(), this.getHeight());
                f4 = CFG.COLOR_INFO_BOX_GRADIENT.r;
                f3 = CFG.COLOR_INFO_BOX_GRADIENT.g;
                f2 = CFG.COLOR_INFO_BOX_GRADIENT.b;
                float f5 = 0.475f;
                f = bl ? 0.775f : (this.getIsHovered() ? 0.675f : 0.475f);
                spriteBatch.setColor(new Color(f4, f3, f2, f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight(), false, false);
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n + this.getWidth() - this.getWidth() / 2, this.getPosY() + n2 - ImageManager.getImage(Images.slider_gradient).getHeight(), this.getWidth() / 2, this.getHeight(), true, false);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.45f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), this.getHeight() / 5);
                spriteBatch.setColor(0.0f, 0.0f, 0.0f, 0.375f);
                ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 + this.getHeight() - this.getHeight() / 5 - ImageManager.getImage(Images.gradient).getHeight(), this.getWidth(), this.getHeight() / 5, false, true);
                f3 = CFG.COLOR_FLAG_FRAME.r;
                f2 = CFG.COLOR_FLAG_FRAME.g;
                f4 = CFG.COLOR_FLAG_FRAME.b;
                if (bl) break block4;
                f = f5;
                if (!this.getIsHovered()) break block5;
            }
            f = 0.625f;
        }
        spriteBatch.setColor(new Color(f3, f2, f4, f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth(), 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth(), 1);
        spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.275f));
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - this.getWidth() / 4 + n, this.getPosY() + n2 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth() / 2, 1);
        ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - this.getWidth() / 4 + n, this.getPosY() + n2 + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight(), this.getWidth() / 2, 1);
        if (this.getIsHovered() || bl) {
            spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.215f));
            ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2 - ImageManager.getImage(Images.line_32_vertical).getHeight(), 1, this.getHeight());
            ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + this.getWidth() - 1 + n, this.getPosY() + n2 - ImageManager.getImage(Images.line_32_vertical).getHeight(), 1, this.getHeight());
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        CFG.drawRect(spriteBatch, this.getPosX() + n - 1, this.getPosY() + n2 - 2, this.getWidth() + 2, this.getHeight() + 2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        if (this.getTextPos() < 0) {
            if (bl) {
                CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
            } else {
                CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.8f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
            }
        } else if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getTextPos() + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.8f / 2.0f) + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : CFG.COLOR_BUTTON_MENU_TEXT_NOT_CLICKABLE);
        return color2;
    }
}

