/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_BotBar;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Space;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import java.util.List;

class Button_BotBar_SuppRebels
extends Button_BotBar {
    protected int iCivsSize = 0;
    private int iProvinceID = 0;
    protected List<Integer> lCivs = new ArrayList<Integer>();
    protected List<Integer> lCivsTurnsLeft = new ArrayList<Integer>();
    protected List<List<Integer>> lSupportedByCivs = new ArrayList<List<Integer>>();

    protected Button_BotBar_SuppRebels(String string2, float f, int n, int n2, int n3, boolean bl, boolean bl2) {
        super(string2, f, n, n2, n3, bl, bl2);
        this.iTextPositionX = CFG.PADDING * 2 + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    private final float getImageScale() {
        return (float)CFG.TEXT_HEIGHT / (float)CFG.CIV_FLAG_HEIGHT;
    }

    @Override
    protected void buildElementHover() {
        ArrayList<MenuElement_Hover_v2_Element2> arrayList = new ArrayList<MenuElement_Hover_v2_Element2>();
        ArrayList<MenuElement_Hover_v2_Element_Type> arrayList2 = new ArrayList<MenuElement_Hover_v2_Element_Type>();
        Object object = new MenuElement_Hover_v2_Element_Type_Flag(CFG.game.getProvince(this.iProvinceID).getCivID());
        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
        object = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getProvince(this.iProvinceID).getName(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
        Object object2 = new StringBuilder();
        ((StringBuilder)object2).append(" - ");
        ((StringBuilder)object2).append(CFG.langManager.get("SupportRebels"));
        object = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object2).toString(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
        object = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_revolution, CFG.PADDING, 0);
        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
        object = new MenuElement_Hover_v2_Element2(arrayList2);
        arrayList.add((MenuElement_Hover_v2_Element2)object);
        arrayList2.clear();
        object = new MenuElement_Hover_v2_Element_Type_Space();
        arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
        object = new MenuElement_Hover_v2_Element2(arrayList2);
        arrayList.add((MenuElement_Hover_v2_Element2)object);
        arrayList2.clear();
        int n = 0;
        while (true) {
            if (n >= this.iCivsSize) break;
            object = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(n));
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = this.lCivs.get(n) > 0 ? CFG.game.getCiv(this.lCivs.get(n)).getCivName() : CFG.langManager.get("Undiscovered");
            object2 = new MenuElement_Hover_v2_Element_Type_Text((String)object, CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            int n2 = 0;
            while (true) {
                int n3;
                int n4;
                block12: {
                    block11: {
                        if (n2 >= this.lSupportedByCivs.get(n).size() || n2 >= 10) break;
                        n4 = !CFG.SPECTATOR_MODE && !CFG.game.isAlly(CFG.game.getPlayer(CFG.PLAYER_TURNID).getCivID(), this.lSupportedByCivs.get(n).get(n2)) ? -this.lSupportedByCivs.get(n).get(n2).intValue() : this.lSupportedByCivs.get(n).get(n2);
                        if (n2 != 0) break block11;
                        n3 = CFG.PADDING;
                        break block12;
                    }
                    n3 = 0;
                }
                object = new MenuElement_Hover_v2_Element_Type_Flag(n4, n3, 0);
                arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
                ++n2;
                continue;
                break;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append(" ");
            ((StringBuilder)object).append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + this.lCivsTurnsLeft.get(n)));
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new StringBuilder();
            ((StringBuilder)object).append(" [");
            ((StringBuilder)object).append(CFG.langManager.get("TurnsX", this.lCivsTurnsLeft.get(n)));
            ((StringBuilder)object).append("]");
            object2 = new MenuElement_Hover_v2_Element_Type_Text(((StringBuilder)object).toString(), CFG.COLOR_TEXT_RANK_HOVER);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object2);
            object = new MenuElement_Hover_v2_Element_Type_Image(Images.time, CFG.PADDING, 0);
            arrayList2.add((MenuElement_Hover_v2_Element_Type)object);
            object = new MenuElement_Hover_v2_Element2(arrayList2);
            arrayList.add((MenuElement_Hover_v2_Element2)object);
            arrayList2.clear();
            ++n;
            continue;
            break;
        }
        try {
            this.menuElementHover = object = new MenuElement_Hover_v2(arrayList);
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        for (int i = 0; i < this.iCivsSize; ++i) {
            if (this.lCivs.get(i) < 0) {
                ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.getTextPos() + (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
                continue;
            }
            CFG.game.getCiv(this.lCivs.get(i)).getFlag().draw(spriteBatch, this.getPosX() + this.getTextPos() + (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - CFG.game.getCiv(this.lCivs.get(i)).getFlag().getHeight() + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getTextPos() + (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) + CFG.PADDING + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * i + n, this.getPosY() - CFG.CIV_FLAG_HEIGHT + this.getHeight() / 2 - (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale() / 2.0f) + n2, (int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()), (int)((float)CFG.CIV_FLAG_HEIGHT * this.getImageScale()));
        }
        ImageManager.getImage(Images.diplo_revolution).draw(spriteBatch, this.getPosX() + this.getTextPos() + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight()))) / 2 - ImageManager.getImage(Images.diplo_revolution).getHeight() + n2, (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())), (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())));
        ImageManager.getImage(Images.ar_up).draw(spriteBatch, this.getPosX() + this.getTextPos() + (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) - ImageManager.getImage(Images.ar_up).getWidth() + CFG.PADDING / 2 + n, this.getPosY() + (this.getHeight() - (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight()))) / 2 + (int)((float)ImageManager.getImage(Images.diplo_revolution).getHeight() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) - ImageManager.getImage(Images.ar_up).getHeight() + CFG.PADDING / 4 + n2);
    }

    @Override
    protected int getCurrent() {
        return this.iProvinceID;
    }

    @Override
    protected int getWidth() {
        return (int)((float)ImageManager.getImage(Images.diplo_revolution).getWidth() * ((float)ImageManager.getImage(Images.victoryPoints).getHeight() / (float)ImageManager.getImage(Images.diplo_revolution).getHeight())) + CFG.PADDING * 2 + 2 + ((int)((float)CFG.CIV_FLAG_WIDTH * this.getImageScale()) + CFG.PADDING) * this.iCivsSize + CFG.PADDING + ImageManager.getImage(Images.bot_left).getWidth() / 2;
    }

    @Override
    protected void setCurrent(int n) {
        this.iProvinceID = n;
        this.lCivs.clear();
        this.lCivsTurnsLeft.clear();
        this.lSupportedByCivs.clear();
        this.iCivsSize = 0;
        for (int i = 0; i < CFG.game.getProvince((int)n).saveProvinceData.iSupportRebelsSize; ++i) {
            List<Object> list;
            int n2;
            int n3;
            block2: {
                n3 = CFG.game.getPlayer(CFG.PLAYER_TURNID).getMetCivilization(CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iRebelsCivID) ? CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iRebelsCivID : CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iRebelsCivID * -1;
                for (n2 = this.lCivs.size() - 1; n2 >= 0; --n2) {
                    if (this.lCivs.get(n2) != n3) continue;
                    list = this.lCivsTurnsLeft;
                    list.set(n2, Math.max(list.get(n2), CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iTurnsLeft));
                    this.lSupportedByCivs.get(n2).add(CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iByCivID);
                    n2 = 1;
                    break block2;
                }
                n2 = 0;
            }
            if (n2 != 0) continue;
            this.lCivs.add(n3);
            this.lCivsTurnsLeft.add(CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iTurnsLeft);
            this.lSupportedByCivs.add(new ArrayList());
            list = this.lSupportedByCivs;
            ((List)list.get(list.size() - 1)).add(CFG.game.getProvince((int)n).saveProvinceData.lSupportRebels.get((int)i).iByCivID);
            if (this.lCivs.size() >= 4) break;
        }
        this.iCivsSize = this.lCivs.size();
    }

    @Override
    public void setText(String string2) {
        block2: {
            this.sText = string2;
            this.setWidth(this.iMinWidth);
            try {
                CFG.glyphLayout.setText(CFG.fontMain, string2);
                this.iTextWidth = (int)(CFG.glyphLayout.width * this.FONT_SCALE);
                this.iTextHeight = (int)(CFG.glyphLayout.height * this.FONT_SCALE);
            }
            catch (NullPointerException nullPointerException) {
                if (!CFG.LOGS) break block2;
                CFG.exceptionStack(nullPointerException);
            }
        }
    }
}

