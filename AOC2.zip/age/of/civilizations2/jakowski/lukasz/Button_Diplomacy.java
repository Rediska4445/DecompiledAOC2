/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Game_Calendar;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.MenuElement;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element2;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Flag;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Image;
import age.of.civilizations2.jakowski.lukasz.MenuElement_Hover_v2_Element_Type_Text;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;
import java.util.List;

class Button_Diplomacy
extends Button {
    protected static int iDiploWidth;
    private float fScrollNewMenuPosY;
    private int iButtonsPosX;
    private int iDiploImageID;
    protected int iHoveredID;
    private int iScrollPosX;
    private int iScrollPosX2;
    protected List<Integer> lCivs;
    private boolean moveable;
    private boolean row;
    private boolean scrollModeY;

    protected Button_Diplomacy(int n, List<Integer> list, int n2, int n3, int n4) {
        int n5 = 0;
        this.row = false;
        this.moveable = false;
        this.scrollModeY = false;
        this.iScrollPosX = -1;
        this.iScrollPosX2 = -1;
        this.fScrollNewMenuPosY = 0.0f;
        this.iHoveredID = -1;
        this.init("", 0, n2, n3, n4, CFG.CIV_FLAG_HEIGHT + CFG.PADDING * 2, true, true, false, false);
        this.iDiploImageID = n;
        this.lCivs = new ArrayList<Integer>();
        for (n = n5; n < list.size(); ++n) {
            this.lCivs.add(list.get(n));
        }
        this.updateMoveable();
        this.typeOfElement = MenuElement.TypeOfElement.DIPLOMACY_INFO;
    }

    private final int getButtonsWidth() {
        return (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * this.lCivs.size() + CFG.PADDING;
    }

    protected static final int getMaxDiploWidth_ExtraPadding() {
        return CFG.PADDING * 4;
    }

    private final void setHoveredID(int n) {
        if (this.iHoveredID != n) {
            this.iHoveredID = n;
            this.buildElementHover();
        }
    }

    protected static final void setMaxDiploWidth(int n) {
        if (Button_Diplomacy.getMaxDiploWidth_ExtraPadding() + n > iDiploWidth) {
            iDiploWidth = n + Button_Diplomacy.getMaxDiploWidth_ExtraPadding();
        }
    }

    private final void updateMoveable() {
        if (this.getButtonsWidth() - CFG.PADDING > this.getWidth() - iDiploWidth) {
            this.moveable = true;
        } else {
            this.moveable = false;
            this.iButtonsPosX = 0;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void buildElementHover() {
        block140: {
            block139: {
                block138: {
                    block137: {
                        block136: {
                            block135: {
                                block134: {
                                    block133: {
                                        block132: {
                                            block131: {
                                                block130: {
                                                    block129: {
                                                        block128: {
                                                            block127: {
                                                                block126: {
                                                                    block125: {
                                                                        block124: {
                                                                            block123: {
                                                                                var1_1 = "";
                                                                                var2_4 = new ArrayList();
                                                                                var3_5 = new ArrayList();
                                                                                if (this.iDiploImageID != Images.diplo_alliance) break block123;
                                                                                var5_10 = new StringBuilder();
                                                                                var5_10.append(CFG.langManager.get("AlliedWith"));
                                                                                var5_10.append(": ");
                                                                                var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var5_10.toString());
                                                                                var3_5.add(var4_6);
                                                                                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                                                                                    var3_5.add(var4_6);
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(-1, CFG.PADDING, 0);
                                                                                    var3_5.add(var4_6);
                                                                                } else {
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                                                                                    var3_5.add(var4_6);
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID), CFG.PADDING, 0);
                                                                                    var3_5.add(var4_6);
                                                                                }
                                                                                var4_6 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                                var2_4.add(var4_6);
                                                                                var3_5.clear();
lbl32:
                                                                                // 2 sources

                                                                                while (true) {
                                                                                    var4_6 = var1_1;
                                                                                    ** GOTO lbl931
                                                                                    break;
                                                                                }
                                                                            }
                                                                            if (this.iDiploImageID == Images.diplo_war) {
                                                                                var5_11 = new StringBuilder();
                                                                                var5_11.append(CFG.langManager.get("AtWarWith"));
                                                                                var5_11.append(": ");
                                                                                var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var5_11.toString());
                                                                                var3_5.add(var4_6);
                                                                                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                                                                                    var3_5.add(var4_6);
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(-1, CFG.PADDING, 0);
                                                                                    var3_5.add(var4_6);
                                                                                } else {
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                                                                                    var3_5.add(var4_6);
                                                                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID), CFG.PADDING, 0);
                                                                                    var3_5.add(var4_6);
                                                                                }
                                                                                var4_6 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                                var2_4.add(var4_6);
                                                                                var3_5.clear();
                                                                                ** continue;
                                                                            }
                                                                            if (this.iDiploImageID != Images.diplo_defensive_pact) ** GOTO lbl122
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("DefensivePact"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                                            var3_5.add(var4_6);
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                                            var3_5.add(var4_6);
                                                                            var4_6 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                            var2_4.add(var4_6);
                                                                            var3_5.clear();
                                                                            if (CFG.FOG_OF_WAR < 2 || this.lCivs.get(this.iHoveredID) >= 0) break block124;
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                                            var3_5.add(var4_6);
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                                            var3_5.add(var4_6);
                                                                            ** GOTO lbl115
                                                                        }
                                                                        var4_6 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                                        var3_5.add(var4_6);
                                                                        var4_6 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                                        var3_5.add(var4_6);
                                                                        var4_6 = new StringBuilder();
                                                                        var4_6.append(" - ");
                                                                        var7_18 = Game_Calendar.TURN_ID;
                                                                        var5_12 = CFG.game;
                                                                        var8_19 = CFG.getActiveCivInfo();
                                                                        var9_20 = this.lCivs;
                                                                        var4_6.append(Game_Calendar.getDate_ByTurnID(var7_18 + var5_12.getDefensivePact(var8_19, var9_20.get(this.iHoveredID))));
                                                                        var6_17 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                                                        var3_5.add(var6_17);
                                                                        var1_1 = new StringBuilder();
                                                                        var1_1.append(" [");
                                                                        var1_1.append(CFG.langManager.get("TurnsX", CFG.game.getDefensivePact(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                                                        var1_1.append("]");
                                                                        var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                                                        var3_5.add(var4_6);
lbl115:
                                                                        // 2 sources

                                                                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                        var2_4.add(var1_1);
                                                                        var3_5.clear();
lbl119:
                                                                        // 13 sources

                                                                        while (true) {
                                                                            var4_6 = "";
                                                                            ** GOTO lbl931
                                                                            break;
                                                                        }
lbl122:
                                                                        // 1 sources

                                                                        var4_6 = "";
                                                                        if (this.iDiploImageID != Images.top_gold2) break block125;
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("WarReparations"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                                        var3_5.add(var1_1);
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                                        var3_5.add(var1_1);
                                                                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                        var2_4.add(var1_1);
                                                                        var3_5.clear();
                                                                        if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                                            var3_5.add(var1_1);
                                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                                            var3_5.add(var1_1);
                                                                        } else {
                                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                                            var3_5.add(var1_1);
                                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                                            var3_5.add(var1_1);
                                                                            var1_1 = new StringBuilder();
                                                                            var1_1.append(" - ");
                                                                            var1_1.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCiv(CFG.getActiveCivInfo()).getWarReparationsPays_TurnsLeft(this.lCivs.get(this.iHoveredID))));
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                                                            var3_5.add(var4_6);
                                                                            var1_1 = new StringBuilder();
                                                                            var1_1.append(" [");
                                                                            var1_1.append(CFG.langManager.get("TurnsX", CFG.game.getCiv(CFG.getActiveCivInfo()).getWarReparationsPays_TurnsLeft(this.lCivs.get(this.iHoveredID))));
                                                                            var1_1.append("]");
                                                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                                                            var3_5.add(var4_6);
                                                                        }
                                                                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                        var2_4.add(var1_1);
                                                                        var3_5.clear();
                                                                        ** GOTO lbl119
                                                                    }
                                                                    if (this.iDiploImageID != Images.diplo_relations_inc) break block126;
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ImprovingRelationsWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                                    var3_5.add(var1_1);
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                                    var3_5.add(var1_1);
                                                                    var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                    var2_4.add(var1_1);
                                                                    var3_5.clear();
                                                                    if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                                        var3_5.add(var1_1);
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                                        var3_5.add(var1_1);
                                                                    } else {
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                                        var3_5.add(var1_1);
                                                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                                        var3_5.add(var1_1);
                                                                    }
                                                                    var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                    var2_4.add(var1_1);
                                                                    var3_5.clear();
                                                                    ** GOTO lbl119
                                                                }
                                                                if (this.iDiploImageID != Images.diplo_relations) break block127;
                                                                var4_6 = new StringBuilder();
                                                                var4_6.append(CFG.langManager.get("ImprovingRelationsFrom"));
                                                                var4_6.append(":");
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                                var3_5.add(var1_1);
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                                var3_5.add(var1_1);
                                                                var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                var2_4.add(var1_1);
                                                                var3_5.clear();
                                                                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                                    var3_5.add(var1_1);
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                                    var3_5.add(var1_1);
                                                                } else {
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                                    var3_5.add(var1_1);
                                                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                                    var3_5.add(var1_1);
                                                                }
                                                                var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                                var2_4.add(var1_1);
                                                                var3_5.clear();
                                                                ** GOTO lbl119
                                                            }
                                                            if (this.iDiploImageID != Images.diplo_relations_dec) break block128;
                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("DiplomaticRelationsAreSuspended"), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                                                            var3_5.add(var1_1);
                                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                            var3_5.add(var1_1);
                                                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                            var2_4.add(var1_1);
                                                            var3_5.clear();
                                                            if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                                var3_5.add(var1_1);
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                                var3_5.add(var1_1);
                                                            } else {
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                                var3_5.add(var1_1);
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                                var3_5.add(var1_1);
                                                                var4_6 = new StringBuilder();
                                                                var4_6.append(" - ");
                                                                var4_6.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCiv(CFG.getActiveCivInfo()).getCivilization_Diplomacy_GameData().isEmbassyClosed_Turns(this.lCivs.get(this.iHoveredID))));
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                                                var3_5.add(var1_1);
                                                                var4_6 = new StringBuilder();
                                                                var4_6.append(" [");
                                                                var4_6.append(CFG.langManager.get("TurnsX", CFG.game.getCiv(CFG.getActiveCivInfo()).getCivilization_Diplomacy_GameData().isEmbassyClosed_Turns(this.lCivs.get(this.iHoveredID))));
                                                                var4_6.append("]");
                                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                                                var3_5.add(var1_1);
                                                            }
                                                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                            var2_4.add(var1_1);
                                                            var3_5.clear();
                                                            ** GOTO lbl119
                                                        }
                                                        if (this.iDiploImageID != Images.diplo_loan) ** GOTO lbl325
                                                        var1_1 = new StringBuilder();
                                                        var1_1.append(CFG.langManager.get("Loans"));
                                                        var1_1.append(": ");
                                                        var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                        var3_5.add(var5_12);
                                                        var6_17 = new StringBuilder();
                                                        var1_1 = var4_6;
                                                        var6_17.append((String)var4_6);
                                                        var1_1 = var4_6;
                                                        var6_17.append(this.lCivs.size());
                                                        var1_1 = var4_6;
                                                        var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var6_17.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_12);
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_12 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_12);
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_12 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                        var1_1 = var4_6;
                                                        var2_4.add(var5_12);
                                                        var1_1 = var4_6;
                                                        var3_5.clear();
                                                        ** GOTO lbl931
lbl325:
                                                        // 1 sources

                                                        var1_1 = var4_6;
                                                        if (this.iDiploImageID != Images.diplo_gift) break block129;
                                                        var1_1 = var4_6;
                                                        if (CFG.FOG_OF_WAR < 2) ** GOTO lbl-1000
                                                        var1_1 = var4_6;
                                                        if (this.lCivs.get(this.iHoveredID) < 0) {
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_13 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_13);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_13 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AGiftFromCivA", CFG.langManager.get("Undiscovered")), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_13);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_13 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_13);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_13 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                            var1_1 = var4_6;
                                                            var2_4.add(var5_13);
                                                            var1_1 = var4_6;
                                                            var3_5.clear();
                                                        } else lbl-1000:
                                                        // 2 sources

                                                        {
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_14 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_14);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_14 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AGiftFromCivA", CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName()), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_14);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_14 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                            var1_1 = var4_6;
                                                            var3_5.add(var5_14);
                                                            var1_1 = var4_6;
                                                            var1_1 = var4_6;
                                                            var5_14 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                            var1_1 = var4_6;
                                                            var2_4.add(var5_14);
                                                            var1_1 = var4_6;
                                                            var3_5.clear();
                                                        }
                                                        ** GOTO lbl931
                                                    }
                                                    var1_1 = var4_6;
                                                    if (this.iDiploImageID != Images.hre_icon) break block130;
                                                    var1_1 = var4_6;
                                                    var1_1 = var4_6;
                                                    var5_15 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("IsPartOfHRE"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                    var1_1 = var4_6;
                                                    var3_5.add(var5_15);
                                                    var1_1 = var4_6;
                                                    var1_1 = var4_6;
                                                    var5_15 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                    var1_1 = var4_6;
                                                    var3_5.add(var5_15);
                                                    var1_1 = var4_6;
                                                    var1_1 = var4_6;
                                                    var5_15 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                    var1_1 = var4_6;
                                                    var2_4.add(var5_15);
                                                    var1_1 = var4_6;
                                                    var3_5.clear();
                                                    var1_1 = var4_6;
                                                    if (CFG.FOG_OF_WAR < 2) ** GOTO lbl-1000
                                                    var1_1 = var4_6;
                                                    if (this.lCivs.get(this.iHoveredID) < 0) {
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_15 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_15);
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_15 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_15);
                                                    } else lbl-1000:
                                                    // 2 sources

                                                    {
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_15 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_15);
                                                        var1_1 = var4_6;
                                                        var1_1 = var4_6;
                                                        var5_15 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                        var1_1 = var4_6;
                                                        var3_5.add(var5_15);
                                                    }
                                                    var1_1 = var4_6;
                                                    var1_1 = var4_6;
                                                    var5_15 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                    var1_1 = var4_6;
                                                    var2_4.add(var5_15);
                                                    var1_1 = var4_6;
                                                    var3_5.clear();
                                                    ** GOTO lbl931
                                                }
                                                var1_1 = var4_6;
                                                if (this.iDiploImageID != Images.diplo_truce) ** GOTO lbl535
                                                var1_1 = var4_6;
                                                var1_1 = var4_6;
                                                var5_12 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("HasATruceWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                                var1_1 = var4_6;
                                                var3_5.add(var5_12);
                                                var1_1 = var4_6;
                                                var1_1 = var4_6;
                                                var5_12 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                                var1_1 = var4_6;
                                                var3_5.add(var5_12);
                                                var1_1 = var4_6;
                                                var1_1 = var4_6;
                                                var5_12 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                                var1_1 = var4_6;
                                                var2_4.add(var5_12);
                                                var1_1 = var4_6;
                                                var3_5.clear();
                                                var1_1 = var4_6;
                                                if (CFG.FOG_OF_WAR < 2) break block131;
                                                var1_1 = var4_6;
                                                if (this.lCivs.get(this.iHoveredID) >= 0) break block131;
                                                var1_1 = var4_6;
                                                var1_1 = var4_6;
                                                var5_12 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                var1_1 = var4_6;
                                                var3_5.add(var5_12);
                                                var1_1 = var4_6;
                                                var1_1 = var4_6;
                                                var5_12 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                var1_1 = var4_6;
                                                var3_5.add(var5_12);
                                                ** GOTO lbl530
                                            }
                                            var1_1 = var4_6;
                                            var1_1 = var4_6;
                                            var5_12 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                            var1_1 = var4_6;
                                            var3_5.add(var5_12);
                                            var1_1 = var4_6;
                                            var1_1 = var4_6;
                                            var5_12 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                            var1_1 = var4_6;
                                            var3_5.add(var5_12);
                                            var1_1 = var4_6;
                                            var1_1 = var4_6;
                                            var1_1 = var4_6;
                                            var9_20 = new StringBuilder();
                                            var1_1 = var4_6;
                                            var9_20.append(" - ");
                                            var1_1 = var4_6;
                                            var7_18 = Game_Calendar.TURN_ID;
                                            var1_1 = var4_6;
                                            var6_17 = CFG.game;
                                            var1_1 = var4_6;
                                            var8_19 = CFG.getActiveCivInfo();
                                            var1_1 = var4_6;
                                            var4_6 = this.lCivs;
                                            var9_20.append(Game_Calendar.getDate_ByTurnID(var7_18 + var6_17.getCivTruce(var8_19, var4_6.get(this.iHoveredID))));
                                            var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var9_20.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                            var3_5.add(var5_12);
                                            var4_6 = new StringBuilder();
                                            var4_6.append(" [");
                                            var4_6.append(CFG.langManager.get("TurnsX", CFG.game.getCivTruce(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                            var4_6.append("]");
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                            var3_5.add(var1_1);
lbl530:
                                            // 2 sources

                                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                            var2_4.add(var1_1);
                                            var3_5.clear();
                                            ** GOTO lbl119
lbl535:
                                            // 1 sources

                                            if (this.iDiploImageID != Images.diplo_non_aggression) break block132;
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("NonAggressionPact"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                            var3_5.add(var1_1);
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                            var3_5.add(var1_1);
                                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                            var2_4.add(var1_1);
                                            var3_5.clear();
                                            if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                                var3_5.add(var1_1);
                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                                var3_5.add(var1_1);
                                            } else {
                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                                var3_5.add(var1_1);
                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                                var3_5.add(var1_1);
                                                var1_1 = new StringBuilder();
                                                var1_1.append(" - ");
                                                var1_1.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCivNonAggressionPact(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                                var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                                var3_5.add(var4_6);
                                                var4_6 = new StringBuilder();
                                                var4_6.append(" [");
                                                var4_6.append(CFG.langManager.get("TurnsX", CFG.game.getCivNonAggressionPact(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                                var4_6.append("]");
                                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                                var3_5.add(var1_1);
                                            }
                                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                            var2_4.add(var1_1);
                                            var3_5.clear();
                                            ** GOTO lbl119
                                        }
                                        if (this.iDiploImageID != Images.diplo_access_has) break block133;
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GivesMilitaryAccess"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                        var3_5.add(var1_1);
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                        var3_5.add(var1_1);
                                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                        var2_4.add(var1_1);
                                        var3_5.clear();
                                        if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                            var3_5.add(var1_1);
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                            var3_5.add(var1_1);
                                        } else {
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                            var3_5.add(var1_1);
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                            var3_5.add(var1_1);
                                            var4_6 = new StringBuilder();
                                            var4_6.append(" - ");
                                            var4_6.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getMilitaryAccess(this.lCivs.get(this.iHoveredID), CFG.getActiveCivInfo())));
                                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                            var3_5.add(var1_1);
                                            var1_1 = new StringBuilder();
                                            var1_1.append(" [");
                                            var1_1.append(CFG.langManager.get("TurnsX", CFG.game.getMilitaryAccess(this.lCivs.get(this.iHoveredID), CFG.getActiveCivInfo())));
                                            var1_1.append("]");
                                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                            var3_5.add(var4_6);
                                        }
                                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                        var2_4.add(var1_1);
                                        var3_5.clear();
                                        ** GOTO lbl119
                                    }
                                    if (this.iDiploImageID != Images.diplo_access_gives) break block134;
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("HaveMilitaryAccess"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                    var3_5.add(var1_1);
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                    var3_5.add(var1_1);
                                    var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                    var2_4.add(var1_1);
                                    var3_5.clear();
                                    if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                        var3_5.add(var1_1);
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                        var3_5.add(var1_1);
                                    } else {
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                        var3_5.add(var1_1);
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                        var3_5.add(var1_1);
                                        var4_6 = new StringBuilder();
                                        var4_6.append(" - ");
                                        var4_6.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getMilitaryAccess(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                        var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                        var3_5.add(var1_1);
                                        var1_1 = new StringBuilder();
                                        var1_1.append(" [");
                                        var1_1.append(CFG.langManager.get("TurnsX", CFG.game.getMilitaryAccess(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                        var1_1.append("]");
                                        var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                        var3_5.add(var4_6);
                                    }
                                    var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                    var2_4.add(var1_1);
                                    var3_5.clear();
                                    ** GOTO lbl119
                                }
                                if (this.iDiploImageID != Images.diplo_guarantee_gives) break block135;
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GuaranteeIndependence"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                                var3_5.add(var1_1);
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                                var3_5.add(var1_1);
                                var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                var2_4.add(var1_1);
                                var3_5.clear();
                                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                    var3_5.add(var1_1);
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                    var3_5.add(var1_1);
                                } else {
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                    var3_5.add(var1_1);
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                    var3_5.add(var1_1);
                                    var4_6 = new StringBuilder();
                                    var4_6.append(" - ");
                                    var4_6.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getGuarantee(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                    var3_5.add(var1_1);
                                    var1_1 = new StringBuilder();
                                    var1_1.append(" [");
                                    var1_1.append(CFG.langManager.get("TurnsX", CFG.game.getGuarantee(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID))));
                                    var1_1.append("]");
                                    var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                    var3_5.add(var4_6);
                                }
                                var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                                var2_4.add(var1_1);
                                var3_5.clear();
                                ** GOTO lbl119
                            }
                            if (this.iDiploImageID != Images.diplo_guarantee_has) break block136;
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GuaranteeTheirIndependence"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                            var3_5.add(var1_1);
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                            var3_5.add(var1_1);
                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                            var2_4.add(var1_1);
                            var3_5.clear();
                            if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                                var3_5.add(var1_1);
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                                var3_5.add(var1_1);
                            } else {
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                                var3_5.add(var1_1);
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                                var3_5.add(var1_1);
                                var1_1 = new StringBuilder();
                                var1_1.append(" - ");
                                var1_1.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getGuarantee(this.lCivs.get(this.iHoveredID), CFG.getActiveCivInfo())));
                                var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                                var3_5.add(var4_6);
                                var4_6 = new StringBuilder();
                                var4_6.append(" [");
                                var4_6.append(CFG.langManager.get("TurnsX", CFG.game.getGuarantee(this.lCivs.get(this.iHoveredID), CFG.getActiveCivInfo())));
                                var4_6.append("]");
                                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                                var3_5.add(var1_1);
                            }
                            var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                            var2_4.add(var1_1);
                            var3_5.clear();
                            ** GOTO lbl119
                        }
                        if (this.iDiploImageID != Images.diplo_vassal) break block137;
                        var1_1 = new StringBuilder();
                        var1_1.append(CFG.langManager.get("Vassal"));
                        var1_1.append(": ");
                        var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString());
                        var3_5.add(var4_6);
                        if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                            var3_5.add(var1_1);
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1, CFG.PADDING, 0);
                            var3_5.add(var1_1);
                        } else {
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                            var3_5.add(var1_1);
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID), CFG.PADDING, 0);
                            var3_5.add(var1_1);
                        }
                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                        var2_4.add(var1_1);
                        var3_5.clear();
                        ** GOTO lbl119
                    }
                    if (this.iDiploImageID == Images.diplo_heart) {
                        if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(this.iHoveredID) < 0) {
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                            var3_5.add(var1_1);
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                            var3_5.add(var1_1);
                        } else {
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                            var3_5.add(var1_1);
                            var4_6 = new StringBuilder();
                            var4_6.append(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                            var4_6.append(": ");
                            var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var4_6.toString());
                            var3_5.add(var1_1);
                            var1_1 = new StringBuilder();
                            var1_1.append("+");
                            var1_1.append((float)((int)(CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID)) * 10.0f)) / 10.0f);
                            var4_6 = new MenuElement_Hover_v2_Element_Type_Text(var1_1.toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                            var3_5.add(var4_6);
                        }
                        var1_1 = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_heart, CFG.PADDING, 0);
                        var3_5.add(var1_1);
                        var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                        var2_4.add(var1_1);
                        var3_5.clear();
                        ** continue;
                    }
                    if (this.iDiploImageID != Images.diplo_rivals) ** GOTO lbl894
                    if (CFG.FOG_OF_WAR < 2 || this.lCivs.get(this.iHoveredID) >= 0) break block138;
                    var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var3_5.add(var1_1);
                    var1_1 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var3_5.add(var1_1);
                    ** GOTO lbl879
                }
                var1_1 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                var3_5.add(var1_1);
                var5_12 = new StringBuilder();
                var5_12.append(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName());
                var5_12.append(": ");
                var1_1 = new MenuElement_Hover_v2_Element_Type_Text(var5_12.toString());
                var3_5.add(var1_1);
                var6_17 = new StringBuilder();
                var1_1 = var4_6;
                var6_17.append((String)var4_6);
                var1_1 = var4_6;
                var6_17.append((float)((int)(CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.lCivs.get(this.iHoveredID)) * 10.0f)) / 10.0f);
                var1_1 = var4_6;
                var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var6_17.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                var1_1 = var4_6;
                var3_5.add(var5_12);
lbl879:
                // 2 sources

                var1_1 = var4_6 = "";
                var1_1 = var4_6;
                var5_12 = new MenuElement_Hover_v2_Element_Type_Image(Images.diplo_rivals, CFG.PADDING, 0);
                var1_1 = var4_6;
                var3_5.add(var5_12);
                var1_1 = var4_6;
                var1_1 = var4_6;
                var5_12 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                var1_1 = var4_6;
                var2_4.add(var5_12);
                var1_1 = var4_6;
                var3_5.clear();
                break block139;
lbl894:
                // 1 sources

                var1_1 = var4_6;
                if (CFG.FOG_OF_WAR < 2) ** GOTO lbl-1000
                var1_1 = var4_6;
                if (this.lCivs.get(this.iHoveredID) < 0) {
                    var1_1 = var4_6;
                    var1_1 = var4_6;
                    var5_16 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var1_1 = var4_6;
                    var3_5.add(var5_16);
                    var1_1 = var4_6;
                    var1_1 = var4_6;
                    var5_16 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var1_1 = var4_6;
                    var3_5.add(var5_16);
                } else lbl-1000:
                // 2 sources

                {
                    var1_1 = var4_6;
                    var1_1 = var4_6;
                    var5_16 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(this.iHoveredID));
                    var1_1 = var4_6;
                    var3_5.add(var5_16);
                    var1_1 = var4_6;
                    var1_1 = var4_6;
                    var5_16 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(this.iHoveredID)).getCivName(), CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE);
                    var1_1 = var4_6;
                    var3_5.add(var5_16);
                }
                var1_1 = var4_6;
                var1_1 = var4_6;
                var5_16 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var3_5);
                var1_1 = var4_6;
                var2_4.add(var5_16);
                var1_1 = var4_6;
                var3_5.clear();
            }
            var1_1 = var4_6;
            var1_1 = var4_6;
            var3_5 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var2_4);
            var1_1 = var4_6;
            this.menuElementHover = var3_5;
            ** GOTO lbl1816
            catch (IndexOutOfBoundsException var1_2) {
                var1_1 = "";
            }
            break block140;
            catch (IndexOutOfBoundsException var4_7) {
                // empty catch block
            }
        }
lbl944:
        // 3 sources

        while (true) {
            if (this.iDiploImageID != Images.diplo_alliance) ** GOTO lbl982
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get(CFG.game.getAlliance(CFG.game.getCiv(CFG.getActiveCivInfo()).getAllianceID()).getAllianceName()), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl982:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_war) ** GOTO lbl1018
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("AtWarWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1018:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_non_aggression) ** GOTO lbl1072
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("HasSignedNonAggressionPactWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" - ");
                    var2_4.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCivNonAggressionPact(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var3_5);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getCivNonAggressionPact(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add(var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1072:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_truce) ** GOTO lbl1126
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("TruceWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCivTruce(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" [");
                    var3_5.append(CFG.langManager.get("TurnsX", CFG.game.getCivTruce(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var3_5.append("]");
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1126:
            // 1 sources

            if (this.iDiploImageID == Images.diplo_loan) {
                var4_6 = new ArrayList();
                var2_4 = new ArrayList();
                var5_12 = new StringBuilder();
                var5_12.append(CFG.langManager.get("Loans"));
                var5_12.append(": ");
                var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var5_12.toString(), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
                var2_4.add(var3_5);
                var3_5 = new StringBuilder();
                var3_5.append((String)var1_1);
                var3_5.append(this.lCivs.size());
                var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                var2_4.add(var5_12);
                var1_1 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
                var2_4.add(var1_1);
                var1_1 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var2_4);
                var4_6.add(var1_1);
                var2_4.clear();
                this.menuElementHover = var1_1 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var4_6);
                return;
            }
            if (this.iDiploImageID != Images.top_gold2) ** GOTO lbl1208
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("WarReparations"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCiv(CFG.getActiveCivInfo()).getWarReparationsPays_TurnsLeft(this.lCivs.get(var7_18))));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" [");
                    var3_5.append(CFG.langManager.get("TurnsX", CFG.game.getCiv(CFG.getActiveCivInfo()).getWarReparationsPays_TurnsLeft(this.lCivs.get(var7_18))));
                    var3_5.append("]");
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1208:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_defensive_pact) ** GOTO lbl1262
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("DefensivePact"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getDefensivePact(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" [");
                    var3_5.append(CFG.langManager.get("TurnsX", CFG.game.getDefensivePact(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var3_5.append("]");
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1262:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_relations_inc) ** GOTO lbl1298
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ImprovingRelationsWith"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1298:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_relations) ** GOTO lbl1334
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("ImprovingRelationsFrom"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1334:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_relations_dec) ** GOTO lbl1388
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("DiplomaticRelationsAreSuspended"), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getCiv(CFG.getActiveCivInfo()).getCivilization_Diplomacy_GameData().isEmbassyClosed_Turns(this.lCivs.get(var7_18))));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getCiv(CFG.getActiveCivInfo()).getCivilization_Diplomacy_GameData().isEmbassyClosed_Turns(this.lCivs.get(var7_18))));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1388:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_gift) ** GOTO lbl1424
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Gift"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1424:
            // 1 sources

            if (this.iDiploImageID != Images.hre_icon) ** GOTO lbl1460
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("IsPartOfHRE"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1460:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_access_has) ** GOTO lbl1514
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GivesMilitaryAccess"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" - ");
                    var2_4.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getMilitaryAccess(this.lCivs.get(var7_18), CFG.getActiveCivInfo())));
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var3_5);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getMilitaryAccess(this.lCivs.get(var7_18), CFG.getActiveCivInfo())));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1514:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_access_gives) ** GOTO lbl1568
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("HaveMilitaryAccess"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add((MenuElement_Hover_v2_Element_Type)var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getMilitaryAccess(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getMilitaryAccess(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1568:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_guarantee_gives) ** GOTO lbl1622
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GuaranteeIndependence"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" - ");
                    var2_4.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getGuarantee(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var3_5);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getGuarantee(CFG.getActiveCivInfo(), this.lCivs.get(var7_18))));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1622:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_guarantee_has) ** GOTO lbl1676
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("GuaranteeTheirIndependence"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(" - ");
                    var3_5.append(Game_Calendar.getDate_ByTurnID(Game_Calendar.TURN_ID + CFG.game.getGuarantee(this.lCivs.get(var7_18), CFG.getActiveCivInfo())));
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString(), CFG.COLOR_TEXT_MODIFIER_NEUTRAL);
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append(" [");
                    var2_4.append(CFG.langManager.get("TurnsX", CFG.game.getGuarantee(this.lCivs.get(var7_18), CFG.getActiveCivInfo())));
                    var2_4.append("]");
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1676:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_vassal) ** GOTO lbl1712
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Vassals"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var4_6.add(var2_4);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1712:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_heart) ** GOTO lbl1761
            var1_1 = new ArrayList();
            var4_6 = new ArrayList();
            var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("FriendlyCivilizations"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element_Type_Image(this.iDiploImageID, CFG.PADDING, 0);
            var4_6.add(var2_4);
            var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
            var1_1.add(var2_4);
            var4_6.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var4_6.add(var2_4);
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var4_6.add(var2_4);
                } else {
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var4_6.add(var2_4);
                    var3_5 = new StringBuilder();
                    var3_5.append(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var3_5.append(": ");
                    var2_4 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString());
                    var4_6.add(var2_4);
                    var2_4 = new StringBuilder();
                    var2_4.append("+");
                    var2_4.append((float)((int)(CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.lCivs.get(var7_18)) * 10.0f)) / 10.0f);
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var2_4.toString(), CFG.COLOR_TEXT_MODIFIER_POSITIVE);
                    var4_6.add((Integer)var3_5);
                }
                var2_4 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var4_6);
                var1_1.add(var2_4);
                var4_6.clear();
            }
            this.menuElementHover = var4_6 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var1_1);
            return;
lbl1761:
            // 1 sources

            if (this.iDiploImageID != Images.diplo_rivals) ** GOTO lbl1812
            var4_6 = new ArrayList();
            var2_4 = new ArrayList();
            var3_5 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Enemies"), CFG.COLOR_TEXT_NUM_OF_PROVINCES);
            var2_4.add(var3_5);
            var10_21 = this.iDiploImageID;
            var8_19 = CFG.PADDING;
            var3_5 = new MenuElement_Hover_v2_Element_Type_Image(var10_21, var8_19, 0);
            var2_4.add(var3_5);
            var3_5 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var2_4);
            var4_6.add(var3_5);
            var2_4.clear();
            for (var7_18 = 0; var7_18 < this.lCivs.size(); ++var7_18) {
                if (CFG.FOG_OF_WAR >= 2 && this.lCivs.get(var7_18) < 0) {
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Flag(-1);
                    var2_4.add(var3_5);
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(CFG.langManager.get("Undiscovered"));
                    var2_4.add(var3_5);
                } else {
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Flag(this.lCivs.get(var7_18));
                    var2_4.add(var3_5);
                    var3_5 = new StringBuilder();
                    var3_5.append(CFG.game.getCiv(this.lCivs.get(var7_18)).getCivName());
                    var3_5.append(": ");
                    var5_12 = new MenuElement_Hover_v2_Element_Type_Text(var3_5.toString());
                    var2_4.add(var5_12);
                    var5_12 = new StringBuilder();
                    var5_12.append((String)var1_1);
                    var5_12.append((float)((int)(CFG.game.getCivRelation_OfCivB(CFG.getActiveCivInfo(), this.lCivs.get(var7_18)) * 10.0f)) / 10.0f);
                    var3_5 = new MenuElement_Hover_v2_Element_Type_Text(var5_12.toString(), CFG.COLOR_TEXT_MODIFIER_NEGATIVE2);
                    var2_4.add(var3_5);
                }
                var3_5 = new MenuElement_Hover_v2_Element2((List<MenuElement_Hover_v2_Element_Type>)var2_4);
                var4_6.add(var3_5);
                var2_4.clear();
            }
            try {
                this.menuElementHover = var1_1 = new MenuElement_Hover_v2((List<MenuElement_Hover_v2_Element2>)var4_6);
                return;
lbl1812:
                // 1 sources

                this.menuElementHover = null;
            }
            catch (IndexOutOfBoundsException var1_3) {
                this.menuElementHover = null;
            }
lbl1816:
            // 3 sources

            return;
        }
        catch (IndexOutOfBoundsException var4_8) {
            ** GOTO lbl944
        }
        catch (IndexOutOfBoundsException var4_9) {
            ** continue;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        boolean bl2 = this.scrollModeY;
        int n3 = 0;
        if (bl2) {
            if (Math.abs(this.fScrollNewMenuPosY) > 1.0f) {
                this.setCurrent(this.iButtonsPosX + (int)this.fScrollNewMenuPosY);
                this.fScrollNewMenuPosY *= 0.97f;
            } else {
                this.scrollModeY = false;
            }
            CFG.setRender_3(true);
        }
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.1f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.125f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.75f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
            }
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), CFG.PADDING);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 3 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 3, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.335f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), this.getHeight());
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.075f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.75f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 2);
            }
            spriteBatch.setColor(new Color(0.06f, 0.06f, 0.1f, 0.65f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, this.getWidth(), 1);
        }
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(this.iDiploImageID).draw(spriteBatch, this.getPosX() + (iDiploWidth - ImageManager.getImage(this.iDiploImageID).getWidth()) / 2 + n, this.getPosY() + (this.getHeight() - ImageManager.getImage(this.iDiploImageID).getHeight()) / 2 + n2);
        Rectangle rectangle = new Rectangle(this.getPosX() + iDiploWidth + n, CFG.GAME_HEIGHT - this.getPosY() - n2, this.getWidth() - iDiploWidth, -this.getHeight());
        spriteBatch.flush();
        ScissorStack.pushScissors(rectangle);
        while (n3 < this.lCivs.size()) {
            if (this.lCivs.get(n3) >= 0) {
                CFG.game.getCiv(this.lCivs.get(n3)).getFlag().draw(spriteBatch, this.getPosX() + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * n3 + n, this.getPosY() + (this.getHeight() - CFG.CIV_FLAG_HEIGHT) / 2 - CFG.game.getCiv(this.lCivs.get(n3)).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            } else {
                ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * n3 + n, this.getPosY() + (this.getHeight() - CFG.CIV_FLAG_HEIGHT) / 2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
            }
            ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * n3 + n, this.getPosY() + (this.getHeight() - CFG.CIV_FLAG_HEIGHT) / 2 + n2);
            ++n3;
        }
        if (this.getIsHovered() && this.iHoveredID >= 0) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.55f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * this.iHoveredID + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + (this.getHeight() - CFG.CIV_FLAG_HEIGHT) / 2 + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT / 3);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * this.iHoveredID + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + (this.getHeight() - CFG.CIV_FLAG_HEIGHT) / 2 + n2 + CFG.CIV_FLAG_HEIGHT - CFG.CIV_FLAG_HEIGHT / 3, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT / 3, false, true);
            spriteBatch.setColor(Color.WHITE);
        }
        try {
            spriteBatch.flush();
            ScissorStack.popScissors();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            return;
        }
    }

    @Override
    protected boolean getAnotherView() {
        return false;
    }

    @Override
    protected int getCurrent() {
        return this.iButtonsPosX;
    }

    @Override
    protected boolean getIsScrollable() {
        return this.moveable;
    }

    @Override
    protected boolean getMoveable() {
        return this.moveable;
    }

    @Override
    protected final void scrollTheMenu() {
        int n;
        int n2;
        if (this.moveable && (n2 = this.iScrollPosX) > 0 && (n = this.iScrollPosX2) > 0 && (float)Math.abs(n2 - n) > CFG.DENSITY * 3.0f) {
            this.fScrollNewMenuPosY = (float)(this.iScrollPosX - this.iScrollPosX2) * 1.25f;
            this.scrollModeY = true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void setAnotherView(boolean bl) {
        if (this.iHoveredID >= 0) {
            if (!CFG.game.getCiv(CFG.getActiveCivInfo()).getControlledByPlayer()) {
                CFG.game.disableDrawCivilizationRegions(CFG.getActiveCivInfo());
            }
            CFG.setActiveCivInfo(this.lCivs.get(this.iHoveredID));
            try {
                CFG.game.setActiveProvinceID(CFG.game.getCiv(CFG.getActiveCivInfo()).getCapitalProvinceID());
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
            CFG.updateActiveCivInfo_CreateNewGame();
            CFG.game.enableDrawCivilizationRegions(CFG.getActiveCivInfo(), 1);
        }
    }

    @Override
    protected void setCurrent(int n) {
        int n2;
        if (n > 0) {
            CFG.menuManager.setUpdateSliderMenuPosX(true);
            this.scrollModeY = false;
            n2 = 0;
        } else {
            n2 = n;
            if (n < -(this.getButtonsWidth() - this.getWidth())) {
                n2 = -(this.getButtonsWidth() - this.getWidth());
                CFG.menuManager.setUpdateSliderMenuPosX(true);
                this.scrollModeY = false;
            }
        }
        if (this.iButtonsPosX != n2) {
            this.iButtonsPosX = n2;
            CFG.setRender_3(true);
        }
    }

    @Override
    protected void setMax(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }

    @Override
    protected final void setScrollPosY(int n) {
        this.iScrollPosX2 = this.iScrollPosX;
        this.iScrollPosX = n;
    }

    @Override
    protected void setTypeOfButton(Button.TypeOfButton typeOfButton) {
        this.iScrollPosX2 = -1;
        this.iScrollPosX = -1;
        this.scrollModeY = false;
    }

    @Override
    protected void srollByWheel(int n) {
        this.scrollModeY = false;
        this.setCurrent(this.getCurrent() + n);
    }

    @Override
    protected void updateHover(int n, int n2, int n3, int n4) {
        if (n >= this.getPosX() + n3 && n <= this.getPosX() + n3 + this.getWidth() && n2 >= this.getPosY() + n4 && n2 <= n4 + this.getPosY() + this.getHeight()) {
            for (n2 = 0; n2 < this.lCivs.size(); ++n2) {
                if (n < this.getPosX() + n3 + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * n2 || n > this.getPosX() + n3 + this.iButtonsPosX + iDiploWidth + (CFG.CIV_FLAG_WIDTH + CFG.PADDING) * n2 + (CFG.CIV_FLAG_WIDTH + CFG.PADDING)) continue;
                this.setHoveredID(n2);
                return;
            }
        }
        this.setHoveredID(-1);
    }
}

