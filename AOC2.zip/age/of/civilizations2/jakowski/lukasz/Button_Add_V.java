/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button_Add;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_Add_V
extends Button_Add {
    protected Button_Add_V(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super(string2, n, n2, n3, n4, n5, bl);
    }

    @Override
    protected final void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        super.drawButtonBG(spriteBatch, n, n2, bl);
        if (!this.getClickable()) {
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 0.6f));
        }
        if (bl) {
            ImageManager.getImage(Images.btn_v_active).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_v_active).getWidth() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_v_active).getHeight() / 2 + n2);
        } else {
            ImageManager.getImage(Images.btn_v).draw(spriteBatch, this.getPosX() + this.getWidth() / 2 - ImageManager.getImage(Images.btn_v).getWidth() + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.btn_v).getHeight() / 2 + n2);
        }
        spriteBatch.setColor(Color.WHITE);
    }
}

