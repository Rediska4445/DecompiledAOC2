/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Rank
extends Button {
    private float fTEXT_SCALE = 1.0f;

    protected Button_Rank(String string2, int n, int n2) {
        super.init(string2, 0, n, n2, ImageManager.getImage(Images.top_circle).getWidth(), ImageManager.getImage(Images.top_circle).getHeight(), true, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        ImageManager.getImage(Images.top_circle).draw(spriteBatch, this.getPosX() + n, this.getPosY() + n2);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontArmy.getData().setScale(this.fTEXT_SCALE);
        CFG.drawArmyText(spriteBatch, this.getText(), this.getPosX() + (this.getWidth() - this.getTextWidth()) / 2 + n, this.getPosY() + (this.getHeight() - this.getTextHeight()) / 2 + n2, this.getColor(bl));
        CFG.fontArmy.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : new Color(0.92f, 0.94f, 0.92f, 1.0f)) : CFG.COLOR_BUTTON_GAME_TEXT_NOT_CLICKABLE);
        return color2;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setText(String string2) {
        Throwable throwable22;
        block11: {
            block10: {
                this.sText = string2;
                try {
                    Object object;
                    Object object2;
                    GlyphLayout glyphLayout;
                    int n;
                    int n2 = n = Integer.parseInt(string2);
                    if (n < 10) {
                        n2 = 99;
                    }
                    this.fTEXT_SCALE = 1.0f;
                    for (n = 0; n < 70; this.fTEXT_SCALE -= 0.01f, ++n) {
                        glyphLayout = CFG.glyphLayout;
                        object2 = CFG.fontArmy;
                        object = new StringBuilder();
                        ((StringBuilder)object).append("");
                        ((StringBuilder)object).append(n2);
                        glyphLayout.setText((BitmapFont)object2, ((StringBuilder)object).toString());
                        if ((float)((int)CFG.glyphLayout.width) <= (float)ImageManager.getImage(Images.top_circle).getWidth() - CFG.GUI_SCALE * 10.0f) break;
                        CFG.fontArmy.getData().setScale(this.fTEXT_SCALE);
                    }
                    if (Integer.parseInt(string2) < 10) {
                        glyphLayout = CFG.glyphLayout;
                        object = CFG.fontArmy;
                        object2 = new StringBuilder();
                        ((StringBuilder)object2).append("");
                        ((StringBuilder)object2).append(string2);
                        glyphLayout.setText((BitmapFont)object, ((StringBuilder)object2).toString());
                    }
                    this.iTextWidth = (int)CFG.glyphLayout.width;
                    this.iTextHeight = (int)CFG.glyphLayout.height;
                }
                catch (Throwable throwable22) {
                    break block11;
                }
                catch (NullPointerException nullPointerException) {
                    if (CFG.LOGS) {
                        CFG.exceptionStack(nullPointerException);
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    if (!CFG.LOGS) break block10;
                    CFG.exceptionStack(indexOutOfBoundsException);
                }
            }
            CFG.fontArmy.getData().setScale(1.0f);
            return;
        }
        CFG.fontArmy.getData().setScale(1.0f);
        throw throwable22;
    }
}

