/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.SoundsManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_Message
extends Button {
    protected static final int ANIMATION_T = 750;
    protected static final float BUTTON_PERC_HEIGHT = 0.6f;
    private int animationState = 0;
    private boolean backAnimation = false;
    private float fAlphaMod = 0.0f;
    private int iBGImageID;
    private int iFromCivID = 0;
    private int iImageID;
    private int iMessageID = 0;
    private long lTime = 0L;
    private long lTimeAnimation = 0L;

    protected Button_Message(int n, int n2, int n3, int n4, int n5, int n6) {
        super.init("", -1, n, n2, Button_Diplomacy.iDiploWidth + ImageManager.getImage(Images.flag_rect).getWidth() + CFG.PADDING * 4, (int)((float)CFG.BUTTON_HEIGHT * 0.6f), true, true, false, false);
        this.iMessageID = n3;
        this.iFromCivID = n4;
        this.iImageID = n5;
        this.iBGImageID = n6;
        this.lTimeAnimation = System.currentTimeMillis();
    }

    @Override
    protected void buildElementHover() {
        try {
            this.menuElementHover = CFG.game.getCiv((int)CFG.game.getPlayer((int)CFG.PLAYER_TURNID).getCivID()).getCivilization_Diplomacy_GameData().messageBox.getMessage(this.iMessageID).getHover();
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            this.menuElementHover = null;
        }
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        int n3;
        spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f));
        ImageManager.getImage(this.iBGImageID).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(this.iBGImageID).getHeight() + n2, this.getWidth() - ImageManager.getImage(this.iBGImageID).getWidth(), this.getHeight() - ImageManager.getImage(this.iBGImageID).getHeight(), false, false);
        ImageManager.getImage(this.iBGImageID).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(this.iBGImageID).getWidth() + n, this.getPosY() - ImageManager.getImage(this.iBGImageID).getHeight() + n2, ImageManager.getImage(this.iBGImageID).getWidth(), this.getHeight() - ImageManager.getImage(this.iBGImageID).getHeight(), true, false);
        ImageManager.getImage(this.iBGImageID).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(this.iBGImageID).getHeight() - ImageManager.getImage(this.iBGImageID).getHeight() + n2, this.getWidth() - ImageManager.getImage(this.iBGImageID).getWidth(), ImageManager.getImage(this.iBGImageID).getHeight(), false, true);
        ImageManager.getImage(this.iBGImageID).draw2(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(this.iBGImageID).getWidth() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(this.iBGImageID).getHeight() - ImageManager.getImage(this.iBGImageID).getHeight() + n2, ImageManager.getImage(this.iBGImageID).getWidth(), ImageManager.getImage(this.iBGImageID).getHeight(), true, true);
        if (this.getIsHovered() || bl) {
            if (this.iBGImageID == Images.messages_r) {
                spriteBatch.setColor(new Color(0.3137255f, 0.13725491f, 0.047058824f, 0.475f - this.fAlphaMod));
            } else if (this.iBGImageID == Images.messages_g) {
                spriteBatch.setColor(new Color(0.13333334f, 0.23529412f, 0.02745098f, 0.475f - this.fAlphaMod));
            } else {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.475f - this.fAlphaMod));
            }
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), this.getHeight() - 4);
        }
        if ((n3 = this.animationState++) >= 0) {
            if (n3 == 0) {
                float f = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 750L) {
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            } else {
                float f = Math.min((float)(System.currentTimeMillis() - this.lTimeAnimation) * 1.0f / 750.0f, 1.0f);
                spriteBatch.setColor(new Color(CFG.COLOR_FLAG_FRAME.r, CFG.COLOR_FLAG_FRAME.g, CFG.COLOR_FLAG_FRAME.b, 0.65f));
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + CFG.PADDING + (int)((float)(this.getWidth() - CFG.PADDING * 2) * f) + n, this.getPosY() + this.getHeight() - 2 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth() - CFG.PADDING * 2 - (int)((float)(this.getWidth() - CFG.PADDING * 2) * f), 1);
                if (this.lTimeAnimation < System.currentTimeMillis() - 750L) {
                    this.animationState = 0;
                    this.lTimeAnimation = System.currentTimeMillis();
                }
            }
            CFG.setRender_3(true);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.game.getCiv(this.iFromCivID).getFlag().draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.flag_rect).getWidth() - CFG.PADDING * 3 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.flag_rect).getHeight() / 2 - CFG.game.getCiv(this.iFromCivID).getFlag().getHeight() + n2, ImageManager.getImage(Images.flag_rect).getWidth(), ImageManager.getImage(Images.flag_rect).getHeight());
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.flag_rect).getWidth() - CFG.PADDING * 3 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(Images.flag_rect).getHeight() / 2 + n2);
        if (this.getIsHovered()) {
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod >= 0.5f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
        } else {
            this.backAnimation = false;
            this.fAlphaMod = 0.0f;
            this.lTime = System.currentTimeMillis();
        }
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + CFG.PADDING * 3 + (Button_Diplomacy.iDiploWidth - CFG.PADDING * 4) / 2 - ImageManager.getImage(this.iImageID).getWidth() / 2 + n, this.getPosY() + this.getHeight() / 2 - ImageManager.getImage(this.iImageID).getHeight() / 2 + n2);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = this.getClickable() ? (bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getIsHovered() ? CFG.COLOR_TEXT_CIV_INFO_HOVER : CFG.COLOR_TEXT_CIV_INFO)) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.65f);
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iMessageID;
    }

    @Override
    protected int getSFX() {
        return SoundsManager.SOUND_CLICK2;
    }
}

