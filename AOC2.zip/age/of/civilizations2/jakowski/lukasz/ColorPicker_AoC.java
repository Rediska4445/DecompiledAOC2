/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ColorPicker_AoC_Action;
import age.of.civilizations2.jakowski.lukasz.Color_GameData;
import age.of.civilizations2.jakowski.lukasz.Image;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import age.of.civilizations2.jakowski.lukasz.Keyboard;
import age.of.civilizations2.jakowski.lukasz.Pallet_Manager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class ColorPicker_AoC {
    protected static int activeRGB = -1;
    protected ColorPicker_AoC_Action ColorPicker_AoC_Action;
    private final float RGB_TEXT_SCALE;
    private boolean activeClose = false;
    private Color activeColor;
    private boolean activeHUE = false;
    private boolean activeMove = false;
    private boolean activeResize = false;
    private boolean activeSV = false;
    private Color colorSVPos = Color.WHITE;
    private float fAlpha = 1.0f;
    private float[] hsv;
    private Color hueColor;
    private float hueVal = 1.0f;
    private int iActiveColorID = -1;
    private int iBTextWidth;
    private int iGTextWidth;
    private int iHUEWidth;
    private int iLastHUEPosY;
    private int iLastSVPosX;
    private int iLastSVPosY;
    private int iPosX = 150;
    private int iPosY = 150;
    private int iRGBTextWidth;
    private int iRTextWidth;
    private int iResizeHeight;
    private int iSVHeight;
    private int iStartPosX;
    private int iStartPosY;
    private int iStartResizeHeight;
    private List<Color> lColors;
    private List<Box> lColorsBoxes;
    private List<Box> lRGBBoxes = new ArrayList<Box>();
    private boolean visible = false;

    protected ColorPicker_AoC() {
        this.RGB_TEXT_SCALE = 0.9f;
        this.lColorsBoxes = new ArrayList<Box>();
        this.lColors = new ArrayList<Color>();
        this.hueColor = new Color(1.0f, 0.0f, 0.0f, 1.0f);
        this.activeColor = new Color(1.0f, 0.0f, 0.0f, 1.0f);
        this.hsv = new float[]{0.0f, 1.0f, 1.0f};
        CFG.glyphLayout.setText(CFG.fontMain, "G 255");
        this.iRGBTextWidth = (int)CFG.glyphLayout.width;
        this.updateRGBWidth();
        this.lRGBBoxes.add(new Box(CFG.PADDING, ImageManager.getImage(Images.btn_close).getHeight() + ImageManager.getImage(Images.btn_close).getHeight() / 2, this.iRGBTextWidth + CFG.PADDING * 2, CFG.TEXT_HEIGHT + CFG.PADDING * 2));
        this.lRGBBoxes.add(new Box(CFG.PADDING, ImageManager.getImage(Images.btn_close).getHeight() + ImageManager.getImage(Images.btn_close).getHeight() / 2 + CFG.PADDING + CFG.TEXT_HEIGHT + CFG.PADDING * 2, this.iRGBTextWidth + CFG.PADDING * 2, CFG.TEXT_HEIGHT + CFG.PADDING * 2));
        this.lRGBBoxes.add(new Box(CFG.PADDING, ImageManager.getImage(Images.btn_close).getHeight() + ImageManager.getImage(Images.btn_close).getHeight() / 2 + CFG.PADDING * 2 + (CFG.TEXT_HEIGHT + CFG.PADDING * 2) * 2, this.iRGBTextWidth + CFG.PADDING * 2, CFG.TEXT_HEIGHT + CFG.PADDING * 2));
        this.updateColorPicker_Action(PickerAction.ACTIVE_CIVILIZATION_COLOR);
    }

    private final void HSVtoRGB(float[] arrf, Color color2) {
        float f;
        float f2 = arrf[0];
        float f3 = arrf[1];
        float f4 = arrf[2];
        if (f3 == 0.0f) {
            f2 = f = f4;
        } else {
            int n = (int)(f2 /= 60.0f);
            float f5 = f2 - (float)n;
            f2 = (1.0f - f3) * f4;
            f = (1.0f - f3 * f5) * f4;
            f3 = (1.0f - f3 * (1.0f - f5)) * f4;
            if (n != 0) {
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            if (n == 4) {
                                f = f4;
                                f4 = f3;
                            }
                        } else {
                            f3 = f4;
                            f4 = f2;
                            f2 = f;
                            f = f3;
                        }
                    } else {
                        f = f4;
                        f4 = f2;
                        f2 = f;
                        f = f3;
                    }
                } else {
                    f3 = f;
                    f = f2;
                    f2 = f4;
                    f4 = f3;
                }
            } else {
                f = f2;
                f2 = f3;
            }
        }
        color2.r = f4;
        color2.g = f2;
        color2.b = f;
        color2.a = 1.0f;
    }

    private final void setActiveRGB_Box(int n, int n2) {
        for (int i = 0; i < this.lRGBBoxes.size(); ++i) {
            if (n < this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth + CFG.PADDING + this.lRGBBoxes.get(i).getPosX() || n > this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth + CFG.PADDING + this.lRGBBoxes.get(i).getPosX() + this.lRGBBoxes.get(i).getWidth() || n2 < this.iPosY + this.lRGBBoxes.get(i).getPosY() || n2 > this.iPosY + this.lRGBBoxes.get(i).getPosY() + this.lRGBBoxes.get(i).getHeight()) continue;
            activeRGB = i;
            break;
        }
    }

    private final void updateColorSVPos(int n) {
        this.colorSVPos = (float)this.iSVHeight * 0.1f > (float)n ? Color.BLACK : Color.WHITE;
    }

    private final void updateHUE(int n) {
        float f = (float)(n - this.iPosY) / (float)this.iSVHeight;
        float[] arrf = this.hsv;
        this.hueVal = f = (1.0f - f) * 360.0f;
        arrf[0] = f;
        arrf[2] = 1.0f;
        arrf[1] = 1.0f;
        this.HSVtoRGB(arrf, this.hueColor);
        this.updateSV(this.iLastSVPosX, this.iLastSVPosY);
        this.iLastHUEPosY = n - this.iPosY;
    }

    private final void updateSV(int n, int n2) {
        float f = n - this.iPosX;
        n = this.iSVHeight;
        float f2 = f / (float)n;
        int n3 = this.iPosY;
        f = (float)(n2 - n3) / (float)n;
        float[] arrf = this.hsv;
        arrf[0] = this.hueVal;
        arrf[1] = f2;
        arrf[2] = 1.0f - f;
        this.updateColorSVPos(n2 - n3);
        this.HSVtoRGB(this.hsv, this.activeColor);
        this.updateRGBWidth();
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void RGBtoHSV(int n, int n2, int n3) {
        float f;
        int n4;
        float f2;
        float f3 = Math.min(Math.min(n, n2), n3);
        if (f3 == (f2 = (float)Math.max(Math.max(n, n2), n3))) {
            float[] arrf = this.hsv;
            arrf[0] = 0.0f;
            arrf[1] = 0.0f;
        } else {
            int n5 = (int)f3;
            n4 = n == n5 ? n2 - n3 : (n2 == n5 ? n3 - n : n - n2);
            float f4 = n4;
            if (n == n5) {
                f = 3.0f;
            } else {
                n4 = n2 == n5 ? 5 : 1;
                f = n4;
            }
            float[] arrf = this.hsv;
            f3 = f2 - f3;
            arrf[0] = (f - f4 / f3) * 60.0f % 360.0f;
            arrf[1] = f3 / f2;
        }
        float[] arrf = this.hsv;
        arrf[2] = f2 / 255.0f;
        this.hueVal = arrf[0];
        f = arrf[1];
        n4 = this.iSVHeight;
        this.iLastSVPosX = (int)(f * (float)n4);
        this.iLastSVPosY = (int)(-arrf[2] * (float)n4 + (float)n4);
        this.iLastHUEPosY = (int)((float)n4 - arrf[0] / 360.0f * (float)n4);
        n4 = this.iPosY;
        this.updateSV(this.iLastSVPosX + n4, n4 + this.iLastSVPosY);
        this.updateHUE(this.iPosY + this.iLastHUEPosY);
        Color color2 = this.activeColor;
        color2.r = (float)n / 255.0f;
        color2.g = (float)n2 / 255.0f;
        color2.b = (float)n3 / 255.0f;
        this.updateRGBWidth();
    }

    protected final void addColor(int n) {
        this.lColors.add(new Color((float)CFG.oR.nextInt(256) / 255.0f, (float)CFG.oR.nextInt(256) / 255.0f, (float)CFG.oR.nextInt(256) / 255.0f, 1.0f));
    }

    protected final void buildColors() {
        this.lColorsBoxes.add(new Box(0, CFG.PADDING, this.getColorBoxWidth(), CFG.TEXT_HEIGHT + CFG.PADDING * 2));
        this.lColors.add(new Color(this.activeColor.r, this.activeColor.g, this.activeColor.b, 1.0f));
        Random random = new Random();
        int n = this.lColorsBoxes.get(0).getPosX();
        int n2 = this.lColorsBoxes.get(0).getWidth();
        while ((n += n2) < CFG.GAME_WIDTH) {
            this.lColorsBoxes.add(new Box(n, CFG.PADDING, this.getColorBoxWidth(), CFG.TEXT_HEIGHT + CFG.PADDING * 2));
            this.addColor(random.nextInt(Pallet_Manager.NUM_OF_COLORS));
            n2 = this.getColorBoxWidth();
        }
    }

    protected final void draw(SpriteBatch spriteBatch, int n) {
        spriteBatch.setColor(1.0f, 1.0f, 1.0f, this.fAlpha);
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, this.iPosX - CFG.PADDING * 2 + n, this.iPosY - CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), this.getWidth() + CFG.PADDING * 4 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), this.getHeight() + CFG.PADDING * 4 - ImageManager.getImage(Images.new_game_top_edge).getHeight());
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, this.iPosX + this.getWidth() + CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getWidth() + n, this.iPosY - CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), ImageManager.getImage(Images.new_game_top_edge).getWidth(), this.getHeight() + CFG.PADDING * 4 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), true);
        ImageManager.getImage(Images.new_game_top_edge).draw2(spriteBatch, this.iPosX - CFG.PADDING * 2 + n, this.iPosY + this.getHeight() + CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getHeight() * 2, this.getWidth() + CFG.PADDING * 4 - ImageManager.getImage(Images.new_game_top_edge).getWidth(), ImageManager.getImage(Images.new_game_top_edge).getHeight(), false, true);
        ImageManager.getImage(Images.new_game_top_edge).draw(spriteBatch, this.iPosX + this.getWidth() + CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getWidth() + n, this.iPosY + this.getHeight() + CFG.PADDING * 2 - ImageManager.getImage(Images.new_game_top_edge).getHeight(), true, true);
        ImageManager.getImage(Images.pickerHUE).draw(spriteBatch, this.iPosX + this.iSVHeight + CFG.PADDING + n, this.iPosY - ImageManager.getImage(Images.pickerHUE).getHeight(), this.iHUEWidth, this.iSVHeight);
        spriteBatch.setColor(Color.WHITE);
        List<Box> list = ImageManager.getImage(Images.pix255_255_255);
        int n2 = this.iPosX;
        int n3 = this.iPosY;
        int n4 = ImageManager.getImage(Images.pix255_255_255).getHeight();
        int n5 = this.iSVHeight;
        ((Image)((Object)list)).draw(spriteBatch, n2 + n, n3 - n4, n5, n5);
        spriteBatch.setColor(this.hueColor);
        list = ImageManager.getImage(Images.pickerSV);
        n4 = this.iPosX;
        n5 = this.iPosY;
        n3 = ImageManager.getImage(Images.pickerSV).getHeight();
        n2 = this.iSVHeight;
        ((Image)((Object)list)).draw(spriteBatch, n4 + n, n5 - n3, n2, n2);
        if (!this.activeResize) {
            block6: {
                float f = this.iPosX + n;
                float f2 = CFG.GAME_HEIGHT - this.iPosY;
                n5 = this.iSVHeight;
                list = new Rectangle(f, f2, n5, -n5);
                spriteBatch.flush();
                ScissorStack.pushScissors((Rectangle)((Object)list));
                spriteBatch.setColor(this.colorSVPos);
                ImageManager.getImage(Images.pickerSVPos).draw(spriteBatch, this.iPosX + this.iLastSVPosX - ImageManager.getImage(Images.pickerSVPos).getWidth() / 2 + n, this.iPosY + this.iLastSVPosY - ImageManager.getImage(Images.pickerSVPos).getHeight() / 2);
                try {
                    spriteBatch.flush();
                    ScissorStack.popScissors();
                }
                catch (IllegalStateException illegalStateException) {
                    if (!CFG.LOGS) break block6;
                    CFG.exceptionStack(illegalStateException);
                }
            }
            spriteBatch.setColor(0.0f, 0.0f, 0.0f, this.fAlpha);
            ImageManager.getImage(Images.pix255_255_255).draw2(spriteBatch, this.iPosX + this.iSVHeight + CFG.PADDING + CFG.PADDING + n, this.iPosY + this.iLastHUEPosY - 1, this.iHUEWidth - CFG.PADDING * 2 + 1, 1);
        } else {
            spriteBatch.setColor(Color.WHITE);
            ImageManager.getImage(Images.pickerEdge).draw(spriteBatch, this.iPosX + this.iSVHeight - ImageManager.getImage(Images.pickerEdge).getWidth() + n, this.iPosY + this.iSVHeight - ImageManager.getImage(Images.pickerEdge).getHeight() - 1);
        }
        if (this.activeMove) {
            spriteBatch.setColor(Color.BLACK);
            ImageManager.getImage(Images.pickerEdge).draw(spriteBatch, this.iPosX + 1 + n, this.iPosY + 1, true, true);
        }
        spriteBatch.setColor(Color.BLACK);
        n5 = this.iPosX;
        n2 = this.iPosY;
        n3 = this.iSVHeight;
        CFG.drawRect(spriteBatch, n5 + n, n2 - 1, n3, n3);
        n2 = this.iPosX;
        n5 = CFG.PADDING;
        n3 = this.iSVHeight;
        CFG.drawRect(spriteBatch, n2 + n5 + n3 + n, this.iPosY - 1, this.iHUEWidth, n3);
        int n6 = this.iPosX;
        int n7 = this.iSVHeight;
        int n8 = CFG.PADDING;
        n4 = this.iHUEWidth;
        int n9 = this.lRGBBoxes.get(0).getPosX();
        n5 = this.iPosY;
        int n10 = this.lRGBBoxes.get(0).getPosY();
        n3 = this.lRGBBoxes.get(0).getWidth();
        n2 = this.lRGBBoxes.get(0).getHeight();
        list = new StringBuilder();
        ((StringBuilder)((Object)list)).append("");
        ((StringBuilder)((Object)list)).append((int)(this.activeColor.r * 255.0f));
        this.drawRGBText(spriteBatch, 0, n6 + n7 + n8 + n4 + n9 + n, n5 + n10, n3, n2, "R", ((StringBuilder)((Object)list)).toString(), this.iRTextWidth);
        n5 = this.iPosX;
        n4 = this.iSVHeight;
        n9 = CFG.PADDING;
        n6 = this.iHUEWidth;
        n8 = this.lRGBBoxes.get(1).getPosX();
        n7 = this.iPosY;
        n10 = this.lRGBBoxes.get(1).getPosY();
        n2 = this.lRGBBoxes.get(1).getWidth();
        n3 = this.lRGBBoxes.get(1).getHeight();
        list = new StringBuilder();
        ((StringBuilder)((Object)list)).append("");
        ((StringBuilder)((Object)list)).append((int)(this.activeColor.g * 255.0f));
        this.drawRGBText(spriteBatch, 1, n5 + n4 + n9 + n6 + n8 + n, n7 + n10, n2, n3, "G", ((StringBuilder)((Object)list)).toString(), this.iGTextWidth);
        n10 = this.iPosX;
        n9 = this.iSVHeight;
        n2 = CFG.PADDING;
        n4 = this.iHUEWidth;
        n5 = this.lRGBBoxes.get(2).getPosX();
        n8 = this.iPosY;
        n6 = this.lRGBBoxes.get(2).getPosY();
        n3 = this.lRGBBoxes.get(2).getWidth();
        n7 = this.lRGBBoxes.get(2).getHeight();
        list = new StringBuilder();
        ((StringBuilder)((Object)list)).append("");
        ((StringBuilder)((Object)list)).append((int)(this.activeColor.b * 255.0f));
        this.drawRGBText(spriteBatch, 2, n10 + n9 + n2 + n4 + n5 + n, n8 + n6, n3, n7, "B", ((StringBuilder)((Object)list)).toString(), this.iBTextWidth);
        this.drawColors(spriteBatch, this.iPosX + n, this.iPosY + this.iSVHeight);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.175f));
        list = ImageManager.getImage(Images.gradient);
        n10 = this.iPosX;
        n3 = this.lColorsBoxes.get(0).getPosX();
        n9 = this.iPosY;
        n8 = this.iSVHeight;
        n4 = this.lColorsBoxes.get(0).getPosY();
        n5 = ImageManager.getImage(Images.gradient).getHeight();
        n2 = this.getWidth();
        Object object = this.lColorsBoxes;
        ((Image)((Object)list)).draw(spriteBatch, n10 + n3 + n, n9 + n8 + n4 - n5, n2, object.get(object.size() - 1).getHeight(), false, true);
        if (this.iActiveColorID >= 0) {
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
            object = ImageManager.getImage(Images.gradient);
            n8 = this.iPosX;
            n10 = this.lColorsBoxes.get(this.iActiveColorID).getPosX();
            n5 = this.iPosY;
            n4 = this.iSVHeight;
            n2 = this.lColorsBoxes.get(0).getPosY();
            n9 = ImageManager.getImage(Images.gradient).getHeight();
            n3 = this.lColorsBoxes.get(this.iActiveColorID).getWidth();
            list = this.lColorsBoxes;
            ((Image)object).draw(spriteBatch, n8 + n10 + n, n5 + n4 + n2 - n9, n3, list.get(list.size() - 1).getHeight());
        }
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, this.fAlpha));
        n5 = this.iPosX;
        n3 = this.lColorsBoxes.get(0).getPosX();
        n2 = this.iPosY;
        n4 = this.iSVHeight;
        n8 = this.lColorsBoxes.get(0).getPosY();
        n10 = this.getWidth();
        list = this.lColorsBoxes;
        CFG.drawRect(spriteBatch, n5 + n3 + n, n2 + n4 + n8, n10, list.get(list.size() - 1).getHeight());
        spriteBatch.setColor(Color.WHITE);
        n5 = this.activeClose ? Images.btnh_close : Images.btn_close;
        ImageManager.getImage(n5).draw(spriteBatch, this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_close).getWidth() + n, this.getPosY());
    }

    protected final void drawColors(SpriteBatch spriteBatch, int n, int n2) {
        for (int i = this.lColorsBoxes.size() - 1; i >= 0; --i) {
            if (!this.lColorsBoxes.get(i).getVisible()) continue;
            spriteBatch.setColor(this.lColors.get((int)i).r, this.lColors.get((int)i).g, this.lColors.get((int)i).b, this.fAlpha);
            ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n + this.lColorsBoxes.get(i).getPosX(), n2 + this.lColorsBoxes.get(i).getPosY(), this.lColorsBoxes.get(i).getWidth(), this.lColorsBoxes.get(i).getHeight());
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.75f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.lColorsBoxes.get(i).getPosX() + n + this.lColorsBoxes.get(i).getWidth(), this.lColorsBoxes.get(i).getPosY() + n2 - ImageManager.getImage(Images.gradient).getHeight(), 1, this.lColorsBoxes.get(i).getHeight());
        }
    }

    protected final void drawRGBText(SpriteBatch spriteBatch, int n, int n2, int n3, int n4, int n5, String string2, String string3, int n6) {
        spriteBatch.setColor(CFG.COLOR_COLOR_PICKER_RGB_BG);
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, n2, n3, n4, n5);
        if (activeRGB != n && Keyboard.activeColor_RGB_ID != n) {
            spriteBatch.setColor(CFG.COLOR_LOADING_SPLIT);
        } else {
            spriteBatch.setColor(CFG.COLOR_LOADING_SPLIT_ACTIVE);
        }
        CFG.drawRect(spriteBatch, n2, n3, n4, n5);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.25f));
        CFG.drawRect(spriteBatch, n2 - 1, n3 - 1, n4 + 2, n5 + 2);
        spriteBatch.setColor(Color.WHITE);
        n = CFG.PADDING;
        n3 = n5 / 2 + n3;
        CFG.drawText(spriteBatch, string2, n + n2, n3 - CFG.TEXT_HEIGHT / 2, new Color(0.84f, 0.84f, 0.88f, 1.0f));
        CFG.fontMain.getData().setScale(0.9f);
        CFG.drawText(spriteBatch, string3, n2 + n4 - CFG.PADDING - (int)((float)n6 * 0.9f), n3 - CFG.TEXT_HEIGHT / 2, CFG.COLOR_TEXT_RANK);
        CFG.fontMain.getData().setScale(1.0f);
    }

    protected final Color getActiveColor() {
        return this.activeColor;
    }

    protected final int getColorBoxWidth() {
        return CFG.TEXT_HEIGHT + CFG.PADDING * 4;
    }

    protected ColorPicker_AoC_Action getColorPickerAction() {
        return this.ColorPicker_AoC_Action;
    }

    protected final int getHeight() {
        return this.iSVHeight + CFG.TEXT_HEIGHT + CFG.PADDING * 3;
    }

    protected final int getPosX() {
        return this.iPosX;
    }

    protected final int getPosY() {
        return this.iPosY;
    }

    protected final boolean getVisible() {
        return this.visible;
    }

    protected final int getWidth() {
        return this.iSVHeight + this.iHUEWidth + CFG.PADDING + this.iRGBTextWidth + CFG.PADDING * 3;
    }

    protected final void setActiveRGBColor(float f, float f2, float f3) {
        this.setActiveRGBColor((int)(f * 255.0f), (int)(f2 * 255.0f), (int)(f3 * 255.0f));
    }

    protected final void setActiveRGBColor(int n, int n2, int n3) {
        if (CFG.menuManager.getKeyboard().getVisible() || Keyboard.activeColor_RGB_ID >= 0) {
            Keyboard.activeColor_RGB_ID = -1;
            CFG.menuManager.getKeyboard().setVisible(false);
        }
        this.RGBtoHSV(n, n2, n3);
    }

    protected final void setHueWidth(int n) {
        this.iHUEWidth = n;
    }

    protected final void setPosX(int n) {
        int n2;
        if (n > CFG.GAME_WIDTH - ImageManager.getImage(Images.pickerSV).getHeight() / 2) {
            n2 = CFG.GAME_WIDTH - ImageManager.getImage(Images.pickerSV).getHeight() / 2;
        } else {
            n2 = n;
            if (n < CFG.PADDING * 2) {
                n2 = CFG.PADDING * 2;
            }
        }
        this.iPosX = n2;
    }

    protected final void setPosY(int n) {
        int n2;
        if (n > CFG.GAME_HEIGHT - ImageManager.getImage(Images.pickerSV).getHeight() / 2) {
            n2 = CFG.GAME_HEIGHT - ImageManager.getImage(Images.pickerSV).getHeight() / 2;
        } else {
            n2 = n;
            if (n < CFG.PADDING * 2) {
                n2 = CFG.PADDING * 2;
            }
        }
        this.iPosY = n2;
    }

    protected final void setResizeHeight(int n) {
        this.iResizeHeight = n;
    }

    protected final void setSVHeight(int n) {
        int n2;
        if (n < ImageManager.getImage(Images.pickerSV).getHeight()) {
            n2 = ImageManager.getImage(Images.pickerSV).getHeight();
        } else {
            n2 = n;
            if (this.getPosY() + n + CFG.TEXT_HEIGHT + CFG.PADDING * 5 > CFG.GAME_HEIGHT) {
                n2 = CFG.GAME_HEIGHT - this.getPosY() - (CFG.TEXT_HEIGHT + CFG.PADDING * 5);
            }
        }
        this.iSVHeight = n2;
        for (n = 1; n < this.lColorsBoxes.size(); ++n) {
            this.lColorsBoxes.get(n).setWidth(this.lColorsBoxes.get(0).getWidth());
            this.lColorsBoxes.get(n).setVisible(true);
        }
        for (n = this.lColorsBoxes.size() - 1; n > 0; --n) {
            if (this.lColorsBoxes.get(n).getPosX() > this.getWidth()) {
                this.lColorsBoxes.get(n).setVisible(false);
                continue;
            }
            this.lColorsBoxes.get(n).setVisible(true);
            if (this.lColorsBoxes.get(n).getPosX() + this.lColorsBoxes.get(n).getWidth() <= this.getWidth()) continue;
            this.lColorsBoxes.get(n).setWidth(this.getWidth() - this.lColorsBoxes.get(n).getPosX());
        }
    }

    protected final void setVisible(boolean bl, PickerAction pickerAction) {
        if (pickerAction != null) {
            this.updateColorPicker_Action(pickerAction);
        } else {
            this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                @Override
                public void setActiveProvince_Action() {
                }

                @Override
                public void update() {
                }
            };
        }
        this.visible = bl;
        if (!bl && CFG.menuManager.getKeyboard().getVisible()) {
            Keyboard.activeColor_RGB_ID = -1;
            CFG.menuManager.getKeyboard().setVisible(false);
        }
    }

    protected final void touch(int n, int n2) {
        if (this.activeHUE) {
            int n3;
            int n4 = this.iPosY;
            if (n2 <= n4) {
                n3 = n4 + 1;
            } else {
                int n5 = this.iSVHeight;
                n3 = n2;
                if (n2 > n4 + n5) {
                    n3 = n4 + n5;
                }
            }
            if (n < this.iPosX + this.iSVHeight + CFG.PADDING) {
                n = this.iPosX;
                n = this.iSVHeight;
                n = CFG.PADDING;
            } else if (n > this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth) {
                n = this.iPosX;
                n = this.iSVHeight;
                n = CFG.PADDING;
                n = this.iHUEWidth;
            }
            this.updateHUE(n3);
            this.updateSV(this.iPosX + this.iLastSVPosX, this.iPosY + this.iLastSVPosY);
        } else if (this.activeSV) {
            int n6;
            int n7;
            int n8 = this.iPosY;
            if (n2 < n8) {
                n7 = n8;
            } else {
                n6 = this.iSVHeight;
                n7 = n2;
                if (n2 > n8 + n6) {
                    n7 = n8 + n6;
                }
            }
            n8 = this.iPosX;
            if (n < n8) {
                n2 = n8;
            } else {
                n6 = this.iSVHeight;
                n2 = n;
                if (n > n8 + n6) {
                    n2 = n8 + n6;
                }
            }
            this.updateSV(n2, n7);
            this.iLastSVPosX = n2 - this.iPosX;
            this.iLastSVPosY = n7 - this.iPosY;
        } else {
            if (this.activeResize) {
                this.setSVHeight(n2 - this.iPosY - this.iStartPosY);
                return;
            }
            if (this.activeMove) {
                this.setPosX(n - this.iStartPosX);
                this.setPosY(n2 - this.iStartPosY);
                this.fAlpha = 0.75f;
                return;
            }
            int n9 = this.iActiveColorID;
            int n10 = 0;
            if (n9 >= 0) {
                for (n2 = n10; n2 < this.lColorsBoxes.size(); ++n2) {
                    if (!this.lColorsBoxes.get(n2).getVisible() || n < this.iPosX + this.lColorsBoxes.get(n2).getPosX() || n > this.iPosX + this.lColorsBoxes.get(n2).getPosX() + this.lColorsBoxes.get(n2).getWidth()) continue;
                    this.iActiveColorID = n2;
                    if ((int)(this.activeColor.r * 255.0f) != (int)(this.lColors.get((int)n2).r * 255.0f) && (int)(this.activeColor.r * 255.0f) != (int)(this.lColors.get((int)n2).g * 255.0f) && (int)(this.activeColor.r * 255.0f) != (int)(this.lColors.get((int)n2).b * 255.0f)) {
                        this.RGBtoHSV((int)(this.lColors.get((int)n2).r * 255.0f), (int)(this.lColors.get((int)n2).g * 255.0f), (int)(this.lColors.get((int)n2).b * 255.0f));
                    }
                    break;
                }
            } else if (activeRGB >= 0) {
                this.setActiveRGB_Box(n, n2);
            } else if (this.activeClose) {
                this.iLastSVPosX = n;
                this.iLastSVPosY = n2;
            } else {
                int n11 = this.iPosX;
                n10 = this.iSVHeight;
                n9 = this.iResizeHeight;
                if (n >= n11 + n10 - n9 && n <= n11 + n10 && n2 >= (n11 = this.iPosY) + n10 - n9 && n2 <= n11 + n10) {
                    this.activeResize = true;
                    this.iStartPosY = n2 - n11 - n10;
                    this.iStartResizeHeight = n10;
                    this.fAlpha = 0.75f;
                    return;
                }
                n9 = this.iPosX;
                if (n >= n9 && n <= n9 + (n11 = this.iResizeHeight) && n2 >= (n10 = this.iPosY) && n2 <= n11 + n10) {
                    this.activeMove = true;
                    this.iStartPosX = n - n9;
                    this.iStartPosY = n2 - n10;
                    return;
                }
                if (n >= this.iPosX + this.iSVHeight + CFG.PADDING && n <= this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth && n2 >= (n10 = this.iPosY) && n2 <= n10 + this.iSVHeight) {
                    this.updateHUE(n2);
                    this.updateSV(this.iPosX + this.iLastSVPosX, this.iPosY + this.iLastSVPosY);
                    this.activeHUE = true;
                    Keyboard.activeColor_RGB_ID = -1;
                    CFG.menuManager.getKeyboard().setVisible(false);
                } else {
                    n9 = this.iPosX;
                    if (n >= n9 && n <= n9 + (n10 = this.iSVHeight) && n2 >= (n9 = this.iPosY) && n2 <= n9 + n10) {
                        this.updateSV(n, n2);
                        this.activeSV = true;
                        this.iLastSVPosX = n - this.iPosX;
                        this.iLastSVPosY = n2 - this.iPosY;
                        Keyboard.activeColor_RGB_ID = -1;
                        CFG.menuManager.getKeyboard().setVisible(false);
                    } else if (n >= this.iPosX + this.lColorsBoxes.get(0).getPosX() && n <= this.iPosX + this.getWidth() && n2 >= this.iPosY + this.iSVHeight + this.lColorsBoxes.get(0).getPosY() && n2 <= this.iPosY + this.iSVHeight + this.lColorsBoxes.get(0).getPosY() + this.lColorsBoxes.get(0).getHeight()) {
                        for (n10 = 0; n10 < this.lColorsBoxes.size(); ++n10) {
                            if (!this.lColorsBoxes.get(n10).getVisible() || n < this.iPosX + this.lColorsBoxes.get(n10).getPosX() || n > this.iPosX + this.lColorsBoxes.get(n10).getPosX() + this.lColorsBoxes.get(n10).getWidth() || n2 < this.iPosY + this.iSVHeight + this.lColorsBoxes.get(n10).getPosY() || n2 > this.iPosY + this.iSVHeight + this.lColorsBoxes.get(n10).getPosY() + this.lColorsBoxes.get(n10).getHeight()) continue;
                            this.iActiveColorID = n10;
                            if ((int)(this.activeColor.r * 255.0f) == (int)(this.lColors.get((int)n10).r * 255.0f) || (int)(this.activeColor.r * 255.0f) == (int)(this.lColors.get((int)n10).g * 255.0f) || (int)(this.activeColor.r * 255.0f) == (int)(this.lColors.get((int)n10).b * 255.0f)) break;
                            this.RGBtoHSV((int)(this.lColors.get((int)n10).r * 255.0f), (int)(this.lColors.get((int)n10).g * 255.0f), (int)(this.lColors.get((int)n10).b * 255.0f));
                            break;
                        }
                        Keyboard.activeColor_RGB_ID = -1;
                        CFG.menuManager.getKeyboard().setVisible(false);
                    } else if (n >= this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth + CFG.PADDING + this.lRGBBoxes.get(0).getPosX() && n <= this.iPosX + this.iSVHeight + CFG.PADDING + this.iHUEWidth + CFG.PADDING + this.lRGBBoxes.get(0).getPosX() + this.lRGBBoxes.get(0).getWidth() && n2 >= this.iPosY + this.lRGBBoxes.get(0).getPosY() && n2 <= this.iPosY + this.lRGBBoxes.get(2).getPosY() + this.lRGBBoxes.get(2).getHeight()) {
                        activeRGB = 0;
                        this.setActiveRGB_Box(n, n2);
                        Keyboard.activeColor_RGB_ID = -1;
                        CFG.menuManager.getKeyboard().setVisible(false);
                    } else if (n >= this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_close).getWidth() && n <= this.getPosX() + this.getWidth() && n2 >= (n = this.iPosY) && n2 <= n + ImageManager.getImage(Images.btn_close).getHeight()) {
                        this.activeClose = true;
                    }
                }
            }
        }
        this.ColorPicker_AoC_Action.update();
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     */
    protected final void touchUp() {
        int n;
        float f;
        int n2;
        if (this.activeResize) {
            int n3 = this.iLastSVPosX;
            n2 = this.iSVHeight;
            f = n3 * n2;
            n3 = this.iStartResizeHeight;
            this.iLastSVPosX = (int)(f / (float)n3);
            this.iLastSVPosY = (int)((float)(this.iLastSVPosY * n2) / (float)n3);
            this.iLastHUEPosY = (int)((float)(this.iLastHUEPosY * n2) / (float)n3);
        } else if (this.activeClose && this.iLastSVPosX >= this.getPosX() + this.getWidth() - ImageManager.getImage(Images.btn_close).getWidth() && this.iLastSVPosX <= this.getPosX() + this.getWidth() && (n = this.iLastSVPosY) >= (n2 = this.iPosY) && n <= n2 + ImageManager.getImage(Images.btn_close).getHeight()) {
            this.setVisible(false, null);
        }
        this.activeSV = false;
        this.activeHUE = false;
        this.activeResize = false;
        this.activeMove = false;
        this.activeClose = false;
        this.iActiveColorID = -1;
        n2 = activeRGB;
        if (n2 >= 0) {
            void var4_6;
            Keyboard.activeColor_RGB_ID = n2;
            n2 = activeRGB;
            if (n2 == 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("R: ");
                f = this.activeColor.r;
            } else if (n2 == 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("G: ");
                f = this.activeColor.g;
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("B: ");
                f = this.activeColor.b;
            }
            var4_6.append((int)(f * 255.0f));
            String string2 = var4_6.toString();
            CFG.showKeyboard_ColorPickerRGB(string2);
            activeRGB = -1;
        }
        this.fAlpha = 1.0f;
    }

    protected final void updateColorPicker_Action(PickerAction pickerAction) {
        switch (31.$SwitchMap$age$of$civilizations2$jakowski$lukasz$ColorPicker_AoC$PickerAction[pickerAction.ordinal()]) {
            default: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                    }
                };
                break;
            }
            case 28: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.flagManager.flagEdit.lOverlays.get((int)CFG.EDIT_ALLIANCE_NAMES_BUNDLE_ID).oColor.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.flagManager.flagEdit.lOverlays.get((int)CFG.EDIT_ALLIANCE_NAMES_BUNDLE_ID).oColor.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.flagManager.flagEdit.lOverlays.get((int)CFG.EDIT_ALLIANCE_NAMES_BUNDLE_ID).oColor.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 27: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.flagManager.flagEdit.lDivisionColors.get(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.flagManager.flagEdit.lDivisionColors.get(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.flagManager.flagEdit.lDivisionColors.get(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 26: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editorCivilization_GameData.sr_GameData.getColor(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.editorCivilization_GameData.sr_GameData.getColor(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.editorCivilization_GameData.sr_GameData.getColor(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID).setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 25: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editorCivilization_GameData.setR((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r * 255.0f));
                        CFG.editorCivilization_GameData.setG((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g * 255.0f));
                        CFG.editorCivilization_GameData.setB((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b * 255.0f));
                    }
                };
                break;
            }
            case 24: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editorServiceRibbon_Colors.set(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID, new Color(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b, 1.0f));
                    }
                };
                break;
            }
            case 23: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editorTerrain_Data2.setColor(new Color_GameData(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b));
                    }
                };
                break;
            }
            case 22: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_POSITIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 21: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEGATIVE[CFG.MANAGE_DIPLOMACY_CUSTOMIZE_RELATIONS_CIV_ID].setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 20: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.settingsManager.COLOR_PROVINCE_DISCOVERY.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.settingsManager.COLOR_PROVINCE_DISCOVERY.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.settingsManager.COLOR_PROVINCE_DISCOVERY.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 19: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.settingsManager.COLOR_PROVINCE_BG_WASTELAND.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.settingsManager.COLOR_PROVINCE_BG_WASTELAND.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.settingsManager.COLOR_PROVINCE_BG_WASTELAND.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 18: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.settingsManager.civNamesFontColorBorder.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.settingsManager.civNamesFontColorBorder.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.settingsManager.civNamesFontColorBorder.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                        CFG.loadFontBorder();
                    }
                };
                break;
            }
            case 17: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.settingsManager.civNamesFontColor.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.settingsManager.civNamesFontColor.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.settingsManager.civNamesFontColor.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                        CFG.loadFontBorder();
                    }
                };
                break;
            }
            case 16: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_NEUTRAL.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 15: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_DEFENSIVE_PACT.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_DEFENSIVE_PACT.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_DEFENSIVE_PACT.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 14: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_MILITARY_ACCESS.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_MILITARY_ACCESS.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_MILITARY_ACCESS.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 13: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_INDEPENDENCE.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_INDEPENDENCE.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_INDEPENDENCE.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 12: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT_MAX.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 11: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_PACT.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 10: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_VASSAL.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_VASSAL.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_VASSAL.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 9: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_AT_WAR.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 8: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_ALLIANCE.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 7: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.diplomacyColors_GameData.COLOR_DIPLOMACY_OWN_PROVINCES.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 6: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                        CFG.menuManager.getColorPicker().setActiveRGBColor(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getR(), CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getG(), CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getB());
                        CFG.menuManager.getColorPicker().updateColors();
                    }

                    @Override
                    public void update() {
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r * 255.0f));
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g * 255.0f));
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b * 255.0f));
                        if (CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID() > 0) {
                            CFG.editorPalletOfCivsColors_Data.setCivColor(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getCivTag(), new Color_GameData(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b));
                        }
                    }
                };
                break;
            }
            case 5: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editor_Region_GameData.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.editor_Region_GameData.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.editor_Region_GameData.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 4: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.editor_Continent_GameData.setR(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r);
                        CFG.editor_Continent_GameData.setG(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g);
                        CFG.editor_Continent_GameData.setB(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b);
                    }
                };
                break;
            }
            case 3: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                        if (ColorPicker_AoC.this.getVisible() && CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getAllianceID() > 0 && CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getAllianceID() != CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID) {
                            CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID = CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getAllianceID();
                            CFG.menuManager.getColorPicker().setActiveRGBColor(CFG.game.getAlliance(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID).getColorOfAlliance().getR(), CFG.game.getAlliance(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID).getColorOfAlliance().getG(), CFG.game.getAlliance(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID).getColorOfAlliance().getB());
                        }
                    }

                    @Override
                    public void update() {
                        CFG.game.getAlliance(CFG.MANAGE_DIPLOMACY_CUSTOMIZE_ALLIANCE_ID).setColorOfAlliance(new Color_GameData(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b));
                    }
                };
                break;
            }
            case 2: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                    }

                    @Override
                    public void update() {
                        CFG.createVassal_Data.oColor = new Color(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g, ((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b, 1.0f);
                    }
                };
                break;
            }
            case 1: {
                this.ColorPicker_AoC_Action = new ColorPicker_AoC_Action(){

                    @Override
                    public void setActiveProvince_Action() {
                        CFG.menuManager.getColorPicker().setActiveRGBColor(CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getR(), CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getG(), CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).getB());
                        CFG.menuManager.getColorPicker().updateColors();
                    }

                    @Override
                    public void update() {
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setR((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.r * 255.0f));
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setG((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.g * 255.0f));
                        CFG.game.getCiv(CFG.game.getProvince(CFG.game.getActiveProvinceID()).getCivID()).setB((int)(((ColorPicker_AoC)ColorPicker_AoC.this).activeColor.b * 255.0f));
                    }
                };
            }
        }
    }

    protected final void updateColors() {
        this.lColors.set(0, new Color(this.activeColor.r, this.activeColor.g, this.activeColor.b, 1.0f));
        for (int i = 1; i < this.lColors.size(); ++i) {
            this.lColors.set(i, new Color((float)CFG.oR.nextInt(256) / 255.0f, (float)CFG.oR.nextInt(256) / 255.0f, (float)CFG.oR.nextInt(256) / 255.0f, 1.0f));
        }
    }

    protected final void updateRGBWidth() {
        Object object = CFG.glyphLayout;
        Object object2 = CFG.fontMain;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((int)(this.activeColor.r * 255.0f));
        ((GlyphLayout)object).setText((BitmapFont)object2, stringBuilder.toString());
        this.iRTextWidth = (int)CFG.glyphLayout.width;
        object2 = CFG.glyphLayout;
        object = CFG.fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((int)(this.activeColor.g * 255.0f));
        ((GlyphLayout)object2).setText((BitmapFont)object, stringBuilder.toString());
        this.iGTextWidth = (int)CFG.glyphLayout.width;
        object = CFG.glyphLayout;
        object2 = CFG.fontMain;
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append((int)(this.activeColor.b * 255.0f));
        ((GlyphLayout)object).setText((BitmapFont)object2, stringBuilder.toString());
        this.iBTextWidth = (int)CFG.glyphLayout.width;
    }

    class Box {
        private int iHeight;
        private int iPosX;
        private int iPosY;
        private int iWidth;
        private boolean visible = true;

        protected Box(int n, int n2, int n3, int n4) {
            this.iPosX = n;
            this.iPosY = n2;
            this.iWidth = n3;
            this.iHeight = n4;
        }

        protected final int getHeight() {
            return this.iHeight;
        }

        protected final int getPosX() {
            return this.iPosX;
        }

        protected final int getPosY() {
            return this.iPosY;
        }

        protected final boolean getVisible() {
            return this.visible;
        }

        protected final int getWidth() {
            return this.iWidth;
        }

        protected final void setHeight(int n) {
            this.iHeight = n;
        }

        protected final void setPosX(int n) {
            this.iPosX = n;
        }

        protected final void setPosY(int n) {
            this.iPosY = n;
        }

        protected final void setVisible(boolean bl) {
            this.visible = bl;
        }

        protected final void setWidth(int n) {
            this.iWidth = n;
        }
    }

    public static enum PickerAction {
        ACTIVE_CIVILIZATION_COLOR,
        CUSTOMIZE_ALLIANCE_COLOR,
        MAP_EDITOR_CONTINENT_COLOR,
        MAP_EDITOR_REGION_COLOR,
        CREATE_VASSAL_COLOR,
        COLOR_DIPLOMACY_OWN_PROVINCES,
        COLOR_DIPLOMACY_ALLIANCE,
        COLOR_DIPLOMACY_AT_WAR,
        COLOR_DIPLOMACY_VASSAL,
        COLOR_DIPLOMACY_PACT,
        COLOR_DIPLOMACY_PACT_MAX,
        COLOR_DIPLOMACY_INDEPENDENCE,
        COLOR_DIPLOMACY_NEGATIVE,
        COLOR_DIPLOMACY_POSITIVE,
        COLOR_DIPLOMACY_NEUTRAL,
        COLOR_DIPLOMACY_MILITARY_ACCESS,
        COLOR_DIPLOMACY_DEFENSIVE_PACT,
        EDITOR_RELIGION_COLOR,
        PALLET_OF_COLORS,
        CIV_NAMES_OVER_PROVINCES,
        CIV_NAMES_OVER_PROVINCES_BORDER,
        PROVINCE_SETTINGS_WASTELAND_COLOR,
        PROVINCE_SETTINGS_DISCOVERY_COLOR,
        EDITOR_TERRAIN_COLOR,
        EDITOR_SERVICE_RIBBON_OVERLAY,
        EDITOR_CIV_GAME_COLOR,
        EDITOR_CIV_GAME_COLOR_SR,
        EDITOR_CIV_FLAG_DIVISION_COLOR,
        EDITOR_CIV_FLAG_OVERLAY_COLOR,
        MAP_EDITOR_TRADE_ZONES;

    }
}

