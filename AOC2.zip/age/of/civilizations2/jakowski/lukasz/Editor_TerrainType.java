/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.Editor;
import age.of.civilizations2.jakowski.lukasz.Game;
import age.of.civilizations2.jakowski.lukasz.UndoTerrain;
import com.badlogic.gdx.Gdx;
import java.util.ArrayList;
import java.util.List;

class Editor_TerrainType
extends Editor {
    protected static int currentTerrainTypeID = 1;
    protected static List<UndoTerrain> lUndo;

    public Editor_TerrainType() {
        lUndo = new ArrayList<UndoTerrain>();
    }

    protected static final void actionSave(boolean bl) {
        if (CFG.game.getActiveProvinceID() >= 0 && !CFG.game.getProvince(CFG.game.getActiveProvinceID()).getSeaProvince()) {
            if (bl) {
                Editor_TerrainType.addUndo(CFG.game.getActiveProvinceID());
            }
            CFG.game.getProvince(CFG.game.getActiveProvinceID()).setTerrainTypeID(currentTerrainTypeID);
            CFG.game.saveProvince_Info_GameData(CFG.game.getActiveProvinceID());
        }
    }

    private static final void addUndo(int n) {
        if (n < 0) {
            return;
        }
        if (lUndo.size() > 0) {
            List<UndoTerrain> list = lUndo;
            if (list.get((int)(list.size() - 1)).iProvinceID != n && currentTerrainTypeID != CFG.game.getProvince(n).getTerrainTypeID()) {
                if (lUndo.size() > 50) {
                    lUndo.remove(0);
                    lUndo.add(new UndoTerrain(n, CFG.game.getProvince(n).getTerrainTypeID()));
                } else {
                    lUndo.add(new UndoTerrain(n, CFG.game.getProvince(n).getTerrainTypeID()));
                }
            }
        } else if (currentTerrainTypeID != CFG.game.getProvince(n).getTerrainTypeID()) {
            lUndo.add(new UndoTerrain(n, CFG.game.getProvince(n).getTerrainTypeID()));
        }
    }

    protected static void popUndo() {
        if (lUndo.size() > 0) {
            List<UndoTerrain> list = CFG.game;
            List<UndoTerrain> list2 = lUndo;
            ((Game)((Object)list)).setActiveProvinceID(list2.get((int)(list2.size() - 1)).iProvinceID);
            list = lUndo;
            currentTerrainTypeID = ((UndoTerrain)list.get((int)(list.size() - 1))).iTerrainID;
            Editor_TerrainType.actionSave(false);
            if (!CFG.game.getProvince(CFG.game.getActiveProvinceID()).getDrawProvince()) {
                CFG.map.getMapCoordinates().centerToProvinceID(CFG.game.getActiveProvinceID());
            }
            list = lUndo;
            list.remove(list.size() - 1);
        }
    }

    @Override
    protected void keyDown(int n) {
        if (Gdx.input.isKeyPressed(21) && --currentTerrainTypeID < 1) {
            currentTerrainTypeID = CFG.terrainTypesManager.getTerrainsSize() - 1;
        }
        if (Gdx.input.isKeyPressed(22) && ++currentTerrainTypeID > CFG.terrainTypesManager.getTerrainsSize() - 1) {
            currentTerrainTypeID = 1;
        }
        if (Gdx.input.isKeyPressed(62)) {
            Editor_TerrainType.actionSave(true);
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TERRAIN: ");
        stringBuilder.append(CFG.terrainTypesManager.getName(currentTerrainTypeID));
        return stringBuilder.toString();
    }
}

