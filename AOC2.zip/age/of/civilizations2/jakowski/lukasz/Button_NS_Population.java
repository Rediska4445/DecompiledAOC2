/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.Button_Diplomacy;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

class Button_NS_Population
extends Button {
    protected static final float FONTSIZE = 0.7f;
    protected static final float FONTSIZE2 = 0.65f;
    protected static final float TEXT_COST_SCALE = 0.7f;
    protected static final float TEXT_MOVEMENT_COST_SCALE = 0.7f;
    protected boolean backAnimation = false;
    protected float fAlphaMod = 0.0f;
    private int iCivID = 0;
    private int iDeathsTEXTWidth;
    private int iDeathsWidth;
    protected int iImageID;
    protected long lTime = 0L;
    protected Color oColor;
    protected boolean row = false;
    private String sDeaths;
    private String sDeathsTEXT;
    protected Color textColor;

    protected Button_NS_Population(Color color2, String string2, int n, String string3, String string4, int n2, Color color3, int n3, int n4, int n5) {
        super.init(string2, 0, n3, n4, n5, CFG.BUTTON_HEIGHT * 4 / 5, true, true, false, false);
        this.iCivID = n;
        this.oColor = color2;
        this.iImageID = n2;
        this.textColor = color3;
        this.sDeaths = string4;
        CFG.glyphLayout.setText(CFG.fontMain, this.sDeaths);
        this.iDeathsWidth = (int)(CFG.glyphLayout.width * 0.65f);
        this.sDeathsTEXT = string3;
        CFG.glyphLayout.setText(CFG.fontMain, this.sDeathsTEXT);
        this.iDeathsTEXTWidth = (int)(CFG.glyphLayout.width * 0.65f);
    }

    @Override
    protected Button.Checkbox buildCheckbox() {
        if (this.checkbox) {
            return new Button.Checkbox(){

                @Override
                public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
                    if (Button_NS_Population.this.getCheckboxState()) {
                        spriteBatch.setColor(new Color(CFG.COLOR_TEXT_MODIFIER_POSITIVE.r, CFG.COLOR_TEXT_MODIFIER_POSITIVE.g, CFG.COLOR_TEXT_MODIFIER_POSITIVE.b, 0.2f));
                        ImageManager.getImage(Images.patt_square).draw2(spriteBatch, Button_NS_Population.this.getPosX() + n, Button_NS_Population.this.getPosY() - ImageManager.getImage(Images.patt_square).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_NS_Population.this.getHeight() - 2, true, false);
                        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.3f));
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_NS_Population.this.getPosX() + n, Button_NS_Population.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + 1 + n2, Button_Diplomacy.iDiploWidth, Button_NS_Population.this.getHeight() / 4, false, false);
                        ImageManager.getImage(Images.gradient).draw(spriteBatch, Button_NS_Population.this.getPosX() + n, Button_NS_Population.this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + Button_NS_Population.this.getHeight() - 1 + n2 - Button_NS_Population.this.getHeight() / 4, Button_Diplomacy.iDiploWidth, Button_NS_Population.this.getHeight() / 4, false, true);
                        spriteBatch.setColor(Color.WHITE);
                    }
                }
            };
        }
        return new Button.Checkbox(){

            @Override
            public void drawCheckBox(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
            }
        };
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(this.oColor.r, this.oColor.g, this.oColor.b, 0.1f));
        ImageManager.getImage(Images.pix255_255_255).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.pix255_255_255).getHeight() + n2, Button_Diplomacy.iDiploWidth, this.getHeight());
        spriteBatch.setColor(new Color(this.oColor.r, this.oColor.g, this.oColor.b, 0.575f));
        ImageManager.getImage(Images.patt_square).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.patt_square).getHeight() + n2, Button_Diplomacy.iDiploWidth, this.getHeight(), true, false);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.45f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth - CFG.PADDING * 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, CFG.PADDING * 2, this.getHeight(), false, false);
        spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_TITLE_BLUE.r, CFG.COLOR_GRADIENT_TITLE_BLUE.g, CFG.COLOR_GRADIENT_TITLE_BLUE.b, 0.35f));
        ImageManager.getImage(Images.line_32_vertical).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth + n, this.getPosY() - ImageManager.getImage(Images.line_32_vertical).getHeight() + n2, 1, this.getHeight());
        if (this.row) {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.4f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_INFO_BOX_GRADIENT.r, CFG.COLOR_INFO_BOX_GRADIENT.g, CFG.COLOR_INFO_BOX_GRADIENT.b, 0.35f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.6f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.35f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        } else {
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.6f));
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight());
            ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DARK_BLUE.r, CFG.COLOR_GRADIENT_DARK_BLUE.g, CFG.COLOR_GRADIENT_DARK_BLUE.b, 0.45f));
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4);
            ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, false, true);
            spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.85f));
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            ImageManager.getImage(Images.line_32_off1).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.line_32_off1).getHeight() + n2, this.getWidth(), 1);
            if (bl || this.getIsHovered()) {
                spriteBatch.setColor(new Color(CFG.COLOR_GRADIENT_DIPLOMACY.r, CFG.COLOR_GRADIENT_DIPLOMACY.g, CFG.COLOR_GRADIENT_DIPLOMACY.b, 0.45f));
                ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight() - 2, true, false);
            }
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (this.getIsHovered()) {
            if (this.lTime < System.currentTimeMillis() - 30L) {
                if (this.backAnimation) {
                    this.fAlphaMod -= 0.02f;
                    if (this.fAlphaMod < 0.0f) {
                        this.backAnimation = false;
                    }
                } else {
                    this.fAlphaMod += 0.02f;
                    if (this.fAlphaMod > 0.4f) {
                        this.backAnimation = true;
                    }
                }
                this.lTime = System.currentTimeMillis();
            }
            spriteBatch.setColor(new Color(1.0f, 1.0f, 1.0f, 1.0f - this.fAlphaMod));
            CFG.setRender_3(true);
        } else {
            this.backAnimation = false;
            this.fAlphaMod = 0.0f;
            this.lTime = System.currentTimeMillis();
        }
        if (this.iCivID >= 0) {
            CFG.game.getCiv(this.iCivID).getFlag().draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 - CFG.game.getCiv(this.iCivID).getFlag().getHeight() + n2, CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        } else {
            ImageManager.getImage(Images.randomCivilizationFlag).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2 - ImageManager.getImage(Images.randomCivilizationFlag).getHeight(), CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        }
        ImageManager.getImage(Images.flag_rect).draw(spriteBatch, this.getPosX() + Button_Diplomacy.iDiploWidth / 2 - CFG.CIV_FLAG_WIDTH / 2 + n, this.getPosY() + this.getHeight() / 2 - CFG.CIV_FLAG_HEIGHT / 2 + n2 - ImageManager.getImage(Images.flag_rect).getHeight(), CFG.CIV_FLAG_WIDTH, CFG.CIV_FLAG_HEIGHT);
        spriteBatch.setColor(Color.WHITE);
        ImageManager.getImage(this.iImageID).draw(spriteBatch, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iDeathsWidth + this.iDeathsTEXTWidth + CFG.PADDING + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + (int)((float)this.getTextHeight() * 0.65f) / 2 - (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale(this.iImageID, 0.65f)) / 2 - ImageManager.getImage(this.iImageID).getHeight() + n2, (int)((float)ImageManager.getImage(this.iImageID).getWidth() * this.getImageScale(this.iImageID, 0.65f)), (int)((float)ImageManager.getImage(this.iImageID).getHeight() * this.getImageScale(this.iImageID, 0.65f)));
        CFG.fontMain.getData().setScale(0.7f);
        CFG.drawTextWithShadow(spriteBatch, this.getText(), this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.7f) - CFG.PADDING / 2 + n2, this.getColor(bl));
        CFG.fontMain.getData().setScale(0.65f);
        CFG.drawTextWithShadow(spriteBatch, this.sDeathsTEXT, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, CFG.COLOR_TEXT_OPTIONS_NS_HOVER);
        CFG.drawTextWithShadow(spriteBatch, this.sDeaths, this.getPosX() + CFG.PADDING + Button_Diplomacy.iDiploWidth + this.iDeathsTEXTWidth + n, this.getPosY() + this.getHeight() / 2 + CFG.PADDING / 2 + n2, this.textColor);
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_TEXT_OPTIONS_NS_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_TEXT_OPTIONS_NS_HOVER : CFG.COLOR_TEXT_OPTIONS_NS) : new Color(CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.r, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.g, CFG.COLOR_TEXT_MODIFIER_NEGATIVE2.b, 0.525f));
        return color2;
    }

    protected float getImageScale(int n, float f) {
        return (float)CFG.TEXT_HEIGHT * f / (float)ImageManager.getImage(n).getHeight();
    }

    @Override
    protected void setCurrent(int n) {
        boolean bl = true;
        if (n != 1) {
            bl = false;
        }
        this.row = bl;
    }
}

