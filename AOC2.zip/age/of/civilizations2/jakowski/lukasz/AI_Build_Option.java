/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.AI_Build;
import age.of.civilizations2.jakowski.lukasz.AI_Build_Farm;
import age.of.civilizations2.jakowski.lukasz.AI_Style;
import age.of.civilizations2.jakowski.lukasz.BuildingsManager;
import age.of.civilizations2.jakowski.lukasz.CFG;

class AI_Build_Option {
    AI_Build_Option() {
    }

    protected AI_Build getData(int n) {
        return new AI_Build_Farm(n, this.getMoney(n));
    }

    protected long getMoney(int n) {
        if (CFG.game.getCiv(n).getMoney() < AI_Style.getMoney_MinReserve(n)) {
            return 0L;
        }
        return CFG.game.getCiv(n).getMoney() - AI_Style.getMoney_MinReserve(n);
    }

    protected float getScore(int n) {
        return CFG.game.getCiv((int)n).civGameData.civPersonality.BUILD_FARM * (1.0f - (float)(CFG.game.getCiv((int)n).iNumOf_Farms / Math.max(CFG.game.getCiv((int)n).iNumOf_Farms_ProvincesPossibleToBuild * BuildingsManager.getFarm_MaxLevel(), 1)));
    }
}

