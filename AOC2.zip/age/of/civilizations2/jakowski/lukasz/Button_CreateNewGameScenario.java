/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_CreateNewGameScenario
extends Button {
    protected static final float FONT_SCALE = 0.8f;

    protected Button_CreateNewGameScenario(String string2, int n, int n2, int n3, int n4) {
        super.init(string2, n, n2, n3, n4, ImageManager.getImage(Images.new_game_top).getHeight() - CFG.PADDING * 2, true, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        if (!bl && !this.getIsHovered()) {
            int n3 = Images.new_game_top_edge;
            ImageManager.getImage(n3).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(n3).getHeight() + n2, this.getWidth() / 2, this.getHeight() - ImageManager.getImage(n3).getHeight(), false, false);
            ImageManager.getImage(n3).draw2(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(n3).getHeight() + n2, this.getWidth() / 2, this.getHeight() - ImageManager.getImage(n3).getHeight(), true, false);
            ImageManager.getImage(n3).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(n3).getHeight() - ImageManager.getImage(n3).getHeight() + n2, this.getWidth() / 2, ImageManager.getImage(n3).getHeight(), false, true);
            ImageManager.getImage(n3).draw2(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() - ImageManager.getImage(n3).getHeight() - ImageManager.getImage(n3).getHeight() + n2, this.getWidth() / 2, ImageManager.getImage(n3).getHeight(), true, true);
        } else {
            spriteBatch.setColor(new Color(0.925f, 0.925f, 1.0f, 0.975f));
            int n4 = Images.new_game_top_edge;
            ImageManager.getImage(n4).draw2(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(n4).getHeight() + n2, this.getWidth() / 2, this.getHeight() - ImageManager.getImage(n4).getHeight(), false, false);
            ImageManager.getImage(n4).draw2(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(n4).getHeight() + n2, this.getWidth() / 2, this.getHeight() - ImageManager.getImage(n4).getHeight(), true, false);
            ImageManager.getImage(n4).draw2(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - ImageManager.getImage(n4).getHeight() - ImageManager.getImage(n4).getHeight() + n2, this.getWidth() / 2, ImageManager.getImage(n4).getHeight(), false, true);
            ImageManager.getImage(n4).draw2(spriteBatch, this.getPosX() + this.getWidth() / 2 + n, this.getPosY() + this.getHeight() - ImageManager.getImage(n4).getHeight() - ImageManager.getImage(n4).getHeight() + n2, this.getWidth() / 2, ImageManager.getImage(n4).getHeight(), true, true);
        }
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.8f);
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + (int)((float)this.getWidth() / 2.0f - (float)this.getTextWidth() * 0.8f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f) / 2 + n2, this.getColor(bl));
        } else {
            CFG.drawTextWithShadow(spriteBatch, this.getTextToDraw(), this.getPosX() + (int)((float)this.getWidth() / 2.0f - (float)this.getTextWidth() * 0.8f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)CFG.TEXT_HEIGHT * 0.8f) / 2 + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? CFG.COLOR_BUTTON_GAME_TEXT_ACTIVE : (this.getClickable() ? (this.getIsHovered() ? CFG.COLOR_BUTTON_GAME_TEXT_HOVERED : CFG.COLOR_TEXT_CNG_TOP_SCENARIO_INFO) : new Color(0.78f, 0.78f, 0.78f, 0.7f));
        return color2;
    }
}

