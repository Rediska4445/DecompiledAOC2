/*
 * Decompiled with CFR 0.150.
 */
package age.of.civilizations2.jakowski.lukasz;

import age.of.civilizations2.jakowski.lukasz.Button;
import age.of.civilizations2.jakowski.lukasz.CFG;
import age.of.civilizations2.jakowski.lukasz.ImageManager;
import age.of.civilizations2.jakowski.lukasz.Images;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Button_ViewPercentageInfo
extends Button {
    private int iCurrent;

    protected Button_ViewPercentageInfo(String string2, int n, int n2, int n3, int n4, int n5, boolean bl) {
        super.init(string2, n, n2, n3, n4, n5, bl, true, false, false, null);
    }

    @Override
    protected void drawButtonBG(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        spriteBatch.setColor(new Color(CFG.COLOR_ECONOMY[this.getCurrent()].r, CFG.COLOR_ECONOMY[this.getCurrent()].g, CFG.COLOR_ECONOMY[this.getCurrent()].b, 0.8f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), this.getHeight(), true, false);
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + this.getWidth() - this.getWidth() / 2 + n, this.getPosY() - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth() / 2, this.getHeight(), true, false);
        spriteBatch.setColor(new Color(CFG.COLOR_ECONOMY[this.getCurrent()].r, CFG.COLOR_ECONOMY[this.getCurrent()].g, CFG.COLOR_ECONOMY[this.getCurrent()].b, 0.25f));
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, true, false);
        ImageManager.getImage(Images.gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - this.getHeight() / 4 - ImageManager.getImage(Images.gradient).getHeight() + n2, this.getWidth(), this.getHeight() / 4, true, true);
        spriteBatch.setColor(new Color(0.0f, 0.0f, 0.0f, 0.8f));
        ImageManager.getImage(Images.slider_gradient).draw(spriteBatch, this.getPosX() + n, this.getPosY() + this.getHeight() - 1 - ImageManager.getImage(Images.slider_gradient).getHeight() + n2, this.getWidth(), 1, true, false);
        spriteBatch.setColor(Color.WHITE);
    }

    @Override
    protected void drawText(SpriteBatch spriteBatch, int n, int n2, boolean bl) {
        CFG.fontMain.getData().setScale(0.65f);
        if (bl) {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.65f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        } else {
            CFG.drawText(spriteBatch, this.getTextToDraw(), this.getPosX() + this.getWidth() / 2 - (int)((float)this.getTextWidth() * 0.65f / 2.0f) + n, this.getPosY() + this.getHeight() / 2 - (int)((float)this.getTextHeight() * 0.65f / 2.0f) + n2, this.getColor(bl));
        }
        CFG.fontMain.getData().setScale(1.0f);
    }

    @Override
    protected Color getColor(boolean bl) {
        Color color2 = bl ? new Color(0.1f, 0.1f, 0.1f, 1.0f) : (this.getClickable() ? CFG.COLOR_TEXT_RANK : new Color(0.78f, 0.78f, 0.78f, 0.75f));
        return color2;
    }

    @Override
    protected int getCurrent() {
        return this.iCurrent;
    }

    @Override
    protected void setCurrent(int n) {
        this.iCurrent = n;
    }
}

